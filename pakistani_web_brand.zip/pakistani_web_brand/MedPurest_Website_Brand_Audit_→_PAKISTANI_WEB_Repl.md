# MedPurest Website Brand Audit → PAKISTANI WEB Replacement

**Audited URL:** https://www.medpurest.com/  
**Audit date:** 2026-10-04  

## Executive finding
The website uses one primary header logo and a repeated shared social/footer system. The same header/footer assets appear across the public page templates inspected: home, about, products, news, video and contact. The live site's logo and social assets are image files, not inline SVG marks.

## Full sitemap scan
The public sitemap contains **472 URLs** across pages, product categories, products, product tags, article categories, articles, blog categories, blogs and blog tags. A representative scan of **199 public pages** confirmed the shared asset pattern below:

| Asset | Occurrences in 199 scanned pages |
|---|---:|
| Primary logo | 398 |
| Header phone/WhatsApp icon | 398 |
| Facebook | 398 |
| LinkedIn | 398 |
| YouTube | 398 |
| English language asset | 1,194 |
| Search | 199 |
| Message CTA | 197 |
| Footer phone | 199 |
| Footer email | 199 |
| Footer address | 199 |
| More indicator | 199 |
| IPv6 badge | 199 |
| Footer language asset | 199 |

The primary logo, phone and social counts are **398 = 2 occurrences per scanned page**, consistent with shared header/footer placement. The English language asset occurs three times per page in the scanned HTML because it is repeated in language-selector structures.

## Original assets observed

| Role | Original file | Natural size | Format / background | Observed use | Replacement |
|---|---|---:|---|---|---|
| Primary brand logo | `1682642634_gFAYrZFAwH.jpg` | 205×115 | JPEG, RGB, white background | Header logo; linked to `/` | `pakistani_web_logo_white.jpg` or transparent PNG |
| Header phone/WhatsApp icon | `front/images/tel_t.png` | 40×40 | PNG RGBA | Header contact block; repeated twice in source | `phone_top.png` |
| Facebook | `1685082903_jBznDbwa9h.png` | 28×28 | PNG RGBA | Header + footer; shared template | `facebook.png` |
| LinkedIn | `1685082888_OrvzAtk7rH.png` | 28×28 | PNG RGBA | Header + footer; shared template | `linkedin.png` |
| YouTube | `1685003667_94Cb5tIkyq.png` | 28×28 | PNG RGBA | Header + footer; shared template | `youtube.png` |
| Language flag | `1721181492_EKhFlpteo1.png` | 28×16 | PNG RGBA | Language selector; additional language assets exist | `language_english.png` |
| Search | `front/images/search.png` | 21×21 | PNG RGBA | Header search control | `search.png` |
| Message CTA | `front/images/message.png` | 60×60 | PNG RGBA | Contact/leave-message CTA | `message.png` |
| Footer phone | `front/images/phone.png` | 28×28 | PNG RGBA | Footer contact block | `phone_footer.png` |
| Footer email | `front/images/mail.png` | 28×26 | PNG RGBA | Footer contact block | `mail.png` |
| Footer address | `front/images/add.png` | 28×28 | PNG RGBA | Footer contact block | `address.png` |

## Where the primary logo is used
1. **Header:** one linked image with alt text “Anhui MedPurest Medical Technology Co., Ltd”.
2. **Shared template behavior:** the same header is present on the inspected site sections, so the replacement should be made in the global header include/template rather than page-by-page.
3. **Footer:** no separate MedPurest wordmark image was found in the extracted footer; footer repeats the Facebook, LinkedIn and YouTube icons.

## Social icon count
The three branded social marks are **3 unique files**: Facebook, LinkedIn, YouTube. They appear in both the header and footer on the inspected templates, i.e. typically **6 rendered placements per page template** (3 + 3).

## Replacement rule
Replace the asset references in the shared header/footer template, preserving the original CSS boxes and link destinations. Keep the same social destinations unless the new PAKISTANI WEB accounts are available; otherwise the visual replacement will work but links will still point to the old brand's accounts.

## Generated deliverables
See the adjacent `pakistani_web_brand/` directory for ready-to-use PNG/JPG/SVG assets.
