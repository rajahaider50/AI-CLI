# PAKISTANI WEB — brand replacement kit

This kit replaces the MedPurest header/footer brand marks with a new, original **PAKISTANI WEB** identity while preserving the audited display boxes.

## Design direction
- **Mark:** navy shield with a negative-space crescent and gold pixel accent.
- **Palette:** Pakistan-inspired emerald (`#0B8F6A`), deep navy (`#0B1F3A`), mint (`#DFF7EF`), gold (`#F2B84B`).
- **Wordmark:** exact text rendered as editable SVG text; the PNG/JPG exports are ready for immediate placement.
- **Style:** clean, trustworthy, digital-first, suitable for header, favicon, social links, and contact UI.

## Files
- `pakistani_web_logo_transparent.png` — 205×115, transparent replacement for original header logo.
- `pakistani_web_logo_white.jpg` — 205×115, white-background replacement for the original JPEG slot.
- `pakistani_web_logo_transparent.svg` — editable vector master.
- `pakistani_web_mark.png` — 120×120 compact mark.
- Social replacements: Facebook, LinkedIn, YouTube at 28×28.
- Utility replacements preserve observed dimensions: phone 40×40 and 28×28, message 60×60, search 21×21, mail/address 28×26/28×28, language 28×16.

## Important implementation note
The supplied URL is a live third-party website; no source repository or deployment credentials were provided. Therefore this turn creates the complete replacement asset set and mapping, but does **not** alter the live domain. Apply the mapping in the site's shared header/footer template to replace every occurrence site-wide.
