# 21 — RESPONSIVE, ACCESSIBILITY & PERFORMANCE

**Project:** Email API Platform  
**Document:** Responsive, Accessibility & Performance Guide  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Audience:** Frontend developers, full-stack developers, UI/UX engineers, QA engineers, DevOps engineers  
**Depends on:** 00–20 architecture and development documents

---

## 1. Purpose

This document defines the production standards for:

- responsive design
- mobile usability
- accessibility
- keyboard navigation
- screen-reader compatibility
- visual accessibility
- motion preferences
- frontend performance
- API/network performance
- asset optimization
- caching
- rendering efficiency
- tables, forms, dashboards and charts
- performance testing
- accessibility testing
- production readiness

These requirements apply to public pages, authentication pages, user panel pages, admin pages, API documentation, templates, logs and system states.

---

# 2. Locked Principles

The platform must be:

1. Responsive by default.
2. Mobile-first in layout decisions.
3. Accessible to keyboard and assistive-technology users.
4. Fast on mid-range mobile devices.
5. Efficient on slower networks.
6. Usable at increased text sizes.
7. Functional without relying on color alone.
8. Compatible with reduced-motion preferences.
9. Optimized without sacrificing security.
10. Measurable through repeatable tests.

Performance must never weaken authentication, authorization, validation or security controls.

---

# 3. Responsive Design Strategy

Use a fluid, mobile-first layout.

```text
Mobile
   ↓
Large Mobile
   ↓
Tablet
   ↓
Desktop
   ↓
Wide Desktop
```

Do not build desktop first and simply shrink it.

The layout must adapt continuously between defined breakpoints.

---

# 4. Responsive Breakpoint Baseline

Bootstrap's breakpoint system is the baseline.

Typical ranges:

| Device class | Approximate width |
|---|---:|
| Small mobile | <576px |
| Mobile / large phone | 576–767px |
| Tablet | 768–991px |
| Desktop | 992–1199px |
| Large desktop | 1200–1399px |
| Wide desktop | ≥1400px |

These values are layout guidance, not assumptions about a specific physical device.

---

# 5. Container Strategy

Use responsive containers.

Desktop content should not stretch indefinitely.

Recommended:

```text
Viewport
┌──────────────────────────────────────────────┐
│              Content Container               │
│  ┌────────────────────────────────────────┐  │
│  │ Page Header                            │  │
│  │                                        │  │
│  │ Main Content                           │  │
│  └────────────────────────────────────────┘  │
└──────────────────────────────────────────────┘
```

Wide screens should use comfortable maximum widths for readability.

---

# 6. Mobile Navigation

Desktop:

```text
┌────────────┬───────────────────────────────┐
│ Sidebar    │ Main                          │
│            │                               │
└────────────┴───────────────────────────────┘
```

Mobile:

```text
┌──────────────────────────────┐
│ Header          ☰            │
├──────────────────────────────┤
│ Main                         │
│                              │
└──────────────────────────────┘
```

Use an off-canvas/drawer navigation pattern where appropriate.

Requirements:

- keyboard accessible
- focus managed
- Escape closes drawer
- background interaction disabled while modal drawer is active
- current navigation item clearly identified

---

# 7. Touch Targets

Interactive controls must be comfortably usable by touch.

Target approximately:

- 44×44 CSS pixels or larger for important controls
- adequate spacing between adjacent controls
- no tiny icon-only destructive actions

Icon-only controls require accessible names.

---

# 8. Responsive Header

Header must adapt to:

- logo
- project selector
- notifications
- user menu
- mobile menu button

On small screens:

- reduce non-essential controls
- move secondary actions into menus
- preserve access to account/security functions

Never hide critical security actions permanently on mobile.

---

# 9. Responsive Page Headers

Page headers must support:

```text
Title
Description
Primary action
Secondary actions
```

On mobile:

```text
Title
Description

[Primary Action]

[More]
```

Action groups must wrap rather than overflow.

---

# 10. Responsive Forms

Forms should stack naturally on smaller widths.

Desktop:

```text
Label       Input
Label       Input
Label       Input
```

Mobile:

```text
Label
Input

Label
Input

Label
Input
```

Avoid horizontal scrolling for normal forms.

---

# 11. Responsive Form Controls

Inputs must:

- remain readable
- have adequate height
- preserve focus visibility
- support browser zoom
- avoid text clipping
- use appropriate input types
- provide labels

Do not reduce input text below a comfortable readable size merely to fit more controls.

---

# 12. Responsive Cards

Cards may transform:

```text
Desktop:
[ Card ][ Card ][ Card ]

Mobile:
[ Card ]
[ Card ]
[ Card ]
```

Cards must preserve hierarchy and action visibility.

---

# 13. Responsive Tables

Large datasets must not force the entire page to become horizontally scrollable.

Options:

1. horizontal table container
2. responsive card representation
3. prioritized column visibility
4. detail screen for full record

Use horizontal scrolling for genuinely tabular data when preserving columns is more useful.

---

# 14. Mobile Tables

Prioritize:

- status
- identity
- timestamp
- primary action

Move secondary fields into a details view where necessary.

Do not remove critical information merely to make the table look smaller.

---

# 15. Responsive Logs

Email/API/webhook logs should support:

- compact mobile list
- expandable details
- filter drawer
- search
- pagination

Log detail screens should stack metadata sections vertically on mobile.

---

# 16. Responsive API Documentation

Code blocks should remain readable.

On mobile:

```text
┌─────────────────────────────┐
│ POST /v1/email/send         │
│ ─────────────────────────── │
│ code → horizontal scroll    │
└─────────────────────────────┘
```

Never shrink code text to the point of illegibility.

---

# 17. Responsive Template Editor

Template editing is a complex workspace.

Mobile behavior may use:

- stacked controls
- collapsible panels
- full-screen editor
- preview tab
- sticky save/publish actions where appropriate

The editor must remain functional without requiring a desktop viewport.

---

# 18. Responsive Dashboard

Dashboard priority on mobile:

1. project identity
2. provider health
3. key metrics
4. recent activity
5. important errors
6. secondary analytics

Do not display every desktop widget at equal priority.

---

# 19. Responsive Charts

Charts must:

- resize
- preserve readable labels
- support horizontal scrolling only when necessary
- have accessible summaries
- avoid tiny legends

Where space is insufficient, simplify the visual rather than compressing it excessively.

---

# 20. Responsive Modals

Large forms should not be trapped in small desktop-sized modals.

On mobile:

- modal may become full-screen
- content may scroll
- header/actions remain reachable
- Escape works
- focus remains managed

---

# 21. Responsive Notifications

Notifications should:

- fit narrow screens
- avoid covering primary actions
- support keyboard access
- remain readable at increased text size

Toast positioning must account for mobile browser UI.

---

# 22. Responsive Error Pages

System screens:

- 404
- 403
- 429
- 500
- Maintenance
- API Error Response

must remain fully usable on small screens.

Primary action should remain obvious.

---

# 23. Responsive Admin Panel

Admin screens contain dense data.

Mobile admin UI must prioritize:

- search
- filters
- status
- detail access
- critical actions

Destructive admin actions should remain deliberate and should not be compressed into ambiguous icon-only controls.

---

# 24. Zoom and Text Scaling

The interface must remain usable at:

- 100%
- 125%
- 150%
- 200%

Do not disable browser zoom.

Do not use fixed-height containers that clip content when text becomes larger.

---

# 25. Accessibility Target

Target **WCAG 2.2 AA** principles.

The platform should support:

- perceivable content
- operable controls
- understandable workflows
- robust semantic structure

Accessibility is a product requirement, not a cosmetic enhancement.

---

# 26. Semantic HTML

Use semantic elements:

```html
<header>
<nav>
<main>
<section>
<article>
<aside>
<footer>
```

Use headings in logical order.

Avoid using `<div>` as a button.

---

# 27. Heading Hierarchy

Preferred:

```text
H1
 ├─ H2
 │   ├─ H3
 │   └─ H3
 └─ H2
```

Do not skip heading levels solely for visual sizing.

Use CSS classes for appearance.

---

# 28. Accessible Names

Every interactive element must have an accessible name.

Examples:

```html
<button aria-label="Delete template">
  ...
</button>
```

Links should describe their destination.

Avoid:

```text
Click here
More
View
```

when context is ambiguous.

---

# 29. Keyboard Accessibility

Every core workflow must be usable with keyboard only.

Test:

- Tab
- Shift+Tab
- Enter
- Space
- Escape
- arrow keys for composite widgets

Keyboard focus must be visible.

---

# 30. Focus Management

After navigation:

- move focus to the new page heading or appropriate landmark where applicable

After opening a dialog:

- move focus inside the dialog

After closing:

- return focus to the triggering control

Never allow focus to disappear into an invisible element.

---

# 31. Focus Styling

Never remove focus outlines without a strong replacement.

Example:

```css
:focus-visible {
  outline: 3px solid currentColor;
  outline-offset: 2px;
}
```

The exact visual token must follow the design system.

---

# 32. Forms and Labels

Every form control must have a programmatically associated label.

Use:

```html
<label for="email">Email address</label>
<input id="email" name="email" type="email">
```

Placeholder text is not a replacement for a label.

---

# 33. Form Errors

Errors must:

- identify the field
- explain the problem
- provide correction guidance
- be announced where necessary
- preserve user input

Example:

```text
Email address
[invalid@example]

Please enter a valid email address.
```

---

# 34. Error Association

Where appropriate:

```html
<input
  aria-invalid="true"
  aria-describedby="email-error">

<div id="email-error">
  Enter a valid email address.
</div>
```

Do not rely only on red borders.

---

# 35. Success and Status Messages

Use accessible status patterns.

Examples:

```html
<div role="status">
  Template saved successfully.
</div>
```

Critical errors may use:

```html
<div role="alert">
  Unable to save the template.
</div>
```

Avoid excessive announcements that interrupt users unnecessarily.

---

# 36. Color Accessibility

Never communicate status through color alone.

Bad:

```text
Green = success
Red = failure
```

Better:

```text
✓ Success
! Failed
```

Color remains supportive rather than the only signal.

---

# 37. Contrast

Text and interactive elements must maintain sufficient contrast.

Test:

- body text
- muted text
- links
- buttons
- form borders
- status badges
- focus indicators
- dark mode

Do not sacrifice contrast for visual subtlety.

---

# 38. Dark Mode Accessibility

If dark mode is enabled:

- maintain contrast
- preserve focus visibility
- avoid pure white/pure black extremes where uncomfortable
- verify disabled states
- verify charts
- verify provider logos
- verify code blocks

Dark mode must not be a separate inaccessible theme.

---

# 39. Reduced Motion

Respect:

```css
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

Core functionality must never depend on animation.

---

# 40. Flashing Content

Avoid rapid flashing or strobing animations.

Loading indicators must remain calm and unobtrusive.

---

# 41. Accessible Icons

Decorative icons:

```html
<svg aria-hidden="true">...</svg>
```

Meaningful icon-only controls:

```html
<button aria-label="Copy API key">
```

Do not rely on tooltip text as the only accessible name.

---

# 42. Accessible Tables

Use:

```html
<table>
  <thead>
    <tr>
      <th scope="col">Status</th>
      <th scope="col">Recipient</th>
    </tr>
  </thead>
</table>
```

For complex tables, provide appropriate relationships.

---

# 43. Accessible Dialogs

Dialogs must:

- have an accessible title
- trap focus appropriately
- support Escape
- restore focus
- prevent background interaction
- avoid unexpected focus movement

---

# 44. Accessible Dropdowns

Dropdowns must:

- be keyboard accessible
- have clear expanded state
- support Escape
- expose selected state
- remain usable without hover

---

# 45. Accessible Tabs

Tabs must communicate:

- tab role
- selected state
- associated panel
- keyboard behavior

Do not implement tabs as visually styled links without semantics when true tab behavior is intended.

---

# 46. Accessible Toasts

Toasts should not steal focus unnecessarily.

Use appropriate status/live-region behavior.

Important failures should remain available in the page context.

---

# 47. Screen Reader Testing

Test key workflows with at least one screen reader where available.

Priority workflows:

- registration
- login
- OTP
- dashboard
- create project
- provider connection
- template creation
- API key creation
- webhook configuration
- admin security

---

# 48. Performance Philosophy

Performance is a system property.

Optimize:

```text
HTML
 ↓
CSS
 ↓
JavaScript
 ↓
Assets
 ↓
API requests
 ↓
Rendering
 ↓
User interaction
```

Do not optimize one layer while ignoring bottlenecks elsewhere.

---

# 49. Core Web Performance

Monitor modern user-centric metrics such as:

- Largest Contentful Paint (LCP)
- Cumulative Layout Shift (CLS)
- Interaction to Next Paint (INP)

Use realistic mobile/network conditions for testing.

Targets should be treated as engineering goals rather than guarantees across every environment.

---

# 50. First Render

Optimize first render by:

- minimizing critical CSS
- avoiding unnecessary blocking scripts
- using `defer` for non-critical scripts
- optimizing fonts
- reserving image dimensions
- reducing initial DOM complexity

---

# 51. JavaScript Performance

Rules:

- avoid unnecessary global listeners
- debounce search
- throttle scroll/resize handlers
- avoid expensive DOM loops
- cancel stale requests
- lazy-load non-critical modules
- remove dead code

---

# 52. DOM Performance

Avoid repeatedly forcing layout.

Bad pattern:

```text
read layout
write DOM
read layout
write DOM
```

Prefer batched DOM updates.

Do not render thousands of rows simultaneously when server-side pagination is available.

---

# 53. CSS Performance

Prefer:

- reusable classes
- design tokens
- efficient selectors
- limited nesting
- minimal duplication

Avoid huge selector chains and unnecessary animation of expensive properties.

---

# 54. Animation Performance

Prefer transform/opacity for animations.

Avoid continuously animating:

- width
- height
- top
- left
- large shadows

Animation must never block critical interaction.

---

# 55. Image Optimization

Use:

- SVG for icons/logos
- WebP for photographs/illustrations where suitable
- responsive images
- correct dimensions
- lazy loading for below-the-fold imagery

Example:

```html
<img
  src="/assets/images/example.webp"
  alt="..."
  loading="lazy"
  width="800"
  height="500">
```

Do not lazy-load critical above-the-fold assets unnecessarily.

---

# 56. Font Performance

Use:

- WOFF2
- limited font weights
- `font-display: swap`
- preload only critical fonts

Avoid loading every available font weight.

---

# 57. Asset Caching

Static assets should be cacheable.

Use versioned filenames or content hashes.

Example:

```text
app.8f3c1.js
styles.a8c91.css
```

Cache invalidation must occur when assets change.

---

# 58. HTTP Compression

Production server should use appropriate compression such as:

- Brotli where supported
- gzip fallback

Compress:

- HTML
- CSS
- JavaScript
- JSON
- SVG where appropriate

Do not attempt to compress already-compressed formats unnecessarily.

---

# 59. API Performance

Frontend API efficiency requires:

- request batching where appropriate
- avoiding duplicate calls
- pagination
- caching safe GET responses
- cancellation of stale requests
- debounced filters
- sensible refresh intervals

Do not create N+1 API requests from one page.

---

# 60. API Request Budget

Each page should have a deliberate request model.

Example dashboard:

```text
Session/User
     |
Project
     |
Dashboard summary
     |
Recent activity
```

Where possible, use backend summary endpoints instead of many independent calls.

---

# 61. Duplicate Request Prevention

Before sending a request:

- check whether an identical operation is already active
- disable duplicate UI actions
- use request keys where supported

This is especially important for:

- email sends
- OTP sends
- provider tests
- API key creation

---

# 62. Search Performance

Search input should use debounce.

Typical starting point:

```text
250–400ms
```

Cancel the previous request when a newer query is submitted.

Never issue one API request per keystroke without debouncing.

---

# 63. Pagination Performance

Large datasets must be paginated server-side.

Use:

```text
page
per_page
```

or the canonical API pagination contract.

Do not fetch an entire email log table into the browser.

---

# 64. Filtering Performance

Filters should be applied server-side for large datasets.

Examples:

- status
- provider
- date range
- project
- event type
- user
- webhook result

Frontend only controls filter state.

---

# 65. Dashboard Performance

Dashboard APIs should return aggregated data where possible.

Avoid loading:

- thousands of log records
- entire user lists
- entire project histories

just to calculate a small metric in JavaScript.

---

# 66. Chart Performance

Charts should use summarized datasets.

For long date ranges:

- aggregate by day/week/month
- avoid thousands of individual points
- allow date-range selection

Do not render a point for every raw event when aggregation is sufficient.

---

# 67. Log Detail Performance

Log detail pages should load:

1. summary
2. metadata
3. detailed sections on demand where useful

Large payloads should not be loaded automatically unless needed.

---

# 68. Template Editor Performance

Template editors can become heavy.

Rules:

- avoid rendering preview on every keystroke
- debounce preview rendering
- isolate preview
- avoid unnecessary DOM rebuilds
- limit expensive syntax processing
- preserve editor state

---

# 69. API Documentation Performance

API docs should avoid loading every endpoint example at once if the documentation is large.

Use:

- collapsible sections
- lazy code rendering
- searchable endpoint lists

Do not sacrifice accessibility for lazy rendering.

---

# 70. Loading Strategy

Use the least expensive loading pattern that communicates progress.

| Content | Preferred |
|---|---|
| Page data | skeleton |
| Small action | button spinner |
| File/image | placeholder |
| Long operation | progress/status |
| Background refresh | subtle indicator |

---

# 71. Skeleton Rules

Skeletons should approximate final content dimensions.

Avoid large layout shifts when real content arrives.

Skeletons must not flash rapidly for very short requests.

---

# 72. Layout Stability

Prevent CLS by reserving space for:

- images
- charts
- tables
- alerts
- navigation
- dynamic controls

Do not insert large UI elements above already-rendered content unexpectedly.

---

# 73. Lazy Loading

Lazy-load:

- below-the-fold images
- non-critical modules
- secondary analytics
- large documentation sections

Do not lazy-load:

- critical navigation
- primary page content
- authentication controls

when doing so harms first interaction.

---

# 74. Code Splitting

If the frontend grows substantially, page-level JavaScript can be loaded on demand.

Example concept:

```text
Dashboard → dashboard.js
Templates → templates.js
Admin → admin.js
```

Do not introduce a complex bundler solely for theoretical optimization.

---

# 75. Caching Rules

Safe to cache:

- static assets
- public documentation
- non-sensitive metadata
- stable UI configuration

Be careful caching:

- authenticated user data
- project data
- logs
- notifications
- security state

Never cache secrets in insecure browser storage.

---

# 76. Back/Forward Navigation

The UI should remain predictable when users navigate browser history.

Avoid:

- stale project data
- duplicated requests
- broken modal state
- unexpected form resets

---

# 77. Network Failure Handling

For failed requests:

```text
Request
  |
  +-- Success
  |
  +-- Network Failure
  |      |
  |      +--> Retry
  |
  +-- API Error
         |
         +--> Explain safely
```

Never show "sent successfully" if the request result is unknown.

---

# 78. Timeout UX

If an operation exceeds expected duration:

```text
Still processing...
```

Provide safe next actions.

For email sends, avoid immediately repeating the request if delivery state is ambiguous.

Use backend request IDs/idempotency where available.

---

# 79. Offline Awareness

If the browser reports no network:

- disable operations that cannot work
- show network state
- allow safe local navigation
- retry only when appropriate

Do not create a fake offline email queue unless explicitly supported by the architecture.

---

# 80. Performance on Low-End Devices

Test on realistic mid/low-range Android hardware.

Prioritize:

- low JS execution
- low memory use
- small images
- simple animations
- efficient tables
- limited simultaneous requests

---

# 81. Performance on Slow Networks

Test with:

- Fast 3G-like conditions
- slower 3G-like conditions
- high latency

The UI should show meaningful progress rather than appearing frozen.

---

# 82. Mobile Browser Considerations

Account for:

- dynamic viewport height
- virtual keyboard
- safe-area insets
- browser address bars
- touch scrolling

Avoid fixed-position UI that blocks form fields when the keyboard opens.

---

# 83. Safe Areas

For devices with display cutouts:

```css
padding-bottom: env(safe-area-inset-bottom);
```

Use safe-area handling where fixed bottom controls require it.

---

# 84. Accessibility + Performance Balance

Do not remove semantic HTML for performance prematurely.

Do not replace accessible controls with custom canvas-based widgets.

Prefer native browser controls when they provide the required behavior.

---

# 85. Performance + Security Balance

Never:

- remove validation to make forms faster
- disable CSRF
- expose credentials for direct provider calls
- cache secrets
- bypass authorization
- remove audit logging

Security controls are not optional performance features.

---

# 86. Accessibility Testing Matrix

| Area | Desktop | Mobile | Keyboard | Screen Reader |
|---|---:|---:|---:|---:|
| Public pages | ✓ | ✓ | ✓ | ✓ |
| Login | ✓ | ✓ | ✓ | ✓ |
| OTP | ✓ | ✓ | ✓ | ✓ |
| Dashboard | ✓ | ✓ | ✓ | ✓ |
| Projects | ✓ | ✓ | ✓ | ✓ |
| Providers | ✓ | ✓ | ✓ | ✓ |
| Templates | ✓ | ✓ | ✓ | ✓ |
| API Keys | ✓ | ✓ | ✓ | ✓ |
| Webhooks | ✓ | ✓ | ✓ | ✓ |
| Logs | ✓ | ✓ | ✓ | ✓ |
| Admin | ✓ | ✓ | ✓ | ✓ |
| Error pages | ✓ | ✓ | ✓ | ✓ |

---

# 87. Responsive QA Matrix

Test at minimum:

- 320px
- 360px
- 375px
- 390px
- 414px
- 480px
- 768px
- 820px
- 1024px
- 1280px
- 1440px
- 1920px

Also test intermediate widths to catch breakpoint bugs.

---

# 88. Browser QA Matrix

Test current versions of:

- Chrome
- Edge
- Firefox
- Safari
- Android Chrome
- iOS Safari

Priority is functional correctness and accessibility.

---

# 89. Zoom QA

Test:

- 100%
- 125%
- 150%
- 200%

Verify:

- no clipped content
- no overlapping controls
- no inaccessible menus
- no hidden form errors
- no broken tables

---

# 90. Keyboard QA Checklist

- [ ] Can reach every interactive element.
- [ ] Focus is visible.
- [ ] Tab order is logical.
- [ ] Modals trap focus.
- [ ] Escape closes temporary overlays.
- [ ] Focus returns after modal close.
- [ ] Dropdowns work without mouse.
- [ ] Forms submit by keyboard.
- [ ] No keyboard trap exists.

---

# 91. Screen Reader QA Checklist

- [ ] Page title is meaningful.
- [ ] H1 is present.
- [ ] Navigation has a label.
- [ ] Forms have labels.
- [ ] Errors are announced.
- [ ] Status updates are announced appropriately.
- [ ] Buttons have names.
- [ ] Icons are correctly hidden/labeled.
- [ ] Tables have headers.
- [ ] Dialogs have titles.

---

# 92. Performance QA Checklist

- [ ] No unnecessary blocking scripts.
- [ ] Images optimized.
- [ ] Fonts optimized.
- [ ] CSS optimized.
- [ ] JavaScript optimized.
- [ ] Requests minimized.
- [ ] Search debounced.
- [ ] Tables paginated.
- [ ] Charts aggregated.
- [ ] No large layout shifts.
- [ ] No long-running UI tasks.
- [ ] Production debug logging disabled.

---

# 93. Lighthouse / Audit Workflow

Use automated audits as a diagnostic tool.

Check:

- Performance
- Accessibility
- Best Practices
- SEO for public pages

Automated scores do not replace manual accessibility testing.

---

# 94. Performance Budgets

Recommended engineering targets:

| Resource | Goal |
|---|---:|
| Initial HTML | keep small |
| Critical CSS | minimal |
| Initial JS | minimal |
| Hero image | optimized |
| Fonts | limited weights |
| API calls on initial load | deliberate |
| Long tasks | minimize |
| Layout shift | near zero |

Exact budgets may be refined after production measurements, but regressions must be detected.

---

# 95. Regression Testing

Performance regressions should be tracked after:

- new dependencies
- major UI changes
- dashboard redesign
- template editor changes
- admin table changes
- analytics changes

Do not allow feature growth to silently degrade mobile performance.

---

# 96. Accessibility Regression Testing

Run checks after changes to:

- navigation
- modal components
- forms
- tables
- charts
- template editor
- API documentation
- admin UI

---

# 97. Third-Party Assets

Third-party scripts must be minimized.

Before adding one, evaluate:

- performance impact
- privacy impact
- security impact
- CSP requirements
- accessibility
- maintenance burden

A dependency must have a clear product benefit.

---

# 98. Third-Party Fonts and Analytics

Third-party resources are optional.

If used:

- load securely
- respect privacy policy
- avoid leaking sensitive page data
- avoid transmitting secrets
- use approved domains in CSP

---

# 99. Monitoring

Production monitoring should track, where appropriate:

- page errors
- API error rates
- slow API calls
- frontend exceptions
- resource loading failures
- provider-related UI failures
- Web Vitals

Do not collect unnecessary sensitive data.

---

# 100. Frontend Error Reporting Privacy

Error reporting must redact:

- Authorization headers
- API keys
- passwords
- OAuth tokens
- SMTP credentials
- webhook secrets
- OTP values
- reset URLs
- sensitive email content

---

# 101. Accessibility of Security UI

Security-sensitive pages must be especially accessible:

- Password Change
- Security Settings
- Active Sessions
- API Keys
- Provider credentials
- Webhooks
- Admin Security
- Blocked IPs
- Audit logs

A security control that cannot be operated accessibly is still a security failure.

---

# 102. Accessibility of OTP

OTP UI should:

- expose a clear label
- allow keyboard entry
- support paste where appropriate
- provide countdown text
- provide resend action
- expose errors clearly

Do not make each OTP digit a separate inaccessible control.

---

# 103. Mobile OTP

OTP input must work well with mobile keyboards.

Use an appropriate input mode and avoid unexpected focus jumps.

---

# 104. Password UI

Password fields should support:

- show/hide password
- accessible toggle
- password manager compatibility
- clear validation
- confirmation

Do not disable browser password managers unnecessarily.

---

# 105. Accessibility of Provider Status

Provider states should include both:

```text
Connected
```

and a non-color indicator such as icon/text.

Do not rely only on green/red dots.

---

# 106. Accessibility of Logs

Status should be text:

```text
Sent
Failed
Processing
Cancelled
```

rather than only colored badges.

---

# 107. Performance of Logs

Logs should use:

- server-side pagination
- filter parameters
- debounced search
- date range filtering
- lazy detail loading where appropriate

Avoid loading entire historical datasets.

---

# 108. Performance of Admin Users

Admin user lists should use:

- pagination
- server-side search
- server-side filters
- lazy details
- explicit action menus

Do not preload all users.

---

# 109. Performance of Provider Lists

Provider screens should show a concise summary.

Detailed connection data should be loaded only when needed.

---

# 110. Performance of API Documentation

Use endpoint indexing and lazy content where useful.

Search should be local for small documentation sets and optimized for larger sets.

---

# 111. Performance of Template Preview

Preview rendering must be controlled.

Do not render untrusted template content into the parent application DOM.

Use isolation and debounce updates.

---

# 112. Responsive Security Actions

Security actions must remain accessible on mobile:

- revoke session
- change password
- revoke API key
- disconnect provider
- rotate webhook secret

Do not bury them in inaccessible overflow menus.

---

# 113. Responsive Destructive Actions

On small screens, confirmation dialogs must clearly identify:

- resource
- action
- consequence

Avoid ambiguous buttons such as only:

```text
OK
Cancel
```

Prefer:

```text
Cancel
Revoke Key
```

---

# 114. Accessibility of Empty States

Empty states must have:

- meaningful heading
- explanation
- action if applicable

Example:

```text
No webhooks configured

Add a webhook endpoint to receive project events.

[Add Webhook]
```

---

# 115. Accessibility of Loading States

Do not make skeletons the only information.

Use status text where necessary:

```text
Loading email logs...
```

---

# 116. Accessibility of Error States

Errors must not depend solely on:

- red color
- icon
- position

Use explicit text and, when appropriate, an alert/status mechanism.

---

# 117. Performance Definition of Done

A feature is performance-ready when:

- [ ] no unnecessary API requests
- [ ] no obvious layout shifts
- [ ] no blocking non-critical scripts
- [ ] assets are optimized
- [ ] mobile interaction is responsive
- [ ] large datasets are paginated
- [ ] search is debounced
- [ ] stale requests are cancellable
- [ ] production logging is minimal
- [ ] performance has been measured

---

# 118. Accessibility Definition of Done

A feature is accessibility-ready when:

- [ ] semantic HTML is used
- [ ] keyboard navigation works
- [ ] focus is visible
- [ ] labels are associated
- [ ] errors are accessible
- [ ] status messages are accessible
- [ ] contrast is acceptable
- [ ] color is not the only signal
- [ ] reduced motion is respected
- [ ] mobile zoom works
- [ ] screen-reader behavior is reviewed

---

# 119. Responsive Definition of Done

A feature is responsive-ready when:

- [ ] mobile layout works
- [ ] tablet layout works
- [ ] desktop layout works
- [ ] no accidental horizontal overflow
- [ ] forms stack correctly
- [ ] tables remain usable
- [ ] navigation works
- [ ] modals work
- [ ] touch targets are usable
- [ ] zoom to 200% remains functional

---

# 120. FINAL NON-NEGOTIABLE RULES

1. Mobile-first responsive behavior is mandatory.
2. Desktop-only functionality is not acceptable.
3. Browser zoom must never be disabled.
4. Keyboard navigation is mandatory.
5. Visible focus is mandatory.
6. Semantic HTML is preferred.
7. Form controls require accessible labels.
8. Color must never be the only status indicator.
9. Reduced motion must be respected.
10. Responsive tables must remain usable.
11. Large datasets must use server-side pagination.
12. Search must be debounced.
13. Stale requests must not overwrite current project data.
14. Critical UI must not depend on JavaScript animation.
15. Images must be optimized.
16. Fonts must be optimized.
17. Non-critical JavaScript must not block rendering.
18. Static assets must be cacheable.
19. Production builds must remove debug output.
20. API requests must be deliberate.
21. Duplicate requests must be prevented where possible.
22. Network failures must be handled safely.
23. Ambiguous email-send outcomes must not trigger unsafe duplicate sends.
24. Accessibility must be tested manually as well as automatically.
25. Performance must be measured, not guessed.
26. Security must never be weakened for performance.
27. Sensitive data must never enter client-side telemetry.
28. Third-party resources must be minimized.
29. Admin screens must remain responsive and accessible.
30. All 93 screens must follow these standards.

---

# 121. Final Architecture Relationship

```text
00–19
Architecture / Security / Backend / UI Foundation
                 |
                 v
20 Frontend Development Guide
                 |
                 v
21 Responsive + Accessibility + Performance
                 |
                 v
22 Testing / QA / Error Handling
                 |
                 v
23 Deployment / Maintenance / Developer Guide
                 |
                 v
24 Development Rules / Final Checklist
```

This document expands the frontend standards without changing the locked architecture.

---

# 122. Final Lock

The responsive, accessibility and performance architecture is **FINAL / LOCKED**.

No future implementation may:

- remove mobile support
- disable browser zoom
- remove keyboard accessibility
- expose secrets for performance convenience
- bypass backend validation
- introduce unsafe client-side credential storage
- load entire large datasets unnecessarily
- allow stale project requests to overwrite current state
- treat accessibility as optional
- sacrifice security for speed
- sacrifice functionality for visual simplicity

**This document is the authoritative responsive, accessibility and performance standard for the Email API Platform.**

**Status: FINAL / LOCKED**
