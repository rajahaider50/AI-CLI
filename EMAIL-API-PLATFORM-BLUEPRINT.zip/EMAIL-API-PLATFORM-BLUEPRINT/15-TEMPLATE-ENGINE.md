# 15 — TEMPLATE ENGINE

**Project:** Email API Platform  
**Document:** Email Template Architecture, Variables, Rendering, Validation, Preview, Versioning & Security  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Parent Architecture:** `00-MASTER-BLUEPRINT.md`  
**Related:** `10-BACKEND-PHP-ARCHITECTURE.md`, `13-EMAIL-ENGINE.md`, `14-EMAIL-PROVIDERS.md`, `16-PROJECTS-API-KEYS-WEBHOOKS.md`, `19-SECURITY-ARCHITECTURE.md`

---

## 1. Document Purpose

This document defines the complete Template Engine for the Email API Platform.

The Template Engine is responsible for:

- Creating email templates.
- Editing templates.
- Storing HTML and plain-text content.
- Managing template subjects.
- Defining template variables.
- Validating variables.
- Rendering templates with runtime data.
- Previewing rendered messages.
- Managing template versions.
- Duplicating templates.
- Publishing/activating versions.
- Archiving templates.
- Protecting templates from unsafe rendering.
- Supporting API-based template sending.
- Integrating with the Email Engine.
- Preserving project isolation.
- Supporting future template features without changing the public send API.

The Template Engine must remain independent from provider-specific sending logic.

---

# 2. Locked Template Architecture

The canonical flow is:

```text
Client / Dashboard
       ↓
Template API
       ↓
Template Service
       ↓
Template Repository
       ↓
Template + Published Version
       ↓
Variable Validation
       ↓
Template Renderer
       ↓
Rendered EmailMessage
       ↓
Email Engine
       ↓
Provider Resolver
       ↓
Gmail / SMTP / Optional Provider
```

The Template Engine creates a message.

The Email Engine sends it.

The Provider layer delivers it.

These responsibilities must not be merged.

---

# 3. Template Types

The platform supports:

1. HTML email templates.
2. Plain-text templates.
3. HTML + plain-text templates.
4. Transactional templates.
5. Verification templates.
6. OTP templates.
7. Password-reset templates.
8. Custom application templates.

A template may contain:

```text
Subject
HTML body
Plain-text body
Variable definitions
Metadata
Version information
```

---

# 4. Template Ownership

Templates are project-scoped.

```text
User
  ↓
Project
  ↓
Template
  ↓
Template Versions
```

A template must never be accessible across projects unless an explicit future sharing mechanism is introduced.

Current architecture does not require cross-project template sharing.

---

# 5. Template Identity

Recommended identifiers:

```text
template_id
project_id
template_key
name
status
created_at
updated_at
```

### template_id

Internal unique identifier.

### template_key

Stable developer-facing identifier.

Example:

```text
welcome_email
email_verification
otp_login
password_reset
contact_notification
```

The API may use the stable template key where appropriate.

---

# 6. Template Naming Rules

Human-readable name:

```text
Welcome Email
Password Reset
Order Confirmation
```

Developer key:

```text
welcome_email
password_reset
order_confirmation
```

Recommended key rules:

- Lowercase.
- Letters, numbers, underscore, hyphen where supported.
- No spaces.
- Unique within a project.
- Immutable after publication where practical.

---

# 7. Template Lifecycle

Recommended states:

```text
DRAFT
ACTIVE
ARCHIVED
DISABLED
```

### DRAFT

Editable and not necessarily available for normal production sends.

### ACTIVE

Has a published version and may be used for sending.

### ARCHIVED

Retained for historical purposes but not used for new sends.

### DISABLED

Temporarily unavailable for sending.

---

# 8. Template Versioning

Templates use versioned content.

Concept:

```text
Template
  │
  ├── Version 1
  ├── Version 2
  ├── Version 3
  └── Published Version → Version 3
```

This prevents content changes from unexpectedly changing historical or in-flight operations.

---

# 9. Version States

Recommended version states:

```text
DRAFT
PUBLISHED
ARCHIVED
```

Only one version should be the current published version per template.

---

# 10. Publishing Model

Publishing is an explicit operation.

```text
Edit Draft
   ↓
Validate
   ↓
Preview
   ↓
Publish
   ↓
Published Version
```

Saving a draft must not automatically change the production version.

This separation is critical for safe template management.

---

# 11. Template Creation Flow

```text
Create Template
      ↓
Enter name
      ↓
Enter template key
      ↓
Enter subject
      ↓
Enter HTML
      ↓
Optional plain text
      ↓
Define variables
      ↓
Validate
      ↓
Save draft
      ↓
Preview
      ↓
Publish
```

---

# 12. Template Editor

The editor should provide:

- Template name.
- Template key.
- Subject.
- HTML editor.
- Plain-text editor.
- Variable panel.
- Preview.
- Validation.
- Save Draft.
- Publish.
- Version information.

The editor must remain usable on mobile and desktop.

---

# 13. HTML Template Format

Example:

```html
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>{{subject}}</title>
</head>
<body>
  <h1>Hello {{user_name}}</h1>
  <p>Welcome to our application.</p>
</body>
</html>
```

The template renderer replaces supported variables before sending.

---

# 14. Plain-Text Template

Example:

```text
Hello {{user_name}},

Welcome to our application.

Your account is ready.
```

Plain text should be used as:

- A fallback for HTML email.
- A standalone email body where desired.
- An accessibility-friendly representation.

---

# 15. Subject Templates

Subjects may contain variables.

Example:

```text
Welcome, {{user_name}}
```

At render time:

```text
Welcome, Raja
```

Subject rendering must use the same variable validation rules as body rendering.

---

# 16. Variable Syntax

The canonical syntax is:

```text
{{variable_name}}
```

Example:

```text
{{user_name}}
{{verification_code}}
{{app_name}}
```

Variables should not contain executable code.

The renderer is a substitution engine, not a general-purpose programming language.

---

# 17. Variable Names

Recommended rules:

```text
[a-zA-Z0-9_]
```

Examples:

```text
user_name
first_name
verification_code
reset_url
company_name
```

Avoid arbitrary expressions such as:

```text
{{ user.name | execute }}
{{php_code}}
{{system_command}}
```

---

# 18. Variable Definition

Each template variable may have metadata:

```text
name
type
required
description
default_value
example_value
```

Example:

```json
{
  "name": "user_name",
  "type": "string",
  "required": true,
  "description": "Recipient display name",
  "example": "Raja"
}
```

---

# 19. Supported Variable Types

Initial types:

```text
string
integer
number
boolean
url
email
date
datetime
```

The renderer may internally normalize values to strings after validation.

Future complex object variables are not required for the initial locked scope.

---

# 20. Required Variables

A variable may be required.

Example:

```text
verification_code
required = true
```

If the API request does not supply it:

```text
TEMPLATE_VARIABLE_MISSING
```

The email must not be sent.

---

# 21. Optional Variables

Optional variables may define a default value.

Example:

```text
company_name
required = false
default = "My Company"
```

If omitted:

```text
My Company
```

is used.

---

# 22. Unknown Variables

If a template contains:

```text
{{unknown_variable}}
```

but no definition exists, publishing should fail.

This prevents accidental production messages containing unresolved placeholders.

---

# 23. Missing Variable Policy

At render time:

```text
Required + missing
    → fail

Optional + missing + default
    → use default

Optional + missing + no default
    → empty value or configured safe behavior
```

The final behavior must be deterministic.

---

# 24. Unresolved Variable Protection

Production sends must not normally contain:

```text
{{user_name}}
{{verification_code}}
```

after rendering.

The renderer should perform a final unresolved-placeholder scan.

If unresolved variables remain:

```text
TEMPLATE_RENDER_FAILED
```

The message must not be sent.

---

# 25. Variable Escaping

Variable output must be escaped according to context.

For normal HTML text:

```text
HTML escape
```

For plain text:

```text
Text-safe normalization
```

For URL attributes:

```text
URL-safe validation/encoding
```

Do not treat all variables as raw HTML.

---

# 26. Raw HTML Variables

Raw HTML insertion is dangerous.

The initial engine should not allow arbitrary raw HTML variables by default.

Example:

```text
{{{html_content}}}
```

should not be treated as a normal variable syntax unless a future, explicitly sandboxed feature is introduced.

Safe default:

```text
All variables are escaped.
```

---

# 27. URL Variables

URL variables should be validated.

Allowed schemes should normally include:

```text
https
http
```

Potentially allowed schemes must be explicitly configured.

Do not allow dangerous schemes such as:

```text
javascript:
data:
vbscript:
```

in clickable URL contexts.

---

# 28. Email Variables

Variables used as email addresses must pass email validation.

Example:

```text
{{recipient_email}}
```

The renderer validates the resulting value before the email engine accepts it.

---

# 29. Template HTML Sanitization

Template HTML is user-authored content and must be treated as untrusted.

Publishing should validate/sanitize unsafe content according to the platform's HTML policy.

At minimum consider:

- Script tags.
- Event handler attributes.
- Dangerous URL schemes.
- Embedded executable content.
- Unsafe iframe/object/embed usage.
- Malformed markup.
- CSS injection risks.

The platform should support legitimate email HTML without permitting browser-executable attacks in dashboard previews.

---

# 30. Email HTML vs Dashboard Preview

A key distinction:

```text
Email HTML
      ↓
Email client
```

versus:

```text
User-provided HTML
      ↓
Web dashboard preview
```

Dashboard previews must be isolated from the platform's own origin.

Recommended approach:

- Sanitize preview HTML.
- Render inside a sandboxed iframe where appropriate.
- Avoid allowing preview content to access parent DOM.
- Avoid executing scripts from templates.

Never inject untrusted template HTML directly into the main dashboard DOM.

---

# 31. Template CSS

Email CSS has different constraints from web application CSS.

Templates may contain inline CSS and email-compatible styles.

The platform should not automatically rewrite every CSS rule unless a deliberate email CSS processing feature is introduced.

A future CSS inliner can be added behind the renderer pipeline.

---

# 32. Responsive Email Templates

Templates should support common email-client responsive patterns.

The platform may provide starter templates for:

- Welcome.
- Verification.
- OTP.
- Password reset.
- Notification.
- Contact form.
- Generic transactional email.

Starter templates must remain editable.

---

# 33. Starter Templates

System starter templates are optional examples and must not be mixed with user-owned templates.

Example:

```text
System Templates
├── Welcome
├── Email Verification
├── OTP
├── Password Reset
└── Generic Notification
```

Copying a starter template creates a project-owned template.

---

# 34. Template Duplication

Duplicate action:

```text
Existing Template
      ↓
Duplicate
      ↓
New Template
      ↓
New template key
      ↓
Draft version
```

The original remains unchanged.

Duplicate should copy content and variable definitions but generate a new template identity.

---

# 35. Template Deletion

Deletion should be controlled.

Recommended:

```text
Active template
      ↓
Archive / disable
      ↓
Optional permanent deletion
```

Historical email logs must not lose the rendered-message reference merely because a template is deleted.

---

# 36. Template Archive

Archived templates:

- Remain visible in history.
- Cannot be used for new sends.
- Preserve versions.
- Preserve metadata.
- Can optionally be restored.

Restore creates an explicit state transition.

---

# 37. Template Preview

Preview should support:

- Subject preview.
- HTML preview.
- Plain-text preview.
- Variable sample data.
- Desktop width.
- Mobile width.
- Light/dark dashboard shell where useful.

Preview must never send an email automatically.

---

# 38. Preview Data

Example:

```json
{
  "user_name": "Raja",
  "verification_code": "483921",
  "app_name": "My App",
  "reset_url": "https://example.com/reset/demo"
}
```

Preview values are demonstration data.

They must not be mistaken for real production credentials or OTPs.

---

# 39. Preview Security

Preview endpoint must:

- Require authorization.
- Verify project ownership/access.
- Sanitize/contain template HTML.
- Prevent script execution.
- Prevent parent-window access.
- Apply safe CSP where possible.
- Avoid loading arbitrary dangerous external resources where feasible.

---

# 40. Template Validation Pipeline

Before publish:

```text
Load Draft
   ↓
Validate Metadata
   ↓
Validate Key
   ↓
Parse Variables
   ↓
Validate Variable Definitions
   ↓
Validate Subject
   ↓
Validate HTML
   ↓
Validate Plain Text
   ↓
Check Unresolved/Invalid Syntax
   ↓
Security/Sanitization Checks
   ↓
Publish
```

---

# 41. Template Parser

The parser should identify all supported variable placeholders.

Input:

```text
Hello {{first_name}}
Your code is {{verification_code}}
```

Output:

```text
first_name
verification_code
```

Duplicate variable usage is allowed.

---

# 42. Variable Consistency

If a variable appears in:

```text
Subject
HTML
Plain Text
```

the definition should be shared.

Example:

```text
{{user_name}}
```

must resolve consistently across all sections.

---

# 43. Variable Extraction

The system may automatically detect variables while editing.

Example UI:

```text
Detected Variables
------------------
user_name
verification_code
reset_url
```

The user can then define:

- Type.
- Required.
- Description.
- Example.
- Default.

Automatic detection must not silently create unsafe variables.

---

# 44. Template Save vs Publish

### Save Draft

Allows incomplete content.

### Publish

Requires:

- Valid template key.
- Valid content.
- Valid variables.
- Security checks.
- No unresolved invalid syntax.
- Valid subject.
- Valid version.

This distinction enables iterative editing.

---

# 45. Template Version Creation

Editing a published template should create a new draft version.

Example:

```text
Published v3
     ↓
Edit
     ↓
Draft v4
     ↓
Preview
     ↓
Publish
     ↓
Published v4
```

Published v3 remains available in version history.

---

# 46. Version Rollback

Rollback should be implemented as a new version, not destructive mutation.

Example:

```text
Published v5
      ↓
Rollback to v3
      ↓
Create v6 using v3 content
      ↓
Publish v6
```

This preserves a complete audit trail.

---

# 47. Version Metadata

Recommended:

```text
version_id
template_id
version_number
subject
html_body
text_body
variables_schema
status
created_by
published_by
created_at
published_at
```

---

# 48. Version Immutability

Published versions should be immutable.

If content changes:

```text
new draft version
```

must be created.

Do not edit the body of a published version in place.

This is essential for reliable auditing.

---

# 49. Template Audit Events

Record:

- Template created.
- Template updated.
- Draft saved.
- Version created.
- Version published.
- Version archived.
- Version rollback.
- Template duplicated.
- Template archived.
- Template restored.
- Template deleted.

Audit records should include actor, project, template, action, timestamp, and safe metadata.

---

# 50. Template API

Conceptual endpoints:

```http
GET    /api/v1/projects/{project}/templates
POST   /api/v1/projects/{project}/templates
GET    /api/v1/projects/{project}/templates/{template}
PATCH  /api/v1/projects/{project}/templates/{template}
DELETE /api/v1/projects/{project}/templates/{template}

POST   /api/v1/projects/{project}/templates/{template}/duplicate
POST   /api/v1/projects/{project}/templates/{template}/preview
POST   /api/v1/projects/{project}/templates/{template}/publish
POST   /api/v1/projects/{project}/templates/{template}/archive

GET    /api/v1/projects/{project}/templates/{template}/versions
GET    /api/v1/projects/{project}/templates/{template}/versions/{version}
POST   /api/v1/projects/{project}/templates/{template}/versions
POST   /api/v1/projects/{project}/templates/{template}/versions/{version}/publish
POST   /api/v1/projects/{project}/templates/{template}/versions/{version}/rollback
```

Exact request/response contracts are defined in `11-REST-API-SPECIFICATION.md`.

---

# 51. Template Send API

The email API may reference a template:

```json
{
  "template": "welcome_email",
  "to": "user@example.com",
  "variables": {
    "user_name": "Raja",
    "app_name": "My App"
  }
}
```

Flow:

```text
API request
   ↓
Project/API-key auth
   ↓
Template lookup
   ↓
Published version lookup
   ↓
Variable validation
   ↓
Render
   ↓
EmailMessage
   ↓
Email Engine
```

---

# 52. Template Snapshot on Send

For reliable history, email logs should preserve enough information to identify the template/version used.

Recommended:

```text
template_id
template_version_id
template_key
```

Where privacy and storage policy permit, a rendered-content snapshot or deterministic reference may also be retained.

Historical logs must not change merely because the template is edited later.

---

# 53. Template Rendering Timing

Rendering should occur before provider selection or at the beginning of the email engine pipeline.

Preferred:

```text
Template
   ↓
Render
   ↓
Canonical EmailMessage
   ↓
Provider
```

Providers receive final message content, not template syntax.

---

# 54. Direct HTML vs Template

The platform may support two send modes:

### Template mode

```json
{
  "template": "welcome_email",
  "variables": {}
}
```

### Direct mode

```json
{
  "subject": "Hello",
  "html": "<p>Hello</p>"
}
```

Direct HTML is subject to the same message-security rules.

Template mode adds reusable versioned content.

---

# 55. Template Variables and Security

Variables may contain:

- User names.
- Verification codes.
- URLs.
- Order numbers.
- Dates.
- Company names.

Variables must never be allowed to:

- Execute PHP.
- Execute JavaScript.
- Run shell commands.
- Access database queries.
- Include arbitrary files.
- Call server-side functions.

The renderer is data substitution only.

---

# 56. No General-Purpose Template Code

Do not introduce PHP-style expressions such as:

```php
{{ system('command') }}
```

or arbitrary executable template languages.

The initial engine uses a deliberately constrained syntax.

This reduces:

- RCE risk.
- Sandbox complexity.
- SSRF risk.
- Data leakage.
- Maintenance burden.

---

# 57. Template Helper Functions

The initial locked scope should not include arbitrary helper execution.

If future helpers are introduced, they must be:

- Allowlisted.
- Pure.
- Deterministic.
- Non-networked.
- Non-file-accessing.
- Non-executable.
- Tested.

---

# 58. Date/Number Formatting

Initial implementation may keep formatting outside the template language.

API clients can provide already-formatted values.

Example:

```json
{
  "invoice_total": "$25.00"
}
```

This keeps the renderer simple and predictable.

Future formatting helpers may be added without enabling arbitrary code.

---

# 59. Template Size Limits

Apply configurable limits to prevent abuse.

Recommended categories:

```text
Template name length
Template key length
Subject length
HTML body size
Plain-text body size
Variable count
Variable name length
Description length
```

Limits must be documented and enforced server-side.

---

# 60. Template API Rate Limits

Template management endpoints should be rate-limited separately from high-volume send endpoints.

Examples:

- Create template.
- Update template.
- Publish.
- Preview.
- Duplicate.

This prevents abuse of expensive preview/render operations.

---

# 61. Preview Rate Limits

Preview rendering can be resource-intensive.

Protect it with:

- Per-user rate limit.
- Per-project rate limit.
- Request size limit.
- Maximum HTML size.
- Maximum variable count.
- Timeout.
- Safe rendering boundary.

---

# 62. Template Caching

Safe cache candidates:

- Published template metadata.
- Published version content.
- Parsed variable schema.

Cache key should include:

```text
project_id
template_id
published_version_id
```

Never cache rendered content across unrelated projects.

---

# 63. Cache Invalidation

When publishing a new version:

```text
Publish v4
   ↓
Invalidate template cache
   ↓
New sends use v4
```

Old version cache may be retained only where historical operations explicitly require it.

---

# 64. Template Repository

Recommended methods:

```text
findById()
findByKey()
listByProject()
create()
updateDraft()
archive()
restore()
delete()
```

Version repository:

```text
findVersion()
listVersions()
createVersion()
publishVersion()
archiveVersion()
```

Repositories perform persistence only.

---

# 65. Template Service

Recommended responsibilities:

```text
TemplateService
TemplateVersionService
TemplateValidationService
TemplateVariableService
TemplateRenderService
TemplatePreviewService
TemplatePublishService
```

Services coordinate business rules.

---

# 66. Renderer Interface

Recommended:

```php
interface TemplateRendererInterface
{
    public function render(
        TemplateVersion $template,
        array $variables
    ): RenderedTemplate;
}
```

Result:

```text
subject
html_body
text_body
used_variables
template_version_id
```

---

# 67. Renderer Determinism

Given:

```text
same template
+
same variables
```

the renderer should produce the same result, except for explicitly supported future dynamic features.

Avoid hidden external calls during rendering.

---

# 68. Rendering Performance

Rendering should be lightweight.

Avoid:

- Network requests.
- Database queries per variable.
- File-system scans.
- Arbitrary expression evaluation.
- Repeated parsing of the same published version.

Parsed templates may be cached.

---

# 69. Template Preview Architecture

Preferred:

```text
Browser
  ↓
POST preview
  ↓
TemplatePreviewService
  ↓
TemplateRenderer
  ↓
Sanitized preview document
  ↓
Sandboxed iframe
```

Do not execute user-authored template scripts.

---

# 70. Email Client Compatibility

The platform should provide documentation rather than promising universal compatibility.

Users should be informed that email clients differ in:

- CSS support.
- Image loading.
- Fonts.
- Dark mode.
- Media queries.
- JavaScript support.

JavaScript must not be relied upon inside email templates.

---

# 71. External Images

External images in email templates may be used.

The platform should warn users that:

- Some email clients block remote images.
- Tracking behavior may differ.
- HTTPS should be preferred.
- External image URLs should be trusted.

The platform should not automatically proxy arbitrary external images unless a future dedicated feature is implemented.

---

# 72. Template Links

Links should be validated for safe schemes.

Prefer:

```text
https://
```

Avoid dangerous schemes.

The template editor should provide link validation feedback.

---

# 73. Template Attachments

Attachments are primarily handled by the Email Engine.

Templates may define attachment metadata only if the future template system explicitly supports it.

Initial template variables should not allow arbitrary filesystem paths.

Never allow:

```text
{{/etc/passwd}}
{{file_path}}
```

to become server-side file access.

---

# 74. Template Internationalization

The initial locked scope does not require a full translation engine.

Projects may create separate templates for languages:

```text
welcome_en
welcome_ur
welcome_ar
```

Future localization can be introduced through a separate layer.

---

# 75. Template Search and Filtering

Template list should support:

- Search by name.
- Search by key.
- Filter by status.
- Sort by updated date.
- Sort by created date.
- Pagination.

Search must be project-scoped.

---

# 76. Template UI States

Required states:

```text
Loading
Empty
Draft
Published
Archived
Validation Error
Preview
Publish Success
Publish Failure
Delete Confirmation
Permission Denied
Rate Limited
Server Error
```

These states are part of the 93-screen UI system.

---

# 77. Template Editor Responsive Behavior

Desktop:

```text
Editor | Variables | Preview
```

Mobile:

```text
Editor
Variables
Preview
```

Use tabs, drawers, or stacked sections rather than forcing a desktop three-column layout onto small screens.

---

# 78. Accessibility

Template management UI must support:

- Keyboard navigation.
- Visible focus states.
- Semantic labels.
- Accessible form errors.
- Screen-reader-friendly controls.
- Adequate contrast.
- No color-only status indicators.
- Accessible dialogs.
- Accessible preview controls.

Code editors must provide accessible labels and a non-editor fallback where practical.

---

# 79. Template Editor Technology

The baseline frontend remains:

- HTML5.
- CSS3.
- Bootstrap 5.3+.
- JavaScript ES6+.
- Fetch API.

A specialized code editor may be introduced only if it does not conflict with the locked frontend architecture.

The editor must not force a framework rewrite.

---

# 80. Template Autosave

Autosave is optional.

If implemented:

- Save drafts only.
- Never auto-publish.
- Use debouncing.
- Show save status.
- Handle concurrent edits safely.
- Preserve explicit publish action.

---

# 81. Concurrent Editing

At minimum, the backend should prevent accidental overwrites using a version or updated-at check.

Example:

```text
Editor A loads v4
Editor B updates v4
Editor A tries to overwrite
      ↓
Conflict detected
```

Return a safe conflict response rather than silently losing B's changes.

---

# 82. Template Import/Export

Not required for initial locked scope.

If later introduced:

- Validate imported content.
- Sanitize HTML.
- Validate variable schemas.
- Prevent cross-project credential injection.
- Require explicit import confirmation.

Do not treat imported templates as trusted.

---

# 83. Template Cloning Across Projects

Not part of the initial scope.

If future cross-project cloning is introduced:

- Require explicit authorization.
- Strip project-specific secrets.
- Revalidate variables.
- Revalidate HTML.
- Create a new project-owned template identity.

---

# 84. Built-In System Variables

Avoid hidden variables where possible.

If system variables are introduced, they must be explicitly documented.

Example future variables:

```text
{{current_year}}
{{platform_name}}
```

They must be deterministic and safe.

---

# 85. Template and OTP

OTP templates may contain:

```text
{{otp_code}}
{{otp_expiry_minutes}}
{{app_name}}
```

The OTP service supplies values.

The template engine does not generate OTPs.

Correct:

```text
OTP Service
   ↓
generated OTP
   ↓
Template variables
   ↓
Renderer
   ↓
Email Engine
```

---

# 86. Template and Password Reset

Password reset template may contain:

```text
{{user_name}}
{{reset_url}}
{{expiry_minutes}}
```

The reset service generates the secure reset URL.

The template engine only renders the supplied value.

---

# 87. Template and Verification Email

Verification template may contain:

```text
{{user_name}}
{{verification_url}}
{{verification_code}}
{{app_name}}
```

The verification service creates the verification token/code.

The renderer does not create authentication tokens.

---

# 88. Template and Email Logs

When a template send succeeds or fails, email logs should record:

```text
template_id
template_version_id
template_key
provider_id
message_id
request_id
status
```

Sensitive variable values should not automatically be stored in logs.

---

# 89. Sensitive Variables

Potentially sensitive variables include:

```text
otp_code
reset_token
verification_token
private links
temporary credentials
```

The platform should avoid storing rendered sensitive values in general logs.

If a message snapshot is retained, apply the project's privacy/retention policy.

---

# 90. Template Data Privacy

Do not log the complete variables payload by default.

Instead log:

```text
variable_count
variable_names
```

where safe.

For example:

```json
{
  "template": "otp_email",
  "variables": [
    "user_name",
    "otp_code"
  ]
}
```

No actual OTP value is necessary.

---

# 91. Template Validation Errors

Normalized codes may include:

```text
TEMPLATE_NOT_FOUND
TEMPLATE_NOT_ACTIVE
TEMPLATE_VERSION_NOT_FOUND
TEMPLATE_INVALID_KEY
TEMPLATE_INVALID_HTML
TEMPLATE_INVALID_VARIABLE
TEMPLATE_VARIABLE_MISSING
TEMPLATE_VARIABLE_INVALID
TEMPLATE_UNRESOLVED_VARIABLE
TEMPLATE_RENDER_FAILED
TEMPLATE_PUBLISH_FAILED
```

These codes should be stable for API clients.

---

# 92. Example Render

Template:

```text
Subject:
Welcome, {{user_name}}

HTML:
<p>Hello {{user_name}}</p>
<p>Your account is ready.</p>
```

Input:

```json
{
  "user_name": "Raja"
}
```

Rendered:

```text
Subject:
Welcome, Raja

HTML:
<p>Hello Raja</p>
<p>Your account is ready.</p>
```

Then:

```text
RenderedTemplate
      ↓
EmailMessage
      ↓
Email Engine
```

---

# 93. Example API Request

```http
POST /api/v1/projects/project_123/email/send
Authorization: Bearer PROJECT_API_KEY
Content-Type: application/json
```

```json
{
  "template": "welcome_email",
  "to": "user@example.com",
  "variables": {
    "user_name": "Raja",
    "app_name": "My App"
  }
}
```

The public API contract remains stable even if the underlying provider changes.

---

# 94. Template Security Boundary

```text
Untrusted user input
        ↓
API validation
        ↓
Template validation
        ↓
Variable validation
        ↓
Safe renderer
        ↓
Canonical EmailMessage
        ↓
Email Engine
```

Never allow template content to bypass the normal email security pipeline.

---

# 95. Template Engine Testing

Unit tests:

- Variable parsing.
- Required variables.
- Optional variables.
- Defaults.
- HTML escaping.
- Text rendering.
- URL validation.
- Email validation.
- Invalid syntax.
- Unresolved variables.
- Version publishing.
- Rollback.
- Duplicate.
- Archive.

Integration tests:

- Template API.
- Project isolation.
- Rendering + Email Engine.
- Gmail provider.
- SMTP provider.
- Logs.
- Webhooks/events.

Security tests:

- XSS.
- Script injection.
- HTML injection.
- URL scheme injection.
- Template authorization bypass.
- Cross-project template access.
- Path traversal attempts.
- Template size abuse.

---

# 96. Template Performance Tests

Measure:

```text
parse time
render time
preview time
publish time
database lookup time
cache hit/miss
```

Stress-test:

- Large templates.
- Many variables.
- Concurrent previews.
- Concurrent sends.
- Multiple projects.

---

# 97. Template Migration Strategy

Database migrations must support:

- Templates.
- Template versions.
- Variable schemas.
- Status fields.
- Published version references.
- Audit relationships.

Migrations must be backward-compatible with deployed application versions where practical.

---

# 98. Template Database Model

Core relationships:

```text
projects
   │
   └── templates
          │
          └── template_versions
```

Suggested template fields:

```text
id
project_id
name
template_key
status
published_version_id
created_by
created_at
updated_at
```

Suggested version fields:

```text
id
template_id
version_number
subject
html_body
text_body
variables_schema
status
created_by
published_by
created_at
published_at
```

Exact schema and indexes are finalized in `09-DATABASE-SCHEMA.md`.

---

# 99. Template Database Constraints

Recommended:

- Unique `(project_id, template_key)`.
- Foreign key template → project.
- Foreign key version → template.
- Controlled status values.
- Version number unique per template.
- Published version belongs to the same template.
- Soft deletion/archive policy where required.

---

# 100. Transaction Rules

Publishing should be transactional.

Concept:

```text
BEGIN
  Validate draft
  Archive previous published version
  Publish new version
  Update template published_version_id
COMMIT
```

If any step fails:

```text
ROLLBACK
```

The system must not leave a template pointing to a non-published version.

---

# 101. Template Cache Consistency

When template state changes:

```text
Draft saved
    ↓
Draft cache update/invalidation

Published
    ↓
Published cache invalidation/update

Archived
    ↓
Sending cache invalidation
```

A disabled or archived template must not remain usable because of stale cache state.

---

# 102. Template Authorization

Required permission chain:

```text
Authenticated user
      ↓
Project access
      ↓
Template belongs to project
      ↓
User/admin permission
      ↓
Requested action
```

Do not trust:

```text
template_id
project_id
version_id
```

from the client without server-side relationship validation.

---

# 103. Template API Key Permissions

Project API keys may have scoped permissions such as:

```text
email:send
template:read
template:use
```

The minimum required permission should be used.

A send-only client should not automatically receive template-management privileges.

---

# 104. Template API and Public Clients

Static HTML/JS clients should only receive:

- Project API key with appropriate scope.
- Template key.
- Variable data.

They must never receive:

- SMTP password.
- Gmail refresh token.
- OAuth client secret.
- Database credentials.
- Application encryption key.

---

# 105. Template Engine Error Handling

Errors should return consistent API envelopes.

Example:

```json
{
  "success": false,
  "error": {
    "code": "TEMPLATE_VARIABLE_MISSING",
    "message": "A required template variable is missing.",
    "details": {
      "variable": "user_name"
    }
  }
}
```

Details must not reveal secrets.

---

# 106. Template Observability

Track:

```text
template_render_total
template_render_failure_total
template_preview_total
template_publish_total
template_publish_failure_total
template_variable_missing_total
```

Useful dimensions:

```text
project
template
version
error_category
```

Do not include sensitive variable values.

---

# 107. Template Governance

Templates are application assets and should be treated as version-controlled content.

Recommended operational practice:

```text
Draft
 ↓
Review
 ↓
Preview
 ↓
Publish
 ↓
Monitor
 ↓
Rollback if necessary
```

---

# 108. Template Review Checklist

Before publishing:

- [ ] Subject is valid.
- [ ] HTML is valid/safe.
- [ ] Plain text is valid where used.
- [ ] All variables are defined.
- [ ] Required variables are intentional.
- [ ] URLs are safe.
- [ ] Preview looks correct.
- [ ] Mobile layout reviewed.
- [ ] No test credentials remain.
- [ ] No accidental secrets exist.
- [ ] Correct project selected.
- [ ] Version is identified.
- [ ] Publish action is intentional.

---

# 109. Template Engine Definition of Done

The Template Engine is complete when:

- Templates can be created.
- Templates can be edited.
- Templates can be duplicated.
- Templates can be archived.
- Versions are immutable after publication.
- Draft and published states are separate.
- Variables are defined and validated.
- Missing variables fail safely.
- HTML variables are escaped.
- Unsafe HTML is handled.
- Preview is sandboxed.
- Template rendering is deterministic.
- Published versions are used for production sends.
- Rollback creates a new version.
- Template sends integrate with the Email Engine.
- Project isolation is enforced.
- Sensitive values are not leaked into logs.
- API permissions are enforced.
- Caching is project/version aware.
- Automated tests cover rendering/security/versioning.
- Responsive/accessibility requirements are met.

---

# 110. Non-Negotiable Template Rules

1. Templates are project-scoped.
2. Published versions are immutable.
3. Drafts never automatically publish.
4. Required variables must be supplied.
5. Unresolved variables must not reach production email.
6. Variables are data, not executable code.
7. No arbitrary PHP execution.
8. No arbitrary JavaScript execution.
9. No arbitrary server-side file access.
10. No network calls during rendering.
11. HTML variables are escaped by default.
12. Raw HTML variables are not enabled by default.
13. URL schemes must be validated.
14. Template previews must be isolated.
15. Template IDs must be authorization-checked.
16. Version rollback must preserve history.
17. Template sends use the Email Engine.
18. Providers never render templates.
19. Templates never send directly.
20. Sensitive variable values must not be logged.
21. Template API responses must not expose secrets.
22. Template keys are unique within a project.
23. Publish operations are transactional.
24. Cache must respect project/version boundaries.
25. Preview endpoints must be rate-limited.
26. Template size limits must be enforced server-side.
27. API keys must have least-privilege permissions.
28. Imported/future external templates must be treated as untrusted.
29. New template features must preserve the constrained renderer security model.
30. Template architecture must remain provider-independent.

---

# 111. Final Template Architecture

```text
                  ┌─────────────────────────┐
                  │ Dashboard / REST API    │
                  └────────────┬────────────┘
                               │
                               ▼
                  ┌─────────────────────────┐
                  │   Template Service      │
                  └────────────┬────────────┘
                               │
              ┌────────────────┼────────────────┐
              │                │                │
              ▼                ▼                ▼
       ┌────────────┐   ┌─────────────┐  ┌──────────────┐
       │ Repository │   │ Validation  │  │ Versioning   │
       └─────┬──────┘   └──────┬──────┘  └──────┬───────┘
             │                 │                │
             └─────────────────┼────────────────┘
                               │
                               ▼
                  ┌─────────────────────────┐
                  │   Template Renderer     │
                  │ Variables / Escaping    │
                  └────────────┬────────────┘
                               │
                               ▼
                  ┌─────────────────────────┐
                  │    Rendered Email       │
                  │    Canonical DTO        │
                  └────────────┬────────────┘
                               │
                               ▼
                  ┌─────────────────────────┐
                  │      Email Engine       │
                  └────────────┬────────────┘
                               │
                               ▼
                  ┌─────────────────────────┐
                  │    Provider Resolver    │
                  └────────────┬────────────┘
                               │
                    ┌──────────┼──────────┐
                    ▼          ▼          ▼
                  Gmail       SMTP    Optional
```

---

# 112. Final Lock

This document establishes the Template Engine architecture for the Email API Platform.

The following decisions are locked:

- Templates are project-scoped.
- Templates use versioned content.
- Published versions are immutable.
- Draft and published states are separate.
- `{{variable_name}}` is the canonical variable syntax.
- Variables are data substitutions only.
- No arbitrary code execution exists in the renderer.
- Required and optional variables are explicitly defined.
- HTML output is escaped/sanitized according to context.
- URL and email variables are validated.
- Unresolved placeholders block production sending.
- Preview is isolated from the main dashboard origin.
- Template rendering is provider-independent.
- The Email Engine receives rendered canonical messages.
- Provider adapters never render templates.
- Template sends preserve template/version references in logs.
- Sensitive variable values are not logged by default.
- Publishing is transactional.
- Rollback creates a new version.
- Cache keys are project/version scoped.
- API authorization is enforced server-side.
- Template management supports responsive and accessible UI.
- New renderer features must preserve the constrained security model.

**STATUS: FINAL / LOCKED**

**Next document:** `16-PROJECTS-API-KEYS-WEBHOOKS.md`
