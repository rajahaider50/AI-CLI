# EMAIL API PLATFORM — MASTER BLUEPRINT

**Document ID:** 00  
**Document:** `00-MASTER-BLUEPRINT.md`  
**Status:** FINAL / LOCKED  
**Project:** EMAIL-API-PLATFORM-BLUEPRINT  
**Documentation Set:** 25 Markdown Documents  
**Primary Backend:** PHP 8.3+  
**Database:** MySQL 8+  
**API Style:** REST + JSON  
**Primary Providers:** Gmail + Custom SMTP  
**Optional Providers:** Brevo + Mailtrap  

---

## 1. DOCUMENT PURPOSE

This document is the master authority for the Email API Platform project.

It defines the final product direction, documentation architecture, technology boundaries, major modules, screen scope, provider strategy, security principles, asset rules, development order, and cross-document dependencies.

The remaining 24 Markdown documents provide detailed specifications for individual areas. They must remain consistent with this document.

If a lower-level document conflicts with this master document, the conflict must be resolved in favor of the latest explicitly approved project decision. Until an explicit project decision is made, this master blueprint is the baseline authority.

---

## 2. PRODUCT VISION

The platform is a professional Email API and transactional email service designed primarily for HTML websites and HTML web applications.

A developer should be able to build a frontend using only HTML, CSS, and JavaScript, then send emails through this platform without requiring PHP on the customer's own website.

The integration model is:

```text
HTML Website / HTML Web App
        |
        | JavaScript Fetch / HTTPS Request
        v
PHP REST API
        |
        +---- Authentication / API Key
        |
        +---- Project
        |
        +---- Template Engine
        |
        +---- Email Engine
        |
        +---- Provider Adapter
        |        |
        |        +---- Gmail
        |        +---- SMTP
        |        +---- Brevo
        |        +---- Mailtrap
        |
        v
Recipient Email
```

The platform also provides OTP delivery, email verification, templates, project management, API keys, logs, usage information, webhooks, security controls, and a centralized administration panel.

---

## 3. FINAL PROJECT SCOPE

### 3.1 Primary objective

Provide a reusable hosted email backend for:

- Static HTML websites
- HTML/CSS/JavaScript applications
- Landing pages
- Contact forms
- Registration forms
- Login verification
- Email verification
- Password recovery
- OTP delivery
- Transactional email
- Developer API integrations

### 3.2 Core product promise

The customer-facing website/application does not need PHP.

The customer's frontend sends a secure HTTPS request to the platform's REST API. The platform authenticates the request, validates the project, renders the requested template, selects the configured email provider, sends the email, and records the result.

---

## 4. FINAL DOCUMENTATION SET

The project documentation contains exactly **25 Markdown files**.

```text
EMAIL-API-PLATFORM-BLUEPRINT/
│
├── 00-MASTER-BLUEPRINT.md
│
├── 01-PROJECT-OVERVIEW.md
├── 02-FINAL-SCOPE-AND-FEATURES.md
├── 03-SYSTEM-ARCHITECTURE.md
├── 04-TECHNOLOGY-STACK.md
│
├── 05-UI-UX-DESIGN-SYSTEM.md
├── 06-SCREENS-AND-NAVIGATION.md
├── 07-ASSETS-ICONS-FONTS-LOGOS.md
│
├── 08-DATABASE-ARCHITECTURE.md
├── 09-DATABASE-SCHEMA.md
│
├── 10-BACKEND-PHP-ARCHITECTURE.md
├── 11-REST-API-SPECIFICATION.md
├── 12-AUTHENTICATION-AND-OTP.md
├── 13-EMAIL-ENGINE.md
├── 14-EMAIL-PROVIDERS.md
├── 15-TEMPLATE-ENGINE.md
├── 16-PROJECTS-API-KEYS-WEBHOOKS.md
│
├── 17-USER-PANEL.md
├── 18-ADMIN-PANEL.md
│
├── 19-SECURITY-ARCHITECTURE.md
├── 20-FRONTEND-DEVELOPMENT-GUIDE.md
├── 21-RESPONSIVE-ACCESSIBILITY-PERFORMANCE.md
│
├── 22-TESTING-QA-AND-ERROR-HANDLING.md
├── 23-DEPLOYMENT-MAINTENANCE-AND-DEVELOPER-GUIDE.md
│
└── 24-DEVELOPMENT-RULES-CHECKLIST.md
```

---

## 5. FINAL SCREEN SCOPE

The approved product scope contains **93 screens/states**.

### Public Website — 10

1. Home
2. Features
3. How It Works
4. Providers
5. API Documentation
6. Pricing
7. FAQ
8. Contact
9. Privacy Policy
10. Terms & Conditions

### Authentication — 7

11. Login
12. Register
13. Email Verification
14. OTP Verification
15. Forgot Password
16. Reset Password
17. Account Recovery

### User Panel — 33

18. User Dashboard
19. Projects
20. Create Project
21. Project Overview
22. Project Settings
23. Email Services
24. Add Gmail
25. Gmail Connection Success
26. Add SMTP
27. SMTP Connection Test
28. Provider Management
29. Email Templates
30. Create Template
31. Template Editor
32. Template Preview
33. Template Variables
34. Email Send
35. Test Email
36. API Integration
37. API Keys
38. API Key Create
39. API Documentation
40. Email Logs
41. Email Log Details
42. OTP Logs
43. Usage & Statistics
44. Webhooks
45. Webhook Settings
46. Notifications
47. Profile Settings
48. Security Settings
49. Password Change
50. Active Sessions

### Admin Panel — 37

51. Admin Dashboard
52. Users
53. User Details
54. Add User
55. Edit User
56. Projects
57. Project Details
58. Project Management
59. Email Providers
60. Gmail Connections
61. SMTP Connections
62. Brevo Connections
63. Mailtrap Connections
64. Email Logs
65. Email Log Details
66. OTP Logs
67. API Logs
68. Webhook Logs
69. Templates
70. Template Details
71. API Keys
72. API Usage
73. Analytics
74. System Statistics
75. Security Dashboard
76. Blocked IPs
77. Rate Limits
78. Login Attempts
79. Security/Audit Logs
80. System Settings
81. Email Settings
82. OTP Settings
83. API Settings
84. General Settings
85. Admin Accounts
86. Admin Profile
87. Admin Security

### System — 6

88. 404
89. 403
90. 429 Rate Limited
91. 500 Server Error
92. Maintenance
93. API Error Response

**Final screen count: 93.**

---

## 6. FINAL CORE MODULES

The platform contains **24 core modules**:

1. User Authentication
2. Email Verification
3. OTP System
4. Password Recovery
5. User Profile
6. Project Management
7. Gmail Integration
8. SMTP Integration
9. Optional Provider Engine
10. Email Template Engine
11. Template Variables
12. Email Sending Engine
13. REST API
14. API Key System
15. Webhook System
16. Email Logs
17. OTP Logs
18. Usage Analytics
19. Rate Limiting
20. Security System
21. Session Management
22. Notification System
23. Admin Management
24. System Configuration

These modules are the stable functional foundation of the product.

---

## 7. FINAL PROVIDER ARCHITECTURE

### Primary providers

- Gmail
- Custom SMTP

### Optional built-in providers

- Brevo
- Mailtrap

The backend must use a provider abstraction/adapter architecture.

Conceptually:

```text
EmailEngine
    |
    v
ProviderInterface
    |
    +-- GmailProvider
    +-- SmtpProvider
    +-- BrevoProvider
    +-- MailtrapProvider
```

The Email Engine must not contain provider-specific logic directly when an adapter can isolate it.

This allows future providers to be added without rewriting the public API, template system, project system, or dashboard.

---

## 8. FINAL TECHNOLOGY BASELINE

### Frontend

- HTML5
- CSS3
- JavaScript ES6+
- Bootstrap 5.3+
- Fetch API
- Responsive CSS
- CSS custom properties
- Lightweight CSS transitions/animations
- GSAP only where advanced animation materially improves UX

### Backend

- PHP 8.3+
- REST architecture
- JSON responses
- PDO
- Modular service architecture
- PHPMailer for SMTP/email transport where appropriate
- OAuth 2.0 for Gmail authorization

### Database

- MySQL 8+
- Relational schema
- Foreign keys
- Appropriate indexes
- Transaction support
- UTC timestamps at the storage layer

### Server

- Apache or Nginx
- PHP-FPM where applicable
- HTTPS
- Cron support
- Environment-based configuration

The detailed rationale and version policy are defined in `04-TECHNOLOGY-STACK.md`.

---

## 9. FINAL DATABASE DOMAIN

The approved database domain contains these principal entities:

```text
users
user_profiles
email_verifications
otp_codes
sessions

projects
project_settings

providers
user_providers
gmail_connections
smtp_connections

templates
template_versions

api_keys
api_requests

email_logs
otp_logs

webhooks
webhook_logs

notifications
usage_statistics

login_attempts
blocked_ips
security_logs

admin_users
admin_logs

system_settings
```

The complete schema, column definitions, indexes, constraints, and relationships belong in:

- `08-DATABASE-ARCHITECTURE.md`
- `09-DATABASE-SCHEMA.md`

No database table should be added casually during implementation. New persistent data requirements must be evaluated against the existing domain model first.

---

## 10. FINAL API MODEL

The platform exposes a REST/JSON API.

Primary API domains include:

```text
/auth
/email
/otp
/projects
/templates
/providers
/api-keys
/webhooks
/logs
/usage
/health
```

The exact endpoint catalog belongs to `11-REST-API-SPECIFICATION.md`.

### API principles

- HTTPS only in production
- JSON request/response format
- Consistent HTTP status codes
- Consistent error object structure
- Authentication before protected operations
- Project/API-key authorization
- Input validation
- Rate limiting
- Auditability
- No sensitive credentials in normal API responses

---

## 11. FINAL AUTHENTICATION MODEL

The platform has two major authentication contexts.

### User dashboard authentication

Used for:

- Registration
- Login
- Email verification
- Password recovery
- Dashboard sessions
- Account security

### Developer API authentication

Used for:

- Sending email
- Sending OTP
- Accessing project-level API functionality

API credentials must be project-scoped wherever practical.

Sensitive credentials must never be exposed after creation unless the design explicitly requires a one-time display.

---

## 12. FINAL OTP MODEL

OTP is a first-class platform feature.

Supported purposes include:

- Email verification
- Login/verification flows where enabled
- Password recovery
- Application-specific OTP delivery

OTP rules include:

- Cryptographically secure code generation
- Short expiration window
- Maximum verification attempts
- Resend throttling
- Rate limiting
- Purpose binding
- User/account binding
- Secure storage
- Log/audit support

The exact lifecycle is defined in `12-AUTHENTICATION-AND-OTP.md`.

---

## 13. FINAL EMAIL ENGINE MODEL

The Email Engine is the central backend service.

```text
API Request
    |
    v
Authentication
    |
    v
Request Validation
    |
    v
Project Validation
    |
    v
Template Resolution
    |
    v
Variable Validation
    |
    v
Provider Selection
    |
    v
Provider Adapter
    |
    v
Send
    |
    +---- Success ---> Email Log
    |
    +---- Failure ---> Error/Retry Policy ---> Email Log
```

The engine must be provider-independent at the orchestration layer.

---

## 14. FINAL TEMPLATE MODEL

Templates are unlimited at the product architecture level.

A template can contain:

- Subject
- HTML body
- Plain-text fallback where supported
- Variables
- Status
- Version
- Metadata
- Creation/update timestamps

Example variable syntax:

```text
{{name}}
{{email}}
{{otp}}
{{verification_link}}
```

Variables must be validated and safely substituted.

HTML template rendering must prevent unintended server-side execution.

---

## 15. FINAL PROJECT MODEL

A project represents one website/application integration.

Example:

```text
User
  |
  +-- Project: My Website
  |      |
  |      +-- API Key
  |      +-- Templates
  |      +-- Provider
  |      +-- Logs
  |
  +-- Project: My Mobile Web App
         |
         +-- API Key
         +-- Templates
         +-- Provider
         +-- Logs
```

Project-level separation is essential for:

- Security
- API keys
- Usage
- Templates
- Logs
- Provider configuration
- Integration management

---

## 16. FINAL SECURITY BASELINE

Security is a core architectural requirement.

The platform must include:

- Password hashing
- Secure sessions
- CSRF protection
- XSS protection
- SQL injection prevention
- Prepared statements
- Input validation
- Output encoding/sanitization
- API key protection
- OAuth token encryption
- SMTP credential encryption
- OTP expiry
- OTP attempt limits
- Login rate limiting
- API rate limiting
- IP controls
- Security logs
- Admin audit logs
- Secure headers
- HTTPS enforcement
- CORS policy
- Session revocation

Secrets must be stored outside publicly accessible source files.

Detailed controls belong in `19-SECURITY-ARCHITECTURE.md`.

---

## 17. FINAL UI/UX DIRECTION

The visual identity is a professional modern SaaS dashboard.

### Design principles

- Clean
- Professional
- Fast
- Consistent
- Accessible
- Responsive
- Mobile-first
- Developer-friendly

### UI components

- Sidebar
- Top navigation
- Cards
- Tables
- Forms
- Modals
- Tabs
- Dropdowns
- Toast notifications
- Alerts
- Badges
- Tooltips
- Breadcrumbs
- Pagination
- Search
- Filters
- Empty states
- Loading states
- Error states

Animations must improve feedback and hierarchy rather than create visual noise.

---

## 18. FINAL ASSET POLICY

### Brand

Six primary brand logo variants are planned:

1. Full logo — light
2. Full logo — dark
3. Icon logo — light
4. Icon logo — dark
5. Horizontal logo
6. Compact logo

### Provider assets

Provider branding includes:

- Gmail
- SMTP
- Brevo
- Mailtrap

Provider logos must follow the relevant brand's permitted usage requirements.

### UI icons

Primary UI icon system:

- Lucide Icons

Technology/brand icon system:

- Simple Icons
- Official provider SVG assets where required

### Fonts

Primary UI font:

- Inter

Code/API font:

- JetBrains Mono

### Custom assets

The project may include original:

- Illustrations
- Empty-state graphics
- Loading graphics
- API graphics
- Security graphics
- Email graphics
- Onboarding graphics

Preferred image formats:

```text
SVG > WebP > PNG > JPG
```

No watermarked, random, low-quality, or improperly licensed assets are permitted.

---

## 19. FINAL RESPONSIVE TARGET

The complete application must support:

- Small mobile
- Standard mobile
- Tablet
- Laptop
- Desktop
- Large desktop

Both portrait and landscape orientations must be considered where relevant.

Touch interactions and keyboard navigation must be supported.

---

## 20. FINAL SECURITY AND PRIVACY PRINCIPLE

The platform handles potentially sensitive information such as:

- User account information
- Email addresses
- API keys
- OAuth tokens
- SMTP credentials
- Email metadata
- OTP-related data

Therefore:

1. Collect only required data.
2. Encrypt sensitive secrets at rest where appropriate.
3. Never log raw credentials.
4. Never expose credentials in client-side HTML.
5. Never return secrets unnecessarily through APIs.
6. Restrict administrative access.
7. Maintain security/audit logs.
8. Apply least-privilege principles.
9. Use HTTPS in production.
10. Provide safe deletion/revocation mechanisms.

---

## 21. FINAL ERROR-HANDLING MODEL

The system must provide predictable error behavior.

### User-facing states

- Validation error
- Authentication error
- Permission error
- Not found
- Rate limited
- Provider error
- Temporary service error
- Internal server error

### HTTP baseline

```text
200 OK
201 Created
204 No Content
400 Bad Request
401 Unauthorized
403 Forbidden
404 Not Found
409 Conflict
422 Unprocessable Entity
429 Too Many Requests
500 Internal Server Error
503 Service Unavailable
```

API responses should use a consistent structure, for example:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The request contains invalid data.",
    "details": {}
  },
  "request_id": "..."
}
```

Exact schemas belong in the API specification.

---

## 22. FINAL LOGGING MODEL

The platform must distinguish between operational logs and security/audit logs.

### Operational areas

- Email requests
- Email delivery attempts
- OTP operations
- API requests
- Webhooks
- Provider responses
- Usage

### Security areas

- Login attempts
- Authentication failures
- API key events
- Credential changes
- Admin actions
- IP blocking
- Security events

Sensitive values must be redacted.

---

## 23. FINAL ADMIN AUTHORITY

The Admin Panel provides centralized management over:

- Users
- Projects
- Providers
- Templates
- Email logs
- OTP logs
- API logs
- Webhooks
- Usage
- Security
- IP controls
- Rate limits
- System settings
- Admin accounts
- Audit logs

Administrative permissions should be designed so that privileged actions can be restricted as the platform grows.

---

## 24. FINAL DEVELOPMENT ORDER

Development documentation and implementation should follow this order:

```text
00 MASTER
  ↓
01 PROJECT OVERVIEW
  ↓
02 SCOPE
  ↓
03 SYSTEM ARCHITECTURE
  ↓
04 TECHNOLOGY STACK
  ↓
05 UI/UX
  ↓
06 SCREENS
  ↓
07 ASSETS
  ↓
08 DATABASE ARCHITECTURE
  ↓
09 DATABASE SCHEMA
  ↓
10 PHP BACKEND
  ↓
11 REST API
  ↓
12 AUTH + OTP
  ↓
13 EMAIL ENGINE
  ↓
14 PROVIDERS
  ↓
15 TEMPLATE ENGINE
  ↓
16 PROJECTS + API KEYS + WEBHOOKS
  ↓
17 USER PANEL
  ↓
18 ADMIN PANEL
  ↓
19 SECURITY
  ↓
20 FRONTEND
  ↓
21 RESPONSIVE + ACCESSIBILITY + PERFORMANCE
  ↓
22 TESTING + QA
  ↓
23 DEPLOYMENT + MAINTENANCE
  ↓
24 DEVELOPMENT RULES
```

This order minimizes architectural rework.

---

## 25. CROSS-DOCUMENT RESPONSIBILITIES

| Document | Authority |
|---|---|
| 00 | Master project decisions |
| 01 | Product overview |
| 02 | Features and scope |
| 03 | System architecture |
| 04 | Technology choices |
| 05 | UI/UX design system |
| 06 | Screens and navigation |
| 07 | Assets, icons, fonts, logos |
| 08 | Database architecture |
| 09 | Exact database schema |
| 10 | PHP backend architecture |
| 11 | REST API contract |
| 12 | Authentication and OTP |
| 13 | Email engine |
| 14 | Provider integrations |
| 15 | Template engine |
| 16 | Projects/API keys/webhooks |
| 17 | User panel |
| 18 | Admin panel |
| 19 | Security |
| 20 | Frontend development |
| 21 | Responsive/accessibility/performance |
| 22 | Testing and QA |
| 23 | Deployment/maintenance |
| 24 | Developer rules/checklist |

---

## 26. FINAL NON-NEGOTIABLE RULES

### Architecture

- Do not mix frontend and backend responsibilities unnecessarily.
- Keep provider-specific logic inside provider adapters.
- Keep database access centralized.
- Keep API contracts explicit.
- Keep authentication and authorization separate.
- Avoid duplicated business logic.

### Security

- Never store plaintext passwords.
- Never expose secrets to the frontend.
- Never log passwords, API secrets, OAuth tokens, or SMTP passwords.
- Never concatenate untrusted input into SQL.
- Never disable security protections for convenience.

### Frontend

- Reuse components.
- Keep responsive behavior intentional.
- Use semantic HTML.
- Provide loading/error/empty states.
- Avoid unnecessary dependencies.

### Backend

- Validate every external input.
- Use prepared statements.
- Return consistent JSON.
- Log safely.
- Use transactions where atomicity is required.

### Assets

- Use approved/licensed assets.
- Prefer SVG for icons and logos.
- Optimize raster images.
- Do not use watermarked graphics.
- Maintain consistent visual language.

### Documentation

- Every major implementation decision must map to an appropriate document.
- API changes must be reflected in the API specification.
- Database changes must be reflected in the schema documentation.
- Security changes must be reflected in the security document.
- No undocumented breaking changes.

---

## 27. DEFINITION OF DONE

A module is not considered complete until:

- Functional requirements are implemented.
- Validation exists.
- Authorization exists where required.
- Security controls are applied.
- Error states are handled.
- Loading states are handled.
- Mobile layout is checked.
- Desktop layout is checked.
- Relevant API behavior is tested.
- Relevant database operations are tested.
- Logs are appropriate.
- Documentation is updated.
- No sensitive information is accidentally exposed.

---

## 28. FINAL PROJECT NUMBERS

```text
Documentation Files       = 25 MD files
Screens / States          = 93
Core Modules              = 24
User Features             = 29
API Feature Areas         = 14
Security Feature Areas    = 25

Primary Providers         = 2
Optional Providers        = 2

Primary UI Icon System    = Lucide
Brand/Tech Icons          = Simple Icons + approved official assets

Primary Font              = Inter
Code Font                 = JetBrains Mono

Frontend                  = HTML5 + CSS3 + JavaScript
UI Framework              = Bootstrap 5.3+
Backend                   = PHP 8.3+
Database                  = MySQL 8+
API                       = REST + JSON
Email Transport           = Gmail OAuth / SMTP
Server                    = Apache or Nginx
```

---

## 29. FINAL STATUS

**PROJECT BLUEPRINT STATUS: LOCKED**

This master document establishes the baseline for the remaining 24 documents.

The next document in the approved sequence is:

```text
01-PROJECT-OVERVIEW.md
```

The next document must build on this master blueprint and must not redefine the project scope independently.

---

**End of `00-MASTER-BLUEPRINT.md`**
