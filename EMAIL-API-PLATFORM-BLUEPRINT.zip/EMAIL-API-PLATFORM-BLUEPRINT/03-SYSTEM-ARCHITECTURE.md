# EMAIL API PLATFORM — SYSTEM ARCHITECTURE

**Document ID:** 03  
**Filename:** `03-SYSTEM-ARCHITECTURE.md`  
**Status:** FINAL / LOCKED  
**Project:** EMAIL-API-PLATFORM-BLUEPRINT

---

## 1. Purpose

This document defines the approved technical architecture of the Email API Platform.

The architecture is a **modular layered monolith** built with PHP 8.3+, MySQL 8+, REST/JSON, PDO, PHPMailer, Gmail OAuth 2.0, Apache or Nginx, PHP-FPM, HTTPS, and cron.

The architecture is intentionally simple enough for low-cost self-hosting while maintaining clear boundaries for future scaling and provider expansion.

---

# 2. High-Level Architecture

```text
Static HTML / Web App
        |
        | HTTPS + Fetch + JSON
        v
+-----------------------------+
| Web Server                  |
| Apache / Nginx + HTTPS      |
+-------------+---------------+
              |
              v
+-----------------------------+
| PHP Application             |
|                             |
| Routing                     |
| Middleware                  |
| Authentication              |
| Authorization               |
| Controllers                |
| Application Services        |
| Domain Logic                |
| Provider Manager            |
| Data Access                 |
+----------+----------+-------+
           |          |
           v          v
      +---------+  +------------------+
      | MySQL 8 |  | Provider Adapters|
      +---------+  +--------+---------+
                             |
                  +----------+----------+
                  |          |          |
                Gmail      SMTP      Optional
                                      Providers
```

---

# 3. Architecture Principles

The platform must follow these principles:

1. **Server-side security** — provider credentials and sensitive secrets never belong in client JavaScript.
2. **Project isolation** — projects are the primary resource boundary.
3. **Provider neutrality** — the email engine works through a common provider interface.
4. **Thin controllers** — controllers coordinate requests rather than contain business logic.
5. **Service-oriented application logic** — business workflows live in reusable services.
6. **Prepared database access** — all database input uses PDO/prepared statements.
7. **Stable API contracts** — public API behavior is versioned and documented.
8. **Secure by default** — authentication, authorization, rate limits, validation, and logging are built into the architecture.
9. **Low-cost deployment** — the first deployment does not require Kubernetes, Redis, Kafka, or microservices.
10. **Future-ready boundaries** — queues, workers, multiple servers, and additional providers can be introduced without redesigning the core API.

---

# 4. Architectural Style

The approved architecture is a **modular monolith**.

It is one deployable PHP application, but internally separated into modules.

```text
One Deployment
      |
      +-- Authentication
      +-- Projects
      +-- Templates
      +-- Email Engine
      +-- Providers
      +-- API Keys
      +-- Webhooks
      +-- Logs
      +-- Usage
      +-- Security
      +-- Notifications
      +-- Admin
```

This avoids premature distributed-system complexity while preserving clean internal boundaries.

---

# 5. Logical Layers

The application is divided into:

1. Presentation Layer
2. HTTP/API Layer
3. Middleware Layer
4. Controller Layer
5. Application Service Layer
6. Domain/Business Logic Layer
7. Provider Abstraction Layer
8. Data Access Layer
9. Infrastructure Layer
10. External Provider Layer

Preferred dependency direction:

```text
Presentation
     |
     v
HTTP/API
     |
     v
Controllers
     |
     v
Application Services
     |
     v
Domain Logic
     |
 +---+----------------+
 |                    |
 v                    v
Data Access      Provider Abstraction
 |                    |
 v                    v
MySQL             Adapters
                       |
                       v
                External Providers
```

Lower-level infrastructure must not force business logic to depend on provider-specific implementation details.

---

# 6. Client Architecture

The primary product requirement is that a client website can send email without PHP.

```text
Static HTML
    |
    +-- JavaScript Fetch
    |
    v
HTTPS REST API
    |
    v
Email API Platform
```

The client only needs:

- HTML
- CSS
- JavaScript
- Internet access
- A project API credential

The client does **not** need:

- PHP
- MySQL
- PHPMailer
- Gmail credentials
- SMTP credentials

---

# 7. Client Request Lifecycle

```text
1. Browser creates request
2. HTTPS connection
3. API route matched
4. Request ID created
5. CORS policy evaluated
6. API key authenticated
7. Project resolved
8. Authorization checked
9. Rate limit checked
10. JSON parsed
11. Input validated
12. Controller invoked
13. Application service runs
14. Email engine processes request
15. Provider adapter sends email
16. Result normalized
17. Logs/usage/webhook events updated
18. JSON response returned
```

---

# 8. Public API Boundary

The REST API is the primary integration boundary.

Recommended versioned structure:

```text
/api/v1/...
```

Example endpoint families:

```text
/api/v1/email/send
/api/v1/otp/send
/api/v1/otp/verify
/api/v1/templates
/api/v1/projects
/api/v1/providers
/api/v1/logs
/api/v1/usage
/api/v1/webhooks
```

Exact routes are defined in `11-REST-API-SPECIFICATION.md`.

---

# 9. Request ID

Every API request should receive a unique request ID.

Example:

```text
req_01HXYZ...
```

The request ID should be available in:

- API responses
- API logs
- Email logs where relevant
- Error logs
- Provider troubleshooting
- Webhook correlation where useful

Example:

```json
{
  "success": true,
  "request_id": "req_01HXYZ..."
}
```

Request IDs must not contain secrets or unnecessary personal information.

---

# 10. Middleware Architecture

Middleware handles cross-cutting request concerns.

Typical flow:

```text
Request
  |
  v
Request ID
  |
  v
HTTPS / Security Policy
  |
  v
CORS
  |
  v
Authentication
  |
  v
API Key Validation
  |
  v
Project Authorization
  |
  v
Rate Limiting
  |
  v
Validation
  |
  v
Controller
```

Not every endpoint requires every middleware layer. Public authentication routes, for example, do not require project API-key authentication.

---

# 11. Authentication Architecture

There are two major authentication contexts.

## 11.1 User Authentication

Used for the dashboard and account functionality.

Includes:

- Registration
- Login
- Logout
- Email verification
- OTP verification where applicable
- Password recovery
- Session management

This uses secure server-side sessions.

## 11.2 Project API Authentication

Used by client applications.

This uses project-scoped API keys.

These authentication mechanisms must remain separate.

---

# 12. Authorization Architecture

Authentication establishes identity. Authorization establishes access.

Example:

```text
Authenticated Identity
        |
        v
Requested Project
        |
        +--> Owner/member relationship valid?
        +--> Project active?
        +--> API key belongs to project?
        +--> Operation allowed?
        |
        v
Authorized Operation
```

No request may access a project merely because it supplies a valid project ID.

---

# 13. Project Isolation

Projects are the central isolation boundary.

```text
Project
├── Project Settings
├── Provider Connections
├── Templates
├── API Keys
├── Webhooks
├── Email Logs
├── OTP Logs
└── Usage Statistics
```

Every project-owned resource must be linked to the project.

Every project must be linked to its owning user.

---

# 14. Project Security Rules

The application must enforce:

- Users can access only their authorized projects.
- API keys are project-scoped.
- Templates are project-scoped.
- Provider connections are project-scoped.
- Logs are project-scoped.
- Webhooks are project-scoped.
- Usage is project-scoped.
- Project identifiers supplied by clients must be authorized server-side.
- Cross-project access must be rejected.

---

# 15. Controller Architecture

Controllers must remain thin.

A controller should:

1. Receive the request.
2. Obtain validated input.
3. Invoke the appropriate service.
4. Map the result to an HTTP response.

Controllers should not contain:

- Raw SQL
- Gmail API implementation
- SMTP implementation
- Complex template rendering
- Large security workflows
- Repeated business rules

Conceptually:

```text
EmailController
      |
      v
EmailService
      |
      +--> ProjectService
      +--> TemplateService
      +--> ProviderService
      +--> EmailEngine
      +--> LogService
      +--> UsageService
```

---

# 16. Application Service Layer

Services coordinate complete use cases.

Core services include:

```text
AuthService
ProjectService
TemplateService
EmailService
OtpService
ApiKeyService
ProviderService
WebhookService
UsageService
NotificationService
SessionService
SecurityService
AdminService
```

Services must contain reusable workflows rather than simply duplicating database-table operations.

---

# 17. Domain Logic

Business rules include:

- Project ownership
- Template rules
- Variable processing
- API key lifecycle
- OTP expiry
- OTP attempts
- Provider availability
- Email validation
- Webhook event creation
- Usage accounting
- Security policies

Domain rules should be reusable by the web UI, API, workers, and administrative workflows.

---

# 18. Provider Abstraction

The email engine must not directly depend on Gmail or SMTP.

```text
EmailService
      |
      v
ProviderManager
      |
      v
EmailProviderInterface
      |
      +--> GmailAdapter
      +--> SMTPAdapter
      +--> BrevoAdapter
      +--> MailtrapAdapter
```

A new provider should be implemented as an adapter rather than by modifying the core email engine.

---

# 19. Provider Contract

The provider abstraction should conceptually support:

```php
interface EmailProviderInterface
{
    public function validateConfiguration(): ProviderResult;

    public function testConnection(): ProviderResult;

    public function send(EmailMessage $message): SendResult;

    public function getStatus(): ProviderStatus;

    public function normalizeError(Throwable $error): ProviderError;
}
```

The exact PHP implementation is defined in the backend/provider documentation.

---

# 20. Gmail Architecture

Gmail uses OAuth 2.0.

```text
User
 |
 v
Add Gmail
 |
 v
OAuth Authorization
 |
 v
Google Authorization
 |
 v
Authorization Callback
 |
 v
Token Exchange
 |
 v
Encrypted Token Storage
 |
 v
Gmail Adapter
 |
 v
Gmail API
```

Gmail passwords must never be collected as an alternative to OAuth.

OAuth tokens remain server-side.

---

# 21. SMTP Architecture

SMTP credentials remain server-side.

```text
User
 |
 v
SMTP Configuration
 |
 v
Validation / Connection Test
 |
 v
Encryption
 |
 v
Secure Storage
 |
 v
SMTP Adapter
 |
 v
SMTP Server
```

SMTP configuration can include:

- Host
- Port
- Encryption/security mode
- Username
- Password
- Sender address
- Sender name

The exact supported settings are defined in the provider documentation.

---

# 22. Optional Provider Architecture

Brevo and Mailtrap are optional adapters.

```text
ProviderManager
   |
   +--> Gmail
   +--> SMTP
   +--> Brevo
   +--> Mailtrap
```

Optional providers must not become mandatory dependencies of the core platform.

---

# 23. Email Engine

The email engine is the central delivery orchestration layer.

```text
Email Request
     |
     v
Normalize
     |
     v
Validate
     |
     v
Resolve Project
     |
     v
Resolve Template
     |
     v
Render Variables
     |
     v
Resolve Provider
     |
     v
Build EmailMessage
     |
     v
Provider Adapter
     |
     v
Send
     |
     v
Normalize Result
     |
     +--> Email Log
     +--> Usage
     +--> Webhook Event
     |
     v
API Response
```

---

# 24. Provider-Neutral Email Message

The email engine should operate on a normalized message model.

Conceptually:

```text
EmailMessage
├── from
├── from_name
├── to
├── cc
├── bcc
├── reply_to
├── subject
├── html
├── text
├── headers
├── metadata
└── template_context
```

Only capabilities explicitly approved by the product scope are exposed publicly.

---

# 25. Template Architecture

Templates are independent of email providers.

```text
Template
  |
  +--> Subject
  +--> HTML
  +--> Variables
  +--> Version
  |
  v
Template Renderer
  |
  v
Rendered Email
```

The template renderer must never execute arbitrary PHP or server-side code supplied through a template.

---

# 26. Variable Processing

```text
Request Variables
       |
       v
Variable Validation
       |
       v
Variable Resolver
       |
       v
Safe Substitution
       |
       v
Rendered Subject + Body
```

Example:

```html
<h1>Hello {{name}}</h1>
<p>Your verification code is {{verification_code}}.</p>
```

Missing or invalid variables must be handled according to the template policy rather than silently producing unsafe or broken output.

---

# 27. API Key Architecture

API keys are project-scoped integration credentials.

Lifecycle:

```text
Generate
   |
   v
Display Once Where Appropriate
   |
   v
Hash / Store
   |
   v
Validate During Requests
   |
   v
Rotate / Revoke
```

Plaintext API keys should not be stored in the database.

API-key identifiers may be stored separately from the secret hash to support efficient lookup and administration.

---

# 28. API Key Validation

```text
Incoming Request
       |
       v
Extract API Key
       |
       v
Validate Format
       |
       v
Find Candidate Record
       |
       v
Secure Hash Verification
       |
       v
Active / Revoked Check
       |
       v
Resolve Project
       |
       v
Project Authorization
       |
       v
Continue
```

Authentication failures must not expose unnecessary information about stored credentials.

---

# 29. Webhook Architecture

Webhooks are generated from application/domain events.

```text
Domain Event
    |
    v
Webhook Event Builder
    |
    v
Find Active Subscriptions
    |
    v
Create Delivery Record
    |
    v
Dispatch
    |
    +--> Success
    |
    +--> Retry
    |
    +--> Permanent Failure
    |
    v
Webhook Log
```

Webhook delivery should not unnecessarily block the main email request.

---

# 30. Webhook Security

Webhook requests should support:

- Shared secret/signature
- Event identifier
- Delivery identifier
- Request correlation
- Retry-safe behavior
- Timestamp protection where appropriate

The exact signature and payload contract is defined in the API/webhook documentation.

---

# 31. Background Processing

The initial deployment does not require a complex queue platform.

Cron-backed PHP workers can handle tasks such as:

- Webhook delivery
- Webhook retries
- Expired OTP cleanup
- Expired session cleanup
- Usage aggregation
- Log maintenance
- Security housekeeping

Conceptually:

```text
Cron
  |
  v
PHP CLI Worker
  |
  +--> Webhook Jobs
  +--> Cleanup
  +--> Usage
  +--> Maintenance
```

The architecture must remain compatible with a future queue system.

---

# 32. Synchronous and Background Operations

Suitable synchronous operations:

- Authentication
- Authorization
- Template retrieval
- Template rendering
- Provider validation
- Normal email submission where required by the initial API contract

Suitable background operations:

- Webhook delivery
- Webhook retries
- Aggregated analytics
- Cleanup
- Maintenance

The initial product must remain deployable without a mandatory Redis/RabbitMQ/Kafka stack.

---

# 33. Data Access Architecture

```text
Controller
    |
    v
Application Service
    |
    v
Repository / Data Access
    |
    v
PDO
    |
    v
MySQL 8+
```

The data layer must:

- Use PDO.
- Use prepared statements.
- Bind values safely.
- Use transactions when appropriate.
- Provide suitable indexes.
- Keep SQL details out of controllers.

---

# 34. Database Boundary

The principal database entities are:

```text
users
user_profiles
email_verifications
otp_codes
sessions
projects
project_settings
providers
user_providers
gmail_connections
smtp_connections
templates
template_versions
api_keys
api_requests
email_logs
otp_logs
webhooks
webhook_logs
notifications
usage_statistics
login_attempts
blocked_ips
security_logs
admin_users
admin_logs
system_settings
```

The complete schema is defined in `09-DATABASE-SCHEMA.md`.

---

# 35. Transaction Architecture

Transactions should be used when related database changes must succeed together.

Example:

```text
BEGIN
  |
  +--> Create API key
  +--> Create audit/security record
  |
COMMIT
```

External provider calls should generally not keep database transactions open unnecessarily.

---

# 36. Email Delivery Flow

Complete request flow:

```text
Client
 |
 v
HTTPS API
 |
 v
Authentication
 |
 v
Project Authorization
 |
 v
Rate Limiting
 |
 v
Input Validation
 |
 v
Email Service
 |
 +--> Template Service
 |
 +--> Variable Renderer
 |
 +--> Provider Service
 |
 v
Email Engine
 |
 v
Provider Adapter
 |
 v
External Provider
 |
 v
Normalized Result
 |
 +--> Email Log
 +--> Usage
 +--> Webhook
 |
 v
JSON Response
```

---

# 37. OTP Architecture

OTP is a security-sensitive subsystem.

Generation:

```text
Client
 |
 v
OTP API
 |
 +--> Authentication
 +--> Rate Limit
 +--> Generate Secure OTP
 +--> Store Protected OTP
 +--> Resolve Provider
 +--> Send
 +--> Log
 |
 v
Response
```

Verification:

```text
Client
 |
 v
Verify OTP API
 |
 +--> Locate OTP Context
 +--> Check Expiry
 +--> Check Attempts
 +--> Secure Comparison
 +--> Mark Used
 +--> Log
 |
 v
Response
```

OTP plaintext must not appear in ordinary logs.

---

# 38. Password Recovery Architecture

```text
User
 |
 v
Forgot Password
 |
 v
Recovery Request
 |
 +--> Rate Limit
 +--> Generate Secure Token
 +--> Store Protected Token
 +--> Send Email
 |
 v
Reset Link
 |
 v
Reset Password
 |
 +--> Validate Token
 +--> Check Expiry
 +--> Update Password
 +--> Revoke Appropriate Sessions
 +--> Audit Event
```

The application should avoid account enumeration through recovery responses.

---

# 39. Provider Connection Flow

## Gmail

```text
Add Gmail
   |
OAuth
   |
Callback
   |
Validate
   |
Encrypt/Store Tokens
   |
Create Connection
   |
Test
   |
Active
```

## SMTP

```text
Add SMTP
   |
Validate Configuration
   |
Test Connection
   |
Encrypt Credentials
   |
Create Connection
   |
Active
```

---

# 40. Logging Architecture

The platform contains:

- API logs
- Email logs
- OTP logs
- Webhook logs
- Security logs
- Admin/audit logs

Logs should be correlatable using:

```text
request_id
user_id
project_id
provider_id
api_key_id
timestamp
```

Never log:

- Passwords
- OAuth access tokens
- OAuth refresh tokens
- SMTP passwords
- API key plaintext
- OTP plaintext
- Encryption keys

---

# 41. Usage Architecture

Usage is derived from controlled events.

```text
Email Request
    |
    +--> API Request
    +--> Email Attempt
    +--> Success / Failure
    +--> Provider Usage
    |
    v
Usage Aggregation
    |
    v
Project Statistics
```

Usage must be project-aware.

---

# 42. Notification Architecture

Notifications can be generated from application events.

Examples:

- Provider connected
- Provider test failed
- API key created
- Security event
- Account event
- System warning
- Webhook failure

Conceptually:

```text
Event
 |
 v
Notification Service
 |
 v
User/Admin Notification
```

---

# 43. Session Architecture

Sessions are server-side.

```text
Login
 |
 v
Session Creation
 |
 v
Secure Cookie
 |
 v
Authenticated Requests
 |
 +--> Rotation
 +--> Expiration
 +--> Revocation
 |
 v
Logout
```

Cookies should use appropriate security attributes including:

- Secure
- HttpOnly
- SameSite

Exact settings are defined in the security architecture document.

---

# 44. Admin Architecture

The admin panel is part of the same application but has a separate authorization boundary.

```text
Admin Browser
     |
     v
Admin Authentication
     |
     v
Admin Authorization
     |
     v
Admin Controllers
     |
     v
Admin Services
     |
     v
Shared Domain/Data Services
```

Admin actions must be auditable.

Admin UI must never bypass application-level security.

---

# 45. Security Architecture

Security is distributed across all layers.

```text
Browser
  |
  | HTTPS
  v
Web Server
  |
  | TLS / Headers
  v
Middleware
  |
  | Auth / CORS / Rate Limits
  v
Application
  |
  | Validation / Authorization
  v
Data Layer
  |
  | Prepared SQL
  v
MySQL
```

Provider credentials follow an additional secure boundary:

```text
Application
   |
   v
Encrypted Credential Storage
   |
   v
Provider Adapter
   |
   v
External Provider
```

---

# 46. CORS Architecture

CORS is enforced at the API boundary.

Production deployments should avoid unrestricted wildcard origins for authenticated operations unless the deployment explicitly requires that model.

Where appropriate, projects can define allowed origins.

```text
Request Origin
      |
      v
CORS Policy
      |
   +--+--+
   |     |
Allowed Denied
   |     |
   v     v
Continue Reject
```

---

# 47. Static Website Security

Browser-based integrations have an important limitation: any credential included in browser JavaScript may potentially be inspected.

Therefore API keys must be treated as integration credentials rather than equivalent to private server secrets.

The architecture requires:

- Project-scoped keys
- Rate limiting
- Origin controls where appropriate
- Usage monitoring
- Key rotation
- Revocation
- Abuse detection

Provider credentials must never be embedded in client-side JavaScript.

---

# 48. Trust Boundaries

Major trust boundaries:

### Browser → API

The browser is untrusted.

### API → Application

Requests must pass authentication, authorization, validation, and rate limiting.

### Application → Database

Only controlled data-access operations are permitted.

### Application → Providers

Credentials and external API calls remain server-side.

### Application → Webhook Recipient

Webhook recipients are external and untrusted.

Webhook responses must never be treated as trusted application data.

---

# 49. Deployment Architecture

Recommended initial topology:

```text
Internet
   |
   v
DNS
   |
   v
HTTPS
   |
   v
Apache / Nginx
   |
   +--> Static Assets
   |
   +--> PHP-FPM
           |
           v
      PHP Application
           |
      +----+----+
      |         |
      v         v
    MySQL    Providers
               |
               +--> Gmail
               +--> SMTP
               +--> Brevo
               +--> Mailtrap
```

Cron/CLI workers run on the same server initially.

---

# 50. Web Server Boundary

Apache/Nginx handles:

- HTTPS/TLS
- Static files
- PHP-FPM forwarding
- Request size limits
- Security headers where configured
- Access restrictions
- Compression where appropriate

The PHP application handles:

- Authentication
- Authorization
- Business logic
- Database operations
- Provider operations
- API responses

---

# 51. PHP-FPM Architecture

Production PHP should run through PHP-FPM.

```text
Nginx/Apache
     |
     v
PHP-FPM
     |
     v
public/index.php
     |
     v
Application Bootstrap
```

Only intended public files should be accessible through the web root.

---

# 52. Recommended Directory Architecture

```text
email-api-platform/
│
├── app/
│   ├── Controllers/
│   ├── Services/
│   ├── Domain/
│   ├── Providers/
│   ├── Repositories/
│   ├── Middleware/
│   ├── Validation/
│   ├── Security/
│   └── Support/
│
├── config/
├── database/
│   ├── migrations/
│   └── seeds/
├── routes/
├── storage/
│   ├── logs/
│   ├── cache/
│   └── private/
├── public/
│   ├── index.php
│   └── assets/
├── resources/
│   ├── views/
│   └── templates/
├── tests/
├── vendor/
├── .env.example
└── composer.json
```

The exact class/file naming rules are defined in `10-BACKEND-PHP-ARCHITECTURE.md`.

---

# 53. Configuration Architecture

Configuration must be separated from source code.

Possible sources:

- Environment variables
- Protected configuration files
- Server-level secrets

Sensitive configuration includes:

- Database credentials
- OAuth client secrets
- Application encryption key
- Application secrets
- SMTP encryption key
- Provider credentials

Secrets must not be committed to source control.

---

# 54. Environment Architecture

The system should support:

```text
Development
Testing
Staging
Production
```

Each environment should have separate:

- Database
- Credentials
- Provider connections
- API keys
- Application secrets

Production secrets must never be reused casually in development.

---

# 55. Encryption Architecture

Sensitive provider credentials should be encrypted at rest.

```text
Plain Secret
    |
    v
Encryption Service
    |
    v
Encrypted Database Value
```

When needed:

```text
Encrypted Value
    |
    v
Decryption Service
    |
    v
Provider Adapter
```

Encryption keys must be stored separately from encrypted application data.

---

# 56. Password Architecture

Passwords are securely hashed rather than reversibly encrypted.

```text
Password
   |
   v
PHP Password Hashing
   |
   v
Password Hash
   |
   v
MySQL
```

Verification uses PHP's secure password verification mechanisms.

---

# 57. Database Security

The application database user should have only the privileges required by the application.

The database should not be publicly exposed where unnecessary.

Preferred topology:

```text
Internet
   X
   |
   v
Application Server
   |
   v
Private / Local MySQL
```

---

# 58. Private Storage

Sensitive operational files must not live in a publicly accessible web directory.

```text
public/
    public assets only

storage/
    logs
    temporary files
    private files
```

Web-server rules must prevent accidental direct access to private storage.

---

# 59. Error Architecture

Errors are categorized as:

- Client errors
- Authentication errors
- Authorization errors
- Provider errors
- System errors

Example normalized response:

```json
{
  "success": false,
  "error": {
    "code": "INVALID_REQUEST",
    "message": "The request could not be processed.",
    "details": {}
  },
  "request_id": "req_..."
}
```

Internal stack traces and sensitive implementation details must never be exposed in production responses.

---

# 60. Error Propagation

```text
Provider Exception
      |
      v
Provider Adapter
      |
      v
Normalized Provider Error
      |
      v
Email Service
      |
      v
Application Error
      |
      v
API Error Formatter
      |
      v
JSON Response
```

This keeps the public API independent of provider-specific exception classes.

---

# 61. Health Check Architecture

A health endpoint may check:

- Application availability
- Database availability
- Required configuration
- Critical dependencies

The response must not reveal:

- Database passwords
- Environment variables
- Internal file paths
- Provider secrets
- Stack traces

---

# 62. Maintenance Mode

Maintenance mode is controlled by system configuration.

```text
Incoming Request
       |
       v
Maintenance Check
       |
   +---+---+
   |       |
Enabled  Disabled
   |       |
   v       v
Maintenance Normal
Response    Flow
```

Administrative access may remain available according to the security policy.

---

# 63. Cron Architecture

Cron is part of the initial deployment.

Potential jobs:

```text
Every minute:
    webhook processing

Every few minutes:
    cleanup / maintenance

Hourly:
    usage aggregation where needed

Daily:
    retention and housekeeping
```

Exact schedules are finalized during deployment.

Cron jobs should be idempotent where practical.

---

# 64. Scalability Path

## Stage 1 — Single Server

```text
Web Server
PHP-FPM
MySQL
Cron
```

## Stage 2 — Dedicated Database

```text
Application Server
       |
       v
Dedicated MySQL
```

## Stage 3 — Background Worker

```text
Application
    |
    v
Queue
    |
    v
Worker
```

## Stage 4 — Multiple Application Servers

```text
Load Balancer
   |
   +--> App 1
   +--> App 2
   +--> App 3
        |
        v
Shared Database / Queue
```

The public API should remain stable across these stages.

---

# 65. Horizontal Scaling Considerations

If multiple application servers are introduced:

- Sessions must use shared storage or a compatible stateless strategy.
- Shared/private files must use shared storage where required.
- Background jobs require a shared queue.
- Rate limiting must use shared state where necessary.
- Provider credentials must be centrally available.
- Configuration must remain consistent.
- Database connections must be managed appropriately.

These are future requirements, not initial deployment requirements.

---

# 66. Queue-Compatible Architecture

Current:

```text
API → Email Engine → Provider
```

Future:

```text
API → Job Dispatcher → Queue → Email Worker → Provider
```

The public API should not need to change simply because internal processing becomes asynchronous, provided the asynchronous behavior is explicitly represented in the API contract.

---

# 67. Observability Architecture

Operational visibility includes:

- API logs
- Email logs
- OTP logs
- Webhook logs
- Security logs
- Admin logs
- Usage statistics
- Health checks

Useful correlation identifiers:

```text
request_id
user_id
project_id
provider_id
api_key_id
timestamp
```

Sensitive credential fields must be excluded.

---

# 68. Backup and Recovery

Production deployment should include:

- MySQL backups
- Secure configuration/secret backup
- Recovery documentation
- Backup verification
- Restore testing

Recovery should cover:

1. Server replacement
2. Database restoration
3. Application deployment
4. Configuration restoration
5. Secret restoration
6. Cron restoration
7. HTTPS configuration
8. Health verification

---

# 69. Testing Architecture

Testing should operate at multiple levels:

```text
Unit
  |
  v
Service / Domain
  |
  v
Integration
  |
  v
API
  |
  v
Provider
  |
  v
End-to-End
```

Provider integrations should support mocks/fakes so normal automated tests do not require live provider accounts.

---

# 70. Provider Testing

Gmail tests should cover:

- OAuth callback
- Token storage
- Token refresh
- Successful send
- Provider failures

SMTP tests should cover:

- Configuration validation
- Connection
- Authentication
- TLS
- Successful send
- Connection failure

Brevo/Mailtrap tests should cover:

- Configuration
- Send operation
- Error normalization

Live provider tests may be maintained separately.

---

# 71. API Testing

Every endpoint should test:

- Valid request
- Missing fields
- Invalid data
- Unauthorized access
- Forbidden access
- Rate limiting
- Not-found behavior
- Provider failure
- Database failure
- Correct status codes
- Correct JSON structure

---

# 72. Performance Architecture

Priorities:

1. Keep frontend JavaScript lightweight.
2. Optimize database queries.
3. Add appropriate indexes.
4. Avoid unnecessary external calls.
5. Avoid long database transactions.
6. Use provider timeouts.
7. Move retryable work to workers where practical.
8. Paginate large datasets.
9. Optimize logs and usage aggregation.
10. Avoid loading unnecessary dashboard data.

---

# 73. Timeout Architecture

External provider calls must have bounded timeouts.

A provider must not be allowed to hang an API request indefinitely.

Timeout failures must be:

- Caught
- Normalized
- Logged
- Returned safely
- Reflected in email/usage status where applicable

---

# 74. Retry Architecture

Retries are appropriate mainly for transient background operations such as webhook delivery.

Email retries require additional care because a retry can create duplicate messages.

The system must not blindly retry an email without considering idempotency and provider behavior.

---

# 75. Rate-Limit Architecture

Rate limiting may operate by:

```text
IP
User
Project
API Key
Endpoint
```

Security-sensitive operations must receive stronger protection.

Initial implementation may use database-backed or lightweight server-side state.

A future shared cache can be added without changing the public API.

---

# 76. Abuse Detection

Potential suspicious activity includes:

- Repeated failed logins
- Excessive OTP requests
- Excessive invalid API keys
- Unusual API volume
- Repeated provider failures
- Rapid resource creation
- Suspicious IP behavior

Events should feed security logs and administrative controls.

---

# 77. Audit Architecture

Audit logs are separate from ordinary operational logs.

Audit actions include:

- User suspension
- Provider changes
- API key creation/revocation
- Security changes
- IP blocking
- System settings changes
- Admin account changes

Audit records should identify:

```text
actor
action
resource
timestamp
request_id
result
```

Sensitive values must not be stored unnecessarily.

---

# 78. Provider Credential Lifecycle

```text
Create
  |
  v
Validate
  |
  v
Encrypt
  |
  v
Store
  |
  v
Use
  |
  +--> Refresh where applicable
  +--> Test
  +--> Disable
  +--> Revoke/Delete
```

Deleting a provider credential must invalidate the associated connection.

---

# 79. Gmail Token Lifecycle

```text
OAuth Authorization
       |
       v
Authorization Code
       |
       v
Token Exchange
       |
       v
Encrypted Storage
       |
       v
Access Token
       |
       +--> Expired?
       |       |
       |       v
       |   Refresh Token
       |
       v
Gmail API
```

Refresh tokens require strong protection.

---

# 80. SMTP Credential Lifecycle

```text
SMTP Form
   |
   v
Validation
   |
   v
Connection Test
   |
   v
Encryption
   |
   v
Database
   |
   v
SMTP Adapter
```

Stored SMTP passwords should never be displayed unnecessarily.

---

# 81. Architecture for Future Providers

Adding a provider should require:

1. Provider adapter.
2. Configuration validation.
3. Connection test.
4. Send implementation.
5. Error normalization.
6. Provider registration.
7. Provider tests.
8. Documentation.
9. UI configuration if required.

The core email engine should remain unchanged.

---

# 82. Architecture for Future Scaling

The architecture intentionally leaves boundaries for:

- Queue workers
- Multiple application servers
- Shared cache
- Dedicated database
- Provider routing
- Larger analytics workloads

However, none of these are mandatory for the initial product.

---

# 83. Explicit Non-Requirements

The initial architecture does not require:

- Kubernetes
- Microservices
- Service mesh
- Kafka
- RabbitMQ
- Redis cluster
- Native mobile apps
- A mandatory frontend framework
- Multi-region deployment
- Global load balancing
- Full CRM infrastructure

Introducing such infrastructure requires a separate architectural decision.

---

# 84. Architecture Rules

Developers must:

1. Keep controllers thin.
2. Keep SQL out of controllers.
3. Keep provider logic behind adapters.
4. Keep secrets server-side.
5. Enforce project authorization.
6. Use prepared statements.
7. Avoid plaintext credential storage.
8. Normalize provider errors.
9. Preserve API contracts.
10. Avoid silent scope expansion.
11. Avoid logging secrets.
12. Keep optional providers optional.
13. Keep modules independently testable.
14. Document architectural exceptions.
15. Treat client-side validation as convenience only, never security.

---

# 85. Architecture Anti-Patterns

### Fat controller

```text
Controller
 ├── SQL
 ├── Gmail API
 ├── SMTP
 ├── Template rendering
 └── Logging
```

### Correct

```text
Controller
   |
   v
Service
   |
   +--> Template
   +--> Email Engine
   +--> Provider Adapter
   +--> Repository
```

### Bad credential flow

```text
Frontend → SMTP password
```

### Correct

```text
Frontend → API → Server-side provider credentials
```

### Bad project access

```text
API key → arbitrary project ID
```

### Correct

```text
API key → associated project → authorization
```

---

# 86. Final Architecture Compliance Checklist

## Core

- [ ] Modular monolith established
- [ ] Layer boundaries established
- [ ] Public REST API established
- [ ] Project isolation established
- [ ] Provider abstraction established

## Client

- [ ] Static HTML integration works
- [ ] Fetch API works
- [ ] HTTPS is enforced
- [ ] Client does not require PHP

## Backend

- [ ] PHP 8.3+
- [ ] REST/JSON
- [ ] PDO
- [ ] Middleware
- [ ] Controllers
- [ ] Services
- [ ] Data access layer

## Providers

- [ ] Gmail adapter
- [ ] SMTP adapter
- [ ] Brevo adapter
- [ ] Mailtrap adapter
- [ ] Common provider contract

## Security

- [ ] User sessions
- [ ] API-key authentication
- [ ] Authorization
- [ ] Rate limiting
- [ ] CORS
- [ ] Secure headers
- [ ] Secret protection
- [ ] Security logs
- [ ] Audit logs

## Data

- [ ] MySQL 8+
- [ ] Prepared statements
- [ ] Transactions where needed
- [ ] Indexes
- [ ] Project relationships

## Operations

- [ ] Cron
- [ ] Health checks
- [ ] Logging
- [ ] Backups
- [ ] Maintenance mode

## Scalability

- [ ] Queue-compatible boundaries
- [ ] Provider abstraction
- [ ] API versioning
- [ ] Future multi-server path

---

# 87. Definition of Done

The architecture is correctly implemented when:

1. A static HTML website can call the platform over HTTPS.
2. Project API keys authenticate requests.
3. Project authorization prevents cross-project access.
4. Templates and variables are processed server-side.
5. Gmail sends through its adapter.
6. SMTP sends through its adapter.
7. Optional providers use the same abstraction.
8. Provider credentials remain server-side.
9. Provider results are normalized.
10. Email activity is logged.
11. Usage is tracked.
12. Webhook events can be generated.
13. OTP flows are rate-limited and protected.
14. Sessions are secure.
15. Admin access is separated and audited.
16. Database access uses prepared statements.
17. Errors are normalized.
18. Background work has a clear boundary.
19. The platform can run on a conventional PHP/MySQL server.
20. The public API does not depend on one specific email provider.
21. Future scaling can occur without redesigning the public API.

---

# 88. Final Architecture Statement

The Email API Platform is a **secure, modular, provider-neutral PHP email API platform**.

The approved architecture is:

```text
Static HTML / Web Apps
          |
        HTTPS
          |
       REST API
          |
 Authentication
 Authorization
 Rate Limiting
 Validation
          |
 Application Services
          |
    +-----+------+
    |            |
Projects      Templates
    |            |
    +-----+------+
          |
      Email Engine
          |
    Provider Manager
          |
   +------+------+------+
   |      |      |      |
 Gmail  SMTP  Brevo  Mailtrap
          |
      Recipients
```

Supporting baseline:

```text
PHP 8.3+
MySQL 8+
PDO
PHPMailer
Gmail OAuth 2.0
Apache/Nginx
PHP-FPM
HTTPS
Cron
```

The architecture is intentionally low-cost, maintainable, secure, modular, and extensible.

**STATUS: FINAL / LOCKED**

---

# 89. Next Document

The next document in the locked documentation sequence is:

```text
04-TECHNOLOGY-STACK.md
```

That document will define the approved frontend, backend, database, server, libraries, dependencies, browser technologies, icons, fonts, asset formats, development tooling, version baselines, and technology-selection rules.
