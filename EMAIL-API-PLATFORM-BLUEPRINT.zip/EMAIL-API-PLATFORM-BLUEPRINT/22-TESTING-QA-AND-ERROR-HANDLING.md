# 22 — TESTING, QA & ERROR HANDLING

**Project:** Email API Platform  
**Document:** Testing, QA & Error Handling Guide  
**Status:** FINAL / LOCKED  
**Version:** 1.0

## 1. Purpose

This document defines the complete testing, quality-assurance, validation, error-handling, regression, release-verification, and recovery standards for the Email API Platform.

It covers:

- unit, integration, API and E2E testing
- frontend and backend QA
- database and migration testing
- authentication, authorization and project isolation
- Gmail OAuth and SMTP testing
- email-engine and template testing
- OTP and webhook testing
- security, accessibility, responsive and performance testing
- concurrency, rate-limit and failure-injection testing
- API error contracts and exception mapping
- logging, monitoring, recovery and rollback
- release gates and production smoke tests

The platform must be tested for both successful behavior and safe failure.

---

# 2. Locked Quality Principles

1. Test business behavior, not implementation details alone.
2. Test success and failure paths.
3. Security controls require automated coverage.
4. Every API error follows a predictable contract.
5. Sensitive data never appears in errors or logs.
6. Provider failures are normalized.
7. Email-send ambiguity is handled safely.
8. Duplicate operations are tested.
9. Project isolation is tested.
10. Authorization is tested independently of UI visibility.
11. Rate limits are tested.
12. OTP expiry and attempt limits are tested.
13. Webhook retry and idempotency behavior is tested.
14. Database transactions are tested.
15. Accessibility and responsive behavior are release requirements.
16. Performance regressions are measurable.
17. Production and development builds are tested separately.
18. Every critical production bug receives regression coverage.
19. Production secrets are never used in tests.
20. A release is not complete until required quality gates pass.

---

# 3. Test Pyramid

```text
             E2E / Browser
                  /\
                 /  \
            Integration
               /      \
             API / DB
              /       \
            Unit Tests
```

Most deterministic business logic should be covered by fast unit tests. Integration and E2E tests validate real component interactions.

---

# 4. Test Levels

## Static Analysis

- PHP syntax checks
- PHPStan
- JavaScript linting
- CSS linting where configured
- dependency/security checks

## Unit Tests

Test isolated validators, services, repositories, renderers, parsers and security helpers.

## Integration Tests

Test database, authentication, providers, email engine, webhooks, transactions and API behavior.

## Browser/E2E Tests

Test complete user journeys in a real browser.

## Manual QA

Validate usability, visual quality, responsive behavior, accessibility and unusual workflows.

---

# 5. Environment Isolation

Recommended environments:

```text
Local → Development → QA/Staging → Production
```

Each environment must use separate:

- database
- API credentials
- provider credentials
- OAuth credentials
- webhook secrets
- encryption keys
- test users
- logging destinations

Never reuse production secrets in development or QA.

---

# 6. Test Database & Fixtures

Automated tests should use a dedicated database and controlled fixtures.

Fixtures should include:

- normal user
- verified user
- unverified user
- suspended user
- multiple projects
- multiple providers
- templates
- API keys
- webhook endpoints
- email logs
- OTP records
- admin users
- restricted admin users

Tests must not depend on unpredictable shared state.

---

# 7. Test User Matrix

| User | Expected |
|---|---|
| Anonymous | Public access only |
| Registered/unverified | Verification flow |
| Verified user | Normal access |
| Suspended user | Restricted access |
| Project owner | Full project permissions |
| Limited project user | Permitted actions only |
| Admin | Admin permissions |
| Restricted admin | Limited admin permissions |

---

# 8. Unit Testing

Cover:

- email validation
- URL validation
- OTP generation/expiry
- template variable parsing
- template rendering
- API-key generation and hashing
- webhook signature generation
- error normalization
- pagination calculations
- rate-limit calculations

Use descriptive names such as:

```text
it_rejects_expired_otp
it_rejects_cross_project_access
it_hashes_api_key_before_storage
it_normalizes_provider_timeout
```

---

# 9. Backend Service & Repository Tests

Services to cover include:

- AuthenticationService
- VerificationService
- OTPService
- ProjectService
- ProviderService
- TemplateService
- EmailService
- WebhookService
- ApiKeyService
- UsageService
- NotificationService
- SecurityService

Repositories must test CRUD, filtering, pagination, project scoping, constraints and transactions.

---

# 10. Project Isolation Tests

Attempt access to another project's resources using:

- direct resource IDs
- modified URL IDs
- modified request-body IDs
- modified query parameters
- guessed IDs
- deleted project IDs
- suspended projects
- wrong-project API keys

Expected behavior follows the API policy, but another project's data must never be returned.

---

# 11. Authorization Tests

Test every protected resource with:

- owner
- authorized member
- unauthorized user
- anonymous user
- suspended user
- admin where applicable
- restricted admin

Hidden frontend controls do not count as authorization.

---

# 12. Authentication Tests

Test:

- valid login
- invalid password
- unknown email
- unverified account
- suspended account
- login rate limiting
- session creation
- session rotation
- session expiration
- session revocation
- logout
- concurrent sessions
- session fixation protection

---

# 13. Registration & Verification Tests

Registration:

- valid registration
- invalid email
- duplicate email
- weak password
- password mismatch
- missing/unknown fields
- verification creation
- rate limiting
- enumeration-safe behavior

Verification:

- valid token
- invalid token
- expired token
- reused token
- already verified account
- resend verification
- resend throttling

---

# 14. Password Recovery Tests

Test:

- valid reset request
- unknown email
- expired token
- invalid token
- reused token
- password policy
- password confirmation
- session invalidation where required
- audit logging
- enumeration protection

Never use real user passwords in tests.

---

# 15. OTP Testing

Cover:

- secure generation
- valid OTP
- invalid OTP
- expired OTP
- maximum attempts
- resend throttling
- invalid purpose
- reused OTP
- correct user/project context
- audit logging

Boundary tests must include:

- one second before expiry
- exact expiry boundary
- one second after expiry
- final allowed attempt
- attempt after lock
- immediate resend
- resend after allowed interval

---

# 16. Session & Cookie Tests

Verify:

- Secure
- HttpOnly
- SameSite policy
- expiration
- logout
- revocation
- session rotation
- concurrent sessions
- inactive-session behavior

---

# 17. API Authentication & API-Key Tests

Test:

- missing key
- malformed key
- invalid key
- revoked key
- expired key
- wrong-project key
- insufficient scope
- suspended project
- excessive requests

API keys must be cryptographically generated and hashed before storage. Tests must never depend on stored plaintext secrets.

---

# 18. REST API Tests

For every endpoint test:

- HTTP method
- authentication
- authorization
- valid request
- missing fields
- malformed JSON
- unknown fields
- invalid fields
- content type
- rate limits
- status code
- response schema
- error schema

---

# 19. API Error Contract

Recommended structure:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The request could not be processed.",
    "fields": {}
  },
  "request_id": "req_..."
}
```

Never return:

- PHP warnings
- stack traces
- SQL errors
- filesystem paths
- internal credentials

Stable error codes must be used instead of frontend dependence on message wording.

---

# 20. Standard Error Codes

Examples:

```text
AUTHENTICATION_REQUIRED
INVALID_CREDENTIALS
FORBIDDEN
RESOURCE_NOT_FOUND
VALIDATION_ERROR
RATE_LIMITED
CONFLICT
PROVIDER_ERROR
EMAIL_SEND_FAILED
OTP_EXPIRED
OTP_INVALID
WEBHOOK_DELIVERY_FAILED
INTERNAL_ERROR
```

---

# 21. HTTP Error Mapping

Conceptual mapping:

```text
400 → malformed/request error
401 → authentication required
403 → unauthorized
404 → resource not found
409 → conflict
422 → validation error
429 → rate limited
500 → internal error
502/503 → upstream/service failure
504 → timeout
```

Exact mappings follow the REST API specification.

---

# 22. Validation & Injection Tests

Test:

- required fields
- type errors
- format errors
- length limits
- range limits
- unsupported values
- nested fields
- unexpected fields
- malicious input

SQL injection payloads and XSS payloads must be tested against all relevant inputs.

Example XSS:

```html
<script>alert(1)</script>
```

Expected: safely escaped or rejected; never executed.

---

# 23. CSRF & CORS Tests

CSRF:

- missing token
- invalid token
- expired token
- wrong-session token

Expected: state-changing browser request rejected.

CORS:

- allowed origin
- disallowed origin
- preflight
- credentials
- unsupported methods/headers

CORS must never be treated as authentication.

---

# 24. Security Header Tests

Verify production responses include the intended:

- Content-Security-Policy
- X-Content-Type-Options
- Referrer-Policy
- Permissions-Policy
- frame protections
- HSTS where applicable

---

# 25. Rate-Limit Tests

Test limits for:

- login
- registration
- password reset
- OTP send/verify
- API requests
- email sending
- relevant webhook operations

Verify:

```text
Allowed → Allowed → ... → 429
```

Also test recovery after the limit window expires.

---

# 26. Email Engine Tests

Test the lifecycle:

```text
REQUESTED
→ VALIDATING
→ PREPARED
→ QUEUED*
→ PROCESSING
→ SENDING
→ SENT
```

Failure:

```text
FAILED
```

Cancellation:

```text
CANCELLED
```

`QUEUED` is deployment-dependent.

---

# 27. Email Validation & Header Injection

Test:

- recipient
- sender
- subject
- reply-to
- HTML
- plain text
- headers
- variables
- attachments
- size limits

Inputs containing `\r`, `\n`, or `\r\n` must not allow arbitrary header injection.

---

# 28. Email Idempotency & Ambiguous Outcomes

Test:

```text
Request A
Request A again
```

Expected: no unintended duplicate send where idempotency is supported.

Also simulate:

```text
Provider accepts message
        ↓
Network response lost
```

The system must not blindly resend the message.

---

# 29. Provider Adapter Tests

Every provider adapter must test:

- configuration validation
- successful send
- authentication failure
- timeout
- rate limit
- unsupported feature
- malformed response
- temporary outage

Gmail, SMTP, Brevo and Mailtrap must conform to the common provider contract.

---

# 30. Gmail OAuth Tests

Test:

- OAuth start
- valid state
- invalid state
- expired state
- callback failure
- token exchange failure
- encrypted token storage
- refresh
- revoked consent
- disconnect

Long-lived OAuth secrets must remain server-side.

---

# 31. SMTP Tests

Test:

- host
- port
- TLS/SSL mode
- authentication
- timeout
- certificate failure
- invalid credentials
- successful test email

Use controlled SMTP infrastructure.

---

# 32. Template Engine Tests

Test:

- create
- update
- duplicate
- delete
- versioning
- publish
- rollback
- preview
- variables
- missing variables
- invalid variables
- HTML safety
- project isolation

Verify immutable historical versions where required.

---

# 33. Template Preview Tests

Verify preview:

- renders expected output
- is isolated
- cannot access parent DOM
- cannot access application secrets
- cannot execute unauthorized scripts
- handles malformed HTML safely

---

# 34. Webhook Tests

Test:

- create
- update
- enable/disable
- delete
- event selection
- secret rotation
- test delivery
- delivery logs

SSRF tests must reject loopback, private/internal and cloud-metadata destinations, including unsafe redirects.

---

# 35. Webhook Signature & Retry Tests

Test:

- valid HMAC
- invalid HMAC
- missing signature
- modified body
- modified timestamp
- replay
- wrong secret
- timeout
- 5xx
- 429
- connection failure

Verify bounded retry/backoff, maximum attempts, final state and delivery logging.

Webhook failure must never make the originating email send fail.

---

# 36. Logging & Audit Tests

Logs may contain safe metadata such as:

- request ID
- message ID
- project ID
- provider type
- status
- error code
- duration

Never log:

- passwords
- API-key secrets
- OAuth tokens
- SMTP passwords
- webhook secrets
- OTP values
- sensitive session secrets

Audit events must cover important authentication, security, provider, project, API-key, webhook and admin actions.

---

# 37. Usage & Date Tests

Test:

- email counts
- OTP counts
- API request counts
- webhook counts
- daily aggregation
- monthly aggregation
- project isolation
- date boundaries
- UTC midnight
- month/year changes
- supported timezone display behavior

---

# 38. Database & Transaction Tests

Test:

- connection failure
- query failure
- timeout
- deadlock
- transaction rollback
- foreign keys
- unique constraints
- indexes
- partial failure

If operation B fails after operation A succeeds inside a transaction, protected changes must roll back.

---

# 39. Concurrency & Race Tests

Test simultaneous:

- API-key creation
- template updates
- project updates
- OTP verification
- duplicate email requests
- webhook workers

Also test frontend stale-response races:

```text
Project A request
Project B request
Late A response
```

The A response must never overwrite B's active context.

---

# 40. File, Path & Command Security Tests

If uploads are supported, test:

- size limits
- MIME mismatch
- filename sanitization
- path traversal
- malicious files
- storage permissions
- cleanup
- authorization

Test traversal variants such as:

```text
../
..%2e%2e
```

Avoid shell execution from user input. Reject malicious command/deserialization input.

---

# 41. Dependency & Static Analysis

CI should run:

- PHP syntax checks
- PHPStan
- JavaScript linting
- CSS linting where configured
- dependency vulnerability checks

Critical findings must block release unless formally accepted under the project's security process.

---

# 42. Frontend Tests

Unit-test:

- validation
- API error normalization
- formatters
- state transitions
- pagination
- date formatting

Integration-test:

- login
- project switching
- provider forms
- template editor
- API-key UI
- webhook UI
- filters
- notifications

---

# 43. Browser / E2E Critical Flow

```text
Register
 ↓
Verify
 ↓
Login
 ↓
Create Project
 ↓
Connect Provider
 ↓
Create Template
 ↓
Create API Key
 ↓
Send Test Email
 ↓
View Log
 ↓
Configure Webhook
 ↓
Verify Delivery
```

---

# 44. Screen Coverage

Public: all 10 screens.

Authentication: all 7 screens.

User panel: all 33 screens.

Admin panel: all 37 screens.

System: all 6 screens.

All 93 screens must have appropriate functional, responsive and error-state coverage.

---

# 45. Accessibility QA

Test:

- keyboard navigation
- screen readers
- focus management
- labels
- contrast
- reduced motion
- 200% zoom
- mobile touch
- accessible error/status announcements

Automated accessibility checks supplement, not replace, manual testing.

---

# 46. Responsive QA

Test at:

```text
320
360
375
390
414
480
768
820
1024
1280
1440
1920
```

Verify:

- no accidental overflow
- readable text
- usable forms
- usable tables
- navigation
- dialogs
- charts
- admin screens

---

# 47. Performance QA

Measure:

- initial load
- LCP
- CLS
- INP
- JavaScript execution
- API latency
- request count
- memory where practical

Test realistic mobile hardware and slower network conditions.

---

# 48. Load & Stress Testing

Load-test:

- login
- API authentication
- send email
- OTP
- templates
- logs
- usage
- webhooks

Stress testing must verify graceful degradation rather than corruption.

Rate-limit stress tests must confirm that limits cannot be bypassed through alternate routes.

---

# 49. Failure Injection

In controlled staging, simulate:

- provider timeout
- provider outage
- provider authentication failure
- database failure
- cache failure where applicable
- worker failure
- network loss
- webhook endpoint failure
- malformed provider response

Verify safe states, logging, retry behavior and recovery.

---

# 50. Queue/Worker/Cron Testing

If background processing is enabled, test:

- worker crash
- duplicate job
- retry
- stale job
- job lock
- restart
- overlapping cron runs

Scheduled jobs must be safe to rerun and must not create duplicate side effects.

---

# 51. Error Logging

Internal errors should contain useful correlation data:

```text
timestamp
severity
request_id
operation
error_code
provider_type
duration
safe actor/project context
```

Production should avoid noisy DEBUG logging.

---

# 52. Error Redaction

Before logging or returning an error, remove:

- passwords
- API keys
- OAuth tokens
- SMTP credentials
- webhook secrets
- OTP values
- reset URLs
- unnecessary personal data

---

# 53. Error Recovery

Recoverable errors follow:

```text
Detect
 ↓
Record
 ↓
Classify
 ↓
Recover / Retry
 ↓
Notify
 ↓
Close
```

Permanent failures must not enter infinite retry loops.

---

# 54. Retry Policy Testing

Test:

- zero retries
- first retry
- maximum retry
- timeout
- permanent failure
- retry-after
- duplicate operation

Retry behavior must not cause duplicate email or webhook side effects.

---

# 55. User-Facing Error Rules

Messages must be:

- safe
- concise
- actionable
- consistent

Example:

```text
We couldn't connect to the email provider.
Check the configuration and try again.
```

Technical stack traces belong in protected logs, not the UI.

---

# 56. HTTP Error UX

### 401
Stop protected calls and move to authentication without redirect loops.

### 403
Explain that the action is not permitted; do not retry unchanged.

### 404
Show a safe not-found state.

### 409
Explain the conflict and provide a recovery action.

### 429
Respect retry information and avoid request storms.

### 5xx
Preserve user input and offer retry only when safe.

---

# 57. Optimistic UI

Use optimistic updates only when rollback is reliable.

Do not use optimistic UI for:

- email sending
- security actions
- provider connections
- API-key creation
- destructive actions

These should wait for authoritative server results.

---

# 58. Visual Regression

Where supported, compare screenshots for:

- public pages
- dashboard
- forms
- templates
- tables
- admin dashboard
- error pages

Review meaningful differences instead of blindly accepting snapshots.

---

# 59. Network & Browser QA

Inspect:

- URLs
- methods
- headers
- status codes
- payload sizes
- duplicate calls
- failed requests
- cache behavior

No secrets may appear in query strings, console logs or telemetry.

---

# 60. Release Candidate Gate

Before approval:

- all automated tests pass
- security tests pass
- migration tests pass
- API contracts pass
- critical E2E flows pass
- responsive QA passes
- accessibility QA passes
- performance checks pass
- error handling passes
- production build passes

Block release for critical security, data-integrity, authentication or duplicate-send failures.

---

# 61. Regression Policy

Every production bug requires:

1. root-cause analysis
2. regression test
3. documentation update if architecture changed
4. monitoring improvement where appropriate

Flaky tests must be fixed rather than ignored.

---

# 62. Bug Severity

### P0 — Critical
Security breach, data corruption, complete outage.

### P1 — High
Major feature unavailable or dangerous incorrect behavior.

### P2 — Medium
Important feature impaired with workaround.

### P3 — Low
Minor defect or visual issue.

Bug reports should include environment, version, reproduction steps, expected/actual results, request ID where available, browser/device and severity. Never attach secrets.

---

# 63. Contract Testing

Test contracts between:

```text
Frontend ↔ Backend
Backend ↔ Provider Adapter
Backend ↔ Webhook Consumer Contract
```

Verify endpoint paths, schemas, status codes, error codes and version compatibility.

---

# 64. Backward Compatibility

When API versions remain supported:

- old clients continue working
- response fields are not unexpectedly removed
- error contracts remain stable
- deprecated behavior follows documented policy

Never silently break the public API.

---

# 65. Database Migration Testing

For every migration test:

- fresh install
- upgrade from previous version
- data preservation
- indexes
- foreign keys
- unique constraints
- performance impact
- rollback/recovery strategy where supported

Never test only on an empty database.

---

# 66. Backup & Restore

Regularly verify:

```text
Backup
 ↓
Restore
 ↓
Verify schema
 ↓
Verify data
 ↓
Verify application
```

An untested backup is not considered proven.

---

# 67. Disaster Recovery

Test recovery from:

- database failure
- provider outage
- application failure
- configuration failure
- credential revocation

Document and periodically rehearse recovery steps.

---

# 68. Production Smoke Test

After deployment verify:

1. public home page
2. login
3. dashboard
4. project loading
5. provider status
6. template loading
7. API health
8. controlled email test path where safe
9. logs
10. admin access where appropriate

Use a controlled test account.

---

# 69. Post-Deployment Monitoring

Monitor:

- 4xx rate
- 5xx rate
- authentication failures
- email failures
- provider failures
- webhook failures
- latency
- rate-limit spikes
- frontend errors
- database errors

---

# 70. Rollback Criteria

Rollback when:

- critical functionality is broken
- data corruption is possible
- security regression exists
- duplicate email sends occur
- authentication is broken
- migration causes severe instability

Rollback procedures must be tested before an emergency.

---

# 71. Coverage Philosophy

Coverage percentage is a signal, not the sole quality metric.

Prioritize:

- authentication
- authorization
- project isolation
- API keys
- email sending
- OTP
- providers
- webhooks
- security
- error handling

Do not create meaningless tests solely to increase a percentage.

---

# 72. Final QA Definition of Done

A feature is complete only when:

- [ ] happy path passes
- [ ] negative paths pass
- [ ] authorization is tested
- [ ] validation is tested
- [ ] error contract is verified
- [ ] logging is verified
- [ ] security tests pass
- [ ] responsive behavior is tested
- [ ] accessibility is tested
- [ ] performance is checked
- [ ] regression coverage exists
- [ ] documentation is updated where required

---

# 73. Final Test Matrix

| Area | Unit | Integration | E2E | Security | Manual |
|---|---:|---:|---:|---:|---:|
| Authentication | ✓ | ✓ | ✓ | ✓ | ✓ |
| OTP | ✓ | ✓ | ✓ | ✓ | ✓ |
| Projects | ✓ | ✓ | ✓ | ✓ | ✓ |
| API Keys | ✓ | ✓ | ✓ | ✓ | ✓ |
| Providers | ✓ | ✓ | ✓ | ✓ | ✓ |
| Email Engine | ✓ | ✓ | ✓ | ✓ | ✓ |
| Templates | ✓ | ✓ | ✓ | ✓ | ✓ |
| Webhooks | ✓ | ✓ | ✓ | ✓ | ✓ |
| Logs | ✓ | ✓ | ✓ | ✓ | ✓ |
| Usage | ✓ | ✓ | ✓ | ✓ | ✓ |
| Admin | ✓ | ✓ | ✓ | ✓ | ✓ |
| Accessibility | — | — | ✓ | — | ✓ |
| Responsive | — | — | ✓ | — | ✓ |
| Performance | — | ✓ | ✓ | — | ✓ |

---

# 74. Final Non-Negotiable Rules

1. No critical feature ships without tests.
2. Security-critical paths require negative tests.
3. Project isolation must be tested.
4. Authorization must be tested independently of frontend UI.
5. API errors must follow the stable contract.
6. Stack traces must never reach users.
7. Secrets must never appear in logs.
8. Real production secrets must never enter tests.
9. Duplicate-send scenarios must be tested.
10. Provider failures must be tested.
11. OTP boundaries must be tested.
12. Rate limits must be tested.
13. Webhook SSRF must be tested.
14. Webhook signatures must be tested.
15. Webhook retry behavior must be tested.
16. Database transactions must be tested.
17. Critical concurrency must be tested.
18. Accessibility is a release requirement.
19. Responsive behavior is a release requirement.
20. Performance regressions must be measurable.
21. Every production bug should gain regression coverage.
22. Migrations must be tested on upgrade paths.
23. Backup restoration must be tested.
24. Production smoke testing is mandatory.
25. Rollback criteria must be defined before deployment.
26. Tests must remain deterministic.
27. Flaky tests must be fixed.
28. Frontend/backend contracts must remain synchronized.
29. Security must never be weakened to make tests pass.
30. A green suite does not replace manual QA for critical workflows.

---

# 75. Final Architecture Relationship

```text
00–19
Core Architecture / Security / Backend
          |
20
Frontend Development
          |
21
Responsive / Accessibility / Performance
          |
22
Testing / QA / Error Handling
          |
23
Deployment / Maintenance / Developer Guide
          |
24
Development Rules / Final Checklist
```

This document adds quality controls without changing the locked system architecture.

---

# 76. Final Lock

The testing, QA and error-handling architecture is **FINAL / LOCKED**.

No implementation may bypass:

- automated testing
- security testing
- project-isolation testing
- API contract testing
- provider failure testing
- error normalization
- safe logging
- accessibility verification
- responsive verification
- performance verification
- migration verification
- production smoke testing
- regression testing

**This document is the authoritative testing, QA and error-handling standard for the Email API Platform.**

**Status: FINAL / LOCKED**
