# 18 — ADMIN PANEL

**Project:** Email API Platform  
**Document:** Complete Administrative Dashboard, User Management, Provider Operations, Logs, Analytics, Security & System Configuration  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Related:** `03-SYSTEM-ARCHITECTURE.md`, `08-DATABASE-ARCHITECTURE.md`, `10-BACKEND-PHP-ARCHITECTURE.md`, `16-PROJECTS-API-KEYS-WEBHOOKS.md`, `17-USER-PANEL.md`, `19-SECURITY-ARCHITECTURE.md`

---

## 1. Purpose

This document defines the complete Admin Panel for the Email API Platform.

The Admin Panel is a privileged operational interface for authorized administrators to manage:

- Users
- Projects
- Providers
- Gmail connections
- SMTP connections
- Optional providers
- Email logs
- OTP logs
- API logs
- Webhook logs
- Templates
- API keys
- API usage
- Analytics
- System statistics
- Security
- Blocked IPs
- Rate limits
- Login attempts
- Security/audit logs
- System settings
- Email settings
- OTP settings
- API settings
- General settings
- Admin accounts
- Admin profile
- Admin security

The Admin Panel is strictly separated from the normal User Panel.

---

# 2. Administrative Boundary

```text
                    ADMIN AUTHENTICATION
                            │
                            ▼
                    ADMIN AUTHORIZATION
                            │
                            ▼
                    ┌─────────────────┐
                    │   ADMIN PANEL   │
                    └────────┬────────┘
                             │
       ┌─────────────┬───────┼─────────┬──────────────┐
       ▼             ▼       ▼         ▼              ▼
     Users        Projects Providers  Logs         Security
       │             │       │         │              │
       └─────────────┴───────┴─────────┴──────────────┘
                             │
                             ▼
                    SYSTEM CONFIGURATION
```

Admin privileges must be enforced by the backend.

Hiding an admin route or button in the frontend is not a security control.

---

# 3. Locked Admin Screens

The Admin Panel contains these 37 locked screens:

```text
51  Admin Dashboard
52  Users
53  User Details
54  Add User
55  Edit User
56  Projects
57  Project Details
58  Project Management
59  Email Providers
60  Gmail Connections
61  SMTP Connections
62  Brevo Connections
63  Mailtrap Connections
64  Email Logs
65  Email Log Details
66  OTP Logs
67  API Logs
68  Webhook Logs
69  Templates
70  Template Details
71  API Keys
72  API Usage
73  Analytics
74  System Statistics
75  Security Dashboard
76  Blocked IPs
77  Rate Limits
78  Login Attempts
79  Security/Audit Logs
80  System Settings
81  Email Settings
82  OTP Settings
83  API Settings
84  General Settings
85  Admin Accounts
86  Admin Profile
87  Admin Security
```

No additional core Admin Panel screen is required outside this locked scope.

---

# 4. Admin Navigation

Recommended structure:

```text
Dashboard

Users
Projects

Providers
  ├── Email Providers
  ├── Gmail Connections
  ├── SMTP Connections
  ├── Brevo Connections
  └── Mailtrap Connections

Email Operations
  ├── Email Logs
  ├── OTP Logs
  ├── API Logs
  └── Webhook Logs

Templates
API Keys
API Usage
Analytics
System Statistics

Security
  ├── Security Dashboard
  ├── Blocked IPs
  ├── Rate Limits
  ├── Login Attempts
  └── Security/Audit Logs

Settings
  ├── System Settings
  ├── Email Settings
  ├── OTP Settings
  ├── API Settings
  └── General Settings

Administration
  ├── Admin Accounts
  ├── Admin Profile
  └── Admin Security
```

---

# 5. Admin Layout

Desktop:

```text
┌──────────────────────────────────────────────────────────────┐
│ Logo        Admin Search       Alerts       Admin Profile    │
├───────────────┬──────────────────────────────────────────────┤
│ Admin Sidebar │ Breadcrumbs                                  │
│               │                                              │
│ Dashboard     │ Page Content                                 │
│ Users         │                                              │
│ Projects      │                                              │
│ Providers     │                                              │
│ Logs          │                                              │
│ Security      │                                              │
│ Settings      │                                              │
│ Administration│                                              │
└───────────────┴──────────────────────────────────────────────┘
```

Mobile:

```text
┌───────────────────────────┐
│ Admin   Alerts   Menu     │
├───────────────────────────┤
│ Page Title                │
│                           │
│ Admin Content             │
└───────────────────────────┘
```

---

# 6. Admin Dashboard

Screen: `51 Admin Dashboard`

Purpose:

Provide a high-level operational view of the platform.

Recommended metrics:

```text
Total Users
Active Users
Suspended Users
Total Projects
Emails Sent
Emails Failed
API Requests
Webhook Deliveries
Provider Errors
Security Events
```

Operational widgets:

```text
Email Volume
API Traffic
Provider Health
Webhook Health
Recent Security Events
Recent Audit Events
System Health
```

---

# 7. Admin Dashboard Principles

The dashboard must:

- Load quickly.
- Degrade gracefully if one widget fails.
- Avoid exposing unnecessary personal information.
- Use aggregated statistics where possible.
- Clearly distinguish current-period metrics from lifetime metrics.

---

# 8. Admin Dashboard Quick Actions

Possible actions:

```text
Add User
Open Users
Open Projects
Review Security Events
Review Failed Emails
Review Provider Health
Open System Settings
```

Destructive operations must not be placed as one-click dashboard actions.

---

# 9. Users

Screen: `52 Users`

Table:

```text
User
Email
Status
Verified
Projects
Last Login
Created
Actions
```

Filters:

```text
Search
Status
Verification
Date
```

Actions:

```text
View
Edit
Suspend
Activate
```

---

# 10. User Details

Screen: `53 User Details`

Sections:

```text
Account
Profile
Projects
Provider Connections
Usage
Recent Email Activity
Security Activity
Sessions
```

Sensitive data must remain protected.

Never display:

- Password hashes.
- API key secrets.
- OAuth tokens.
- SMTP passwords.
- OTP values.

---

# 11. Add User

Screen: `54 Add User`

Fields:

```text
Name
Email
Password
Email Verified
Account Status
```

Recommended status options:

```text
Active
Suspended
```

Admin-created passwords must still satisfy the platform password policy.

---

# 12. User Creation Rules

After creating a user:

- Password is securely hashed.
- Audit event is created.
- Welcome/verification flow follows system policy.
- Sensitive values are never logged.
- Admin identity is recorded.

---

# 13. Edit User

Screen: `55 Edit User`

Editable:

```text
Name
Email
Status
Verification State
```

Security-sensitive changes may require administrator re-authentication.

Changing a user's email should follow email verification policy.

---

# 14. User Suspension

Suspending a user should invalidate or restrict:

```text
User sessions
Project access
API key authentication
Email sending
Webhook management
```

The exact behavior is controlled by backend policy.

Suspension must create an audit event.

---

# 15. User Activation

Activation should:

```text
Restore eligible account access
Preserve existing historical records
Create audit event
Notify user if policy requires
```

Activation must not silently restore revoked credentials.

---

# 16. Projects

Screen: `56 Projects`

Display:

```text
Project
Owner
Environment
Status
Providers
Emails
API Requests
Created
```

Filters:

```text
Search
Owner
Status
Environment
Date
```

---

# 17. Project Details

Screen: `57 Project Details`

Sections:

```text
Overview
Owner
Settings
Providers
Templates
API Keys
Email Activity
Usage
Webhooks
Security Events
```

Admin access is read/write only where the specific operation is authorized.

---

# 18. Project Management

Screen: `58 Project Management`

Administrative actions:

```text
View
Suspend
Activate
Archive
Delete
Change operational settings
```

Destructive actions require explicit confirmation.

Project deletion must follow the locked data-retention and deletion policy.

---

# 19. Email Providers

Screen: `59 Email Providers`

Global provider overview:

```text
Provider Type
Projects Using
Healthy
Degraded
Failed
Last Health Check
```

Provider types:

```text
Gmail
SMTP
Brevo
Mailtrap
```

The provider adapter architecture remains the source of truth.

---

# 20. Gmail Connections

Screen: `60 Gmail Connections`

Display:

```text
User
Project
Google Account
Status
Scopes
Connected
Last Used
```

Never display:

```text
OAuth access token
OAuth refresh token
Client secret
```

Admins may revoke a connection where policy permits.

---

# 21. Gmail Connection Operations

Actions:

```text
View Metadata
Test
Disable
Revoke
```

Revocation must:

- Protect stored credentials.
- Update provider state.
- Invalidate future sends.
- Create an audit event.

---

# 22. SMTP Connections

Screen: `61 SMTP Connections`

Display:

```text
User
Project
Provider Name
Host
Port
Encryption
Status
Last Test
```

Do not display the stored SMTP password.

Actions:

```text
Test
Disable
Edit
Remove
```

---

# 23. Brevo Connections

Screen: `62 Brevo Connections`

Optional provider administration.

Display only safe metadata:

```text
User
Project
Connection Name
Status
Last Used
```

Provider secrets must remain encrypted/protected.

---

# 24. Mailtrap Connections

Screen: `63 Mailtrap Connections`

Purpose:

Support optional testing/development email workflows.

Display:

```text
User
Project
Connection
Environment
Status
Last Used
```

Do not expose credentials.

---

# 25. Email Logs

Screen: `64 Email Logs`

Admin log table:

```text
Message ID
User
Project
Recipient
Provider
Status
Created
```

Filters:

```text
User
Project
Provider
Status
Date
Recipient
Template
```

Pagination is mandatory.

---

# 26. Email Log Details

Screen: `65 Email Log Details`

Display safe operational data:

```text
Message ID
Request ID
User
Project
Provider
Status
Recipient
Subject
Template
Created
Sent
Duration
Retry Count
Normalized Error
Provider Response Code
```

Sensitive content should be minimized.

Credentials and secrets must never appear.

---

# 27. OTP Logs

Screen: `66 OTP Logs`

Display:

```text
OTP Request ID
User
Project
Purpose
Destination
Status
Attempts
Created
Expires
Verified
```

Never display the actual OTP.

---

# 28. API Logs

Screen: `67 API Logs`

Display:

```text
Request ID
User
Project
Endpoint
Method
Status
Response Time
IP
Created
```

Sensitive request bodies should be redacted or excluded.

---

# 29. Webhook Logs

Screen: `68 Webhook Logs`

Display:

```text
Delivery ID
User
Project
Webhook
Event
Status
HTTP Status
Attempt
Duration
Created
```

Actions:

```text
View
Retry where supported
```

Retry operations must respect idempotency and delivery policy.

---

# 30. Templates

Screen: `69 Templates`

Admin template list:

```text
Template
Owner
Project
Version
Status
Updated
Usage
```

Actions:

```text
View
Edit where authorized
Archive
Delete where permitted
```

---

# 31. Template Details

Screen: `70 Template Details`

Display:

```text
Template Metadata
Current Version
Variables
Usage
Project
Owner
Status
Version History
```

Template HTML should be handled as potentially untrusted content.

Admin preview must use the same safe rendering policy as the User Panel.

---

# 32. API Keys

Screen: `71 API Keys`

Display:

```text
Key Prefix
User
Project
Scopes
Status
Created
Expires
Last Used
```

Never display the full API key secret.

Actions:

```text
Revoke
Suspend
Review Usage
```

Admin must not recover an existing secret.

---

# 33. API Usage

Screen: `72 API Usage`

Metrics:

```text
Requests
Successful
Failed
Rate Limited
Average Latency
Top Endpoints
Top Projects
```

Filters:

```text
Date
User
Project
Endpoint
Status
```

---

# 34. Analytics

Screen: `73 Analytics`

Platform-wide analytics:

```text
User Growth
Project Growth
Email Volume
API Volume
Success Rate
Failure Rate
Provider Distribution
Webhook Success
OTP Activity
```

Time periods:

```text
Today
7 Days
30 Days
90 Days
Custom
```

---

# 35. Analytics Privacy

Analytics should use aggregated data whenever detailed records are not required.

Avoid unnecessary exposure of:

- Message contents.
- Password data.
- Credentials.
- Full API keys.
- OTP values.

---

# 36. System Statistics

Screen: `74 System Statistics`

Display:

```text
PHP Version
Database Status
Database Latency
Storage Status
Cron Status
Email Engine Status
Provider Health
Webhook Worker Status
Queue/Worker Compatibility Status
```

Environment details must not expose secrets.

---

# 37. System Health

Recommended health states:

```text
Healthy
Degraded
Critical
Unknown
```

Health checks should be separated from deep diagnostic operations.

Public health endpoints must expose only safe information.

---

# 38. Security Dashboard

Screen: `75 Security Dashboard`

Metrics:

```text
Failed Logins
Blocked IPs
Rate-Limited Requests
Suspicious Activity
Revoked Sessions
Security Events
Admin Events
```

Recent alerts:

```text
High
Medium
Low
```

---

# 39. Security Dashboard Rules

Security data is sensitive.

Only authorized administrators may access it.

Do not expose secrets while investigating security events.

---

# 40. Blocked IPs

Screen: `76 Blocked IPs`

Display:

```text
IP
Reason
Source
Created
Expires
Status
```

Actions:

```text
Block
Unblock
Extend
```

IP blocks must support expiration where policy allows.

---

# 41. IP Blocking Safety

Before blocking an IP, consider:

```text
Current admin session
Trusted/admin networks
Shared NAT environments
False positives
Existing security events
```

Avoid accidental administrative lockout.

---

# 42. Rate Limits

Screen: `77 Rate Limits`

Display/configure:

```text
Scope
Endpoint
Limit
Window
Current Usage
Status
```

Possible scopes:

```text
IP
User
Project
API Key
Endpoint
```

Changes must be audited.

---

# 43. Rate Limit Safety

Do not permit administrators to disable all protection without explicit confirmation.

Critical authentication/security limits must retain minimum safe boundaries.

---

# 44. Login Attempts

Screen: `78 Login Attempts`

Display:

```text
User
Email
IP
Result
Reason
Timestamp
User Agent
```

Use for:

- Account security.
- Brute-force investigation.
- Suspicious activity review.

Sensitive authentication data must be minimized.

---

# 45. Security/Audit Logs

Screen: `79 Security/Audit Logs`

Events may include:

```text
Admin Login
Admin Logout
User Created
User Suspended
User Activated
Project Suspended
API Key Revoked
Provider Revoked
Settings Changed
Security Policy Changed
IP Blocked
Rate Limit Changed
```

Each record should include:

```text
Actor
Action
Target
Timestamp
Request ID
IP
Result
```

Audit logs must be tamper-resistant according to the deployment design.

---

# 46. System Settings

Screen: `80 System Settings`

Purpose:

Central system-level configuration.

Sections:

```text
System
Security
Email
OTP
API
Rate Limits
Maintenance
Logging
```

Only authorized administrators may modify settings.

---

# 47. Email Settings

Screen: `81 Email Settings`

Possible settings:

```text
Default Provider Policy
Maximum Message Size
Attachment Limits
Default From Policy
Retry Policy
Provider Timeout
Email Log Retention
```

Changing email engine settings must be validated before activation.

---

# 48. OTP Settings

Screen: `82 OTP Settings`

Possible settings:

```text
OTP Length
Expiry
Maximum Attempts
Resend Cooldown
Maximum Resends
Purpose Policies
OTP Log Retention
```

Unsafe values must be rejected.

---

# 49. API Settings

Screen: `83 API Settings`

Possible settings:

```text
API Version
Request Limits
Maximum Body Size
Default Rate Limits
CORS Policy
Allowed Origins Policy
Request Timeout
API Log Retention
```

CORS must never be treated as authentication.

---

# 50. General Settings

Screen: `84 General Settings`

Possible:

```text
Application Name
Application URL
Timezone
Default Locale
Maintenance Mode
Support Contact
System Notifications
```

System URLs must be validated.

---

# 51. Settings Change Workflow

For sensitive settings:

```text
Open Setting
   ↓
Edit
   ↓
Validate
   ↓
Show Impact
   ↓
Confirm
   ↓
Optional Re-authentication
   ↓
Save
   ↓
Audit Event
```

---

# 52. Maintenance Mode

Maintenance mode may:

- Restrict normal user access.
- Display maintenance page.
- Preserve admin access for authorized administrators.
- Allow critical system/health operations.

Maintenance activation must be audited.

---

# 53. Admin Accounts

Screen: `85 Admin Accounts`

Display:

```text
Admin
Email
Role
Status
Last Login
Created
```

Actions:

```text
Add
Edit
Suspend
Activate
Revoke Sessions
```

---

# 54. Admin Roles

Recommended baseline:

```text
Super Admin
Admin
Operations Admin
Security Admin
Read-Only Admin
```

Exact role implementation may use permissions rather than hard-coded role assumptions.

Least privilege is mandatory.

---

# 55. Admin Permission Model

Examples:

```text
users.read
users.write
projects.read
projects.write
providers.read
providers.write
logs.read
security.read
security.write
settings.read
settings.write
admins.read
admins.write
```

Sensitive permissions should be independently controllable.

---

# 56. Super Admin Protection

Super Admin operations require the strongest controls.

Recommended:

```text
Strong password
Re-authentication
OTP/MFA where enabled
Session protection
Audit logging
```

A Super Admin must not be able to silently erase audit history.

---

# 57. Admin Profile

Screen: `86 Admin Profile`

Fields:

```text
Name
Email
Avatar
Timezone
```

Actions:

```text
Save
Change Password
Open Security
View Sessions
```

---

# 58. Admin Security

Screen: `87 Admin Security`

Sections:

```text
Authentication
Sessions
Login Protection
Security Events
Admin Activity
```

Actions:

```text
Change Password
Revoke Sessions
Review Login Attempts
Review Audit Logs
```

---

# 59. Admin Login Security

Admin authentication must enforce:

- Secure sessions.
- Password hashing.
- Login rate limiting.
- Brute-force protection.
- CSRF protection for session-based actions.
- Secure cookies.
- HTTPS.
- Session regeneration.
- Session revocation.
- Audit logging.

---

# 60. Admin Session Management

Admin sessions must support:

```text
Current Session
Other Sessions
Revoke
Revoke All
```

High-risk admin changes may invalidate sessions according to security policy.

---

# 61. Admin Audit Requirements

Every sensitive admin action should record:

```text
Actor Admin ID
Action
Target Type
Target ID
Timestamp
IP
Request ID
Result
Safe Metadata
```

Never record:

```text
Passwords
API key secrets
OAuth tokens
SMTP passwords
OTP values
```

---

# 62. Admin API Boundary

The frontend must call dedicated admin API routes or an equivalent strongly authorized backend boundary.

Example:

```text
/api/v1/admin/users
/api/v1/admin/projects
/api/v1/admin/providers
/api/v1/admin/logs
/api/v1/admin/security
/api/v1/admin/settings
/api/v1/admin/admins
```

Exact routing can follow the REST API specification while preserving the admin authorization boundary.

---

# 63. Admin Authorization Flow

```text
Request
  ↓
Authenticate Admin
  ↓
Load Admin Identity
  ↓
Check Admin Status
  ↓
Check Permission
  ↓
Check Resource Policy
  ↓
Execute Operation
  ↓
Write Audit Event
  ↓
Return Response
```

Authorization must occur server-side.

---

# 64. User vs Admin Separation

```text
USER PANEL
    │
    ├── Own Account
    ├── Own Projects
    └── Own Project Resources

ADMIN PANEL
    │
    ├── Platform Users
    ├── Platform Projects
    ├── Platform Providers
    ├── Platform Logs
    ├── Platform Security
    └── Platform Settings
```

Do not use frontend-only route hiding as the separation mechanism.

---

# 65. Search

Admin search may cover:

```text
Users
Projects
API Keys
Logs
Providers
Templates
Audit Events
```

Search must enforce admin permissions and minimize returned sensitive data.

---

# 66. Filters and Pagination

All large admin datasets require:

```text
Server-side filtering
Server-side pagination
Stable sorting
Search
Date filtering
```

Never load the entire platform log dataset into the browser.

---

# 67. Bulk Operations

Bulk operations may be supported for safe administrative tasks.

Examples:

```text
Export safe metadata
Activate users
Suspend users
Block IPs
```

Destructive bulk operations require:

- Explicit confirmation.
- Affected-record count.
- Audit event.
- Permission check.

---

# 68. Export Rules

If exports are supported:

- Export only authorized fields.
- Exclude secrets.
- Protect generated files.
- Use short-lived access.
- Audit exports.
- Avoid exposing unnecessary personal data.

---

# 69. Admin Error States

Support:

```text
401 Unauthorized
403 Forbidden
404 Not Found
409 Conflict
422 Validation Error
429 Rate Limited
500 Server Error
503 Service Unavailable
```

Do not expose stack traces.

---

# 70. Admin Loading States

Every admin page must support:

```text
Initial Loading
Refreshing
Submitting
Empty
Error
Retry
```

Sensitive operations should clearly show progress.

---

# 71. Destructive Action UX

Before:

```text
Delete User
Delete Project
Delete Provider
Delete Template
```

show:

```text
What will happen
What cannot be undone
What dependencies are affected
Confirmation
```

For high-risk actions, require typed confirmation.

---

# 72. User Suspension Confirmation

Example:

```text
Suspend user?

This will restrict account access and may invalidate active
sessions/API access according to platform policy.

[Cancel] [Suspend User]
```

---

# 73. Project Suspension Confirmation

Example:

```text
Suspend project?

Email sending and project API access may stop immediately.

[Cancel] [Suspend Project]
```

---

# 74. Security Operations Confirmation

Security actions such as:

```text
Block IP
Revoke admin session
Change security policy
Change rate limits
```

must provide clear impact information.

---

# 75. Admin Responsive Design

Desktop:

```text
Full sidebar + data tables
```

Tablet:

```text
Compact navigation + responsive tables
```

Mobile:

```text
Drawer navigation + cards
```

Dense administrative tables may horizontally scroll where card conversion would reduce clarity.

---

# 76. Accessibility

Admin Panel must support:

- Keyboard navigation.
- Focus management.
- Semantic headings.
- Accessible forms.
- Accessible tables.
- Accessible dialogs.
- Screen reader announcements.
- Reduced motion.
- Sufficient contrast.

---

# 77. Admin Performance

Admin Panel should:

- Paginate large datasets.
- Debounce search.
- Lazy-load secondary widgets.
- Cache safe metadata.
- Avoid repeated dashboard requests.
- Use efficient server-side queries.
- Index common filter columns.
- Avoid expensive unbounded analytics queries.

---

# 78. Security Dashboard Performance

Security dashboards should prefer:

```text
Aggregated counters
Recent-event windows
Indexed queries
Precomputed usage statistics where available
```

Do not repeatedly scan massive raw logs during every page load.

---

# 79. Audit Log Integrity

Audit logs should be append-oriented.

Normal administrators must not have an interface action that silently edits historical audit records.

If retention/deletion is legally or operationally required, it must follow explicit system policy and be auditable.

---

# 80. Provider Operations Safety

Admin provider operations must use the same provider adapter abstraction as normal email sending.

Do not create a second provider implementation solely for the Admin Panel.

---

# 81. Email Operations Safety

Admin-triggered test emails must still pass through:

```text
Email Engine
Provider Adapter
Validation
Rate Limits
Logging
Audit/Event Tracking
```

The Admin Panel must never send email by bypassing the email engine.

---

# 82. API Key Safety

Administrators can manage API key metadata and revoke keys where authorized.

They must not:

- Recover an existing secret.
- Display full historical secrets.
- Log secrets.
- Copy secrets into audit records.

---

# 83. Template Safety

Admin template preview and editing must respect the same:

```text
Sanitization
Variable validation
Rendering
Project isolation
Versioning
```

rules as the template engine.

---

# 84. Webhook Safety

Admin webhook operations must preserve:

```text
HMAC signing
SSRF protection
Retry policy
Idempotency
Delivery logging
Secret protection
```

Webhook failures must never be allowed to break the primary email send.

---

# 85. System Configuration Safety

Settings should be validated against:

```text
Allowed ranges
Data types
Security boundaries
Provider capabilities
Current system state
```

Do not permit arbitrary configuration values to reach runtime components.

---

# 86. Notifications

Admin notifications may cover:

```text
Critical provider failure
System health degradation
Security alert
High failure rate
Webhook outage
Storage/database issue
Maintenance event
```

Critical alerts should remain visible until acknowledged where appropriate.

---

# 87. Admin Dashboard Alert Priority

Use:

```text
Critical
High
Medium
Low
Info
```

Avoid color-only status communication.

---

# 88. Admin API Rate Limiting

Admin APIs require rate limiting too.

High-risk endpoints should use stricter limits:

```text
Login
Password changes
Admin creation
Permission changes
Security configuration
Bulk actions
```

---

# 89. Admin CSRF

Session-authenticated admin state-changing requests require CSRF protection.

For token-authenticated API endpoints, use the platform's API authentication and authorization model instead of incorrectly adding browser CSRF assumptions.

---

# 90. Admin CORS

Admin frontend should use a controlled origin policy.

CORS does not provide authorization.

Sensitive admin endpoints should not be made broadly accessible to arbitrary origins.

---

# 91. Admin Request Logging

Log safe metadata:

```text
Request ID
Admin ID
Endpoint
Method
Status
Duration
IP
```

Do not log sensitive request bodies indiscriminately.

---

# 92. Admin Database Access

The Admin Panel must use application services/repositories.

Controllers must not contain raw SQL business logic.

Use:

```text
Controller
  ↓
Admin Service
  ↓
Policy/Authorization
  ↓
Repository
  ↓
PDO
```

---

# 93. Admin Transaction Rules

Use database transactions for operations requiring multiple related updates.

Examples:

```text
Suspend user + invalidate sessions
Revoke provider + update provider state
Change system setting + audit event
```

---

# 94. Admin Concurrency

Protect against conflicting operations.

Example:

```text
Admin A opens project
Admin B suspends project
Admin A attempts provider change
```

Backend must re-check current authorization/status before mutation.

---

# 95. Admin Idempotency

High-impact repeated operations should be safely repeatable where practical.

Examples:

```text
Revoke API key
Disable provider
Suspend project
Revoke session
```

The API should return a consistent final state rather than creating duplicate side effects.

---

# 96. Admin Observability

Admin operations should expose enough information for diagnosis:

```text
Request ID
Audit ID where available
Operation result
Safe error code
Timestamp
```

Do not expose internal stack traces.

---

# 97. Admin Testing Matrix

Test:

```text
Super Admin
Admin
Operations Admin
Security Admin
Read-Only Admin
Disabled Admin
Expired Session
Insufficient Permission
Unauthorized Request
Cross-resource access
User suspension
Project suspension
Provider revocation
API key revocation
Security policy changes
Rate limit changes
Bulk operations
Large datasets
Mobile layout
Keyboard navigation
Slow network
429
500
503
```

---

# 98. Security Test Cases

Verify:

```text
Normal user cannot access admin routes
Admin without permission receives 403
Disabled admin cannot authenticate
Revoked session cannot access admin APIs
Admin cannot read API key secrets
Admin cannot read OAuth tokens
Admin cannot read SMTP passwords
Admin cannot read OTP values
Audit events are created for sensitive changes
CSRF protection works
Rate limiting works
Project isolation remains intact
```

---

# 99. Admin User Journey — Investigate Failed Email

```text
Admin Dashboard
      ↓
Email Logs
      ↓
Filter FAILED
      ↓
Open Email Log
      ↓
Inspect normalized error
      ↓
Identify Provider
      ↓
Open Provider Connection
      ↓
Test/Review
      ↓
Audit operational action
```

---

# 100. Admin User Journey — Security Incident

```text
Security Dashboard
      ↓
Recent Security Event
      ↓
Login Attempts
      ↓
Identify suspicious IP
      ↓
Review affected account/project
      ↓
Block IP if authorized
      ↓
Revoke relevant sessions/keys
      ↓
Record audit trail
```

---

# 101. Admin User Journey — Provider Incident

```text
Provider Health
      ↓
Identify degraded provider
      ↓
Review provider connections
      ↓
Review email failures
      ↓
Test provider
      ↓
Apply authorized operational action
      ↓
Monitor recovery
```

---

# 102. Admin User Journey — System Configuration

```text
System Settings
      ↓
Select Setting
      ↓
Review Current Value
      ↓
Edit
      ↓
Validate
      ↓
Confirm Impact
      ↓
Re-authenticate if required
      ↓
Save
      ↓
Audit
```

---

# 103. Admin Panel and User Panel Relationship

The User Panel manages user-owned resources.

The Admin Panel manages platform operations.

```text
User Panel
    ↓
User-owned resources

Admin Panel
    ↓
Platform-wide privileged operations
```

Both panels use the same backend domain services where appropriate.

They do not create duplicate business logic.

---

# 104. Shared Service Rule

Example:

```text
User Panel ─────┐
                ├── Email Service ── Email Engine
Admin Panel ────┘
```

Likewise:

```text
User Panel ─────┐
                ├── Provider Service
Admin Panel ────┘
```

and:

```text
User Panel ─────┐
                ├── Audit/Event Service
Admin Panel ────┘
```

---

# 105. Admin Asset Rules

Use the locked asset policy:

- Inter.
- JetBrains Mono.
- Lucide.
- Official/Simple Icons.
- SVG/WebP/PNG as appropriate.
- No arbitrary icon libraries.
- No unlicensed provider logos.

---

# 106. Admin Theme

Follow the global UI/UX design system.

Admin-specific emphasis may include:

```text
Operational status
Security severity
System health
Audit activity
```

but must remain visually consistent with the product.

---

# 107. Admin Empty States

Examples:

```text
No users found.
No projects found.
No blocked IPs.
No recent security events.
No provider incidents.
No webhook failures.
```

Empty states should distinguish:

```text
No data
No matching results
No permission
```

---

# 108. Admin Search Result Security

Search results must not leak information merely because a user can search for it.

Authorization is applied before returning results.

Sensitive fields should be excluded at the query/service layer where possible.

---

# 109. Data Minimization

Admin visibility should follow least privilege.

Display the minimum information required for the operational task.

This reduces:

- Privacy risk.
- Insider risk.
- Accidental disclosure.
- Browser exposure.
- Log exposure.

---

# 110. Admin Export Security

Generated exports should:

```text
Have explicit authorization
Use safe fields
Have limited lifetime
Be logged
Avoid secrets
```

Do not create permanent public download URLs for sensitive exports.

---

# 111. System Settings Versioning

Settings changes should record:

```text
Setting
Old Value
New Value
Actor
Time
Request ID
```

Secrets must be represented safely, for example:

```text
[REDACTED]
```

rather than storing the actual value in audit metadata.

---

# 112. Maintenance and Recovery

The Admin Panel must remain usable during controlled maintenance when policy permits.

Critical operations should have safe failure behavior.

Do not allow a partially applied configuration update to leave the system in an undefined state.

---

# 113. Backup Awareness

Admin Panel may display safe backup status:

```text
Last Backup
Backup Health
Last Successful Backup
```

Actual backup credentials and secrets are never exposed.

---

# 114. Retention Management

Where retention settings are configurable, define policies for:

```text
Email Logs
OTP Logs
API Logs
Webhook Logs
Security Logs
Audit Logs
Notifications
```

Retention changes must be audited.

---

# 115. Privacy Controls

Admin interfaces should support operational privacy requirements without exposing unnecessary personal data.

Examples:

```text
Masked email where full address is unnecessary
Redacted request bodies
No OTP values
No credentials
No API secrets
```

---

# 116. Admin Definition of Done

The Admin Panel is complete when:

- All 37 locked screens are implemented.
- Admin authentication is isolated.
- Role/permission authorization is enforced server-side.
- Users can be managed.
- Projects can be managed.
- Providers can be monitored and managed.
- Gmail/SMTP/optional provider connections can be administered safely.
- Email/OTP/API/Webhook logs are available.
- Templates can be reviewed safely.
- API key metadata can be managed without revealing secrets.
- Usage and analytics are available.
- System statistics are available.
- Security dashboard is operational.
- IP/rate-limit/login controls are available.
- Security/audit logs are available.
- System/email/OTP/API/general settings are controlled.
- Admin accounts are manageable.
- Admin profile/security are available.
- Sensitive data is protected.
- All destructive actions are confirmed and audited.
- Responsive/accessibility requirements are met.
- Admin functionality cannot be accessed by normal users.
- Admin UI does not duplicate core business logic.

---

# 117. Non-Negotiable Rules

1. Admin authentication is separate from normal user authorization.
2. Admin authorization is enforced server-side.
3. Frontend route hiding is never a security boundary.
4. Least privilege is mandatory.
5. Admin roles must map to explicit permissions.
6. Disabled admins cannot access the panel.
7. Admin sessions must be revocable.
8. Sensitive admin operations must be audited.
9. Passwords are never displayed.
10. API key secrets are never recoverable through the Admin Panel.
11. OAuth tokens are never displayed.
12. SMTP passwords are never displayed.
13. OTP values are never displayed.
14. Secrets are never written to audit logs.
15. User suspension must create an audit event.
16. Project suspension must create an audit event.
17. Provider revocation must create an audit event.
18. Security changes must create an audit event.
19. Large datasets use server-side pagination.
20. Search results remain permission-scoped.
21. CORS is not authentication.
22. CSRF protection applies to session-authenticated state changes.
23. Admin APIs are rate limited.
24. Destructive actions require explicit confirmation.
25. High-risk operations may require re-authentication.
26. Admin operations use shared backend domain services.
27. Admin Panel never bypasses the Email Engine.
28. Admin Panel never bypasses Provider Adapters.
29. Admin Panel never bypasses project/resource authorization.
30. Webhook operations preserve HMAC/SSRF/retry/idempotency rules.
31. Template operations preserve template security rules.
32. User Panel and Admin Panel remain separate UX boundaries.
33. Audit history is append-oriented and protected.
34. Sensitive exports are controlled and audited.
35. Error responses never expose stack traces.
36. System settings are validated before activation.
37. Maintenance mode changes are audited.
38. Provider credentials remain encrypted/protected.
39. Security information is minimized to operational need.
40. No Admin Panel feature may introduce a new conflicting architecture.

---

# 118. Final Architecture Diagram

```text
                         ADMIN
                           │
                           ▼
                  ┌─────────────────┐
                  │ ADMIN AUTH      │
                  └────────┬────────┘
                           │
                           ▼
                  ┌─────────────────┐
                  │ ADMIN RBAC      │
                  │ / PERMISSIONS   │
                  └────────┬────────┘
                           │
                           ▼
                  ┌─────────────────┐
                  │   ADMIN PANEL   │
                  └────────┬────────┘
                           │
        ┌──────────────────┼──────────────────┐
        ▼                  ▼                  ▼
      USERS            PROJECTS          SECURITY
        │                  │                  │
        └────────────┬─────┴──────┬───────────┘
                     ▼            ▼
                 PROVIDERS       LOGS
                     │            │
                     └─────┬──────┘
                           ▼
                    SHARED SERVICES
                           │
       ┌───────────────────┼────────────────────┐
       ▼                   ▼                    ▼
   EMAIL ENGINE       PROVIDER ENGINE       AUDIT/EVENTS
       │                   │                    │
       ▼                   ▼                    ▼
   Gmail/SMTP/etc.     Provider APIs       Security Logs
```

---

# 119. Final Lock

The Admin Panel architecture is now defined as the privileged operational interface for the Email API Platform.

Locked decisions:

- 37 admin screens remain the official Admin Panel scope.
- Admin authentication and authorization are separate from normal user access.
- Permission-based least privilege is mandatory.
- Admin operations use shared domain services instead of duplicate business logic.
- Users, projects, providers, templates, API keys, logs, analytics, security and system settings are managed through their defined boundaries.
- Secrets are never recoverable through normal admin UI.
- All sensitive operations are audited.
- Large datasets are paginated and filtered server-side.
- Security and privacy minimization are mandatory.
- The Admin Panel never bypasses the Email Engine, Provider Engine, project authorization or security architecture.
- User Panel and Admin Panel remain separate interfaces.
- No structural architecture change is permitted without an explicit architecture revision.

**STATUS: FINAL / LOCKED**

**Next document:** `19-SECURITY-ARCHITECTURE.md`
