# 05 — UI/UX DESIGN SYSTEM

**Project:** Email API Platform  
**Document:** 05-UI-UX-DESIGN-SYSTEM.md  
**Status:** FINAL / LOCKED  
**Document Set:** 5 of 25  
**Scope:** Product-wide UI/UX rules, visual language, components, interaction patterns, responsive behavior, accessibility, and design governance.

---

## 1. Purpose

This document defines the locked UI/UX design system for the Email API Platform.

It establishes a single visual and interaction language across:

- Public website
- Authentication
- User dashboard
- Project management
- Email providers
- Templates
- Email sending
- API integration
- API keys
- Logs
- Usage and analytics
- Webhooks
- Notifications
- Profile and security
- Administration
- System and error states

The design system exists to prevent inconsistent screens, duplicated component behavior, arbitrary styling, and structural UI changes during implementation.

**UI/UX architecture is locked.** Future implementation work must extend this system rather than replace it.

---

# 2. Product UX Principles

## 2.1 Clarity First

Every screen must communicate:

1. Where the user is.
2. What the user can do.
3. What happened.
4. What needs attention.
5. What the next useful action is.

Avoid decorative UI that competes with primary tasks.

## 2.2 Developer-Friendly by Default

The platform is an email API product. Interfaces must feel comfortable to developers while remaining understandable to non-developers.

Developer-oriented areas should use:

- Clear endpoint labels
- HTTP method badges
- Monospace code
- Copy buttons
- Syntax-friendly code blocks
- Request/response examples
- API key visibility controls
- Technical error messages with human-readable explanations

## 2.3 Progressive Disclosure

Do not expose every advanced setting immediately.

Primary actions appear first. Advanced configuration can appear through:

- Expandable sections
- Tabs
- Secondary panels
- Advanced settings blocks
- Detail drawers
- Modal dialogs where appropriate

## 2.4 Consistent Mental Models

The same action should behave the same way throughout the product.

Examples:

- `Create` uses the same primary action treatment.
- `Delete` always requires appropriate confirmation.
- `Save` reports success or failure clearly.
- Provider connection states use consistent status indicators.
- Logs use consistent filtering and detail patterns.

## 2.5 Safe Destructive Actions

Destructive operations must never be visually equivalent to ordinary actions.

Examples:

- Delete project
- Delete template
- Revoke API key
- Disconnect provider
- Revoke session
- Suspend user
- Block IP

Use explicit confirmation and explain consequences when necessary.

## 2.6 Feedback Is Mandatory

Every asynchronous action should produce a visible state:

- Loading
- Success
- Failure
- Empty
- Disabled
- Retry, where applicable

Never leave users wondering whether an action was submitted.

---

# 3. Locked Technology-Level UI Baseline

The UI is implemented with the locked frontend stack:

- HTML5
- CSS3
- Bootstrap 5.3+
- JavaScript ES6+
- Fetch API
- CSS variables
- Lightweight CSS animation
- GSAP only where useful
- Lucide icons
- Simple Icons and official provider SVG assets
- Inter
- JetBrains Mono

Bootstrap provides structural utilities and responsive primitives. It must not dictate the entire visual identity.

The product's custom CSS design tokens and components are authoritative.

---

# 4. Visual Identity

## 4.1 Design Character

The platform should visually communicate:

- Reliable
- Technical
- Secure
- Fast
- Professional
- Modern
- Developer-focused
- Clean
- Operational

Avoid:

- Excessive gradients
- Heavy glassmorphism
- Excessive shadows
- Oversized decorative illustrations
- Unnecessary motion
- Dense visual noise
- Consumer-social UI patterns

## 4.2 Visual Hierarchy

Every screen should have a clear hierarchy:

**Level 1 — Page purpose**

The primary heading communicates the screen's purpose.

**Level 2 — Primary task**

The dominant card, form, table, editor, or dashboard section.

**Level 3 — Supporting information**

Descriptions, metadata, helper text, secondary statistics.

**Level 4 — Advanced/secondary actions**

Settings, exports, advanced filters, destructive operations.

---

# 5. Design Tokens

Design tokens must be centralized using CSS custom properties.

Example token structure:

```css
:root {
  --color-primary: ...;
  --color-primary-hover: ...;
  --color-background: ...;
  --color-surface: ...;
  --color-surface-muted: ...;
  --color-border: ...;
  --color-text: ...;
  --color-text-muted: ...;
  --color-success: ...;
  --color-warning: ...;
  --color-danger: ...;
  --color-info: ...;

  --font-sans: "Inter", sans-serif;
  --font-mono: "JetBrains Mono", monospace;

  --radius-sm: ...;
  --radius-md: ...;
  --radius-lg: ...;

  --shadow-sm: ...;
  --shadow-md: ...;

  --space-1: ...;
  --space-2: ...;
  --space-3: ...;
  --space-4: ...;
  --space-5: ...;
  --space-6: ...;
}
```

Exact color values may be finalized during visual implementation, but all components must consume tokens rather than scattered hard-coded values.

---

# 6. Typography

## 6.1 Primary Font

**Inter** is the primary interface font.

Use it for:

- Navigation
- Headings
- Body text
- Labels
- Buttons
- Tables
- Forms
- Alerts
- Dashboard content

## 6.2 Monospace Font

**JetBrains Mono** is reserved for technical content.

Use it for:

- API endpoints
- HTTP methods where appropriate
- API keys
- Code examples
- JSON
- HTML snippets
- Error codes
- Technical identifiers
- Log IDs
- Request IDs

## 6.3 Type Hierarchy

Recommended semantic hierarchy:

| Level | Usage |
|---|---|
| Display | Public hero sections |
| H1 | Page title |
| H2 | Major section |
| H3 | Card/section heading |
| H4 | Subsection |
| Body | Normal content |
| Small | Metadata/helper text |
| Caption | Secondary labels |

Do not use heading levels only for visual size. HTML heading semantics must remain meaningful.

---

# 7. Spacing System

Use a consistent spacing scale based on a small unit and Bootstrap-compatible utilities.

Primary spacing concepts:

- Tight: icon-to-label and compact controls
- Small: related fields
- Medium: card content
- Large: sections
- Extra-large: major page separation

Avoid arbitrary one-off margins.

Component spacing must be predictable so screens remain visually consistent.

---

# 8. Layout System

## 8.1 Public Layout

Public pages use:

- Global header
- Main content
- Optional secondary sections
- Footer

Hero sections may use a two-column layout on desktop and stack vertically on mobile.

## 8.2 Auth Layout

Authentication screens prioritize:

- Focused form
- Minimal navigation
- Clear identity
- Security reassurance
- Validation feedback

Auth pages should not feel like the full dashboard.

## 8.3 Application Layout

The authenticated application uses:

- Sidebar/navigation
- Top bar
- Main content area
- Optional contextual actions
- Responsive navigation behavior

The sidebar contains product-level navigation, while page-level actions stay inside the main content area.

## 8.4 Admin Layout

The admin interface follows the same design system but visually communicates elevated operational context through:

- Stronger information density
- Administrative navigation
- Security status indicators
- Data tables
- Filters
- Audit information

Do not create a completely unrelated visual language for admin.

---

# 9. Navigation

## 9.1 Public Navigation

Primary navigation:

- Home
- Features
- How It Works
- Providers
- API Documentation
- Pricing
- FAQ
- Contact

Authentication actions:

- Login
- Register

## 9.2 User Navigation

Primary areas:

- Dashboard
- Projects
- Email Services
- Templates
- Email Send
- API Integration
- API Keys
- Logs
- Usage & Statistics
- Webhooks
- Notifications
- Profile
- Security

## 9.3 Admin Navigation

Primary areas:

- Dashboard
- Users
- Projects
- Providers
- Logs
- Templates
- API Keys
- API Usage
- Analytics
- Security
- Settings
- Admin Accounts

Navigation must show active state clearly.

---

# 10. Buttons

## 10.1 Button Hierarchy

Use:

1. Primary
2. Secondary
3. Tertiary/ghost
4. Destructive
5. Icon-only

There should normally be one visually dominant primary action per section.

## 10.2 Button States

Every interactive button must support:

- Default
- Hover
- Focus
- Active
- Disabled
- Loading

Loading state must prevent accidental duplicate submissions.

Example:

```html
<button type="button" class="btn btn-primary" data-loading="true">
  <span class="spinner-border spinner-border-sm" aria-hidden="true"></span>
  <span>Sending...</span>
</button>
```

## 10.3 Icon Buttons

Icon-only controls require:

- Accessible label
- Tooltip where useful
- Adequate hit area
- Visible focus state

Never rely on an icon alone when the action could be ambiguous.

---

# 11. Forms

Forms are central to:

- Authentication
- Project creation
- Provider configuration
- SMTP connection
- Template creation
- API key creation
- Webhooks
- Profile/security settings
- Admin configuration

## 11.1 Form Rules

Every field should have:

- Visible label
- Input/control
- Optional helper text
- Validation state where relevant
- Error message where relevant

Placeholder text must not replace labels.

## 11.2 Validation

Validation should happen at appropriate levels:

- Client-side for immediate feedback
- Server-side for authoritative validation

Server validation is always required.

## 11.3 Error Placement

Prefer:

- Inline field errors for field-specific problems
- Alert/banner for form-level failures
- Toast for completed background operations

Error text must explain how to recover when practical.

---

# 12. Cards

Cards group related information.

Use cards for:

- Dashboard statistics
- Provider status
- Project summaries
- Template summaries
- Configuration groups
- Security settings
- Usage metrics

Avoid excessive card nesting.

A card should have a clear purpose and should not simply wrap every small element.

---

# 13. Tables

Tables are essential for:

- Users
- Projects
- Providers
- Email logs
- OTP logs
- API logs
- Webhook logs
- API keys
- Sessions
- Security logs

## 13.1 Table Requirements

Tables should support where applicable:

- Search
- Filtering
- Sorting
- Pagination
- Row actions
- Status indicators
- Responsive behavior

## 13.2 Mobile Tables

Do not force a desktop-width table onto small screens.

Use one of:

- Horizontal scrolling
- Responsive stacked rows
- Priority columns with secondary information hidden behind details

The selected pattern must preserve access to important information.

---

# 14. Status System

Statuses must have both visual and textual meaning.

Standard semantic states:

- Success
- Warning
- Error/Danger
- Information
- Neutral
- Pending
- Disabled

Examples:

- Connected
- Disconnected
- Pending
- Verified
- Unverified
- Active
- Suspended
- Blocked
- Delivered
- Failed
- Queued

Do not communicate status through color alone.

---

# 15. Alerts and Notifications

## 15.1 Inline Alerts

Use for contextual messages:

- Security warnings
- Provider connection issues
- Configuration problems
- API notices
- Important account information

## 15.2 Toast Notifications

Use for lightweight action feedback:

- Saved successfully
- Template duplicated
- API key created
- Webhook updated
- Session revoked

Toasts must not be the only location for critical errors.

## 15.3 Critical Notifications

Security-critical events may require a persistent alert or notification center entry.

---

# 16. Modals and Dialogs

Use modals for focused decisions:

- Delete confirmation
- Revoke confirmation
- Disconnect provider
- API key reveal
- Important configuration confirmation

Do not use large modals for complex workflows that deserve a full page.

Modals must:

- Have accessible titles
- Trap focus correctly
- Support keyboard dismissal where appropriate
- Return focus to the triggering element

---

# 17. Drawers and Detail Panels

Detail drawers are useful for operational interfaces such as logs.

Example:

**Email Log List → Log Details**

A drawer may show:

- Request ID
- Project
- Recipient
- Provider
- Subject
- Status
- Timestamp
- Response
- Error details
- Metadata

For highly detailed content, use a dedicated detail page.

---

# 18. Code and API UI

The API documentation and integration experience must be first-class.

Code blocks should include:

- Language indicator
- Copy button
- Horizontal scrolling when necessary
- Readable line height
- JetBrains Mono
- Clear contrast

Example:

```javascript
const response = await fetch("https://api.example.com/v1/email/send", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Authorization": "Bearer YOUR_API_KEY"
  },
  body: JSON.stringify({
    to: "user@example.com",
    subject: "Welcome",
    template_id: "welcome"
  })
});
```

Never expose real production secrets in documentation.

---

# 19. API Key UX

API keys require special security treatment.

Rules:

- Mask keys by default.
- Provide controlled reveal.
- Provide copy action.
- Show creation date.
- Show last-used information where available.
- Allow revocation.
- Warn users that secrets should not be exposed publicly.
- Never display secret values in ordinary logs.

Newly generated secrets may be shown once with a clear warning.

---

# 20. Provider UX

Provider screens must make connection state immediately understandable.

Supported provider experiences include:

- Gmail
- Custom SMTP
- Optional provider adapters such as Brevo and Mailtrap

Provider cards should show:

- Provider name
- Provider icon
- Connection status
- Account/identifier where safe
- Last connection/test state
- Primary action
- Secondary management action

### Gmail

Use OAuth-oriented language:

- Connect Gmail
- Authorize access
- Connection successful
- Connection failed
- Reconnect
- Disconnect

Never ask users to paste OAuth access tokens into normal forms.

### SMTP

Use fields such as:

- Host
- Port
- Encryption
- Username
- Password/secret
- From address
- From name

Provide a connection test before enabling production use where applicable.

---

# 21. Template Editor UX

The template system must support:

- Template name
- Subject
- HTML content
- Variables
- Preview
- Test email
- Save
- Duplicate
- Delete
- Version-aware architecture

The editor should keep the primary editing area visually dominant.

Variables should be discoverable and copyable.

Example:

```text
{{name}}
{{email}}
{{verification_code}}
{{reset_url}}
```

The interface must clearly distinguish:

- Editable content
- Variable placeholders
- Preview rendering
- Test sending

---

# 22. Email Send UX

The Email Send experience should guide users through:

1. Project
2. Provider
3. Recipient
4. Sender
5. Subject/template
6. Variables/content
7. Optional metadata
8. Test/send action
9. Result

Do not require unnecessary configuration for simple sends.

For failed sends, provide:

- Human-readable summary
- Technical error where useful
- Request/log ID
- Suggested next action

---

# 23. Dashboard UX

The user dashboard should answer:

- What is the current state of my projects?
- Is email sending working?
- Which providers are connected?
- How much email has been sent?
- Are there recent failures?
- Are there security issues?
- What should I do next?

Typical dashboard sections:

- Overview statistics
- Project summary
- Provider health
- Recent email activity
- Usage
- Recent failures
- Security/notification alerts
- Quick actions

Do not overload the dashboard with every available metric.

---

# 24. Logs UX

Logs should be operationally useful rather than merely decorative.

## Email Logs

Display:

- Timestamp
- Project
- Recipient
- Provider
- Subject
- Status
- Request ID
- Error summary

## OTP Logs

Display:

- Timestamp
- Project/user context where appropriate
- Purpose
- Delivery status
- Expiry state
- Attempt status

Never expose OTP secrets in logs.

## API Logs

Display:

- Timestamp
- Endpoint
- Method
- Status code
- Project
- Request ID
- Response time
- Rate-limit information where applicable

---

# 25. Empty States

Every major collection screen must have a meaningful empty state.

Examples:

- No projects
- No templates
- No providers
- No email logs
- No webhooks
- No API keys
- No notifications

An empty state should contain:

1. Explanation
2. Primary next action
3. Optional short guidance

Avoid empty states that merely say "No data."

---

# 26. Loading States

Use appropriate loading patterns:

- Button spinner for submitted actions
- Skeletons for dashboard/table content
- Inline progress for long operations
- Page-level loading only when necessary

Do not show indefinite spinners without timeout/error handling.

---

# 27. Error UX

Errors must be understandable at three levels.

## User Level

What went wrong?

## Recovery Level

What should the user do?

## Technical Level

What identifier or technical detail can help debugging?

Example:

> Email could not be sent.  
> Check the connected provider or SMTP credentials and try again.  
> Request ID: `req_...`

---

# 28. System Error Screens

The locked system screens are:

- 404
- 403
- 429 Rate Limited
- 500 Server Error
- Maintenance
- API Error Response

Each must provide:

- Clear status
- Short explanation
- Recovery action where possible
- Consistent branding

The API error response is machine-readable and must follow the REST API specification.

---

# 29. Search and Filtering

Operational lists should support search/filtering where useful.

Common filters:

- Status
- Project
- Provider
- Date/time
- User
- Endpoint
- Event type

Filters should be:

- Clearly labeled
- Resettable
- Keyboard accessible
- Responsive

Do not make filtering depend solely on color or iconography.

---

# 30. Responsive Design

The interface must support:

- Small mobile
- Large mobile
- Tablet portrait
- Tablet landscape
- Laptop
- Desktop
- Large desktop

## 30.1 Mobile Principles

On mobile:

- Navigation collapses appropriately.
- Multi-column layouts stack.
- Buttons remain tappable.
- Tables adapt.
- Forms become single-column where appropriate.
- Cards avoid excessive nesting.
- Code blocks can scroll horizontally.
- Modals fit within the viewport.
- Critical actions remain visible.

## 30.2 Touch Targets

Interactive controls must have comfortable touch targets and adequate spacing.

Do not place destructive and safe actions so close together that accidental taps become likely.

---

# 31. Accessibility

Accessibility is a product requirement, not an optional enhancement.

## 31.1 Semantic HTML

Use:

- `header`
- `nav`
- `main`
- `section`
- `article`
- `footer`
- Correct heading hierarchy
- Native form controls where possible

## 31.2 Keyboard Access

All core workflows must be usable with keyboard navigation.

Required:

- Visible focus
- Logical tab order
- Keyboard-operable controls
- Accessible modals
- No keyboard traps

## 31.3 Screen Readers

Use:

- Labels
- ARIA only when necessary
- Descriptive button names
- Status announcements where appropriate
- Meaningful link text

## 31.4 Color

Color must not be the sole method of communicating:

- Error
- Success
- Warning
- Provider state
- Account state

Pair semantic color with text, icon, or another indicator.

## 31.5 Motion

Respect reduced-motion preferences.

Animations must never prevent users from completing tasks.

---

# 32. Motion Design

Motion should communicate state, not decorate every interaction.

Appropriate uses:

- Page entrance
- Dropdown transitions
- Modal transitions
- Loading feedback
- Success confirmation
- Subtle dashboard transitions

Avoid:

- Continuous background animation
- Excessive parallax
- Long transitions
- Motion on every hover

Use CSS transitions by default. Use GSAP only when a transition materially benefits from it.

Recommended transition principle:

- Fast for controls
- Moderate for panels
- Minimal for critical/security workflows

---

# 33. Icons

## Primary Icon System

**Lucide** is the primary interface icon set.

Use icons for:

- Navigation
- Actions
- Status
- Settings
- Security
- Logs
- Projects
- Templates
- Webhooks

## Brand Icons

Use:

- Simple Icons
- Official provider SVG assets

Provider branding must remain recognizable and must not be recreated as arbitrary iconography.

## Icon Rules

- Consistent size within a component
- Consistent stroke weight
- Adequate spacing
- Accessible labels for icon-only actions
- Do not use icons merely as decoration when they add noise

---

# 34. Logo and Branding

The product supports six primary logo variants as defined by the asset specification.

Logo usage must preserve:

- Aspect ratio
- Clear space
- Legibility
- Appropriate background contrast

Do not stretch, rotate, recolor arbitrarily, or distort the logo.

Favicon/app icon targets include:

- 16×16
- 32×32
- 48×48
- 180×180
- 192×192
- 512×512

---

# 35. Image and Illustration Rules

Preferred formats:

1. SVG
2. WebP
3. PNG
4. JPG

Use original/custom assets for:

- Empty states
- API illustrations
- Security illustrations
- Email illustrations
- Loading graphics
- Product onboarding where useful

Do not make decorative imagery the primary communication method.

---

# 36. Public Website UX

Public pages should communicate the product in a logical sequence:

1. What it is
2. Why it matters
3. How it works
4. Supported providers
5. API capabilities
6. Pricing
7. Questions
8. Contact/legal information

Primary CTA should remain consistent across public pages.

Public copy should be concise and technically credible.

---

# 37. Authentication UX

Authentication includes:

- Login
- Register
- Email Verification
- OTP Verification
- Forgot Password
- Reset Password
- Account Recovery

Requirements:

- Clear field labels
- Password visibility control
- Password guidance where appropriate
- Rate-limit feedback
- Verification state
- Recovery path
- Session/security messaging

Never reveal whether an account exists through overly specific password-recovery responses when that would create account-enumeration risk.

---

# 38. Security UX

Security settings must be understandable without hiding important technical details.

Include where applicable:

- Password change
- Active sessions
- Session revocation
- Verification state
- Login/security events
- API key management
- Provider credential management

Security-critical operations require confirmation and clear success/failure feedback.

---

# 39. Admin UX

Admin screens prioritize:

- Operational clarity
- Searchability
- Filtering
- Auditability
- Safe actions
- High information density

Admin actions should display consequences clearly.

Examples:

**Suspend user**

Show what access will be affected.

**Block IP**

Show scope and reason where applicable.

**Delete/revoke**

Require deliberate confirmation.

---

# 40. Responsive Navigation Behavior

### Desktop

Persistent sidebar is allowed.

### Tablet

Sidebar may collapse to an icon/compact state or drawer.

### Mobile

Use a drawer/off-canvas navigation pattern.

The current section must remain obvious after navigation closes.

---

# 41. Component State Matrix

Every reusable component should consider:

| Component | Required States |
|---|---|
| Button | Default, hover, focus, active, disabled, loading |
| Input | Default, focus, filled, error, disabled |
| Select | Default, open, selected, error, disabled |
| Checkbox | Unchecked, checked, focus, disabled |
| Radio | Unselected, selected, focus, disabled |
| Card | Default, interactive where applicable |
| Alert | Info, success, warning, error |
| Badge | Semantic status variants |
| Table | Loading, populated, empty, error |
| Modal | Open, loading, error, success |
| Toast | Info, success, warning, error |
| Tabs | Active, inactive, disabled |
| Pagination | Normal, active, disabled |
| Code block | Normal, copied |
| Provider card | Connected, disconnected, pending, error |

---

# 42. Data Density Rules

The platform contains operational and technical data.

Use density intentionally:

- Dashboard: moderate density
- Forms: comfortable density
- Logs: higher density
- Admin tables: higher density
- Documentation: readable density
- Mobile: reduced density

Never sacrifice readability merely to fit more rows.

---

# 43. Copywriting Rules

Interface language should be:

- Direct
- Specific
- Calm
- Professional
- Action-oriented

Prefer:

> Connect Gmail

Over:

> Click here to connect your Gmail account.

Prefer:

> SMTP connection failed. Check host, port, credentials, and encryption settings.

Over:

> Something went wrong.

Avoid unnecessary jargon in user-facing messages, while preserving technical detail where developers need it.

---

# 44. Confirmation Rules

Confirmation is required for high-impact actions.

Examples:

- Delete project
- Delete template
- Revoke API key
- Disconnect provider
- Revoke session
- Suspend account
- Block IP

Confirmation should state:

- Action
- Target
- Consequence
- Final action button

Avoid ambiguous labels such as "Continue" for destructive confirmations.

---

# 45. Onboarding

The initial experience should guide users toward a successful first email.

Logical sequence:

1. Create account
2. Verify account
3. Create project
4. Connect provider
5. Create template or use custom content
6. Generate API key
7. Send test email
8. Integrate API
9. Monitor logs

Onboarding should not force unnecessary steps before the user can understand the product.

---

# 46. Performance UX

UI must remain responsive during API operations.

Rules:

- Use asynchronous Fetch requests.
- Avoid blocking the entire page for local operations.
- Debounce search where appropriate.
- Paginate large datasets.
- Lazy-load noncritical resources.
- Optimize images.
- Avoid unnecessary JavaScript dependencies.
- Avoid expensive animation.
- Preserve perceived progress during long actions.

---

# 47. Frontend Security UX

The frontend must not imply that client-side controls are security boundaries.

Examples:

- Hidden UI is not authorization.
- Disabled buttons are not authorization.
- Client validation is not server validation.
- API keys must not be assumed safe merely because they are masked.
- Sensitive actions must be authorized server-side.

The UI should accurately reflect server responses.

---

# 48. Design-to-Development Rules

Every screen implementation must:

1. Use existing design tokens.
2. Reuse established components.
3. Follow the locked navigation model.
4. Follow the locked screen inventory.
5. Use semantic HTML.
6. Remain responsive.
7. Support keyboard interaction.
8. Include loading/error/empty states where relevant.
9. Avoid introducing a new visual pattern without justification.
10. Avoid hard-coded secrets or credentials.
11. Keep business logic out of presentation-only components where practical.
12. Use the existing API contract.

---

# 49. Component Naming Convention

Use predictable component classes and data attributes.

Example:

```text
component
component-header
component-body
component-footer
component--variant
is-active
is-loading
is-disabled
has-error
```

JavaScript behavior hooks should use dedicated data attributes where possible:

```html
<button
  type="button"
  data-action="copy-api-key"
  data-key-id="123">
  Copy
</button>
```

Avoid coupling JavaScript behavior to fragile presentation selectors.

---

# 50. Frontend File Organization

A recommended frontend organization is:

```text
public/
├── css/
│   ├── app.css
│   ├── tokens.css
│   ├── components.css
│   ├── utilities.css
│   └── responsive.css
│
├── js/
│   ├── app.js
│   ├── api.js
│   ├── auth.js
│   ├── forms.js
│   ├── notifications.js
│   ├── tables.js
│   ├── templates.js
│   ├── providers.js
│   └── utils.js
│
└── assets/
    ├── logos/
    ├── icons/
    ├── providers/
    ├── illustrations/
    └── images/
```

Actual backend organization remains governed by `10-BACKEND-PHP-ARCHITECTURE.md`.

---

# 51. Screen Consistency Checklist

Before marking a screen complete, verify:

### Structure

- Correct page title
- Correct navigation state
- Correct primary action
- Correct section hierarchy

### Visual

- Correct typography
- Correct spacing
- Correct component variants
- Correct iconography
- Correct responsive layout

### Interaction

- Loading state
- Success state
- Error state
- Empty state where applicable
- Disabled state
- Confirmation for destructive actions

### Accessibility

- Semantic HTML
- Labels
- Keyboard navigation
- Visible focus
- Color-independent status
- Accessible modal/dialog behavior

### Security

- No secret leakage
- Correct permission behavior
- Safe API key handling
- Safe error messages

---

# 52. Locked 93-Screen UX Coverage

The design system applies to all 93 locked screens:

## Public — 10

1. Home
2. Features
3. How It Works
4. Providers
5. API Documentation
6. Pricing
7. FAQ
8. Contact
9. Privacy Policy
10. Terms & Conditions

## Authentication — 7

11. Login
12. Register
13. Email Verification
14. OTP Verification
15. Forgot Password
16. Reset Password
17. Account Recovery

## User — 33

18. User Dashboard
19. Projects
20. Create Project
21. Project Overview
22. Project Settings
23. Email Services
24. Add Gmail
25. Gmail Connection Success
26. Add SMTP
27. SMTP Connection Test
28. Provider Management
29. Email Templates
30. Create Template
31. Template Editor
32. Template Preview
33. Template Variables
34. Email Send
35. Test Email
36. API Integration
37. API Keys
38. API Key Create
39. API Documentation
40. Email Logs
41. Email Log Details
42. OTP Logs
43. Usage & Statistics
44. Webhooks
45. Webhook Settings
46. Notifications
47. Profile Settings
48. Security Settings
49. Password Change
50. Active Sessions

## Admin — 37

51. Admin Dashboard
52. Users
53. User Details
54. Add User
55. Edit User
56. Projects
57. Project Details
58. Project Management
59. Email Providers
60. Gmail Connections
61. SMTP Connections
62. Brevo Connections
63. Mailtrap Connections
64. Email Logs
65. Email Log Details
66. OTP Logs
67. API Logs
68. Webhook Logs
69. Templates
70. Template Details
71. API Keys
72. API Usage
73. Analytics
74. System Statistics
75. Security Dashboard
76. Blocked IPs
77. Rate Limits
78. Login Attempts
79. Security/Audit Logs
80. System Settings
81. Email Settings
82. OTP Settings
83. API Settings
84. General Settings
85. Admin Accounts
86. Admin Profile
87. Admin Security

## System — 6

88. 404
89. 403
90. 429 Rate Limited
91. 500 Server Error
92. Maintenance
93. API Error Response

No screen may bypass this design system.

---

# 53. UX Relationship to Core Product Modules

The UI must support the locked 24 modules:

1. User Authentication
2. Email Verification
3. OTP System
4. Password Recovery
5. User Profile
6. Project Management
7. Gmail Integration
8. SMTP Integration
9. Optional Provider Engine
10. Email Template Engine
11. Template Variables
12. Email Sending Engine
13. REST API
14. API Key System
15. Webhook System
16. Email Logs
17. OTP Logs
18. Usage Analytics
19. Rate Limiting
20. Security System
21. Session Management
22. Notification System
23. Admin Management
24. System Configuration

UI behavior must reflect the underlying module boundaries rather than inventing unrelated product concepts.

---

# 54. UX Quality Standard

A production-ready screen must be:

- Visually consistent
- Responsive
- Accessible
- Keyboard usable
- Secure
- Fast
- Understandable
- Error-tolerant
- Consistent with the API
- Consistent with navigation
- Consistent with the component library

A screen is not complete merely because the happy path works.

---

# 55. Non-Negotiable Design Rules

1. Do not introduce a second primary font.
2. Do not introduce a second icon system without a documented need.
3. Do not create arbitrary one-off component styles.
4. Do not remove responsive behavior.
5. Do not rely on color alone for status.
6. Do not expose secrets in UI or logs.
7. Do not use placeholder text as the only field label.
8. Do not create inaccessible modal workflows.
9. Do not hide important errors in console output only.
10. Do not make destructive actions one-click without appropriate safeguards.
11. Do not redesign the locked navigation without an explicit scope change.
12. Do not create duplicate screens for the same product concept.
13. Do not bypass design tokens for convenience.
14. Do not add unnecessary animation.
15. Do not let Bootstrap defaults override the product identity.
16. Do not change the locked 93-screen inventory.
17. Do not change the locked architecture through UI requirements.
18. Do not expose provider credentials or OAuth secrets.
19. Do not treat frontend restrictions as authorization.
20. Do not mark a screen complete without its required states.

---

# 56. Definition of Done — UI/UX

A UI/UX implementation is complete only when:

- The screen matches the locked information architecture.
- The visual hierarchy is clear.
- Components use design tokens.
- Typography follows the font rules.
- Icons follow the icon rules.
- Responsive behavior is verified.
- Keyboard behavior is verified.
- Accessibility requirements are met.
- Loading states are implemented.
- Error states are implemented.
- Empty states are implemented where applicable.
- Destructive actions are protected.
- Security-sensitive data is handled safely.
- API feedback is correctly represented.
- The screen works across supported viewport sizes.
- No unnecessary custom pattern has been introduced.

---

# 57. Relationship to Other Documents

This document is intentionally part of the larger locked documentation system.

- `00-MASTER-BLUEPRINT.md` — overall product authority
- `01-PROJECT-OVERVIEW.md` — product and user experience context
- `02-FINAL-SCOPE-AND-FEATURES.md` — locked scope and feature inventory
- `03-SYSTEM-ARCHITECTURE.md` — application architecture
- `04-TECHNOLOGY-STACK.md` — implementation technology baseline
- `05-UI-UX-DESIGN-SYSTEM.md` — this document
- `06-SCREENS-AND-NAVIGATION.md` — detailed screen and navigation specification
- `07-ASSETS-ICONS-FONTS-LOGOS.md` — asset standards
- `08-DATABASE-ARCHITECTURE.md` — database architecture
- `09-DATABASE-SCHEMA.md` — database schema
- `10-BACKEND-PHP-ARCHITECTURE.md` — backend structure
- `11-REST-API-SPECIFICATION.md` — API contract
- Remaining documents define authentication, email engine, providers, templates, projects/API keys/webhooks, user/admin panels, security, frontend implementation, QA, deployment, and development governance.

No later document may contradict this design system without an explicit project-scope decision.

---

# 58. Final UI/UX Lock

The Email API Platform uses a unified, professional, developer-focused design system built on:

- HTML5
- CSS3
- Bootstrap 5.3+
- JavaScript ES6+
- Fetch API
- CSS variables
- Lightweight CSS animation
- Selective GSAP
- Inter
- JetBrains Mono
- Lucide
- Simple Icons
- Official provider SVG assets
- Responsive and accessible HTML

The system covers the complete 93-screen product surface and is designed to remain consistent across public, authentication, user, admin, and system experiences.

**STATUS: FINAL / LOCKED**

Future implementation should refine visual details through the defined token and component system without changing the product's locked information architecture or introducing a competing UI framework.
