# 08 — DATABASE ARCHITECTURE

**Project:** Self-Hosted Email API Platform  
**Document:** `08-DATABASE-ARCHITECTURE.md`  
**Status:** FINAL / LOCKED  
**Database:** MySQL 8+  
**Storage Engine:** InnoDB  
**Character Set:** `utf8mb4`  
**Collation:** `utf8mb4_0900_ai_ci` where supported  
**Database Access:** PHP PDO with prepared statements

---

## 1. Purpose

This document defines the database architecture for the Email API Platform.

It establishes:

- database responsibilities;
- domain boundaries;
- entity ownership;
- relationships;
- project isolation;
- authentication and session storage;
- provider and credential storage;
- templates and versions;
- API keys and API requests;
- email and OTP logs;
- webhooks and webhook delivery records;
- usage and analytics data;
- security and audit data;
- administration data;
- system configuration;
- indexing and retention strategy;
- transaction boundaries;
- data protection requirements;
- migration rules;
- backup and recovery expectations.

This architecture is the foundation for `09-DATABASE-SCHEMA.md`.

**The database architecture is locked. Later implementation work must refine SQL details without changing the domain model unless a deliberate architecture revision is approved.**

---

# 2. Database Design Goals

The database must be:

1. **Relational** — use normalized relational structures for core business data.
2. **Project-aware** — project data must remain isolated by `project_id`.
3. **Secure** — credentials and secrets must never be stored as ordinary plaintext.
4. **Auditable** — security-sensitive operations must produce traceable records.
5. **Queryable** — common dashboard, log, and administration queries must be index-supported.
6. **Maintainable** — tables should have clear ownership and predictable naming.
7. **Extensible** — provider adapters and future features must not require redesign of existing core entities.
8. **Transaction-safe** — related state changes must use appropriate database transactions.
9. **Operationally practical** — the design must work on a conventional MySQL 8 server without mandatory distributed infrastructure.
10. **Retention-aware** — high-volume logs must support cleanup and archival policies.

---

# 3. Database Technology Baseline

## 3.1 Required

- MySQL 8.0+
- InnoDB
- `utf8mb4`
- PDO
- Prepared statements
- Foreign-key constraints where appropriate
- UTC timestamps at the application/database boundary
- Explicit migrations

## 3.2 Recommended MySQL settings

The production environment should use:

- strict SQL mode;
- transactional InnoDB tables;
- appropriate connection limits;
- slow-query monitoring;
- binary logging where operationally appropriate;
- regular automated backups.

Do not depend on MySQL-specific behavior that is unnecessary for portability unless it provides a clear operational benefit.

---

# 4. Logical Database Domains

The database is organized into the following logical domains.

| Domain | Primary responsibility |
|---|---|
| Identity | Users, profiles, verification, authentication state |
| Authentication | OTPs, sessions, login attempts, recovery |
| Projects | Project ownership and configuration |
| Providers | Gmail, SMTP, and optional provider connections |
| Templates | Email templates and immutable template versions |
| API | API keys and request records |
| Email | Email delivery requests and delivery outcomes |
| Webhooks | Webhook configuration and delivery history |
| Usage | Aggregated usage and statistics |
| Notifications | User-facing system notifications |
| Security | IP controls, security events, audit records |
| Administration | Admin accounts and admin activity |
| System | Global platform configuration |

---

# 5. Core Entity Model

The principal database entities are:

```text
users
user_profiles
email_verifications
otp_codes
sessions
projects
project_settings
providers
user_providers
gmail_connections
smtp_connections
templates
template_versions
api_keys
api_requests
email_logs
otp_logs
webhooks
webhook_logs
notifications
usage_statistics
login_attempts
blocked_ips
security_logs
admin_users
admin_logs
system_settings
```

These entities form the locked principal database model.

Additional implementation-only tables may be introduced for technical reasons such as migrations, queues, locks, or internal maintenance, but they must not duplicate core business ownership.

---

# 6. High-Level Relationship Model

```text
users
 ├── user_profiles
 ├── email_verifications
 ├── otp_codes
 ├── sessions
 ├── login_attempts
 ├── projects
 │    ├── project_settings
 │    ├── user_providers
 │    │    ├── gmail_connections
 │    │    └── smtp_connections
 │    ├── templates
 │    │    └── template_versions
 │    ├── api_keys
 │    ├── api_requests
 │    ├── email_logs
 │    ├── otp_logs
 │    ├── webhooks
 │    │    └── webhook_logs
 │    ├── usage_statistics
 │    └── notifications
 └── security_logs

system_settings
admin_users
 └── admin_logs

blocked_ips
```

Provider definitions are global:

```text
providers
 └── user_providers
       ├── gmail_connections
       └── smtp_connections
```

The relationship model deliberately separates:

- provider type;
- provider assignment;
- provider credentials/configuration.

---

# 7. Ownership Model

Every record must have a clear owner.

## 7.1 User-owned

The following are primarily owned by a user:

- profile;
- verification records;
- sessions;
- projects;
- login attempts;
- personal notifications;
- security events associated with the account.

## 7.2 Project-owned

The following are project-scoped:

- project settings;
- provider connections;
- templates;
- API keys;
- API requests;
- email logs;
- OTP logs;
- webhooks;
- webhook delivery logs;
- usage statistics.

## 7.3 Global/system-owned

The following are platform-scoped:

- provider definitions;
- system settings;
- blocked IP rules;
- admin accounts;
- admin activity logs.

---

# 8. Multi-Project Isolation

Project isolation is a mandatory architectural rule.

A user may own multiple projects.

A project must never expose data belonging to another project.

For project-scoped tables, the application should normally include:

```text
project_id
```

in the primary query condition.

Examples:

```sql
SELECT *
FROM email_logs
WHERE project_id = :project_id
ORDER BY created_at DESC;
```

Do not rely solely on frontend route parameters for project isolation.

The authenticated server-side context must establish:

```text
authenticated_user
        ↓
authorized_project
        ↓
requested_resource
```

A resource is accessible only when:

```text
resource.project_id = authorized_project.id
```

and the authenticated user is authorized to operate on that project.

---

# 9. User and Identity Data

## 9.1 `users`

Stores the primary authentication identity.

Responsibilities:

- user ID;
- email;
- password hash;
- account status;
- verification state;
- timestamps.

Important rules:

- Store passwords only as strong password hashes.
- Never store plaintext passwords.
- Email uniqueness must be enforced.
- Authentication queries must use indexed email values.

Recommended status values:

```text
pending
active
suspended
disabled
```

## 9.2 `user_profiles`

Stores non-authentication profile information.

Possible fields include:

- display name;
- first name;
- last name;
- avatar reference;
- timezone;
- locale;
- preferences.

Authentication data should not be duplicated here.

---

# 10. Email Verification Data

## `email_verifications`

Stores email verification attempts/tokens.

Responsibilities:

- verification token hash;
- expiration;
- consumption state;
- attempt metadata;
- creation and consumption timestamps.

Never store a reusable verification token in plaintext when a hashed representation is sufficient.

A verification token must be:

- random;
- sufficiently long;
- single-use;
- time-limited.

---

# 11. OTP Data

## `otp_codes`

Stores OTP issuance and verification state.

Recommended logical fields:

```text
id
user_id
project_id nullable
purpose
destination
code_hash
expires_at
attempt_count
max_attempts
consumed_at
created_at
```

Typical purposes:

```text
email_verification
login
password_reset
account_recovery
custom
```

For project-level OTP APIs, `project_id` identifies the project responsible for the request.

OTP plaintext codes must not be stored after issuance.

Use a secure hash or keyed protection strategy appropriate to the OTP lifecycle.

---

# 12. Session Data

## `sessions`

Stores server-side session state.

Recommended logical fields:

```text
id
user_id
session_token_hash
ip_address
user_agent
last_activity_at
expires_at
revoked_at
created_at
```

Session tokens should not be stored in plaintext where a hash can be used for lookup.

The application must support:

- session expiration;
- explicit logout;
- session revocation;
- revocation after password/security events;
- active-session listing.

---

# 13. Projects

## `projects`

A project is the primary isolation boundary for email/API activity.

A project should contain:

- owner;
- name;
- identifier/slug;
- status;
- timestamps.

Recommended status values:

```text
active
suspended
archived
```

Project IDs should be stable and non-semantic.

Do not expose sequential database IDs unnecessarily in public APIs.

---

# 14. Project Settings

## `project_settings`

Stores project-level configuration that does not belong in the core project record.

Possible configuration areas:

- default sender;
- default reply-to;
- default provider;
- default template behavior;
- allowed origins;
- API behavior;
- notification preferences;
- rate-limit overrides where supported.

Sensitive secrets do not belong here unless they are explicitly encrypted.

---

# 15. Provider Architecture

Provider data uses three conceptual layers.

```text
providers
     ↓
user_providers
     ↓
provider-specific connection table
```

This prevents provider-specific credentials from being forced into one oversized table.

---

# 16. Provider Definitions

## `providers`

Stores the supported provider types.

Examples:

```text
gmail
smtp
brevo
mailtrap
```

The platform's provider registry may mark providers as:

```text
active
inactive
deprecated
```

The provider registry describes capabilities; it does not store user credentials.

---

# 17. User Provider Connections

## `user_providers`

Connects a project/user context to a provider definition.

Recommended logical fields:

```text
id
project_id
provider_id
name
status
is_default
created_at
updated_at
```

The table acts as the common provider connection record.

Provider-specific tables contain credentials/configuration.

---

# 18. Gmail Connections

## `gmail_connections`

Stores encrypted Gmail OAuth connection data.

Recommended logical fields:

```text
id
user_provider_id
google_account_email
access_token_encrypted
refresh_token_encrypted
token_expires_at
scopes
status
last_tested_at
created_at
updated_at
```

Rules:

- OAuth refresh tokens must be encrypted at rest.
- Access tokens must be treated as secrets.
- Tokens must never appear in normal application logs.
- OAuth scopes must be minimized.
- Disconnecting Gmail must invalidate/remove the usable credential material according to the application's retention policy.

---

# 19. SMTP Connections

## `smtp_connections`

Stores encrypted SMTP configuration.

Possible fields:

```text
id
user_provider_id
host
port
encryption
username
password_encrypted
authentication_mode
from_email
from_name
status
last_tested_at
created_at
updated_at
```

Supported encryption should normally include:

```text
none
starttls
ssl
```

Production deployments should strongly prefer encrypted transport.

SMTP passwords must never be stored or displayed in plaintext.

---

# 20. Templates

## `templates`

Represents the logical email template.

A template belongs to a project.

Recommended data:

```text
id
project_id
name
slug
subject
status
current_version_id nullable
created_at
updated_at
deleted_at nullable
```

A template should support:

- HTML content;
- plain-text fallback;
- subject;
- variables;
- versioning;
- preview;
- duplication;
- archival/deletion behavior.

---

# 21. Template Versions

## `template_versions`

Stores versioned template content.

Recommended fields:

```text
id
template_id
version_number
subject
html_body
text_body
variables_schema
created_by
created_at
```

Template versions should be immutable after publication.

If content changes:

```text
new version
    ↓
new row
```

rather than overwriting historical content.

This provides reliable auditing and rollback.

---

# 22. API Keys

## `api_keys`

Stores project-scoped API credentials.

Recommended logical fields:

```text
id
project_id
name
key_prefix
key_hash
permissions
last_used_at
expires_at
revoked_at
created_at
```

Rules:

- The complete secret is shown only once at creation.
- Store a secure hash rather than the plaintext secret.
- Store a short prefix for identification.
- Support revocation.
- Support expiration.
- Do not log complete API keys.

Example conceptual format:

```text
public prefix + secret
```

Only the hash is persisted as the authentication secret.

---

# 23. API Requests

## `api_requests`

Stores API request metadata for operational analysis.

Recommended fields:

```text
id
project_id
api_key_id nullable
user_id nullable
request_id
method
route
status_code
ip_address
user_agent
request_size
response_size
duration_ms
created_at
```

Never store sensitive request payloads by default.

If request bodies are retained for debugging, they must be explicitly controlled, sanitized, access-restricted, and subject to retention limits.

---

# 24. Email Logs

## `email_logs`

This is one of the highest-volume operational tables.

It records email sending activity and outcomes.

Recommended fields:

```text
id
project_id
provider_connection_id
template_id nullable
api_key_id nullable
request_id
message_id nullable
to_address
from_address
reply_to nullable
subject
status
provider_status nullable
provider_message_id nullable
error_code nullable
error_message nullable
attempt_count
queued_at nullable
sent_at nullable
failed_at nullable
created_at
```

Typical statuses:

```text
queued
processing
sent
failed
cancelled
```

Email log design must distinguish:

- application request;
- provider submission;
- final known outcome.

A successful API response does not automatically mean the recipient received the message.

---

# 25. Email Log Privacy

Email addresses and message metadata may contain personal information.

Therefore:

- restrict access;
- avoid logging full message bodies by default;
- never store authentication secrets in email logs;
- redact sensitive variables where applicable;
- apply retention policies;
- protect admin access;
- avoid exposing internal provider errors to end users unnecessarily.

If body storage is implemented later, it must be explicitly designed and encrypted/protected as necessary.

---

# 26. OTP Logs

## `otp_logs`

Stores operational history for OTP requests.

Recommended fields:

```text
id
project_id
user_id nullable
request_id
purpose
destination
status
attempt_count
provider_connection_id nullable
error_code nullable
created_at
verified_at nullable
expired_at nullable
```

Do not store the plaintext OTP.

---

# 27. Webhooks

## `webhooks`

Stores project webhook subscriptions.

Recommended fields:

```text
id
project_id
name
url
secret_encrypted
events
status
failure_count
last_success_at
last_failure_at
created_at
updated_at
```

Webhook secrets must be encrypted or otherwise protected.

Supported event examples:

```text
email.sent
email.failed
otp.sent
otp.verified
provider.connected
provider.disconnected
```

The exact event catalog is defined by the API/webhook documentation.

---

# 28. Webhook Logs

## `webhook_logs`

Records webhook delivery attempts.

Recommended fields:

```text
id
webhook_id
event_type
event_id
attempt_number
request_id
response_status
response_time_ms
response_body_excerpt nullable
status
error_message nullable
next_retry_at nullable
created_at
```

Do not store unrestricted response bodies.

Keep only bounded diagnostic information.

---

# 29. Notifications

## `notifications`

Stores in-platform user notifications.

Examples:

- provider connection failure;
- Gmail token expiration;
- SMTP test result;
- security alert;
- project event;
- system announcement.

Recommended fields:

```text
id
user_id
project_id nullable
type
title
message
severity
read_at nullable
created_at
```

Notifications should not become a substitute for the audit/security log.

---

# 30. Usage Statistics

## `usage_statistics`

Stores aggregated usage data.

Recommended dimensions:

```text
id
project_id
date
emails_sent
emails_failed
otp_sent
otp_verified
api_requests
api_errors
webhook_deliveries
webhook_failures
```

Use daily aggregation as the default reporting granularity.

For large installations, additional hourly aggregation can be introduced without changing the core transactional tables.

Do not calculate all dashboard statistics by repeatedly scanning raw email logs if aggregated data can satisfy the request.

---

# 31. Login Attempts

## `login_attempts`

Stores authentication attempt telemetry.

Recommended fields:

```text
id
user_id nullable
email
ip_address
user_agent
success
failure_reason
created_at
```

This table supports:

- brute-force detection;
- rate limiting;
- security dashboards;
- account recovery investigation.

Avoid storing sensitive authentication material.

---

# 32. Blocked IPs

## `blocked_ips`

Stores IP-based access restrictions.

Recommended fields:

```text
id
ip_address
reason
scope
expires_at nullable
created_by nullable
created_at
```

Scope may include:

```text
global
login
api
admin
```

Temporary blocks should have expiration timestamps.

---

# 33. Security Logs

## `security_logs`

Stores security-relevant events.

Examples:

- login success/failure;
- password change;
- API key creation/revocation;
- provider credential changes;
- session revocation;
- suspicious activity;
- IP blocking;
- admin security actions.

Recommended fields:

```text
id
user_id nullable
project_id nullable
admin_user_id nullable
event_type
severity
ip_address
user_agent
request_id nullable
metadata
created_at
```

`metadata` should contain structured JSON without secrets.

Never place passwords, OAuth tokens, API secrets, SMTP passwords, or OTP values in security metadata.

---

# 34. Admin Accounts

## `admin_users`

Admin identities are intentionally separated from normal application users.

Recommended fields:

```text
id
email
password_hash
name
role
status
last_login_at
created_at
updated_at
```

Possible roles:

```text
super_admin
admin
support
auditor
```

Role capabilities should be enforced in application authorization code.

---

# 35. Admin Logs

## `admin_logs`

Records administrative actions.

Examples:

- user suspension;
- project status change;
- provider inspection;
- IP block;
- system setting change;
- maintenance mode change;
- admin account modification.

Recommended fields:

```text
id
admin_user_id
action
target_type
target_id
ip_address
request_id
metadata
created_at
```

Admin logs should be append-oriented and protected from ordinary user access.

---

# 36. System Settings

## `system_settings`

Stores platform-wide configuration.

Examples:

```text
site_name
maintenance_mode
default_rate_limit
default_otp_expiry
default_session_lifetime
email_from_address
support_email
```

Sensitive system secrets should not be stored as ordinary setting values.

For secret configuration, prefer:

- server environment variables;
- encrypted secret storage;
- deployment secret managers where available.

---

# 37. Foreign-Key Strategy

Foreign keys should be used for core relational integrity where practical.

Examples:

```text
projects.user_id → users.id
templates.project_id → projects.id
api_keys.project_id → projects.id
email_logs.project_id → projects.id
webhooks.project_id → projects.id
template_versions.template_id → templates.id
webhook_logs.webhook_id → webhooks.id
```

Avoid unnecessary cascading deletes on high-value audit/log data.

---

# 38. Delete Strategy

Different entities require different deletion behavior.

## 38.1 Hard delete

Appropriate for data that has no required historical dependency.

Examples may include:

- temporary verification records;
- expired transient session records;
- old internal locks.

## 38.2 Soft delete/archive

Prefer for business objects that may be referenced historically:

- projects;
- templates;
- provider connections;
- API keys.

## 38.3 Retention cleanup

Use scheduled cleanup for:

- old API request records;
- old login attempts;
- old OTP records;
- old webhook logs;
- old notifications;
- old high-volume operational logs.

Retention periods are configurable operational policies and must be documented before production deployment.

---

# 39. Indexing Strategy

Indexes must reflect actual query patterns.

## 39.1 High-priority indexes

Users:

```text
users.email UNIQUE
```

Projects:

```text
projects.user_id
projects.status
```

Templates:

```text
templates.project_id
templates.project_id + slug
```

API keys:

```text
api_keys.project_id
api_keys.key_prefix
api_keys.key_hash
```

Email logs:

```text
email_logs.project_id + created_at
email_logs.project_id + status + created_at
email_logs.request_id
email_logs.provider_message_id
```

OTP logs:

```text
otp_logs.project_id + created_at
otp_logs.project_id + status + created_at
```

API requests:

```text
api_requests.project_id + created_at
api_requests.request_id
api_requests.status_code + created_at
```

Webhooks:

```text
webhooks.project_id
webhook_logs.webhook_id + created_at
```

Security:

```text
security_logs.user_id + created_at
security_logs.project_id + created_at
security_logs.event_type + created_at
login_attempts.email + created_at
login_attempts.ip_address + created_at
blocked_ips.ip_address
```

---

# 40. Composite Index Principles

Use composite indexes when queries commonly filter by project and sort/filter by time.

Preferred:

```text
(project_id, created_at)
```

rather than many unrelated single-column indexes when the dominant query is:

```sql
WHERE project_id = ?
ORDER BY created_at DESC
```

Do not create indexes speculatively on every column.

Each index adds:

- storage cost;
- write overhead;
- maintenance overhead.

---

# 41. Identifier Strategy

Use a consistent primary-key strategy.

The implementation may use:

- BIGINT unsigned IDs;
- UUID/ULID-style identifiers;
- another stable non-semantic identifier.

The selected strategy must be finalized in `09-DATABASE-SCHEMA.md` and used consistently.

Public-facing identifiers should not expose unnecessary internal information.

---

# 42. Timestamp Strategy

Store timestamps consistently.

Recommended fields:

```text
created_at
updated_at
deleted_at
expires_at
```

The application should normalize timestamps to UTC.

User interface formatting should convert UTC timestamps to the user's selected timezone.

Do not store localized display strings in database timestamp fields.

---

# 43. JSON Data

MySQL JSON columns may be used for genuinely variable structured data.

Appropriate examples:

- template variable schema;
- provider capabilities;
- webhook event lists;
- structured security metadata;
- system metadata.

Do not use JSON as a replacement for relational columns when the data is:

- frequently queried;
- used for authorization;
- part of a foreign-key relationship;
- required for indexing;
- central to reporting.

---

# 44. Secret Storage Model

Secrets are divided into three categories.

## 44.1 Hash-only secrets

Use hashing when the application only needs to verify a secret.

Examples:

- API key secret;
- OTP;
- session token where appropriate;
- verification token.

## 44.2 Encrypted secrets

Use authenticated encryption when the application must recover the secret later.

Examples:

- Gmail OAuth refresh token;
- SMTP password;
- webhook secret.

## 44.3 Deployment secrets

Prefer environment/deployment secret storage for platform-level credentials.

Examples:

- application encryption key;
- database password;
- OAuth client secret;
- SMTP relay secret used by the platform itself.

Never place these values in source control.

---

# 45. Encryption Requirements

Application-level encryption keys must be stored outside the database where possible.

The application should use a modern authenticated encryption scheme provided by the platform's cryptographic library.

Do not invent custom encryption algorithms.

Encrypted database values should include sufficient metadata/versioning to permit controlled key rotation.

Conceptually:

```text
ciphertext
key_version
encryption_version
```

---

# 46. Database Access Layer

Application code should not scatter raw SQL across controllers.

Recommended flow:

```text
Controller
   ↓
Service
   ↓
Repository / Data Access Layer
   ↓
PDO
   ↓
MySQL
```

Responsibilities:

### Controller

- HTTP input/output;
- authentication context;
- validation coordination.

### Service

- business rules;
- transactions;
- orchestration.

### Repository

- SQL;
- database reads/writes;
- mapping persistence records.

### PDO

- prepared statements;
- database connection;
- transaction primitives.

---

# 47. Transaction Boundaries

Transactions should be used whenever multiple related records must remain consistent.

Examples:

## Create project

```text
BEGIN
  create project
  create project settings
COMMIT
```

## Create template

```text
BEGIN
  create template
  create initial template version
  assign current version
COMMIT
```

## Revoke API key

```text
BEGIN
  revoke key
  write security event
COMMIT
```

## Provider disconnect

```text
BEGIN
  deactivate provider connection
  revoke/remove credential material
  write security event
COMMIT
```

Avoid excessively long transactions around network calls.

Never hold a database transaction open while waiting for an external email provider unless there is a compelling and explicitly designed reason.

---

# 48. Email Sending and Database Consistency

External provider calls must be treated as separate from local database transactions.

Preferred conceptual flow:

```text
API request
   ↓
validate/authenticate
   ↓
create email log
   ↓
commit local state
   ↓
send through provider
   ↓
update email log
```

If a future queue is introduced:

```text
API request
   ↓
create email job/log
   ↓
commit
   ↓
worker sends
   ↓
update result
```

This avoids holding MySQL locks during SMTP/API network operations.

---

# 49. Provider Connection Testing

Provider tests must not store test credentials or test message bodies unnecessarily.

A provider test should:

1. load encrypted credentials;
2. decrypt only inside the protected application process;
3. connect/authenticate;
4. return a sanitized result;
5. update `last_tested_at` and status;
6. write a security/operational event where appropriate.

Provider errors stored in logs must be sanitized.

---

# 50. API Request and Email Log Correlation

Every meaningful API operation should receive a request/correlation identifier.

Example:

```text
request_id
    ↓
api_requests
    ↓
email_logs
    ↓
webhook_logs
    ↓
security_logs
```

This allows administrators to trace a request without exposing credentials.

---

# 51. Rate-Limit Data

Rate limiting may use application memory/cache or database-backed counters depending on deployment size.

The core database should not be treated as the mandatory high-frequency rate-limit counter store.

Database records are appropriate for:

- login attempt history;
- security investigations;
- persistent rate-limit configuration;
- administrative overrides.

If Redis or another cache is introduced later, it must remain an optimization rather than a mandatory dependency of the core architecture.

---

# 52. Queue/Worker Compatibility

The current architecture does not require a queue system.

However, the database model is designed to support asynchronous processing later.

Fields such as:

```text
status
attempt_count
queued_at
sent_at
failed_at
next_retry_at
```

allow email and webhook processing to evolve from synchronous delivery to worker-based delivery without replacing the core entities.

---

# 53. Reporting Architecture

Operational reporting should use two levels.

## Transactional data

Used for:

- individual email logs;
- individual API requests;
- individual OTP records;
- security events.

## Aggregated data

Used for:

- dashboard totals;
- daily email volume;
- failure rates;
- API usage charts;
- provider statistics.

This prevents expensive dashboard queries from repeatedly scanning large transactional tables.

---

# 54. Data Retention

Retention must be configurable according to deployment requirements.

Suggested policy categories:

| Data | Retention approach |
|---|---|
| Users | Until account deletion/legal requirement |
| Projects | Until deleted/archived |
| Templates | Long-term |
| API keys | Until revoked + audit retention |
| Email logs | Configurable operational retention |
| API requests | Shorter configurable retention |
| OTP codes | Short-lived |
| Login attempts | Security retention window |
| Webhook logs | Configurable |
| Notifications | User-facing retention |
| Security logs | Longer retention |
| Admin logs | Longer retention |

Never define an operational retention period merely to reduce database size without considering audit, security, and support requirements.

---

# 55. Database Backup Strategy

Production database backups must include:

- full database backups;
- binary/incremental recovery capability where configured;
- backup encryption;
- protected backup storage;
- backup retention;
- restoration testing.

A backup that has never been restored successfully should not be considered a verified recovery strategy.

---

# 56. Recovery Priorities

The database should support recovery of:

1. users and authentication state;
2. projects;
3. provider connections;
4. templates;
5. API keys;
6. operational logs;
7. usage data;
8. security/audit history.

Credential encryption keys are especially critical.

A database backup without the required encryption key material may render encrypted provider credentials unrecoverable.

---

# 57. Migration Strategy

All schema changes must be migration-based.

Do not manually modify production tables without a corresponding migration.

Migration principles:

- one logical change per migration;
- forward-compatible changes where possible;
- reversible where practical;
- tested against a production-like MySQL version;
- documented;
- version-controlled.

Example:

```text
001_create_users.sql
002_create_profiles.sql
003_create_projects.sql
...
```

The exact migration numbering system may be implemented by the backend tooling, but migrations must remain deterministic and ordered.

---

# 58. Zero-Downtime-Friendly Changes

When the platform grows, prefer migration sequences such as:

```text
add nullable column
    ↓
deploy code that writes new column
    ↓
backfill
    ↓
deploy code that requires it
    ↓
add constraint
```

Avoid destructive schema changes that require old application instances to stop immediately unless a maintenance deployment explicitly allows it.

---

# 59. Data Validation

Database constraints should support application validation.

Use:

- `NOT NULL` where appropriate;
- `UNIQUE` constraints;
- foreign keys;
- sensible defaults;
- length limits;
- status constraints where practical.

Application validation remains mandatory.

The database is the final integrity boundary, not the only validation layer.

---

# 60. Security Boundaries

The database must never be directly exposed to the public internet unless the deployment architecture explicitly requires secure remote access.

Preferred topology:

```text
Internet
   ↓
HTTPS
   ↓
Apache/Nginx
   ↓
PHP-FPM
   ↓
MySQL
```

MySQL should normally accept connections only from the application host/network.

Administrative database access must use:

- restricted accounts;
- strong credentials;
- encrypted connections when remote;
- least privilege.

---

# 61. Database Accounts

Do not run the application using a MySQL root account.

Create a dedicated application database user with only the required permissions.

Example conceptual permissions:

```text
SELECT
INSERT
UPDATE
DELETE
CREATE
ALTER
INDEX
```

Migration tooling may use a separate higher-privilege account from the runtime application account.

---

# 62. Least-Privilege Model

Separate:

```text
application runtime account
migration/deployment account
administrative DBA account
```

The runtime account should not have unnecessary administrative privileges.

Database credentials must never be committed to Git.

---

# 63. Query Safety

Every dynamic query must use prepared statements.

Never construct SQL from raw request values.

Unsafe:

```php
$sql = "SELECT * FROM users WHERE email = '$email'";
```

Required pattern:

```php
$stmt = $pdo->prepare(
    'SELECT * FROM users WHERE email = :email'
);

$stmt->execute([
    'email' => $email
]);
```

Dynamic identifiers such as sort columns must use allowlists rather than parameter interpolation.

---

# 64. N+1 Query Prevention

Dashboard and list endpoints must avoid unnecessary N+1 queries.

Prefer:

- joins where appropriate;
- batched queries;
- aggregate queries;
- eager retrieval of required relations.

Do not over-join massive log tables when pagination or aggregation is sufficient.

---

# 65. Pagination

Large datasets must never be returned without limits.

Use:

```text
LIMIT
```

and preferably cursor/keyset pagination for high-volume logs where appropriate.

Offset pagination may be acceptable for small administrative datasets.

Email logs, API logs, security logs, and webhook logs should be designed for efficient pagination.

---

# 66. Search Strategy

Searchable fields should be explicitly identified.

Examples:

- user email;
- project name;
- template name;
- API key prefix;
- provider connection name;
- request ID;
- provider message ID.

Do not add unrestricted full-text search to all columns.

---

# 67. Sensitive Data Redaction

Sensitive values must never appear in:

- SQL query logs;
- exception messages;
- debug logs;
- audit metadata;
- API request logs;
- admin pages.

Examples:

```text
password
password_hash
api_key_secret
oauth_access_token
oauth_refresh_token
smtp_password
otp_code
webhook_secret
encryption_key
```

---

# 68. Soft Deletion Rules

If soft deletion is used, all normal queries must explicitly exclude deleted records.

Example:

```sql
WHERE deleted_at IS NULL
```

Administrative recovery workflows may query deleted records intentionally.

Soft deletion must not accidentally allow:

- revoked API keys to authenticate;
- deleted projects to send mail;
- deleted providers to be selected;
- archived templates to be sent.

---

# 69. Status Transition Integrity

Important status fields must follow valid transitions.

Example email lifecycle:

```text
queued
  ↓
processing
  ↓
sent

queued → failed
processing → failed
queued → cancelled
```

Do not permit arbitrary status changes from unrelated code paths.

Business services should own lifecycle transitions.

---

# 70. Provider Status Lifecycle

Example:

```text
pending
   ↓
connected
   ↓
testing
   ↓
active
   ↓
disconnected
```

A provider may also become:

```text
error
expired
disabled
```

The exact implementation may simplify these states, but status semantics must remain consistent throughout the API, UI, and database.

---

# 71. API Key Lifecycle

```text
created
   ↓
active
   ↓
revoked
```

Optional:

```text
active → expired
```

A revoked or expired key must never authenticate a request.

---

# 72. Template Lifecycle

Example:

```text
draft
   ↓
active
   ↓
archived
```

Version lifecycle should remain separate from template lifecycle.

A template can have multiple versions while only one is the current active version.

---

# 73. Database Observability

Production monitoring should track:

- connection usage;
- query latency;
- slow queries;
- table growth;
- index effectiveness;
- failed transactions;
- deadlocks;
- lock waits;
- backup status;
- disk usage.

Large tables require proactive growth monitoring.

---

# 74. High-Volume Table Planning

The expected high-growth tables are:

1. `email_logs`
2. `api_requests`
3. `webhook_logs`
4. `security_logs`
5. `login_attempts`
6. `otp_logs`

These tables should have:

- time-based indexes;
- project indexes where applicable;
- retention policies;
- pagination;
- controlled payload sizes.

Partitioning is not mandatory for the initial deployment.

If partitioning becomes necessary, it must be introduced based on measured workload and tested migration procedures.

---

# 75. Database Performance Rules

Do:

- index actual query patterns;
- select only required columns;
- paginate large lists;
- aggregate usage data;
- reuse PDO connections appropriately;
- monitor slow queries;
- clean expired records.

Do not:

- use `SELECT *` for large API responses;
- scan entire email logs for every dashboard load;
- store huge email bodies in logs by default;
- create excessive indexes;
- hold transactions during network requests;
- use database polling for every request when caching is appropriate.

---

# 76. Consistency With Application Architecture

The database must support the locked modular-monolith architecture.

Recommended application modules map to database domains:

```text
Authentication
    → users, sessions, email_verifications, login_attempts

OTP
    → otp_codes, otp_logs

Projects
    → projects, project_settings

Providers
    → providers, user_providers,
      gmail_connections, smtp_connections

Templates
    → templates, template_versions

Email Engine
    → email_logs

API
    → api_keys, api_requests

Webhooks
    → webhooks, webhook_logs

Notifications
    → notifications

Analytics
    → usage_statistics

Security
    → blocked_ips, security_logs

Administration
    → admin_users, admin_logs

System
    → system_settings
```

---

# 77. Database-to-API Boundary

API clients must never receive raw database records blindly.

The service layer should map database records to API response DTOs/resources.

This prevents:

- internal IDs leaking unnecessarily;
- encrypted values being exposed;
- internal columns becoming accidental public API;
- schema changes breaking API consumers.

---

# 78. Database-to-Admin Boundary

The admin panel may expose more operational information than the user panel, but it must still respect secret redaction.

For example:

Allowed:

```text
SMTP host
SMTP port
SMTP username
connection status
last tested time
```

Not allowed:

```text
SMTP password
OAuth refresh token
API key secret
webhook secret
encryption key
```

---

# 79. Auditability Requirements

Security-sensitive changes should produce an audit/security record.

At minimum:

- login/security events;
- password changes;
- API key creation/revocation;
- provider connection/disconnection;
- credential updates;
- project status changes;
- user suspension;
- admin changes;
- security setting changes.

Audit records must identify:

```text
who
what
when
where
target
request/correlation ID where available
```

---

# 80. Data Lifecycle Summary

```text
CREATE
  ↓
VALIDATE
  ↓
PERSIST
  ↓
USE
  ↓
AUDIT
  ↓
ARCHIVE / RETAIN
  ↓
PURGE WHEN POLICY ALLOWS
```

Each major entity should have an explicit lifecycle.

---

# 81. Schema Documentation Requirements

`09-DATABASE-SCHEMA.md` must translate this architecture into implementation-ready SQL-oriented documentation.

It must define for every locked table:

- columns;
- data types;
- nullability;
- defaults;
- primary keys;
- foreign keys;
- unique constraints;
- indexes;
- status values;
- deletion behavior;
- relationship notes.

The schema document must not introduce a competing entity model.

---

# 82. Recommended Table Creation Order

The implementation should generally create tables in dependency order:

```text
1. users
2. user_profiles
3. email_verifications
4. sessions
5. projects
6. project_settings
7. providers
8. user_providers
9. gmail_connections
10. smtp_connections
11. templates
12. template_versions
13. api_keys
14. api_requests
15. email_logs
16. otp_codes
17. otp_logs
18. webhooks
19. webhook_logs
20. notifications
21. usage_statistics
22. login_attempts
23. blocked_ips
24. security_logs
25. admin_users
26. admin_logs
27. system_settings
```

Actual migration ordering may be adjusted to satisfy foreign-key dependencies, but the logical dependency order must remain intact.

---

# 83. Development Environment

Local development should use an isolated MySQL database.

Recommended:

```text
email_api_dev
email_api_test
email_api_staging
email_api_production
```

Never run destructive tests against production.

Automated tests should use a separate database/schema.

---

# 84. Testing Database Behavior

Database tests should cover:

- user creation;
- unique email enforcement;
- project ownership;
- project isolation;
- API key hashing;
- template versioning;
- provider relationships;
- email log lifecycle;
- OTP expiry;
- session revocation;
- webhook relationships;
- audit log creation;
- transaction rollback;
- soft deletion;
- retention cleanup.

---

# 85. Failure Handling

If a database operation fails:

1. do not expose SQL internals to the client;
2. roll back the current transaction;
3. log a safe internal diagnostic;
4. attach the request ID;
5. return a standardized API error;
6. avoid partial business state.

Example:

```text
Database failure
      ↓
ROLLBACK
      ↓
internal log + request_id
      ↓
safe API error
```

---

# 86. Database Error Classification

Application code should distinguish:

```text
validation error
authorization error
not found
conflict
constraint violation
temporary database failure
unexpected database failure
```

For example, duplicate project slug/name constraints may produce a controlled conflict response rather than a generic 500 response.

---

# 87. Security Checklist

Before production:

- [ ] MySQL 8+ is used.
- [ ] InnoDB is used.
- [ ] `utf8mb4` is enabled.
- [ ] Application DB user is not root.
- [ ] Database is network-restricted.
- [ ] Strong DB credentials are configured.
- [ ] Credentials are outside source control.
- [ ] PDO prepared statements are used.
- [ ] Passwords are hashed.
- [ ] API keys are hashed.
- [ ] OTPs are protected.
- [ ] OAuth tokens are encrypted.
- [ ] SMTP passwords are encrypted.
- [ ] Webhook secrets are protected.
- [ ] Sensitive values are redacted from logs.
- [ ] Project isolation is enforced server-side.
- [ ] Foreign keys are reviewed.
- [ ] Indexes match real queries.
- [ ] High-volume tables have retention policies.
- [ ] Backups are automated.
- [ ] Backups are protected.
- [ ] Restore testing has been performed.
- [ ] Encryption keys are backed up separately and securely.
- [ ] Migration process is version-controlled.

---

# 88. Performance Checklist

- [ ] Common project/time queries are indexed.
- [ ] Large tables are paginated.
- [ ] Dashboard statistics use aggregates where appropriate.
- [ ] N+1 queries are avoided.
- [ ] Large payloads are not stored unnecessarily.
- [ ] Slow queries are monitored.
- [ ] Expired transient data is cleaned.
- [ ] Database transactions are short.
- [ ] External provider calls occur outside long DB transactions.
- [ ] Connection limits are appropriate.
- [ ] Disk growth is monitored.

---

# 89. Architecture Decision Summary

| Decision | Final choice |
|---|---|
| Database | MySQL 8+ |
| Engine | InnoDB |
| Encoding | `utf8mb4` |
| Access | PHP PDO |
| SQL safety | Prepared statements |
| Core model | Relational |
| Project isolation | `project_id` + authorization |
| Password storage | Strong password hashing |
| API key storage | Hash |
| OTP storage | Hash/protected representation |
| OAuth credentials | Encrypted |
| SMTP passwords | Encrypted |
| Webhook secrets | Encrypted/protected |
| Logs | Project-scoped where applicable |
| Analytics | Aggregated usage table |
| Transactions | Service-layer boundaries |
| Queues | Optional future capability |
| Redis | Not mandatory |
| Partitioning | Not mandatory initially |
| Backups | Required |
| Migrations | Required |
| Public DB access | Prohibited by default |

---

# 90. Non-Negotiable Database Rules

1. MySQL 8+ is the production database baseline.
2. InnoDB is mandatory for core tables.
3. `utf8mb4` is mandatory.
4. Application SQL uses PDO prepared statements.
5. Database root must never be used by the application.
6. User passwords are never stored in plaintext.
7. API key secrets are never stored in plaintext.
8. OTP values are never stored as plaintext.
9. OAuth tokens are encrypted.
10. SMTP passwords are encrypted.
11. Webhook secrets are protected.
12. Project isolation is enforced server-side.
13. High-volume logs are indexed and retention-controlled.
14. External network calls must not hold unnecessary DB transactions.
15. Dashboard queries must not repeatedly scan large raw log tables unnecessarily.
16. Database schema changes use migrations.
17. Production backups are mandatory.
18. Restore procedures must be tested.
19. Sensitive data must be redacted from logs.
20. `09-DATABASE-SCHEMA.md` must implement this architecture without introducing a conflicting model.

---

# 91. Definition of Done

The database architecture is considered complete when:

- all locked domains have clear ownership;
- all principal entities are defined;
- project isolation is explicit;
- provider architecture supports Gmail and SMTP;
- templates support versioning;
- API keys support secure hashing and lifecycle management;
- email/OTP/API/webhook logs are modeled;
- usage aggregation is defined;
- security and audit data are modeled;
- secret storage strategy is defined;
- indexing strategy is defined;
- transaction boundaries are documented;
- retention and backup expectations are documented;
- migration principles are established;
- database access follows least privilege;
- the model maps cleanly to the locked application architecture.

---

# 92. Final Lock

This document is **FINAL / LOCKED** for the current Email API Platform blueprint.

The next database document, `09-DATABASE-SCHEMA.md`, must convert this architecture into implementation-ready table definitions while preserving:

- the 25-document structure;
- the 93-screen scope;
- the 24 core modules;
- the 29 user features;
- the 14 API feature areas;
- the 25 security features;
- the modular-monolith architecture;
- Gmail + Custom SMTP as primary providers;
- optional Brevo + Mailtrap provider support;
- project-based isolation;
- secure credential handling;
- the established PHP/MySQL technology stack.

**Next document:** `09-DATABASE-SCHEMA.md`
