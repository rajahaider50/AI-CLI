# EMAIL API PLATFORM — TECHNOLOGY STACK

**Document ID:** 04  
**Filename:** `04-TECHNOLOGY-STACK.md`  
**Status:** FINAL / LOCKED  
**Project:** EMAIL-API-PLATFORM-BLUEPRINT

---

## 1. Purpose

This document locks the approved technology stack for the Email API Platform.

The stack is intentionally based on mature, widely supported, low-cost technologies suitable for self-hosted deployment while providing production security, maintainability, provider integrations, responsive panels, and future scalability.

---

## 2. Technology Stack Summary

| Layer | Approved Technology |
|---|---|
| Markup | HTML5 |
| Styling | CSS3 |
| CSS Framework | Bootstrap 5.3+ |
| Client JavaScript | JavaScript ES6+ |
| HTTP Client | Fetch API |
| Animation | CSS animations + GSAP where useful |
| Primary Icons | Lucide |
| Brand Icons | Simple Icons + official provider SVGs |
| Primary Font | Inter |
| Code Font | JetBrains Mono |
| Backend | PHP 8.3+ |
| API Style | REST + JSON |
| Database Driver | PDO |
| Database | MySQL 8+ |
| Email Library | PHPMailer |
| Gmail Authentication | OAuth 2.0 |
| Web Server | Apache or Nginx |
| PHP Runtime | PHP-FPM in production |
| Scheduling | Cron |
| Package Manager | Composer |
| Source Control | Git |
| Testing | PHPUnit |
| Static Analysis | PHPStan recommended |
| Image Formats | SVG > WebP > PNG > JPG |
| Deployment | Conventional VPS/PHP-capable infrastructure |
| HTTPS | TLS/HTTPS required |
| Architecture | Modular monolith |

---

## 3. Technology Selection Principles

1. Prefer mature and actively maintained technologies.
2. Prefer native browser capabilities before adding dependencies.
3. Keep dependencies minimal and purposeful.
4. Avoid unnecessary frontend frameworks.
5. Keep provider credentials and application secrets server-side.
6. Preserve replaceability through internal abstractions.
7. Prefer technologies that are inexpensive to self-host.
8. Do not introduce distributed infrastructure before the product requires it.
9. Keep the public API independent from individual provider implementations.
10. Maintain compatibility with the architecture defined in `03-SYSTEM-ARCHITECTURE.md`.

---

# 4. Frontend Stack

## 4.1 HTML5

HTML5 is the base markup language.

Use semantic elements such as:

```html
<header>
<nav>
<main>
<section>
<article>
<footer>
<form>
<label>
<button>
```

Prefer semantic HTML over unnecessary custom structures.

---

## 4.2 CSS3

CSS3 is the primary styling technology.

Use:

- CSS variables
- Flexbox
- CSS Grid
- Media queries
- Transitions
- Keyframe animations
- Responsive units
- Logical properties where useful
- Modern layout techniques

Example:

```css
:root {
    --color-primary: #4f46e5;
    --color-text: #111827;
    --color-muted: #6b7280;
    --color-border: #e5e7eb;
}
```

The final visual tokens are defined in `05-UI-UX-DESIGN-SYSTEM.md`.

---

## 4.3 Bootstrap 5.3+

Bootstrap provides:

- Responsive grid
- Utilities
- Forms
- Buttons
- Cards
- Tables
- Modals
- Dropdowns
- Offcanvas
- Alerts
- Navigation
- Toasts

Bootstrap is a structural/UI utility layer, not the complete visual identity.

Custom styling must be used where required by the locked design system.

---

## 4.4 JavaScript ES6+

The client uses modern JavaScript.

Approved features include:

```text
const
let
modules
async/await
Promises
fetch()
template literals
destructuring
optional chaining
nullish coalescing
```

Use ES modules where practical:

```html
<script type="module" src="/assets/js/app.js"></script>
```

---

## 4.5 Fetch API

Fetch is the standard browser HTTP client.

Example:

```javascript
const response = await fetch('/api/v1/email/send', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    },
    body: JSON.stringify(payload)
});
```

Axios is not required for the initial platform.

---

## 4.6 Frontend JavaScript Organization

Recommended structure:

```text
assets/js/
├── app.js
├── api/
│   ├── client.js
│   ├── auth.js
│   ├── projects.js
│   ├── templates.js
│   ├── providers.js
│   ├── email.js
│   └── logs.js
├── components/
├── pages/
├── forms/
├── validation/
├── ui/
├── utils/
└── admin/
```

Exact implementation rules are defined in `20-FRONTEND-DEVELOPMENT-GUIDE.md`.

---

## 4.7 Animation

CSS is the default animation technology.

Use:

- `transition`
- `transform`
- `opacity`
- `@keyframes`

GSAP may be used selectively for:

- Landing-page hero animations
- Complex dashboard transitions
- Provider connection states
- Advanced micro-interactions

GSAP must not become necessary for ordinary UI behavior.

---

## 4.8 Reduced Motion

Non-essential animation must respect:

```css
@media (prefers-reduced-motion: reduce) {
    /* Reduce or disable non-essential animation */
}
```

Animations should prioritize `transform` and `opacity` for performance.

---

# 5. Backend Stack

## 5.1 PHP

**Minimum:** PHP 8.3+

PHP is the primary application runtime.

Reasons:

- Broad hosting availability
- Mature ecosystem
- Low deployment complexity
- Strong MySQL support
- Mature email libraries
- Suitable REST API capabilities
- Low infrastructure cost

The application must avoid deprecated PHP behavior.

---

## 5.2 PHP Coding Baseline

Use:

- PSR-compatible conventions
- Strict typing where practical
- Typed properties
- Return types
- Small focused classes
- Dependency injection where useful
- Explicit validation
- Exceptions for exceptional failures

Example:

```php
declare(strict_types=1);

final class EmailService
{
    public function send(EmailMessage $message): SendResult
    {
        // ...
    }
}
```

---

## 5.3 Composer

Composer is the approved PHP dependency manager.

Required:

```text
composer.json
composer.lock
```

Runtime and development dependencies should be separated appropriately.

Composer dependencies must be maintained deliberately and audited periodically.

---

## 5.4 PHPMailer

PHPMailer is the approved SMTP transport library.

Responsibilities include:

- SMTP connection
- SMTP authentication
- TLS/security
- Message construction
- SMTP error handling
- Supported email transport features

Business logic must not directly depend on PHPMailer.

Architecture:

```text
Email Engine
    |
    v
SMTP Adapter
    |
    v
PHPMailer
    |
    v
SMTP Server
```

---

## 5.5 Gmail Integration

Gmail is a primary provider.

Authentication:

```text
OAuth 2.0
```

The platform must never request a user's normal Gmail password for Gmail integration.

Flow:

```text
User
 |
 v
Gmail OAuth
 |
 v
Google Authorization
 |
 v
Callback
 |
 v
Encrypted Token Storage
 |
 v
Gmail Adapter
```

---

## 5.6 OAuth 2.0

OAuth-sensitive values include:

- Google client ID
- Google client secret
- Access tokens
- Refresh tokens

Secrets and tokens must remain server-side and be protected at rest.

---

# 6. Database Stack

## 6.1 MySQL 8+

MySQL is the primary relational database.

It stores:

```text
Users
Profiles
Sessions
Projects
Providers
Provider connections
Templates
Template versions
API keys
API requests
Email logs
OTP logs
Webhooks
Webhook logs
Notifications
Usage statistics
Security records
Admin records
System settings
```

---

## 6.2 PDO

PDO is the approved PHP database interface.

All database access must use prepared statements.

Example:

```php
$stmt = $pdo->prepare(
    'SELECT id FROM users WHERE email = :email'
);

$stmt->execute([
    'email' => $email
]);
```

Never concatenate untrusted values into SQL.

---

## 6.3 MySQL Configuration Baseline

Use:

```text
Engine: InnoDB
Character set: utf8mb4
```

The database should use appropriate indexes, foreign keys, unique constraints, and timestamps.

---

## 6.4 Database Security

The application database user should have only required privileges.

MySQL should not be publicly exposed unless there is a deliberate, secured reason.

Preferred:

```text
Internet
   X
   |
Application Server
   |
MySQL
```

---

# 7. Server Stack

## 7.1 Web Server

Approved:

```text
Apache
or
Nginx
```

Either is valid for the initial deployment.

---

## 7.2 PHP-FPM

Production PHP should run through PHP-FPM.

```text
Browser
   |
 HTTPS
   |
Apache/Nginx
   |
PHP-FPM
   |
PHP Application
```

---

## 7.3 Operating System

Recommended:

- Ubuntu LTS
- Debian Stable
- Another actively supported Linux distribution

The application must avoid unnecessary operating-system-specific assumptions.

---

## 7.4 HTTPS/TLS

HTTPS is mandatory in production.

HTTPS protects:

- Authentication
- Sessions
- API keys
- Email content
- Provider credentials
- OAuth callbacks
- Dashboard traffic

HTTP should redirect to HTTPS.

---

## 7.5 Cron

Cron is the approved initial scheduler.

Potential tasks:

```text
Webhook processing
Webhook retries
OTP cleanup
Session cleanup
Usage aggregation
Log maintenance
Security housekeeping
```

---

## 7.6 PHP CLI

PHP CLI is required for operational tasks.

Examples:

```text
php bin/worker.php
php bin/migrate.php
php bin/cleanup.php
```

CLI commands must use the same secure configuration principles as web requests.

---

# 8. API Stack

## 8.1 REST + JSON

The public API uses:

```text
REST
+
JSON
+
HTTPS
```

Example:

```text
POST /api/v1/email/send
Content-Type: application/json
Accept: application/json
```

---

## 8.2 API Versioning

Initial version:

```text
v1
```

Example:

```text
/api/v1/email/send
```

Breaking changes require a new API version.

---

## 8.3 JSON Contract

Success:

```json
{
  "success": true,
  "data": {
    "message_id": "msg_123"
  },
  "request_id": "req_123"
}
```

Error:

```json
{
  "success": false,
  "error": {
    "code": "INVALID_REQUEST",
    "message": "The request is invalid."
  },
  "request_id": "req_123"
}
```

---

## 8.4 API Documentation

API documentation must include:

- Endpoint
- HTTP method
- Authentication
- Headers
- Parameters
- Request body
- Response
- Error responses
- Rate limits
- Examples

Markdown documentation is required. An OpenAPI-compatible specification may also be maintained.

---

# 9. Authentication and Security Technology

## 9.1 User Authentication

Dashboard authentication uses secure server-side sessions.

Includes:

- Login
- Logout
- Registration
- Email verification
- Password recovery
- Password change
- Session management

---

## 9.2 Project API Authentication

Client integrations use project-scoped API keys.

These are separate from dashboard sessions.

```text
Dashboard → Session
Client Website → Project API Key
```

---

## 9.3 Password Hashing

Use PHP password hashing APIs:

```php
password_hash()
password_verify()
```

Do not implement a custom password hashing algorithm.

---

## 9.4 Cryptographic Randomness

Security-sensitive values must use cryptographically secure randomness.

Examples:

- OTPs
- Reset tokens
- API key secrets
- Webhook secrets

Do not use `rand()` or `mt_rand()` for security-sensitive values.

---

## 9.5 Validation

Server-side validation is mandatory.

Use:

- Type validation
- Domain validators
- Length constraints
- Format validation
- Database constraints
- Business-rule validation

Client-side validation is UX only.

---

## 9.6 CSRF

CSRF protection is required for browser-session state-changing operations.

API-key authenticated external requests follow the API authentication model.

The implementation must clearly distinguish dashboard sessions from project API credentials.

---

## 9.7 CORS

CORS is enforced at the API boundary.

Production configuration should avoid unrestricted wildcard origins for authenticated operations unless deliberately required.

Project-level allowed origins may be supported.

---

## 9.8 Security Headers

Production should configure appropriate security headers, including where applicable:

```text
Content-Security-Policy
Strict-Transport-Security
X-Content-Type-Options
Referrer-Policy
Permissions-Policy
Frame protections
```

Exact policies are defined in `19-SECURITY-ARCHITECTURE.md`.

---

# 10. Frontend Icons, Logos and Fonts

## 10.1 Primary Icons

Approved:

```text
Lucide
```

Use for:

- Navigation
- Actions
- Status
- Security controls
- Dashboard controls
- Form affordances

---

## 10.2 Brand Icons

Approved sources:

```text
Simple Icons
Official provider SVG assets
```

Required provider branding:

- Gmail
- SMTP
- Brevo
- Mailtrap

Provider logos must not be manually redrawn when suitable official/licensed assets are available.

---

## 10.3 Icon Rules

Icons must:

- Use consistent dimensions
- Maintain visual consistency
- Have accessible names when interactive
- Not replace essential text unnecessarily
- Use suitable stroke weight

---

## 10.4 Typography

Primary UI font:

```text
Inter
```

Technical/code font:

```text
JetBrains Mono
```

JetBrains Mono is appropriate for:

- API keys
- Code
- JSON
- Endpoint paths
- Logs
- Technical identifiers

---

## 10.5 Font Loading

Prefer:

- Self-hosted fonts where appropriate
- Optimized webfont formats
- `font-display: swap`
- Only required font weights

Avoid loading unnecessary font families.

---

# 11. Asset Technology

## 11.1 Format Priority

```text
SVG
↓
WebP
↓
PNG
↓
JPG
```

Use SVG for:

- Logos
- Icons
- Simple illustrations
- Provider marks

Use WebP for optimized raster imagery.

Use PNG where lossless transparency is required.

Use JPG mainly for photographs.

---

## 11.2 Required Logo Variants

The project baseline includes six main logo variants covering:

1. Full logo on light background
2. Full logo on dark background
3. Compact logo
4. Icon-only mark
5. Monochrome/light variant
6. Monochrome/dark variant

Exact design is defined in `07-ASSETS-ICONS-FONTS-LOGOS.md`.

---

## 11.3 Favicon/App Icons

Required baseline sizes:

```text
16x16
32x32
48x48
180x180
192x192
512x512
```

---

## 11.4 Original Graphics

Custom graphics may be used for:

- Empty states
- API explanations
- Security pages
- Email delivery
- Provider connection states
- Error pages
- Onboarding

Graphics must follow the approved visual system.

---

# 12. CSS Architecture

Recommended:

```text
assets/css/
├── variables.css
├── base.css
├── typography.css
├── layout.css
├── components.css
├── forms.css
├── tables.css
├── dashboard.css
├── admin.css
├── responsive.css
└── app.css
```

The exact organization may be consolidated if it improves maintainability.

---

# 13. JavaScript Dependency Policy

Default:

```text
No large frontend framework
```

Allowed dependencies must provide meaningful value.

Approved baseline:

```text
Bootstrap JavaScript components
GSAP selectively
```

Avoid multiple overlapping UI libraries.

---

# 14. Bootstrap JavaScript

Bootstrap's JavaScript components may provide:

- Modal
- Dropdown
- Offcanvas
- Tooltip
- Collapse
- Toast

Do not add another component framework for the same functions.

---

# 15. Build Strategy

The initial frontend does not require a complex build system.

A valid initial approach is:

```text
HTML
CSS
ES Modules
Bootstrap assets
```

A build tool may be introduced later without changing application behavior.

---

# 16. Development Tooling

Approved/recommended:

```text
Git
Composer
PHP CLI
MySQL CLI
Browser DevTools
Code editor/IDE
PHPUnit
PHPStan
```

Additional tools may be used when they solve a documented problem.

---

# 17. Testing Stack

Recommended backend testing framework:

```text
PHPUnit
```

Tests should cover:

- Services
- Validation
- Authentication
- Authorization
- Template rendering
- API behavior
- Provider adapters
- Security rules

Provider integrations should support mocks/fakes so routine tests do not depend on live accounts.

---

# 18. Static Analysis

Recommended:

```text
PHPStan
```

Static analysis should be introduced progressively and maintained as the codebase grows.

---

# 19. Coding Standards

The project follows PSR-compatible PHP coding conventions.

Optional tools:

```text
PHP_CodeSniffer
PHP CS Fixer
```

The project should standardize on a minimal set rather than requiring redundant tooling.

---

# 20. Source Control

Git is required.

Possible branch structure:

```text
main
development
feature/*
hotfix/*
```

For a solo/small team, this can be simplified while retaining safe release practices.

---

# 21. Environment Configuration

Use environment variables or protected configuration for sensitive settings.

Examples:

```text
APP_ENV
APP_URL
APP_KEY
DB_HOST
DB_DATABASE
DB_USERNAME
DB_PASSWORD
GOOGLE_CLIENT_ID
GOOGLE_CLIENT_SECRET
ENCRYPTION_KEY
```

Exact names are finalized during backend implementation.

---

## 21.1 Environment Files

A development environment may use:

```text
.env
```

Commit only:

```text
.env.example
```

Never commit production secrets.

---

# 22. Dependency Security

Dependencies must be:

- From trusted sources
- Maintained
- Audited
- Removed when unused
- Updated deliberately
- Locked consistently

`composer.lock` should be committed for application deployments.

---

# 23. Dependency Update Policy

Priority:

```text
Security patch → highest priority
Bug fix → prompt evaluation
Minor update → test before deployment
Major update → migration plan
```

Never perform large production upgrades blindly.

---

# 24. Browser Support

Target modern supported versions of:

- Chrome
- Edge
- Firefox
- Safari
- Android browsers
- iOS browsers

Non-essential advanced browser features should degrade gracefully.

---

# 25. Responsive Technology

Use:

```text
Bootstrap breakpoints
+
CSS media queries
+
Flexible layouts
+
Responsive components
```

Required:

- Small phones
- Large phones
- Tablets
- Laptops
- Desktops
- Large screens
- Portrait
- Landscape

---

# 26. Accessibility Technology

Use:

- Semantic HTML
- Proper labels
- Keyboard navigation
- Visible focus states
- Screen-reader support
- Sufficient contrast
- Reduced-motion support
- ARIA only where necessary

Accessibility must not depend exclusively on JavaScript.

---

# 27. Performance Technology

Use:

- Browser caching
- Optimized assets
- Compressed images
- Efficient CSS
- Deferred/non-blocking JavaScript where appropriate
- Database indexes
- Pagination
- Provider timeouts
- Controlled logging

Avoid premature infrastructure complexity.

---

# 28. Caching

Redis is **not required** for the initial release.

Initial caching can use:

- Browser/HTTP caching
- PHP/application caching
- File caching where appropriate
- Database-backed state where necessary

A shared cache may be added later if horizontal scaling requires it.

---

# 29. Queue Technology

No mandatory queue system is included in the initial stack.

Initial background processing:

```text
Cron
+
PHP CLI workers
```

Future options may include Redis or RabbitMQ, but these are not initial dependencies.

---

# 30. Containerization

Docker is optional.

The application must remain deployable directly to a conventional PHP/MySQL server.

Docker development environments must not create a mandatory production dependency.

---

# 31. CI/CD

A future CI/CD workflow may contain:

```text
Git push
   |
Tests
   |
Static analysis
   |
Validation
   |
Deployment
```

No specific CI provider is locked.

---

# 32. Email Technology

The email engine uses a provider-neutral internal message model.

Conceptual objects:

```text
EmailMessage
EmailAddress
TemplateContext
SendResult
ProviderError
```

The core email engine must not depend directly on Gmail or PHPMailer internals.

---

# 33. Template Technology

Templates use:

```text
HTML
+
safe variable placeholders
```

Example:

```html
<h1>Hello {{name}}</h1>
```

Templates must never execute arbitrary:

```text
PHP
JavaScript
server-side code
```

---

# 34. OTP Technology

OTP generation must use cryptographically secure randomness.

The subsystem requires:

- Expiration
- Attempt limits
- Request rate limits
- Protected storage
- Used-state tracking
- Logging without plaintext OTPs

---

# 35. Webhook Technology

Webhooks use:

```text
HTTPS
+
JSON
+
authentication/signature
```

where configured.

Webhook delivery should include enough metadata for:

- Event identification
- Delivery identification
- Correlation
- Authenticity verification
- Idempotent processing

---

# 36. Logging Technology

Application logging may use PHP/application logging facilities.

User-facing structured records remain in the database:

```text
Email logs
OTP logs
Webhook logs
API logs
Security logs
Audit logs
```

Never log:

- Passwords
- OAuth tokens
- SMTP passwords
- API key plaintext
- OTP plaintext
- Encryption keys

---

# 37. Time and Date Technology

Application/database timestamps should be stored consistently, preferably UTC.

Use modern PHP date/time APIs.

Convert timestamps for display where user/project timezone presentation is required.

---

# 38. Identifier Strategy

The application must use a consistent identifier strategy.

Public identifiers should avoid unnecessary sequential enumeration where appropriate.

Identifier formats must be standardized before API implementation.

---

# 39. File Storage

The initial product does not require object storage.

Local storage may be used for:

- Temporary files
- Internal logs
- Operational files

Sensitive/private files must remain outside the public web root.

---

# 40. Email Attachment Technology

If attachments are included in the final API scope:

- Validate file size
- Validate file type
- Reject executable content
- Use safe temporary storage
- Apply request-size limits
- Prevent arbitrary server paths
- Avoid uncontrolled memory usage

Clients must never supply arbitrary filesystem paths.

---

# 41. Public Asset Structure

Recommended:

```text
public/assets/
├── css/
├── js/
├── icons/
├── images/
└── fonts/
```

Only public-safe assets belong here.

---

# 42. Public Directory Architecture

The web server document root should point to:

```text
/public
```

Recommended application structure:

```text
email-api-platform/
├── app/
├── config/
├── database/
├── storage/
├── vendor/
└── public/
```

This protects:

- Configuration
- Source code
- Composer files
- Environment files
- Private storage

---

# 43. Server Permissions

Use least-privilege filesystem permissions.

The PHP process should write only to required directories such as:

```text
storage/
cache/
temporary directories
```

Source code and configuration should not be unnecessarily writable by the web process.

---

# 44. Production Error Display

Production must not expose PHP diagnostics to users.

Recommended baseline:

```text
display_errors = Off
```

Errors should be logged internally and converted into normalized API responses.

---

# 45. Development Error Display

Development may use verbose diagnostics.

Development credentials must remain separate from production credentials.

Never casually use production secrets in local development.

---

# 46. Security Maintenance

The technology stack must be reviewed periodically for:

- PHP security updates
- MySQL updates
- PHPMailer security releases
- Bootstrap updates
- OAuth changes
- Provider API changes
- Composer vulnerabilities
- Browser compatibility

---

# 47. Provider Dependency Policy

External provider APIs are isolated behind adapters.

```text
Core Email Engine
       |
       v
Provider Adapter
       |
       v
External Provider
```

Provider-specific API changes should primarily affect the relevant adapter.

---

# 48. Technology Upgrade Rules

Upgrades must preserve:

- Public API compatibility
- Database compatibility
- Provider integrations
- Existing projects
- Existing templates
- Existing API keys
- Security
- Responsive behavior

Breaking changes require explicit migration planning.

---

# 49. Technology Rejection Rules

Do not introduce without an approved architectural reason:

- Frontend SPA frameworks
- Multiple CSS frameworks
- Multiple overlapping icon systems
- A second ORM
- Multiple email libraries
- Mandatory Redis
- Mandatory queues
- Microservices
- Kubernetes
- Service mesh
- Mandatory Docker deployment
- Unmaintained dependencies
- Client-side provider credentials

---

# 50. Approved Technology Matrix

| Category | Decision | Status |
|---|---|---|
| HTML | HTML5 | Locked |
| CSS | CSS3 | Locked |
| UI Framework | Bootstrap 5.3+ | Locked |
| JavaScript | ES6+ | Locked |
| HTTP | Fetch API | Locked |
| Animation | CSS + selective GSAP | Locked |
| Backend | PHP 8.3+ | Locked |
| API | REST/JSON | Locked |
| Database | MySQL 8+ | Locked |
| DB Access | PDO | Locked |
| Email | PHPMailer | Locked |
| Gmail | OAuth 2.0 | Locked |
| Web Server | Apache/Nginx | Locked |
| Runtime | PHP-FPM | Locked |
| Scheduler | Cron | Locked |
| Package Manager | Composer | Locked |
| Source Control | Git | Locked |
| Icons | Lucide | Locked |
| Brand Icons | Simple Icons / official SVG | Locked |
| UI Font | Inter | Locked |
| Code Font | JetBrains Mono | Locked |
| Images | SVG/WebP/PNG/JPG | Locked |
| Testing | PHPUnit | Locked baseline |
| Static Analysis | PHPStan | Recommended |
| Code Standards | PSR-compatible | Locked |
| Queue | Not required initially | Locked |
| Redis | Not required initially | Locked |
| Docker | Optional | Locked |
| Frontend SPA | Not required | Locked |
| Microservices | Not required | Locked |

---

# 51. Minimum Production Requirements

```text
PHP 8.3+
PHP-FPM
MySQL 8+
PDO MySQL
Apache or Nginx
HTTPS/TLS
Cron
PHP CLI
Composer dependencies
Secure environment configuration
Private writable storage
```

Gmail additionally requires the appropriate Google OAuth configuration.

SMTP requires an SMTP server/account.

---

# 52. Recommended Development Environment

```text
Git
PHP 8.3+
PHP CLI
Composer
MySQL 8+
Modern browser
Browser DevTools
Code editor/IDE
PHPUnit
PHPStan
```

---

# 53. Recommended Production Environment

```text
Linux
Apache or Nginx
PHP-FPM
PHP 8.3+
MySQL 8+
HTTPS
Cron
Composer dependencies
Secure environment configuration
```

A modest VPS is sufficient for initial deployment within expected traffic/provider limits.

---

# 54. Cost-Control Strategy

The initial platform should be deployable with:

```text
1 application server
1 MySQL instance
1 cron scheduler
External email provider
```

No managed queue, distributed cache, Kubernetes cluster, or distributed database is required.

---

# 55. Free/Low-Cost Provider Strategy

Primary providers:

```text
Gmail
Custom SMTP
```

Optional providers:

```text
Brevo
Mailtrap
```

All providers must use the common provider abstraction.

---

# 56. Technology Responsibility Map

```text
HTML/CSS/Bootstrap
    → UI structure and presentation

JavaScript/Fetch
    → Browser interaction and API communication

PHP
    → Application logic

PDO
    → Database access

MySQL
    → Persistent data

PHPMailer
    → SMTP transport

Gmail OAuth/API
    → Gmail integration

Apache/Nginx
    → Web serving and HTTPS boundary

PHP-FPM
    → PHP execution

Cron/PHP CLI
    → Background and maintenance tasks

Composer
    → PHP dependencies

Git
    → Source control
```

---

# 57. Relationship to System Architecture

The technology stack directly supports the architecture defined in `03-SYSTEM-ARCHITECTURE.md`.

```text
Static HTML / Web App
        |
HTML5 + CSS3 + Bootstrap + JavaScript + Fetch
        |
        v
REST API
        |
        v
PHP 8.3+
        |
        +---- PDO ----> MySQL 8+
        |
        +---- Provider Abstraction
                    |
                    +--> Gmail OAuth/API
                    +--> PHPMailer → SMTP
                    +--> Brevo
                    +--> Mailtrap
```

---

# 58. Final Technology Lock

The approved baseline is:

```text
Frontend:
HTML5
CSS3
Bootstrap 5.3+
JavaScript ES6+
Fetch API
CSS animation
GSAP selectively

Backend:
PHP 8.3+
REST/JSON
PDO
PHPMailer
OAuth 2.0

Database:
MySQL 8+
utf8mb4
InnoDB

Server:
Linux
Apache or Nginx
PHP-FPM
HTTPS
Cron

Tooling:
Composer
Git
PHPUnit
PHPStan recommended

UI:
Lucide
Simple Icons
Official provider SVGs
Inter
JetBrains Mono

Assets:
SVG
WebP
PNG
JPG
```

This stack is optimized for a **professional self-hosted Email API platform without unnecessary infrastructure complexity**.

**STATUS: FINAL / LOCKED**

---

# 59. Definition of Done

- [ ] HTML5/CSS3/Bootstrap 5.3+ are used.
- [ ] JavaScript ES6+ and Fetch API are used.
- [ ] PHP 8.3+ is used.
- [ ] MySQL 8+ is used.
- [ ] PDO is used for database access.
- [ ] PHPMailer is used for SMTP delivery.
- [ ] Gmail uses OAuth 2.0.
- [ ] Apache or Nginx serves the application.
- [ ] PHP-FPM is used in production.
- [ ] HTTPS is enabled.
- [ ] Cron is available.
- [ ] Composer manages PHP dependencies.
- [ ] Git manages source control.
- [ ] Lucide is the primary UI icon system.
- [ ] Inter is the primary UI font.
- [ ] JetBrains Mono is used for technical/code content.
- [ ] Provider credentials remain server-side.
- [ ] No unnecessary frontend framework is introduced.
- [ ] Redis/queue infrastructure is not mandatory for initial release.
- [ ] The application remains deployable on conventional PHP/MySQL infrastructure.
- [ ] Future technology additions are evaluated against this document.

---

# 60. Next Document

The next document in the locked documentation sequence is:

```text
05-UI-UX-DESIGN-SYSTEM.md
```

It will define the visual language, color system, typography hierarchy, spacing, grid, components, buttons, forms, cards, tables, navigation, dashboards, states, responsive UI, accessibility presentation, animation rules, and design tokens.

**STATUS: FINAL / LOCKED**
