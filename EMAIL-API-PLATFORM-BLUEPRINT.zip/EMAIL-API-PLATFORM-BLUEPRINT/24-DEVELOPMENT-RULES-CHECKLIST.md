# 24 — Development Rules & Checklist

**Project:** EMAIL API PLATFORM  
**Document:** 24 of 25  
**Status:** FINAL / LOCKED  
**Purpose:** Final engineering rules, implementation checklist, security gates, quality gates, release gates, and Definition of Done for the complete Email API Platform.

---

## 1. Purpose

This document is the final developer governance document for the Email API Platform.

It converts the decisions in the previous 24 blueprint documents into practical rules that must be followed during:

- Development
- Code review
- Testing
- Security review
- Database changes
- API development
- Frontend development
- Provider integration
- Deployment
- Maintenance
- Release management

This document does not introduce a new architecture.

---

## 2. Final Architecture Rule

The architecture defined by the master blueprint is **FINAL / LOCKED**.

The implementation must remain:

```text
Frontend
HTML5 + CSS3 + Bootstrap + JavaScript + Fetch
        ↓
HTTPS / REST JSON API
        ↓
PHP 8.3+ Modular Monolith
        ↓
Services / Policies / Repositories
        ↓
MySQL 8+ / PDO
        ↓
Email Engine
        ↓
Provider Adapter
        ↓
Gmail / SMTP / Optional Providers
```

Do not introduce architectural changes casually.

---

## 3. Master Rules

- [ ] Read the master blueprint before major implementation.
- [ ] Follow all locked architecture decisions.
- [ ] Do not duplicate core business logic.
- [ ] Do not bypass authorization.
- [ ] Do not trust frontend security checks.
- [ ] Keep project isolation mandatory.
- [ ] Keep provider logic behind adapters.
- [ ] Keep email sending centralized in the Email Engine.
- [ ] Keep security cross-cutting and server-side.
- [ ] Preserve API compatibility.

---

# 4. Repository Rules

## 4.1 Structure

- [ ] Use the approved application structure.
- [ ] Keep `public/` as the web-accessible boundary.
- [ ] Keep private configuration outside the public root.
- [ ] Keep runtime storage controlled.
- [ ] Keep database migrations versioned.
- [ ] Keep tests separated from production code.
- [ ] Keep documentation synchronized with implementation.

## 4.2 Source Control

- [ ] Use Git.
- [ ] Commit meaningful changes.
- [ ] Do not commit secrets.
- [ ] Do not commit production `.env`.
- [ ] Do not commit private credentials.
- [ ] Keep `composer.lock` under version control.
- [ ] Review changes before merging.
- [ ] Keep commits reasonably focused.

---

# 5. PHP Rules

- [ ] PHP 8.3+ is the baseline.
- [ ] Use strict typing where appropriate.
- [ ] Keep classes focused.
- [ ] Avoid giant controllers.
- [ ] Avoid duplicated business logic.
- [ ] Use dependency injection.
- [ ] Keep external services behind clear interfaces.
- [ ] Use exceptions consistently.
- [ ] Do not expose internal exceptions to users.
- [ ] Do not use `eval()`.
- [ ] Do not execute user-controlled PHP/code.
- [ ] Do not trust user-controlled filesystem paths.
- [ ] Avoid unsafe dynamic includes.
- [ ] Avoid unsafe deserialization.
- [ ] Validate all external input.

---

# 6. Backend Layering Rules

Use the established separation:

```text
Route
  ↓
Middleware
  ↓
Controller
  ↓
Policy / Authorization
  ↓
Service
  ↓
Repository
  ↓
Database
```

External providers should be reached through dedicated provider/service boundaries.

### Rules

- [ ] Controllers remain thin.
- [ ] Services contain business workflows.
- [ ] Policies enforce authorization.
- [ ] Repositories handle persistence.
- [ ] Providers remain adapter-based.
- [ ] Validation happens before business execution.
- [ ] Serialization is intentional.
- [ ] Database access does not leak into presentation code.

---

# 7. Authentication Rules

- [ ] Passwords use strong password hashing.
- [ ] Passwords are never stored plaintext.
- [ ] Login attempts are rate-limited.
- [ ] Account recovery is protected.
- [ ] Email verification is enforced where required.
- [ ] Session IDs are regenerated after authentication.
- [ ] Sessions can be revoked.
- [ ] Secure cookies are used in production.
- [ ] HttpOnly cookies are used where appropriate.
- [ ] SameSite policy is configured.
- [ ] Authentication errors are enumeration-safe where required.

---

# 8. OTP Rules

- [ ] OTPs are generated securely.
- [ ] OTPs expire.
- [ ] OTP attempts are limited.
- [ ] OTP resend is throttled.
- [ ] OTP values are never logged.
- [ ] OTP records are scoped correctly.
- [ ] OTP verification is server-side.
- [ ] Used/expired OTPs cannot be reused.
- [ ] OTP abuse is monitored.
- [ ] OTP operations produce appropriate audit/security events.

---

# 9. Authorization Rules

Authentication is not authorization.

Every protected operation must answer:

```text
Who is the caller?
What are they allowed to do?
Which project/resource do they own?
```

### Checklist

- [ ] User authorization is server-side.
- [ ] Project ownership/access is verified.
- [ ] Resource IDs cannot bypass authorization.
- [ ] Admin authorization is separate.
- [ ] Role permissions are enforced.
- [ ] Suspended users cannot perform prohibited actions.
- [ ] Suspended projects cannot use protected resources.
- [ ] Deleted/revoked resources cannot remain accessible.

---

# 10. Project Isolation Rules

Projects are the primary application isolation boundary.

- [ ] Every project-scoped operation verifies project context.
- [ ] API keys are project-scoped.
- [ ] Templates are project-scoped.
- [ ] Providers are project-scoped where applicable.
- [ ] Logs are project-scoped.
- [ ] Usage is project-scoped.
- [ ] Webhooks are project-scoped.
- [ ] Project IDs are never trusted from the frontend without authorization.
- [ ] Cross-project access is explicitly tested.
- [ ] IDOR/BOLA cases are tested.

---

# 11. API Key Rules

- [ ] API keys are generated cryptographically.
- [ ] Secret material is shown only when appropriate.
- [ ] API key secrets are stored as hashes.
- [ ] API key permissions/scopes are enforced.
- [ ] Keys can be revoked.
- [ ] Keys can be rotated.
- [ ] Expired keys are rejected.
- [ ] Private server keys never enter frontend JavaScript.
- [ ] Browser-exposed keys are treated as public credentials.
- [ ] Browser keys receive minimal permissions.
- [ ] API key usage is logged safely.
- [ ] Secrets never appear in logs.

---

# 12. REST API Rules

- [ ] API responses use a consistent JSON structure.
- [ ] HTTP status codes are meaningful.
- [ ] Validation errors are predictable.
- [ ] Authentication errors are consistent.
- [ ] Authorization errors are safe.
- [ ] Rate-limit responses are consistent.
- [ ] Server errors do not expose internals.
- [ ] Request IDs are supported.
- [ ] API versions are controlled.
- [ ] Breaking changes require explicit versioning/policy.
- [ ] API documentation matches implementation.

---

# 13. Request Validation Rules

Validate:

- [ ] Data type
- [ ] Required fields
- [ ] Length
- [ ] Format
- [ ] Allowed values
- [ ] Ownership
- [ ] Resource existence
- [ ] Limits
- [ ] File constraints
- [ ] URL safety
- [ ] Email format
- [ ] Template variables
- [ ] Provider configuration

Never rely solely on browser-side validation.

---

# 14. SQL Rules

- [ ] Use PDO.
- [ ] Use prepared statements.
- [ ] Never concatenate untrusted SQL values.
- [ ] Validate dynamic sort/filter fields against allowlists.
- [ ] Use transactions for multi-step atomic operations.
- [ ] Define appropriate indexes.
- [ ] Enforce important relationships with constraints.
- [ ] Avoid N+1 queries.
- [ ] Review slow queries.
- [ ] Never use database root credentials from the application.

---

# 15. Database Rules

Every new table must define:

- [ ] Primary key
- [ ] Foreign keys where appropriate
- [ ] Ownership/project relationship
- [ ] Unique constraints
- [ ] Indexes
- [ ] Timestamp strategy
- [ ] Retention strategy
- [ ] Privacy classification
- [ ] Migration
- [ ] Backup/recovery implications

Never introduce an unplanned table merely to avoid understanding an existing domain model.

---

# 16. Migration Rules

- [ ] Every schema change has a migration.
- [ ] Migration is versioned.
- [ ] Migration is tested.
- [ ] Migration is reversible or has a recovery strategy.
- [ ] Production backup exists before risky migration.
- [ ] Large migrations consider locking and runtime.
- [ ] Destructive changes use an explicit plan.
- [ ] Application/schema compatibility is considered.
- [ ] Staging migration is completed before production.

---

# 17. Email Engine Rules

All email sending must pass through the centralized Email Engine.

- [ ] Validate recipient.
- [ ] Validate sender.
- [ ] Validate subject.
- [ ] Validate content.
- [ ] Prevent header injection.
- [ ] Resolve project/provider context.
- [ ] Resolve template/direct content.
- [ ] Render variables safely.
- [ ] Build canonical email DTO.
- [ ] Select provider through adapter layer.
- [ ] Apply timeouts.
- [ ] Normalize provider errors.
- [ ] Record email status.
- [ ] Generate request/message identifiers.
- [ ] Apply rate limits.
- [ ] Apply idempotency where appropriate.
- [ ] Never log secrets.

---

# 18. Email Status Rules

The implementation must preserve the established lifecycle:

```text
REQUESTED
VALIDATING
PREPARED
QUEUED*
PROCESSING
SENDING
SENT
FAILED
CANCELLED
```

`QUEUED` is optional in the initial synchronous deployment but the architecture must remain queue-compatible.

Do not invent conflicting status systems in individual modules.

---

# 19. Email Provider Rules

Every provider must implement the provider contract.

### Provider checklist

- [ ] Configuration validation
- [ ] Authentication
- [ ] Connection/send method
- [ ] Capability declaration
- [ ] Timeout handling
- [ ] Error normalization
- [ ] Retry classification
- [ ] Health behavior
- [ ] Logging
- [ ] Credential protection
- [ ] Tests

Core email logic must not contain provider-specific branches everywhere.

---

# 20. Gmail Rules

- [ ] Use OAuth 2.0.
- [ ] Protect OAuth state.
- [ ] Validate callback.
- [ ] Encrypt recoverable tokens.
- [ ] Never log tokens.
- [ ] Handle token refresh failures.
- [ ] Support reauthorization.
- [ ] Support disconnect/revocation.
- [ ] Verify redirect URI.
- [ ] Respect provider scopes.

---

# 21. SMTP Rules

- [ ] Validate host.
- [ ] Validate port.
- [ ] Validate security mode.
- [ ] Protect credentials.
- [ ] Test connection.
- [ ] Use secure transport.
- [ ] Apply timeout.
- [ ] Normalize errors.
- [ ] Support credential rotation.
- [ ] Never log SMTP passwords.

---

# 22. Template Rules

- [ ] Templates are project-scoped.
- [ ] Versions are tracked.
- [ ] Draft/published state is explicit.
- [ ] Variables are validated.
- [ ] Rendering is controlled.
- [ ] Arbitrary PHP execution is impossible.
- [ ] HTML is handled safely.
- [ ] Preview is isolated.
- [ ] Rollback is supported where required.
- [ ] Published templates are stable.
- [ ] Template errors are user-readable and safe.

---

# 23. Webhook Rules

- [ ] HTTPS is required for production webhook delivery.
- [ ] Webhook URLs are validated.
- [ ] SSRF protection is mandatory.
- [ ] Payloads are sanitized.
- [ ] HMAC-SHA256 signatures are used.
- [ ] Secrets are protected.
- [ ] Event IDs are unique.
- [ ] Delivery IDs are unique.
- [ ] Retries are bounded.
- [ ] Backoff is controlled.
- [ ] Duplicate delivery is expected.
- [ ] Consumers should use idempotency.
- [ ] Webhook failure never makes email sending fail.

---

# 24. Security Rules

The 25 locked security features remain mandatory:

- [ ] Password hashing
- [ ] Secure sessions
- [ ] CSRF protection
- [ ] XSS protection
- [ ] SQL injection protection
- [ ] Prepared statements
- [ ] API key authentication
- [ ] API key hashing
- [ ] OAuth 2.0
- [ ] Encrypted OAuth tokens
- [ ] Encrypted SMTP credentials
- [ ] Rate limiting
- [ ] Login attempt protection
- [ ] OTP attempt limiting
- [ ] OTP expiry
- [ ] IP blocking
- [ ] Suspicious activity detection
- [ ] Session revocation
- [ ] Audit logs
- [ ] Admin activity logs
- [ ] Secure headers
- [ ] HTTPS enforcement
- [ ] CORS control
- [ ] Input validation
- [ ] Output sanitization

---

# 25. Browser Security Rules

- [ ] HTTPS in production.
- [ ] Secure cookies.
- [ ] HttpOnly cookies where applicable.
- [ ] SameSite configured.
- [ ] CSRF protection for browser mutations.
- [ ] CSP reviewed.
- [ ] Clickjacking protection.
- [ ] MIME sniffing protection.
- [ ] Referrer policy reviewed.
- [ ] CORS is explicit.
- [ ] CORS is never treated as authentication.
- [ ] Sensitive data is not embedded in HTML unnecessarily.

---

# 26. Frontend Rules

- [ ] Use semantic HTML.
- [ ] Use Bootstrap according to the approved design system.
- [ ] Use JavaScript ES6+.
- [ ] Use Fetch for API communication.
- [ ] Keep frontend logic modular.
- [ ] Never put private API keys in frontend code.
- [ ] Handle loading states.
- [ ] Handle empty states.
- [ ] Handle success states.
- [ ] Handle validation errors.
- [ ] Handle API errors.
- [ ] Handle network failures.
- [ ] Prevent duplicate submissions.
- [ ] Preserve responsive behavior.

---

# 27. UI/UX Rules

All 93 screens/states must have intentional behavior for:

- [ ] Loading
- [ ] Empty
- [ ] Success
- [ ] Error
- [ ] Validation
- [ ] Permission denied
- [ ] Rate limited where relevant
- [ ] Mobile layout
- [ ] Keyboard navigation
- [ ] Accessible labels
- [ ] Focus states

Do not create visually different patterns for identical system states without a reason.

---

# 28. Accessibility Rules

Target:

**WCAG 2.2 AA**

Checklist:

- [ ] Keyboard accessible.
- [ ] Visible focus.
- [ ] Semantic headings.
- [ ] Form labels.
- [ ] Accessible errors.
- [ ] Accessible dialogs.
- [ ] Accessible tables.
- [ ] Sufficient contrast.
- [ ] Reduced-motion support.
- [ ] Screen-reader compatible controls.
- [ ] No critical information conveyed by color alone.

---

# 29. Performance Rules

- [ ] Optimize images.
- [ ] Use appropriate asset formats.
- [ ] Minimize unnecessary JavaScript.
- [ ] Avoid blocking resources.
- [ ] Optimize database queries.
- [ ] Paginate large datasets.
- [ ] Limit API response sizes.
- [ ] Avoid unbounded logs/queries.
- [ ] Cache only safe data.
- [ ] Measure before optimizing.

Security and correctness take priority over premature optimization.

---

# 30. Error Handling Rules

Every expected failure should have:

```text
Internal cause
      ↓
Safe internal error classification
      ↓
Stable API/application error
      ↓
User-safe message
      ↓
Structured log
```

### Rules

- [ ] Do not expose stack traces.
- [ ] Do not expose SQL.
- [ ] Do not expose credentials.
- [ ] Do not expose provider secrets.
- [ ] Do not expose internal file paths unnecessarily.
- [ ] Use stable error codes.
- [ ] Include request ID where useful.
- [ ] Log actionable diagnostic context safely.

---

# 31. Logging Rules

Log important operational/security events.

Never log:

- [ ] Passwords
- [ ] API key secrets
- [ ] OAuth tokens
- [ ] SMTP passwords
- [ ] Webhook secrets
- [ ] Authorization headers
- [ ] OTP plaintext
- [ ] Unnecessary sensitive email content

Use:

- [ ] Request IDs
- [ ] Event IDs
- [ ] Message IDs
- [ ] Safe user/project context
- [ ] Severity
- [ ] Error codes
- [ ] Timestamps

---

# 32. Rate Limiting Rules

Rate-limit sensitive and abuse-prone operations.

Examples:

- [ ] Login
- [ ] Registration
- [ ] Password reset
- [ ] OTP send
- [ ] OTP verification
- [ ] Email send
- [ ] API requests
- [ ] Webhook operations
- [ ] Test email
- [ ] Provider connection attempts

Rate limits should consider:

```text
IP
+
User
+
Project
+
API key
+
Endpoint
```

Use the dimensions appropriate to the operation.

---

# 33. Abuse Prevention

- [ ] Detect suspicious volume.
- [ ] Limit repeated authentication failures.
- [ ] Limit OTP abuse.
- [ ] Limit email sending abuse.
- [ ] Support IP blocking.
- [ ] Support project suspension.
- [ ] Support API key revocation.
- [ ] Record security events.
- [ ] Alert administrators when appropriate.

---

# 34. Admin Rules

Admin functionality must be more restrictive than normal user functionality.

- [ ] Admin authentication is protected.
- [ ] Admin sessions are secure.
- [ ] Admin roles are explicit.
- [ ] Admin actions are audited.
- [ ] Sensitive actions require authorization.
- [ ] Admin credentials are protected.
- [ ] Admin security events are monitored.
- [ ] Admin access is revocable.
- [ ] Admin APIs use the same secure principles as user APIs.

---

# 35. File Upload Rules

If uploads are enabled:

- [ ] Validate size.
- [ ] Validate MIME/type.
- [ ] Validate extension.
- [ ] Generate safe server filenames.
- [ ] Prevent path traversal.
- [ ] Prevent executable uploads.
- [ ] Store private files outside public root.
- [ ] Scan/validate where appropriate.
- [ ] Apply retention rules.
- [ ] Do not trust client filenames.

---

# 36. Dependency Rules

- [ ] Use Composer.
- [ ] Keep lock file.
- [ ] Review security advisories.
- [ ] Update dependencies in staging.
- [ ] Run tests after updates.
- [ ] Avoid abandoned packages.
- [ ] Minimize dependencies.
- [ ] Review package permissions and behavior.

---

# 37. Testing Rules

Every significant feature must include appropriate tests.

### Required categories

- [ ] Unit tests
- [ ] Service tests
- [ ] Repository tests
- [ ] Authorization tests
- [ ] API tests
- [ ] Security tests
- [ ] Integration tests
- [ ] E2E tests where applicable
- [ ] Regression tests

---

# 38. Security Testing Checklist

Test at minimum:

- [ ] SQL injection
- [ ] XSS
- [ ] CSRF
- [ ] IDOR/BOLA
- [ ] Privilege escalation
- [ ] Session fixation
- [ ] Authentication bypass
- [ ] Rate-limit bypass
- [ ] API key abuse
- [ ] SSRF
- [ ] Webhook signature failures
- [ ] Replay attempts
- [ ] Path traversal
- [ ] File upload abuse
- [ ] Command injection
- [ ] Unsafe deserialization
- [ ] Secret exposure
- [ ] Information leakage

---

# 39. API Contract Testing

For every public endpoint:

- [ ] Request schema documented.
- [ ] Response schema documented.
- [ ] Authentication documented.
- [ ] Authorization documented.
- [ ] Error codes documented.
- [ ] Rate limits documented where needed.
- [ ] Examples tested.
- [ ] Backward compatibility checked.

---

# 40. Frontend QA

For every important screen:

- [ ] Desktop
- [ ] Tablet
- [ ] Mobile
- [ ] Keyboard
- [ ] Screen reader where practical
- [ ] Slow network
- [ ] API failure
- [ ] Empty state
- [ ] Loading state
- [ ] Validation state
- [ ] Permission state

---

# 41. Database QA

- [ ] Migration test passes.
- [ ] Constraints work.
- [ ] Indexes exist.
- [ ] Project isolation works.
- [ ] Transactions behave correctly.
- [ ] Concurrent operations are safe.
- [ ] Backup restores successfully.
- [ ] Retention jobs work.

---

# 42. Deployment Checklist

Before production:

- [ ] Tests pass.
- [ ] Security tests pass.
- [ ] Static analysis passes.
- [ ] Composer lock verified.
- [ ] Environment variables verified.
- [ ] Database backup exists.
- [ ] Migration tested.
- [ ] Rollback plan exists.
- [ ] HTTPS verified.
- [ ] Permissions verified.
- [ ] Cron verified.
- [ ] Monitoring verified.
- [ ] Health check verified.
- [ ] Provider integrations tested.
- [ ] Smoke tests pass.

---

# 43. Release Checklist

```text
[ ] Requirements complete
[ ] Code reviewed
[ ] Architecture reviewed
[ ] Security reviewed
[ ] Tests passed
[ ] Documentation updated
[ ] Migration reviewed
[ ] Backup confirmed
[ ] Deployment plan ready
[ ] Rollback plan ready
[ ] Monitoring ready
[ ] Release version assigned
[ ] Staging validated
[ ] Production smoke test planned
```

---

# 44. Incident Response Checklist

If a security or reliability incident occurs:

- [ ] Identify incident.
- [ ] Assign severity.
- [ ] Contain impact.
- [ ] Protect credentials.
- [ ] Revoke compromised keys.
- [ ] Rotate affected secrets.
- [ ] Preserve relevant logs.
- [ ] Restore service safely.
- [ ] Patch root cause.
- [ ] Validate fix.
- [ ] Monitor.
- [ ] Document incident.
- [ ] Add regression tests.
- [ ] Update documentation.

---

# 45. Code Review Checklist

Before approving code:

### Architecture

- [ ] Follows locked architecture.
- [ ] No unnecessary new infrastructure.
- [ ] Correct module boundary.
- [ ] No duplicated core logic.

### Security

- [ ] Authorization correct.
- [ ] Input validated.
- [ ] Output safe.
- [ ] Secrets protected.
- [ ] Logs safe.
- [ ] Abuse controls considered.

### Data

- [ ] Queries safe.
- [ ] Transactions appropriate.
- [ ] Project scope correct.
- [ ] Migration included if needed.

### Reliability

- [ ] Errors handled.
- [ ] Timeouts considered.
- [ ] Retries safe.
- [ ] Idempotency considered.

### Quality

- [ ] Tests included.
- [ ] Documentation updated.
- [ ] Accessibility considered.
- [ ] Performance considered.

---

# 46. Feature Completion Checklist

A feature is not complete until:

- [ ] Requirements implemented.
- [ ] UI implemented.
- [ ] API implemented if required.
- [ ] Authorization implemented.
- [ ] Validation implemented.
- [ ] Database changes implemented.
- [ ] Error handling implemented.
- [ ] Logging implemented.
- [ ] Security reviewed.
- [ ] Tests added.
- [ ] Responsive behavior tested.
- [ ] Accessibility considered.
- [ ] Documentation updated.
- [ ] Production impact understood.

---

# 47. New Provider Checklist

```text
[ ] Provider requirements documented
[ ] Adapter interface implemented
[ ] Authentication implemented
[ ] Credentials protected
[ ] Capability mapping implemented
[ ] Error normalization implemented
[ ] Timeout handling implemented
[ ] Retry classification implemented
[ ] Health behavior implemented
[ ] Tests added
[ ] User UI added if required
[ ] Admin UI added if required
[ ] Documentation updated
[ ] Security review passed
```

---

# 48. New Endpoint Checklist

```text
[ ] Endpoint purpose defined
[ ] HTTP method defined
[ ] Authentication defined
[ ] Authorization defined
[ ] Project scope defined
[ ] Input schema defined
[ ] Validation implemented
[ ] Business service implemented
[ ] Repository changes implemented
[ ] Error contract defined
[ ] Rate limiting reviewed
[ ] Logging reviewed
[ ] Tests added
[ ] API documentation updated
```

---

# 49. New Screen Checklist

```text
[ ] Screen purpose defined
[ ] Route defined
[ ] Navigation location defined
[ ] Permission defined
[ ] Project context defined
[ ] Desktop layout
[ ] Tablet layout
[ ] Mobile layout
[ ] Loading state
[ ] Empty state
[ ] Error state
[ ] Success state
[ ] Validation state
[ ] Accessibility
[ ] Responsive QA
[ ] API integration
```

---

# 50. New Database Table Checklist

```text
[ ] Business purpose
[ ] Owner/project scope
[ ] Primary key
[ ] Foreign keys
[ ] Unique constraints
[ ] Indexes
[ ] Timestamps
[ ] Sensitive fields
[ ] Retention
[ ] Migration
[ ] Rollback/recovery plan
[ ] Tests
[ ] Documentation
```

---

# 51. Production Security Checklist

```text
[ ] HTTPS enabled
[ ] HTTP behavior configured
[ ] Debug disabled
[ ] Secure cookies enabled
[ ] CSRF enabled
[ ] CORS restricted
[ ] Security headers configured
[ ] Database credentials restricted
[ ] Secrets protected
[ ] File permissions restricted
[ ] Public root isolated
[ ] API rate limits active
[ ] Login protection active
[ ] OTP protection active
[ ] Admin protection active
[ ] Audit logging active
[ ] Secret redaction verified
[ ] Backups active
[ ] Restore test completed
[ ] Monitoring active
```

---

# 52. Documentation Checklist

The documentation set must remain complete:

```text
00 MASTER BLUEPRINT
01 PROJECT OVERVIEW
02 FINAL SCOPE AND FEATURES
03 SYSTEM ARCHITECTURE
04 TECHNOLOGY STACK
05 UI/UX DESIGN SYSTEM
06 SCREENS AND NAVIGATION
07 ASSETS, ICONS, FONTS, LOGOS
08 DATABASE ARCHITECTURE
09 DATABASE SCHEMA
10 BACKEND PHP ARCHITECTURE
11 REST API SPECIFICATION
12 AUTHENTICATION AND OTP
13 EMAIL ENGINE
14 EMAIL PROVIDERS
15 TEMPLATE ENGINE
16 PROJECTS, API KEYS, WEBHOOKS
17 USER PANEL
18 ADMIN PANEL
19 SECURITY ARCHITECTURE
20 FRONTEND DEVELOPMENT GUIDE
21 RESPONSIVE, ACCESSIBILITY, PERFORMANCE
22 TESTING, QA AND ERROR HANDLING
23 DEPLOYMENT, MAINTENANCE AND DEVELOPER GUIDE
24 DEVELOPMENT RULES CHECKLIST
```

---

# 53. Non-Negotiable Rules

1. The architecture is locked.
2. Projects remain the primary isolation boundary.
3. Authorization is always server-side.
4. Frontend checks are never sufficient security.
5. API key secrets are cryptographically generated.
6. API key secrets are stored as hashes.
7. Recoverable provider credentials are encrypted.
8. OAuth tokens are protected.
9. SMTP credentials are protected.
10. Webhook secrets are protected.
11. Webhook signatures use HMAC-SHA256.
12. Webhook URLs receive SSRF protection.
13. CORS is not authentication.
14. CSRF protects browser session mutations.
15. SQL uses prepared statements.
16. User input is validated server-side.
17. Output is serialized intentionally.
18. Secrets never enter logs.
19. OTP plaintext never enters logs.
20. Passwords never enter logs.
21. Production debug output remains disabled.
22. Rate limiting protects abuse-prone operations.
23. Project access is verified for every project-scoped resource.
24. Provider-specific logic remains inside adapters.
25. Email sending remains centralized in the Email Engine.
26. Webhook failure never causes email failure.
27. Retries are bounded.
28. Background jobs are idempotent.
29. Database changes use migrations.
30. Backups are restore-tested.
31. Production deployments are versioned.
32. Rollback is planned.
33. Security tests are mandatory.
34. API compatibility is preserved.
35. Documentation must match implementation.
36. No unnecessary infrastructure is introduced.
37. No module may bypass security architecture.
38. No secret may be embedded in frontend source.
39. No production operation should require undocumented manual intervention.
40. Approved architecture changes must be reflected across the entire blueprint.

---

# 54. Final Definition of Done

The Email API Platform is considered development-ready when:

- [ ] All 25 blueprint documents are complete.
- [ ] All 93 screens/states are defined.
- [ ] All 24 core modules are covered.
- [ ] All 29 user features are covered.
- [ ] All 14 API feature areas are covered.
- [ ] All 25 security feature areas are covered.
- [ ] Database architecture is defined.
- [ ] Database schema is defined.
- [ ] Backend architecture is defined.
- [ ] REST API is defined.
- [ ] Authentication and OTP are defined.
- [ ] Email Engine is defined.
- [ ] Provider architecture is defined.
- [ ] Template Engine is defined.
- [ ] Projects/API keys/Webhooks are defined.
- [ ] User Panel is defined.
- [ ] Admin Panel is defined.
- [ ] Security Architecture is defined.
- [ ] Frontend development rules are defined.
- [ ] Responsive/accessibility/performance rules are defined.
- [ ] Testing and QA rules are defined.
- [ ] Deployment and maintenance rules are defined.
- [ ] This final checklist is approved.
- [ ] Implementation can proceed without architectural guesswork.

---

# 55. Final Blueprint Completion Gate

Before starting implementation, confirm:

```text
ARCHITECTURE
[ ] Locked

SCOPE
[ ] Locked

SCREENS
[ ] 93 defined

MODULES
[ ] 24 defined

FEATURES
[ ] 29 user features defined

API
[ ] 14 API areas defined

SECURITY
[ ] 25 security areas defined

DATABASE
[ ] Architecture + schema defined

BACKEND
[ ] PHP architecture defined

EMAIL
[ ] Email Engine defined

PROVIDERS
[ ] Gmail + SMTP + optional adapters defined

TEMPLATES
[ ] Template Engine defined

PROJECTS
[ ] Project isolation defined

API KEYS
[ ] Key lifecycle defined

WEBHOOKS
[ ] Signing/retry/security defined

USER PANEL
[ ] Defined

ADMIN PANEL
[ ] Defined

FRONTEND
[ ] Development rules defined

ACCESSIBILITY
[ ] WCAG 2.2 AA target defined

TESTING
[ ] QA strategy defined

DEPLOYMENT
[ ] Production operations defined

DEVELOPER RULES
[ ] Final checklist defined
```

---

# 56. Final Project Rule

The platform must be built as one coherent system.

Do not implement documents independently as disconnected features.

The correct dependency direction is:

```text
Master Blueprint
       ↓
Architecture
       ↓
Database + Backend
       ↓
Authentication + Security
       ↓
Email Engine + Providers
       ↓
Templates + Projects + API Keys + Webhooks
       ↓
User/Admin Panels
       ↓
Frontend
       ↓
Testing
       ↓
Deployment
```

Cross-cutting security, authorization, logging, validation, rate limiting, and project isolation apply throughout the entire stack.

---

# FINAL LOCK

**24-DEVELOPMENT-RULES-CHECKLIST.md is FINAL / LOCKED.**

This is the final development governance document for the 25-file Email API Platform Blueprint.

The architecture, scope, security model, database model, API model, provider model, UI structure, testing strategy, deployment strategy, and development rules are now considered complete.

**No implementation may bypass the locked architecture.**

**No feature is complete without security, authorization, validation, testing, error handling, and documentation.**

**Any future architectural change requires an explicit blueprint revision rather than an undocumented implementation shortcut.**

---

## Blueprint Status

```text
00–24  = 25 DOCUMENTS
93     = SCREENS / STATES
24     = CORE MODULES
29     = USER FEATURES
14     = API FEATURE AREAS
25     = SECURITY FEATURES

STATUS: FINAL / LOCKED
```

**END OF EMAIL API PLATFORM BLUEPRINT**
