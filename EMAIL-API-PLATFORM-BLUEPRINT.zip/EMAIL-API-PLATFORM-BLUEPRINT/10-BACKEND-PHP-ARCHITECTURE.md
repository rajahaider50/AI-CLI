# 10 — BACKEND PHP ARCHITECTURE

**Project:** Self-Hosted Email API Platform  
**Status:** FINAL / LOCKED  
**Backend:** PHP 8.3+  
**Database:** MySQL 8+  
**Architecture:** Modular Monolith + REST/JSON API  
**Primary Email Library:** PHPMailer  
**Primary Auth:** Secure PHP sessions + project API keys  
**Gmail:** OAuth 2.0  
**Primary Providers:** Gmail + Custom SMTP  
**Optional Providers:** Brevo + Mailtrap

---

## 1. Purpose

This document defines the complete backend PHP architecture for the Email API Platform.

It converts the locked system architecture and database schema into an implementation blueprint covering:

- PHP application structure;
- request lifecycle;
- routing;
- controllers;
- middleware;
- authentication;
- authorization;
- services;
- repositories;
- database access;
- validation;
- DTOs;
- API responses;
- provider adapters;
- email sending;
- templates;
- OTP;
- webhooks;
- logs;
- rate limiting;
- security;
- errors;
- configuration;
- cron jobs;
- testing;
- deployment;
- maintainability.

The backend must remain a **modular monolith**. The initial implementation must not be split into microservices.

---

# 2. Backend Architecture Principle

The backend follows:

```text
HTTP Request
    ↓
Public Entry Point
    ↓
Router
    ↓
Global Middleware
    ↓
Authentication Middleware
    ↓
Authorization / Project Context
    ↓
Controller
    ↓
Service
    ↓
Repository / Provider Adapter
    ↓
Database / External Provider
    ↓
Service Result
    ↓
API Response
```

The most important boundary is:

```text
Controller
    ↓
Service
    ↓
Repository
```

Controllers must not contain business logic.

Repositories must not contain HTTP logic.

Provider adapters must not contain controller logic.

---

# 3. Architectural Style

## 3.1 Modular Monolith

The application runs as one PHP application but is divided into clear modules.

Recommended modules:

```text
Auth
Users
Projects
Providers
Gmail
SMTP
Templates
Email
OTP
API Keys
Webhooks
Logs
Usage
Notifications
Security
Admin
System
```

Each module owns its domain logic while using shared infrastructure.

## 3.2 Why Modular Monolith

The project requires:

- simple deployment;
- low operational cost;
- PHP compatibility;
- straightforward debugging;
- shared transactions;
- shared database;
- provider extensibility;
- future scaling without premature infrastructure.

Microservices, Kubernetes, mandatory Redis, and mandatory message queues are not part of the initial architecture.

---

# 4. Recommended Directory Structure

```text
app/
├── Config/
│   ├── app.php
│   ├── database.php
│   ├── mail.php
│   ├── security.php
│   ├── providers.php
│   └── services.php
│
├── Core/
│   ├── Application.php
│   ├── Container.php
│   ├── Router.php
│   ├── Request.php
│   ├── Response.php
│   ├── JsonResponse.php
│   ├── Controller.php
│   ├── Middleware.php
│   ├── ExceptionHandler.php
│   ├── Logger.php
│   ├── Database.php
│   ├── Validator.php
│   ├── Pagination.php
│   └── Result.php
│
├── Auth/
│   ├── Controllers/
│   ├── Services/
│   ├── Repositories/
│   ├── Middleware/
│   ├── DTOs/
│   └── Policies/
│
├── Users/
│   ├── Controllers/
│   ├── Services/
│   ├── Repositories/
│   └── DTOs/
│
├── Projects/
│   ├── Controllers/
│   ├── Services/
│   ├── Repositories/
│   ├── DTOs/
│   └── Policies/
│
├── Providers/
│   ├── Controllers/
│   ├── Services/
│   ├── Repositories/
│   ├── Contracts/
│   └── Adapters/
│       ├── Gmail/
│       ├── SMTP/
│       ├── Brevo/
│       └── Mailtrap/
│
├── Templates/
│   ├── Controllers/
│   ├── Services/
│   ├── Repositories/
│   └── DTOs/
│
├── Email/
│   ├── Controllers/
│   ├── Services/
│   ├── Repositories/
│   ├── Contracts/
│   ├── DTOs/
│   └── Rendering/
│
├── OTP/
│   ├── Controllers/
│   ├── Services/
│   ├── Repositories/
│   └── Policies/
│
├── ApiKeys/
│   ├── Controllers/
│   ├── Services/
│   └── Repositories/
│
├── Webhooks/
│   ├── Controllers/
│   ├── Services/
│   ├── Repositories/
│   └── Delivery/
│
├── Logs/
│   ├── Controllers/
│   ├── Services/
│   └── Repositories/
│
├── Usage/
│   ├── Controllers/
│   ├── Services/
│   └── Repositories/
│
├── Notifications/
│   ├── Controllers/
│   ├── Services/
│   └── Repositories/
│
├── Security/
│   ├── Services/
│   ├── Repositories/
│   ├── Middleware/
│   └── Policies/
│
├── Admin/
│   ├── Controllers/
│   ├── Services/
│   ├── Repositories/
│   └── Middleware/
│
└── System/
    ├── Controllers/
    ├── Services/
    └── Repositories/

bootstrap/
├── app.php
├── container.php
├── routes.php
└── middleware.php

config/
├── app.php
├── database.php
├── mail.php
├── security.php
├── providers.php
└── services.php

database/
├── migrations/
├── seeders/
└── factories/

public/
├── index.php
├── assets/
└── .htaccess

routes/
├── web.php
├── api.php
├── admin.php
└── health.php

storage/
├── logs/
├── cache/
└── temporary/

tests/
├── Unit/
├── Integration/
├── Feature/
└── Security/

vendor/
```

---

# 5. Public Entry Point

The application should use a single front controller:

```text
public/index.php
```

The web server routes application requests to this entry point.

Basic lifecycle:

```php
require dirname(__DIR__) . '/vendor/autoload.php';

$app = require dirname(__DIR__) . '/bootstrap/app.php';

$app->run();
```

The public directory must be the web server document root.

Application source, configuration secrets, migrations, and storage must not be directly web-accessible.

---

# 6. Bootstrap Sequence

Recommended startup:

```text
Load Composer autoloader
        ↓
Load environment/configuration
        ↓
Create service container
        ↓
Create database connection
        ↓
Register repositories/services
        ↓
Register provider adapters
        ↓
Register middleware
        ↓
Register routes
        ↓
Create application
        ↓
Process request
```

Bootstrap code should remain small.

Business logic must never be placed in `bootstrap/app.php`.

---

# 7. Composer Dependencies

Core dependencies:

```text
phpmailer/phpmailer
```

Recommended development dependencies:

```text
phpunit/phpunit
phpstan/phpstan
```

Additional packages should be introduced only when they solve a real requirement and are compatible with PHP 8.3+.

Avoid unnecessary framework/dependency weight if the platform does not need it.

---

# 8. Environment Configuration

Secrets must come from environment/deployment secret storage.

Example:

```text
APP_ENV=production
APP_DEBUG=false
APP_URL=https://example.com

DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=email_api
DB_USERNAME=...
DB_PASSWORD=...

APP_ENCRYPTION_KEY=...

GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REDIRECT_URI=...

MAIL_DEFAULT_FROM=...
```

Never commit actual secrets to Git.

Never place secrets inside frontend JavaScript.

Never expose server environment variables through API responses.

---

# 9. Configuration Layer

Application code should not repeatedly call `getenv()`.

Instead:

```text
Environment
    ↓
Config loader
    ↓
Typed configuration
    ↓
Application services
```

Example:

```php
$config = [
    'app' => [
        'env' => env('APP_ENV', 'production'),
        'debug' => env('APP_DEBUG', false),
    ],
];
```

Production configuration should disable detailed exception output.

---

# 10. Dependency Container

The application should use a lightweight dependency container.

Responsibilities:

- create PDO;
- create repositories;
- create services;
- create provider adapters;
- create logger;
- create validator;
- inject dependencies.

Example:

```php
$container->singleton(PDO::class, function () {
    return Database::connection();
});
```

Services should receive dependencies through constructors.

Avoid hidden global dependencies.

---

# 11. HTTP Request Object

Create a normalized request abstraction.

Responsibilities:

```text
HTTP method
path
query parameters
headers
JSON body
form body
IP address
user agent
request ID
authenticated user
project context
API key context
```

The request object should not automatically trust client-supplied identity fields.

---

# 12. HTTP Response Object

Responses should be generated through a common response abstraction.

Example:

```php
return JsonResponse::success(
    data: $data,
    status: 200
);
```

Errors:

```php
return JsonResponse::error(
    code: 'VALIDATION_ERROR',
    message: 'Invalid request.',
    status: 422
);
```

Do not return PHP arrays directly from controllers.

---

# 13. Standard API Response Envelope

Successful response:

```json
{
  "success": true,
  "data": {},
  "meta": {
    "request_id": "..."
  }
}
```

Error response:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The request is invalid.",
    "details": {}
  },
  "meta": {
    "request_id": "..."
  }
}
```

Sensitive internal exception details must never be returned.

---

# 14. Request ID

Every request should receive a unique request ID.

Example:

```text
X-Request-ID
```

If the client supplies a valid ID, it may be accepted under controlled rules; otherwise generate one server-side.

Use the request ID across:

```text
API request log
email log
OTP log
webhook log
security log
admin log
application log
```

This provides end-to-end troubleshooting.

---

# 15. Router

Routes should be explicit.

Example:

```text
POST   /api/v1/auth/login
POST   /api/v1/auth/register
POST   /api/v1/auth/verify-email

GET    /api/v1/projects
POST   /api/v1/projects
GET    /api/v1/projects/{project}

GET    /api/v1/projects/{project}/templates
POST   /api/v1/projects/{project}/templates

POST   /api/v1/projects/{project}/email/send
POST   /api/v1/projects/{project}/otp/send
POST   /api/v1/projects/{project}/otp/verify
```

Avoid ambiguous catch-all routes.

---

# 16. API Versioning

Initial API:

```text
/api/v1/
```

Versioning belongs in the public URL.

Breaking changes require a new version.

Backward-compatible additions should remain in the current version.

---

# 17. Middleware Pipeline

Recommended global order:

```text
Request ID
    ↓
Trusted proxy/IP normalization
    ↓
Security headers
    ↓
CORS policy
    ↓
Rate limiting
    ↓
Body/content validation
    ↓
Authentication
    ↓
Project/API-key context
    ↓
Authorization
    ↓
Controller
```

Not every route uses every middleware.

---

# 18. Authentication Types

The platform has separate authentication contexts.

## Browser/User Authentication

```text
Secure session cookie
```

Used for:

- dashboard;
- projects;
- templates;
- provider management;
- profile;
- security;
- admin interfaces where applicable.

## API Authentication

```text
Project API key
```

Used for:

- email sending;
- OTP APIs;
- project API operations;
- integration endpoints.

## Admin Authentication

Separate admin identity/session boundary.

Never treat an ordinary user session as an admin session.

---

# 19. Session Security

Use:

```text
HttpOnly
Secure
SameSite
session ID regeneration
server-side expiration
revocation
idle timeout
absolute timeout where required
```

Session IDs must never be stored in application database logs.

On successful authentication:

```text
regenerate session ID
create/update session record
record login event
```

---

# 20. Authentication Service

Responsibilities:

```text
register
login
logout
verify email
forgot password
reset password
account recovery
session revocation
password change
```

The controller only translates HTTP input/output.

---

# 21. Password Handling

Use PHP's password API:

```php
password_hash(
    $password,
    PASSWORD_DEFAULT
);
```

Verify:

```php
password_verify(
    $password,
    $hash
);
```

Never:

```text
MD5
SHA1
plain SHA256
plaintext passwords
reversible password encryption
```

---

# 22. Password Policy

The exact user-facing password policy belongs to configuration, but the backend must enforce:

- minimum length;
- maximum safe length;
- non-empty;
- secure hashing;
- confirmation where required;
- rate limiting;
- password-change session handling.

Do not impose arbitrary complexity requirements unless the product policy requires them.

---

# 23. Email Verification

Flow:

```text
Register
   ↓
Create user
   ↓
Create verification token hash
   ↓
Send verification email
   ↓
User opens verification URL
   ↓
Hash supplied token
   ↓
Find active token
   ↓
Validate expiry
   ↓
Mark token consumed
   ↓
Mark user verified
```

Use a transaction for the final state change.

---

# 24. OTP Service

OTP service responsibilities:

```text
generate code
hash code
store protected record
enforce expiry
enforce attempts
send code
verify code
consume code
write OTP log
```

Never log the actual OTP.

Verification must be atomic.

---

# 25. Project Authorization

Every project-scoped request must establish:

```text
authenticated identity
       ↓
project ownership/permission
       ↓
resource ownership
```

Example:

```php
$project = $projectService->authorize(
    userId: $user->id,
    projectId: $projectId
);
```

Never trust:

```text
project_id from JSON alone
user_id from JSON
owner_id from JSON
```

---

# 26. Authorization Policies

Use explicit policy methods.

Examples:

```text
canViewProject()
canEditProject()
canDeleteProject()
canManageProvider()
canManageTemplate()
canManageApiKey()
canManageWebhook()
canViewLogs()
```

Admin authorization is separate.

---

# 27. Controller Responsibilities

A controller should:

1. receive request;
2. validate basic input;
3. call service;
4. transform result;
5. return response.

Example:

```php
public function create(Request $request): Response
{
    $input = $this->validator->validate(
        $request->json(),
        CreateProjectRules::rules()
    );

    $project = $this->projectService->create(
        $this->auth->user(),
        $input
    );

    return JsonResponse::created(
        ProjectResource::from($project)
    );
}
```

Controllers should remain thin.

---

# 28. Service Layer

Services own business rules.

Examples:

```text
AuthService
ProjectService
ProviderService
GmailService
SMTPService
TemplateService
EmailService
OtpService
ApiKeyService
WebhookService
UsageService
SecurityService
NotificationService
AdminService
```

A service may coordinate multiple repositories and adapters.

---

# 29. Repository Layer

Repositories own database persistence.

Example:

```php
interface ProjectRepository
{
    public function findById(int $id): ?Project;

    public function findForUser(
        int $projectId,
        int $userId
    ): ?Project;

    public function create(array $data): Project;
}
```

Repositories should not:

- send email;
- render HTML;
- authorize HTTP requests;
- return HTTP responses.

---

# 30. PDO Database Layer

Create one managed PDO connection per application request where appropriate.

Recommended PDO attributes:

```php
PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
PDO::ATTR_EMULATE_PREPARES => false
```

Always use prepared statements for values.

---

# 31. Transaction Pattern

Example:

```php
$pdo->beginTransaction();

try {
    // related database changes

    $pdo->commit();
} catch (Throwable $e) {
    $pdo->rollBack();
    throw $e;
}
```

Never swallow transaction exceptions.

---

# 32. External Provider Boundary

Never hold a long DB transaction while calling:

```text
Gmail
SMTP
Brevo
Mailtrap
Webhook URL
```

Correct pattern:

```text
validate
  ↓
create state/log
  ↓
commit
  ↓
external operation
  ↓
update result
```

---

# 33. Email Architecture

The email subsystem uses:

```text
EmailController
      ↓
EmailService
      ↓
TemplateRenderer
      ↓
ProviderResolver
      ↓
EmailProviderInterface
      ↓
GmailAdapter / SMTPAdapter / ...
```

---

# 34. Email Provider Contract

Define a common interface.

Example:

```php
interface EmailProviderInterface
{
    public function send(
        EmailMessage $message
    ): ProviderSendResult;

    public function test(): ProviderTestResult;

    public function validate(): ProviderValidationResult;
}
```

Every provider must implement the same contract.

---

# 35. Provider Resolver

Input:

```text
project
provider connection
```

Output:

```text
EmailProviderInterface
```

Example:

```text
provider code = gmail
        ↓
GmailAdapter

provider code = smtp
        ↓
SMTPAdapter
```

Provider-specific details remain inside adapters.

---

# 36. Gmail Adapter

Responsibilities:

- validate Gmail connection;
- refresh OAuth access token;
- create PHPMailer/Gmail transport as appropriate;
- send email;
- normalize provider result;
- expose safe diagnostics.

Never expose OAuth tokens.

Gmail credentials remain encrypted at rest.

---

# 37. SMTP Adapter

Responsibilities:

```text
load encrypted credentials
decrypt in memory
configure PHPMailer
configure host/port/encryption
authenticate
send
normalize result
```

The decrypted password must never be written to logs.

---

# 38. Optional Provider Adapters

Optional adapters:

```text
BrevoAdapter
MailtrapAdapter
```

They must implement the same provider contract.

Core email logic must not contain:

```php
if ($provider === 'brevo') ...
```

throughout the application.

Provider-specific branching belongs in the resolver/adapter layer.

---

# 39. PHPMailer Boundary

PHPMailer should be treated as an infrastructure dependency.

Application code should pass a normalized `EmailMessage`.

Example:

```text
EmailMessage
    ↓
Provider Adapter
    ↓
PHPMailer
```

Do not spread PHPMailer configuration across controllers.

---

# 40. Email Message DTO

Example fields:

```text
to
cc
bcc
from
from_name
reply_to
subject
html_body
text_body
headers
attachments
metadata
```

Attachments must be validated carefully.

---

# 41. Email Send Flow

```text
API request
    ↓
authenticate API key
    ↓
authorize project
    ↓
validate payload
    ↓
resolve template if requested
    ↓
render variables
    ↓
validate sender/provider
    ↓
create email log
    ↓
send through provider
    ↓
update email log
    ↓
update usage
    ↓
dispatch webhook if configured
    ↓
return normalized response
```

---

# 42. Email Log Safety

Do not store full email content by default.

Operational logs should contain:

```text
recipient
sender
subject where policy permits
status
provider
message ID
request ID
timestamps
error code
```

If message-body storage is ever introduced, it requires explicit retention/privacy rules.

---

# 43. Template Architecture

Template flow:

```text
TemplateService
    ↓
load template
    ↓
load current version
    ↓
validate variables
    ↓
render subject
    ↓
render HTML
    ↓
render text
```

Template versions are immutable.

---

# 44. Template Variable Safety

Variables must be explicitly supplied.

Example:

```json
{
  "name": "Raja",
  "verification_url": "https://example.com/verify"
}
```

Do not expose server internals as template variables.

Do not execute arbitrary PHP/code inside templates.

Template rendering must not become a code-execution mechanism.

---

# 45. HTML Sanitization

User-authored email HTML must be treated as untrusted input where applicable.

Prevent dangerous constructs according to the product's template policy.

Never allow server-side executable code inside template content.

---

# 46. API Key Service

Responsibilities:

```text
generate
hash
store
list metadata
revoke
expire
validate
authorize permissions
```

Recommended generated secret format:

```text
public prefix + high-entropy secret
```

Store only:

```text
key_prefix
key_hash
```

Display the complete secret only at creation.

---

# 47. API Key Validation

Flow:

```text
extract key
    ↓
extract prefix
    ↓
database candidate lookup
    ↓
secure secret verification
    ↓
revocation check
    ↓
expiry check
    ↓
project status check
    ↓
permission check
```

Never compare secrets with ordinary unsafe string logic where timing-sensitive verification applies.

---

# 48. API Permissions

Permission examples:

```text
email:send
otp:send
otp:verify
templates:read
templates:write
logs:read
projects:read
projects:write
webhooks:manage
usage:read
```

Permissions should be checked by the service/policy layer.

---

# 49. Webhook Architecture

Flow:

```text
Domain event
    ↓
WebhookService
    ↓
find subscribed endpoints
    ↓
create delivery record
    ↓
sign payload
    ↓
HTTP delivery
    ↓
record response
    ↓
retry if configured
```

The initial architecture may perform delivery synchronously for simple events, but the design must remain compatible with future background processing.

---

# 50. Webhook Security

Webhook requests should include:

```text
event ID
event type
timestamp
signature
payload
```

Use an HMAC-based signing strategy with a securely stored webhook secret.

Consumers can verify authenticity and reject stale/replayed events.

---

# 51. Webhook Retry

Retry only transient failures.

Examples:

```text
408
429
5xx
network timeout
connection failure
```

Do not blindly retry permanent client errors such as most `4xx` responses.

Backoff policy should be bounded.

---

# 52. Rate Limiting Architecture

Rate limiting is required at multiple levels:

```text
IP
user
project
API key
route/category
```

Important protected operations:

```text
login
register
OTP send
OTP verify
password reset
email send
webhook delivery
admin authentication
```

The first implementation may use database-backed or lightweight application storage according to deployment scale.

Redis is not mandatory.

---

# 53. Security Middleware

Security middleware must handle:

- secure headers;
- request IDs;
- trusted IP processing;
- CORS;
- rate limiting;
- authentication;
- CSRF for browser state-changing requests;
- input constraints.

---

# 54. CSRF

Browser session endpoints must use CSRF protection for state-changing requests where cookie authentication is involved.

API-key requests generally use header-based authentication and are not treated as browser-cookie CSRF flows.

Never disable CSRF globally merely because the application has an API.

---

# 55. CORS

CORS must be allowlist-based.

Project settings may define approved origins.

Never default production to:

```text
Access-Control-Allow-Origin: *
```

when credentials are involved.

Validate the requesting origin before returning permissive CORS headers.

---

# 56. Input Validation

Validation occurs before service execution.

Validate:

```text
type
required fields
length
format
email syntax
URL syntax
allowed enum values
array sizes
HTML/template limits
recipient limits
attachment limits
```

Validation does not replace authorization.

---

# 57. Output Serialization

Use resource/DTO classes.

Example:

```php
ProjectResource::from($project)
```

Never serialize database entities blindly.

Explicitly select public fields.

---

# 58. Error Architecture

Define application exceptions:

```text
ValidationException
AuthenticationException
AuthorizationException
NotFoundException
ConflictException
RateLimitException
ProviderException
DatabaseException
WebhookException
```

Map them to HTTP status codes.

Example:

```text
400 → malformed request
401 → unauthenticated
403 → unauthorized
404 → not found
409 → conflict
422 → validation failure
429 → rate limited
500 → internal failure
502/503 → provider/upstream failure where appropriate
```

---

# 59. Global Exception Handler

Production response:

```json
{
  "success": false,
  "error": {
    "code": "INTERNAL_ERROR",
    "message": "An internal error occurred."
  },
  "meta": {
    "request_id": "..."
  }
}
```

Detailed exception traces belong in protected server logs only.

---

# 60. Database Exception Handling

Never expose:

```text
SQL query
database credentials
table structure
PDO stack trace
```

to clients.

Translate expected database conflicts into domain errors.

Unexpected database errors become internal errors and are logged with request IDs.

---

# 61. Logging Architecture

Separate:

```text
application log
security log
audit log
API request log
email log
OTP log
webhook log
admin log
```

Do not duplicate sensitive data across every log.

---

# 62. Sensitive Data Logging Rules

Never log:

```text
password
password hash
API key secret
API key hash where unnecessary
OTP
OAuth token
SMTP password
webhook secret
encryption key
session token
verification token
```

Mask sensitive identifiers where useful.

---

# 63. Security Event Examples

Log:

```text
login_success
login_failed
password_changed
session_revoked
api_key_created
api_key_revoked
provider_connected
provider_disconnected
oauth_refresh_failed
suspicious_request
ip_blocked
admin_login
admin_action
```

---

# 64. Admin Backend

Admin modules use the same service/repository architecture but require separate authorization.

Admin routes:

```text
/admin/*
```

or equivalent API namespace.

Admin controllers must never bypass services simply because the user is an administrator.

---

# 65. Admin Roles

Locked roles:

```text
super_admin
admin
support
auditor
```

Role permissions should be explicit.

Example:

```text
auditor → read-only
support → operational support
admin → normal administration
super_admin → highest administrative privileges
```

---

# 66. System Settings

System settings are accessed through:

```text
SystemSettingsRepository
SystemSettingsService
```

Do not read raw settings directly throughout the codebase.

Secret settings should be encrypted or moved to deployment secret storage.

---

# 67. Notifications

Notification service creates records in:

```text
notifications
```

Events may include:

```text
provider_expired
provider_failed
security_warning
api_key_created
webhook_failure
system_notice
```

Notification creation must not expose secrets.

---

# 68. Usage Tracking

Usage service records:

```text
emails_sent
emails_failed
otp_sent
otp_verified
api_requests
api_errors
webhook_deliveries
webhook_failures
```

Daily aggregation is stored in:

```text
usage_statistics
```

Do not calculate every dashboard metric by scanning millions of raw logs.

---

# 69. Cron Architecture

Cron is used for maintenance tasks.

Examples:

```text
expire sessions
expire OTPs
expire verification tokens
cleanup old login attempts
cleanup old API request logs
aggregate usage
process webhook retries
provider credential health checks
cleanup temporary files
```

Recommended CLI structure:

```text
php bin/console sessions:cleanup
php bin/console otp:cleanup
php bin/console usage:aggregate
php bin/console webhooks:retry
```

A single scheduler/cron entry may invoke these commands.

---

# 70. CLI Bootstrap

CLI code must reuse the same:

```text
configuration
container
repositories
services
logging
database connection
```

Do not duplicate business logic in cron scripts.

---

# 71. Email Provider Testing

Provider test flow:

```text
load provider
    ↓
validate credentials
    ↓
attempt safe connection/test
    ↓
normalize result
    ↓
update provider status
    ↓
write audit/security information
```

Never expose raw provider credentials.

---

# 72. Gmail OAuth Flow

```text
User clicks Add Gmail
        ↓
Generate OAuth state
        ↓
Redirect to Google authorization
        ↓
Google callback
        ↓
Validate state
        ↓
Exchange authorization code
        ↓
Encrypt tokens
        ↓
Store gmail connection
        ↓
Mark provider active
        ↓
Redirect to success UI
```

OAuth state must be protected against CSRF.

---

# 73. SMTP Connection Flow

```text
User enters SMTP settings
        ↓
Validate host/port/encryption
        ↓
Encrypt credential
        ↓
Create pending connection
        ↓
Test connection
        ↓
Mark active/error
```

The password should not be returned to the frontend after submission.

---

# 74. Provider Status Model

Common normalized statuses:

```text
pending
testing
active
error
expired
disconnected
disabled
```

Adapters may have provider-specific errors, but the core system should normalize them.

---

# 75. Provider Error Normalization

Example internal result:

```php
new ProviderSendResult(
    success: false,
    providerCode: 'gmail',
    providerMessageId: null,
    errorCode: 'AUTH_EXPIRED',
    retryable: false
);
```

The API should expose a safe public error representation.

---

# 76. Email Idempotency

Where required, API requests may support an idempotency key.

Recommended header:

```text
Idempotency-Key
```

The backend should define exact semantics before enabling it publicly.

Never accidentally send duplicate transactional messages because a client retried a request.

---

# 77. Request Limits

Enforce configurable limits for:

```text
JSON body size
recipient count
subject length
HTML size
text body size
template size
attachment size
webhook payload size
pagination size
```

Reject oversized requests early.

---

# 78. File/Attachment Security

If attachments are supported:

- validate size;
- validate type;
- prevent path traversal;
- never trust filename extensions;
- use generated storage names;
- store outside the public directory;
- scan/validate according to deployment requirements;
- never execute uploaded files.

---

# 79. Temporary Storage

Temporary files belong under:

```text
storage/temporary/
```

not:

```text
public/
```

Cleanup must be automated.

---

# 80. Database Repository Example

```php
final class ProjectRepository
{
    public function __construct(
        private PDO $pdo
    ) {}

    public function findForUser(
        int $projectId,
        int $userId
    ): ?array {
        $stmt = $this->pdo->prepare(
            'SELECT *
             FROM projects
             WHERE id = :id
               AND user_id = :user_id
               AND deleted_at IS NULL
             LIMIT 1'
        );

        $stmt->execute([
            'id' => $projectId,
            'user_id' => $userId,
        ]);

        $row = $stmt->fetch();

        return $row ?: null;
    }
}
```

---

# 81. Service Example

```php
final class ProjectService
{
    public function __construct(
        private ProjectRepository $projects,
        private ProjectSettingsRepository $settings
    ) {}

    public function getForUser(
        int $projectId,
        int $userId
    ): array {
        $project = $this->projects
            ->findForUser($projectId, $userId);

        if (!$project) {
            throw new NotFoundException(
                'Project not found.'
            );
        }

        return $project;
    }
}
```

---

# 82. Controller Example

```php
final class ProjectController
{
    public function __construct(
        private ProjectService $service
    ) {}

    public function show(Request $request): Response
    {
        $project = $this->service->getForUser(
            (int) $request->route('project'),
            $request->user()->id
        );

        return JsonResponse::success([
            'project' => ProjectResource::from($project),
        ]);
    }
}
```

---

# 83. Repository Rules

Repositories must:

- use prepared statements;
- use explicit columns where practical;
- use transactions through service coordination;
- return domain-oriented data;
- paginate large results;
- avoid N+1 queries;
- never trust caller ownership without query constraints.

---

# 84. Service Rules

Services must:

- enforce business rules;
- coordinate repositories;
- enforce project isolation;
- enforce authorization policies;
- define transaction boundaries;
- normalize provider results;
- emit domain events where appropriate.

---

# 85. Controller Rules

Controllers must not:

- access PDO directly;
- decrypt credentials;
- send email directly;
- generate SQL;
- implement provider logic;
- implement complex authorization;
- contain large business workflows.

---

# 86. Provider Adapter Rules

Adapters must:

- implement provider contracts;
- handle provider-specific protocols;
- normalize errors;
- keep credentials in memory only as needed;
- never log secrets;
- remain replaceable.

---

# 87. Security Boundary

Sensitive operations should follow:

```text
HTTP
 ↓
Authentication
 ↓
Authorization
 ↓
Validation
 ↓
Service
 ↓
Secure repository/adapter
```

No shortcut should bypass this sequence.

---

# 88. API Endpoint Grouping

Recommended route groups:

```text
/api/v1/auth/*
/api/v1/projects/*
/api/v1/templates/*
/api/v1/providers/*
/api/v1/email/*
/api/v1/otp/*
/api/v1/api-keys/*
/api/v1/webhooks/*
/api/v1/logs/*
/api/v1/usage/*
/api/v1/health
```

Admin:

```text
/api/v1/admin/*
```

---

# 89. Health Endpoint

Public or protected health endpoint should distinguish:

```text
application healthy
database healthy
provider infrastructure where appropriate
```

Do not expose internal secrets, credentials, stack traces, or sensitive topology.

Example:

```json
{
  "success": true,
  "data": {
    "status": "ok"
  }
}
```

---

# 90. API Documentation Compatibility

The backend must expose enough metadata for API documentation to describe:

```text
endpoint
method
authentication
request body
parameters
response
errors
rate limits
examples
```

Documentation must reflect the actual implementation.

---

# 91. Testing Architecture

Tests:

```text
Unit
Integration
Feature
Security
```

## Unit

Test:

```text
validators
services
template rendering
provider normalization
policies
utility classes
```

## Integration

Test:

```text
PDO
repositories
migrations
provider adapters with controlled test environments
```

## Feature

Test complete API flows.

## Security

Test:

```text
authorization bypass
SQL injection
XSS
CSRF
rate limiting
API key leakage
session fixation
project isolation
secret exposure
```

---

# 92. Project Isolation Security Test

Attempt:

```text
User A
    ↓
Project B ID
```

Expected:

```text
404 or 403
```

and never return Project B data.

This test is mandatory.

---

# 93. API Key Security Tests

Test:

```text
valid key
invalid key
revoked key
expired key
wrong project
insufficient permission
malformed key
replayed request where relevant
```

---

# 94. Provider Security Tests

Test:

```text
expired Gmail token
invalid SMTP password
wrong SMTP port
TLS failure
provider timeout
provider rejection
provider recovery
```

Ensure credentials never appear in errors/logs.

---

# 95. Error Recovery

Provider failures should:

1. update the operational log;
2. return safe API error;
3. classify retryability;
4. update provider state where appropriate;
5. emit webhook/notification where configured;
6. preserve request ID for troubleshooting.

---

# 96. Concurrency

Protect against:

```text
double OTP verification
duplicate API key creation where uniqueness matters
template version collisions
simultaneous provider updates
duplicate webhook delivery
duplicate transactional sends
```

Use:

```text
unique constraints
transactions
row locks where justified
idempotency
atomic updates
```

Do not rely solely on PHP memory state.

---

# 97. Caching

Caching may be used for:

```text
system configuration
provider registry
static metadata
```

Do not cache secrets carelessly.

Project authorization must not be bypassed by stale cached ownership information.

Caching is an optimization, not a security boundary.

---

# 98. Performance Rules

Backend should:

- use prepared statements;
- avoid N+1 queries;
- paginate logs;
- aggregate usage;
- avoid huge JSON payloads;
- avoid unnecessary provider calls;
- reuse service instances within a request;
- keep transactions short;
- use indexes defined by the schema;
- profile slow operations before adding infrastructure.

---

# 99. Scalability Path

Initial:

```text
Nginx/Apache
    ↓
PHP-FPM
    ↓
MySQL
```

Future:

```text
Load Balancer
    ↓
Multiple PHP-FPM instances
    ↓
Shared MySQL
    ↓
Optional cache/queue
```

The application must remain stateless except for intentionally stored sessions/state.

---

# 100. Queue Compatibility

Queues are not required initially.

If volume later requires asynchronous email:

```text
EmailService
    ↓
Job abstraction
    ↓
Queue adapter
    ↓
Worker
    ↓
Provider adapter
```

The domain service should not become tightly coupled to a particular queue technology.

---

# 101. Deployment Structure

Recommended:

```text
/var/www/email-api/
├── app/
├── bootstrap/
├── config/
├── database/
├── public/
├── routes/
├── storage/
├── tests/
├── vendor/
└── .env
```

Web server root:

```text
/var/www/email-api/public
```

---

# 102. File Permissions

The PHP process must have write access only where required, such as:

```text
storage/
```

Application source should normally be read-only to the runtime process.

`.env` and secrets must not be publicly accessible.

---

# 103. Apache Deployment

If Apache is used, the public directory should be the document root.

A minimal front-controller strategy may use:

```text
public/.htaccess
```

with rewrite rules directing non-file requests to:

```text
public/index.php
```

Never expose `.env`, `.git`, configuration, or storage files.

---

# 104. Nginx Deployment

Nginx should:

```text
root → public/
index → index.php
PHP → PHP-FPM
```

Deny access to:

```text
.env
.git
storage
config
database
vendor metadata not intended for public access
```

---

# 105. HTTPS

Production API and dashboard must use HTTPS.

Redirect HTTP to HTTPS where appropriate.

Secure cookies must be enabled in production.

OAuth redirect URIs must use approved HTTPS URLs in production.

---

# 106. Cron Security

Cron commands should:

- use the same application bootstrap;
- validate environment;
- use locks where duplicate execution is dangerous;
- write structured logs;
- fail with non-zero exit codes on serious errors.

---

# 107. Deployment Sequence

Recommended:

```text
backup
  ↓
deploy code
  ↓
install Composer dependencies
  ↓
run compatible migrations
  ↓
clear/rebuild safe caches
  ↓
health check
  ↓
enable traffic
```

Avoid destructive migrations before compatible code is deployed.

---

# 108. Database Migration Rule

Application code and migrations must remain backward-compatible during deployment transitions.

Preferred:

```text
add
  ↓
deploy
  ↓
backfill
  ↓
switch reads/writes
  ↓
remove later
```

---

# 109. Configuration Validation

Application startup should validate required production configuration.

Examples:

```text
APP_ENV
APP_URL
database credentials
encryption key
Google OAuth credentials
mail defaults
```

If critical configuration is missing, fail safely instead of starting in an insecure state.

---

# 110. Encryption Service

Create a dedicated:

```text
EncryptionService
```

Responsibilities:

```text
encrypt
decrypt
key version
algorithm/version metadata
safe failure handling
```

It must use a standard authenticated encryption implementation.

Never create custom encryption algorithms.

---

# 111. Secret Decryption Rule

Secrets should be decrypted only immediately before use.

Example:

```text
load encrypted SMTP password
    ↓
decrypt
    ↓
configure transport
    ↓
send
    ↓
release reference
```

Never put decrypted secrets into:

```text
logs
exceptions
JSON responses
database
analytics
notifications
```

---

# 112. Security Headers

Production responses should consider:

```text
Strict-Transport-Security
Content-Security-Policy
X-Content-Type-Options
Referrer-Policy
Permissions-Policy
```

Exact policy values depend on deployment and frontend requirements.

---

# 113. Content Security Policy

The CSP should be restrictive and compatible with the actual frontend.

Do not add:

```text
unsafe-eval
```

unless an explicitly reviewed dependency requires it.

Avoid unnecessary:

```text
*
```

origins.

---

# 114. Audit vs Application Logs

Application logs answer:

```text
What went wrong technically?
```

Audit logs answer:

```text
Who changed what?
```

Security logs answer:

```text
What security event occurred?
```

Do not merge these responsibilities into one unstructured log.

---

# 115. Data Privacy

Backend must minimize stored personal data.

Examples:

```text
Do not store email bodies unless required.
Do not retain raw passwords.
Do not retain raw OTPs.
Do not retain raw API secrets.
Do not log OAuth tokens.
```

Retention must be configurable/documented where applicable.

---

# 116. Error Messages

User-facing:

```text
safe
clear
actionable
non-sensitive
```

Internal logs:

```text
diagnostic
request-correlated
sanitized
```

Never reveal whether a security-sensitive account exists when the product policy requires generic responses.

---

# 117. Service Naming Convention

Use explicit names:

```text
CreateProjectService
ProjectService
SendEmailService
VerifyOtpService
CreateApiKeyService
```

For small domains, a cohesive service class is acceptable.

Avoid:

```text
GodService
HelperEverything
UtilsManager
```

---

# 118. DTO Naming

Examples:

```text
CreateProjectData
UpdateProjectData
SendEmailData
SendOtpData
VerifyOtpData
CreateTemplateData
CreateApiKeyData
CreateWebhookData
```

DTOs should represent validated application input, not raw HTTP.

---

# 119. Resource Naming

Examples:

```text
UserResource
ProjectResource
TemplateResource
ProviderResource
EmailLogResource
WebhookResource
UsageResource
```

Resources define public API representation.

---

# 120. Policy Naming

Examples:

```text
ProjectPolicy
TemplatePolicy
ProviderPolicy
ApiKeyPolicy
WebhookPolicy
AdminPolicy
```

Policies answer authorization questions.

---

# 121. Event Naming

If domain events are used:

```text
UserRegistered
EmailVerified
ProjectCreated
ProviderConnected
ProviderDisconnected
EmailSent
EmailFailed
OtpSent
OtpVerified
ApiKeyCreated
ApiKeyRevoked
WebhookFailed
```

Events must contain safe metadata only.

---

# 122. Backend Coding Standards

Use:

```text
PSR-compatible PHP style
strict typing where practical
typed properties
typed method parameters
return types
small focused classes
dependency injection
exceptions for exceptional failures
```

Example:

```php
declare(strict_types=1);
```

Avoid excessive static state.

---

# 123. PHP Error Handling

Production:

```text
display_errors = Off
log_errors = On
```

Development may show detailed errors locally.

Never enable production stack traces in API responses.

---

# 124. Static Analysis

PHPStan is recommended.

Static analysis should detect:

```text
type errors
unreachable paths
nullability mistakes
invalid method calls
unsafe assumptions
```

Increase strictness progressively.

---

# 125. Automated Testing Pipeline

Recommended:

```text
Composer validation
    ↓
PHP syntax check
    ↓
PHPUnit
    ↓
PHPStan
    ↓
migration tests
    ↓
security tests
    ↓
build/deploy validation
```

---

# 126. Backend Definition of Done

Backend implementation is complete when:

- [ ] front controller works;
- [ ] routing works;
- [ ] middleware works;
- [ ] authentication works;
- [ ] project authorization works;
- [ ] repositories use PDO safely;
- [ ] services own business logic;
- [ ] controllers remain thin;
- [ ] Gmail OAuth works;
- [ ] SMTP works;
- [ ] provider adapter contract works;
- [ ] templates work;
- [ ] email sending works;
- [ ] OTP works;
- [ ] API keys work;
- [ ] webhooks work;
- [ ] logs work;
- [ ] usage aggregation works;
- [ ] notifications work;
- [ ] admin authorization works;
- [ ] rate limiting works;
- [ ] security logging works;
- [ ] error handling is normalized;
- [ ] cron jobs work;
- [ ] tests pass;
- [ ] production configuration is secure.

---

# 127. Non-Negotiable Backend Rules

1. PHP 8.3+.
2. Modular monolith.
3. REST/JSON API.
4. PDO for database access.
5. Prepared statements.
6. Thin controllers.
7. Business logic in services.
8. Persistence in repositories.
9. Provider-specific code in adapters.
10. Project isolation on every project-scoped query.
11. API secrets stored as hashes.
12. OAuth/SMTP/webhook secrets encrypted.
13. Passwords hashed, never encrypted.
14. OTPs never logged.
15. No credentials in API responses.
16. No database root account for application runtime.
17. No raw SQL concatenation with user values.
18. No PHP execution inside user templates.
19. No secrets in Git.
20. No production stack traces.
21. HTTPS in production.
22. Secure session cookies.
23. CSRF for cookie-authenticated state changes.
24. Allowlisted CORS.
25. Rate limiting on sensitive endpoints.
26. Short database transactions.
27. No transaction held during network provider calls.
28. Explicit API versioning.
29. Structured request IDs.
30. Consistent error responses.
31. Logs must be sanitized.
32. Admin authorization is separate.
33. Queue/Redis/microservices are not mandatory initial dependencies.
34. Future scaling must preserve the domain/service boundaries.
35. Architecture changes require deliberate review rather than ad-hoc implementation.

---

# 128. Final Architecture Diagram

```text
                    ┌──────────────────────┐
                    │   Browser / Client   │
                    │ HTML / JS / Fetch    │
                    └──────────┬───────────┘
                               │ HTTPS
                               ▼
                    ┌──────────────────────┐
                    │ Web Server           │
                    │ Apache / Nginx       │
                    └──────────┬───────────┘
                               ▼
                    ┌──────────────────────┐
                    │ public/index.php     │
                    │ Front Controller      │
                    └──────────┬───────────┘
                               ▼
                    ┌──────────────────────┐
                    │ Router + Middleware  │
                    └──────────┬───────────┘
                               ▼
                    ┌──────────────────────┐
                    │ Authentication /     │
                    │ Authorization        │
                    └──────────┬───────────┘
                               ▼
                    ┌──────────────────────┐
                    │ Controllers          │
                    └──────────┬───────────┘
                               ▼
                    ┌──────────────────────┐
                    │ Application Services │
                    └──────┬─────────┬─────┘
                           │         │
                ┌──────────▼───┐   ┌─▼────────────────┐
                │ Repositories │   │ Provider Adapters │
                └──────┬───────┘   └───────┬──────────┘
                       │                   │
                ┌──────▼───────┐     ┌─────▼──────────────┐
                │ MySQL 8+     │     │ Gmail / SMTP       │
                │ PDO / InnoDB │     │ Brevo / Mailtrap   │
                └──────────────┘     └────────────────────┘
```

---

# 129. Relationship to Other Documents

This document depends on:

```text
03-SYSTEM-ARCHITECTURE.md
04-TECHNOLOGY-STACK.md
08-DATABASE-ARCHITECTURE.md
09-DATABASE-SCHEMA.md
```

It provides the implementation foundation for:

```text
11-REST-API-SPECIFICATION.md
12-AUTHENTICATION-AND-OTP.md
13-EMAIL-ENGINE.md
14-EMAIL-PROVIDERS.md
15-TEMPLATE-ENGINE.md
16-PROJECTS-API-KEYS-WEBHOOKS.md
```

---

# 130. Final Lock

This document is **FINAL / LOCKED**.

The PHP backend must implement the previously finalized architecture without introducing structural changes that conflict with:

- 93 screens;
- 24 core modules;
- 29 user features;
- 14 API feature areas;
- 25 security features;
- MySQL 8+ schema;
- PHP 8.3+;
- Gmail + Custom SMTP primary providers;
- optional Brevo + Mailtrap;
- modular-monolith architecture;
- project-based isolation;
- REST/JSON API;
- PHPMailer;
- OAuth 2.0;
- PDO;
- secure sessions;
- API keys;
- webhooks;
- logging;
- OTP;
- admin controls.

**Next document:** `11-REST-API-SPECIFICATION.md`
