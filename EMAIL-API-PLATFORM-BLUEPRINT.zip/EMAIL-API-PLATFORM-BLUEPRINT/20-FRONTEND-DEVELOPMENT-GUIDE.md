# 20 — Frontend Development Guide

**Project:** Email API Platform  
**Document:** Frontend Development Guide  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Audience:** Frontend developers, full-stack PHP developers, UI/UX engineers, QA engineers  
**Depends on:** 00–19 architecture documents  
**Primary frontend stack:** HTML5, CSS3, Bootstrap 5.3+, JavaScript ES6+, Fetch API  
**Primary fonts:** Inter, JetBrains Mono  
**Primary icon system:** Lucide  
**Browser model:** Modern evergreen browsers with progressive enhancement

---

## 1. Purpose

This document defines the complete frontend engineering standard for the Email API Platform.

It specifies:

- frontend architecture
- page structure
- component conventions
- CSS architecture
- JavaScript architecture
- API communication
- authentication handling
- project context
- forms and validation
- loading, empty, success, and error states
- templates and email editor behavior
- API key UI
- provider connection UI
- logs and analytics UI
- webhooks UI
- admin frontend rules
- responsive behavior
- accessibility
- performance
- security
- browser storage
- frontend testing
- coding standards
- deployment requirements

The frontend is a presentation and interaction layer. It must never replace server-side authorization, validation, security controls, or business rules.

---

# 2. Locked Architecture

The frontend is a server-independent UI layer that communicates with the PHP backend through HTTPS REST/JSON APIs.

```text
Browser
  |
  +-- HTML
  +-- CSS / Bootstrap
  +-- JavaScript
  |
  +-- Fetch API
        |
        v
     HTTPS REST API
        |
        v
     PHP Backend
        |
        +-- Auth
        +-- Authorization
        +-- Projects
        +-- Templates
        +-- Providers
        +-- Email Engine
        +-- Webhooks
        +-- Logs
        +-- Usage
```

### Non-negotiable rule

The frontend may improve usability, but the backend remains the authoritative source of truth.

---

# 3. Frontend Goals

The frontend must be:

- professional
- responsive
- accessible
- fast
- predictable
- secure
- maintainable
- component-oriented
- API-driven
- project-aware
- keyboard friendly
- mobile usable
- visually consistent

The UI must communicate system state clearly.

---

# 4. Frontend Responsibilities

The frontend is responsible for:

- rendering pages
- navigation
- displaying API data
- collecting user input
- client-side validation
- form state
- loading states
- success states
- error presentation
- confirmation dialogs
- pagination
- filtering
- sorting
- search
- project selection
- provider setup UI
- template editing UI
- API integration examples
- dashboard visualization
- notification presentation

The frontend must not be responsible for:

- authorization decisions
- API key validation
- password hashing
- OAuth token handling
- SMTP credential decryption
- rate-limit enforcement
- security policy enforcement
- SQL/database access
- email provider credentials
- bypassing backend validation

---

# 5. Technology Baseline

## Required

- HTML5
- CSS3
- Bootstrap 5.3+
- JavaScript ES6+
- Fetch API
- CSS variables
- semantic HTML
- responsive layout
- modular JavaScript

## Recommended

- ESLint
- Prettier
- PHPUnit for backend integration
- Playwright or equivalent browser testing
- Lighthouse
- browser DevTools

No frontend framework is mandatory.

React, Vue, Angular, or another framework must not be introduced as a structural requirement unless the entire architecture is deliberately revised.

---

# 6. Browser Support

Support modern evergreen versions of:

- Chrome
- Edge
- Firefox
- Safari
- Android Chrome
- iOS Safari

Do not optimize for obsolete browsers at the expense of maintainability or security.

Progressive enhancement is preferred.

---

# 7. Frontend Directory Structure

Recommended structure:

```text
public/
├── index.html
├── assets/
│   ├── css/
│   │   ├── bootstrap.min.css
│   │   ├── app.css
│   │   ├── components.css
│   │   ├── utilities.css
│   │   └── responsive.css
│   ├── js/
│   │   ├── app.js
│   │   ├── api.js
│   │   ├── auth.js
│   │   ├── router.js
│   │   ├── state.js
│   │   ├── ui.js
│   │   ├── validation.js
│   │   ├── notifications.js
│   │   ├── modals.js
│   │   ├── tables.js
│   │   ├── forms.js
│   │   ├── templates.js
│   │   ├── providers.js
│   │   ├── projects.js
│   │   ├── webhooks.js
│   │   └── admin.js
│   ├── icons/
│   ├── images/
│   ├── logos/
│   └── fonts/
└── pages/
```

The exact server-side rendering strategy may vary, but frontend responsibilities and contracts remain unchanged.

---

# 8. HTML Standards

Use semantic HTML.

Preferred structure:

```html
<header></header>
<nav></nav>
<main></main>
<section></section>
<article></article>
<aside></aside>
<footer></footer>
```

Avoid using generic `<div>` elements when semantic elements communicate structure more accurately.

Every page must have:

- one clear `<main>`
- logical heading hierarchy
- descriptive page title
- accessible form labels
- keyboard-accessible controls
- meaningful link text

---

# 9. Page Shell

Authenticated application pages use a common shell:

```text
+------------------------------------------------------+
| Top Bar                                              |
+----------+-------------------------------------------+
| Sidebar  | Page Header                               |
|          +-------------------------------------------+
|          | Main Content                              |
|          |                                           |
|          | Cards / Tables / Forms / Charts           |
|          |                                           |
+----------+-------------------------------------------+
```

The shell must support:

- desktop sidebar
- collapsed/mobile navigation
- project context
- user menu
- notifications
- breadcrumbs where useful
- responsive content width

---

# 10. Public Website Frontend

Public screens:

1. Home
2. Features
3. How It Works
4. Providers
5. API Documentation
6. Pricing
7. FAQ
8. Contact
9. Privacy Policy
10. Terms & Conditions

Public pages must share:

- header
- footer
- typography
- buttons
- cards
- spacing
- responsive behavior
- accessibility rules

Public pages must not expose authenticated project data.

---

# 11. Authentication Frontend

Authentication screens:

- Login
- Register
- Email Verification
- OTP Verification
- Forgot Password
- Reset Password
- Account Recovery

Frontend responsibilities:

- collect credentials
- validate obvious input errors
- submit securely over HTTPS
- show server responses safely
- display OTP countdown
- disable repeated submissions when appropriate
- provide resend controls
- preserve non-sensitive workflow state

Never store passwords in localStorage, sessionStorage, cookies created by JavaScript, or URL parameters.

---

# 12. Session Handling

The backend owns the authenticated session.

The frontend must treat authentication state as server-controlled.

On application startup:

```text
Load application
     |
     v
Check authenticated session
     |
 +---+---+
 |       |
No      Yes
 |       |
Login   Load user/project context
```

If the server returns an authentication failure:

1. clear local non-sensitive UI state
2. stop protected requests
3. redirect to login
4. optionally preserve a safe return path
5. never expose the server error payload directly

Do not implement fake client-side authentication.

---

# 13. Project Context

Projects are the primary application isolation boundary.

The frontend must always know which project is active on authenticated project pages.

Recommended state:

```js
const appState = {
  user: null,
  activeProject: null,
  projects: [],
  notifications: [],
  permissions: [],
  ui: {}
};
```

Changing project context must:

1. update the active project state
2. update the URL or route context if applicable
3. reload project-specific data
4. invalidate stale project-specific UI
5. prevent stale data from appearing as current data

Never assume that a project ID selected in the browser grants authorization.

The backend must authorize every protected request.

---

# 14. Navigation

Primary user navigation:

- Dashboard
- Projects
- Email Services
- Templates
- Email Send
- API Integration
- API Keys
- Logs
- Usage
- Webhooks
- Notifications
- Profile
- Security

Admin navigation must be separated from normal user navigation.

Navigation visibility may reflect permissions, but hidden navigation is not authorization.

---

# 15. Routing

Routes must be:

- readable
- predictable
- bookmarkable where appropriate
- free from secrets
- compatible with authentication state

Never place:

- API keys
- OAuth tokens
- SMTP credentials
- passwords
- webhook secrets

inside URLs.

---

# 16. API Client Architecture

All REST requests should pass through a central API client.

Example:

```js
async function apiRequest(url, options = {}) {
  const response = await fetch(url, {
    credentials: "include",
    headers: {
      "Accept": "application/json",
      ...(options.body ? { "Content-Type": "application/json" } : {}),
      ...(options.headers || {})
    },
    ...options
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw normalizeApiError(response, data);
  }

  return data;
}
```

Do not duplicate raw `fetch()` configuration throughout every page module.

---

# 17. API Response Handling

The frontend must support the backend response contract defined by the REST API specification.

Conceptually:

```json
{
  "success": true,
  "data": {},
  "meta": {},
  "request_id": "..."
}
```

Error example:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The request could not be processed.",
    "fields": {}
  },
  "request_id": "..."
}
```

The frontend must:

- use stable error codes
- display safe human-readable messages
- map field errors to forms
- preserve request IDs for support/debugging
- avoid displaying internal stack traces

---

# 18. HTTP Status Handling

Important statuses:

| Status | Frontend behavior |
|---|---|
| 200 | render successful response |
| 201 | show creation success |
| 204 | treat as successful empty response |
| 400 | show validation/request error |
| 401 | authentication flow |
| 403 | authorization message |
| 404 | not found state |
| 409 | conflict state |
| 422 | field validation |
| 429 | rate-limit UI |
| 500 | generic server error |
| 502/503 | provider/service unavailable |
| 504 | timeout/retry guidance |

Never retry every failure automatically.

Only retry operations when the API contract allows it and idempotency is safe.

---

# 19. Request IDs

When an API response includes a request ID:

- keep it available for diagnostics
- show it in technical error details when appropriate
- include it in support/report dialogs
- never expose sensitive request metadata

Example:

```text
Something went wrong.
Request ID: req_01J...
```

---

# 20. CSRF

Browser session mutations must follow the backend CSRF contract.

The frontend must:

- obtain the current CSRF token using the approved mechanism
- send it with protected state-changing requests
- refresh it when required
- handle expired tokens safely

Do not invent a separate client-side CSRF system.

API-key-authenticated server-to-server requests are governed by the API authentication model rather than browser session CSRF.

---

# 21. CORS

CORS is controlled by the backend.

Frontend code must not assume that CORS grants authorization.

For client integrations:

```text
Browser Website
      |
      | HTTPS Fetch
      v
Email API
      |
      +-- Origin validation
      +-- API key validation
      +-- Project authorization
      +-- Rate limits
```

CORS must never be treated as an authentication mechanism.

---

# 22. Forms

Every form should have:

- visible label
- input
- helper text where useful
- validation state
- error state
- submit state
- success state
- keyboard support

Example:

```html
<label for="smtpHost">SMTP Host</label>
<input
  id="smtpHost"
  name="smtp_host"
  type="text"
  autocomplete="off"
  required
>
<div class="invalid-feedback"></div>
```

Never rely on placeholder text as the only label.

---

# 23. Client-Side Validation

Client validation is for usability.

Server validation is authoritative.

Validate common issues such as:

- required fields
- email format
- URL format
- numeric ranges
- maximum length
- password confirmation
- template variable syntax
- webhook URL format

Always submit to the backend for final validation.

---

# 24. Form Submission Pattern

Recommended:

```text
Idle
 |
 v
Editing
 |
 v
Submitting
 |
 +----> Success
 |
 +----> Validation Error
 |
 +----> Server Error
```

While submitting:

- disable duplicate submission
- show progress state
- preserve user input
- prevent accidental navigation where practical

On failure, do not erase valid user input.

---

# 25. Buttons

Button hierarchy:

- Primary: main action
- Secondary: alternative action
- Outline: low-emphasis action
- Danger: destructive action
- Ghost: lightweight navigation/action
- Icon-only: compact action with accessible label

Destructive actions require confirmation where appropriate.

Examples:

- delete project
- revoke API key
- disconnect provider
- delete template
- remove webhook
- suspend account

---

# 26. Loading States

Every asynchronous view must define a loading state.

Use:

- skeletons for page/card content
- spinners for short operations
- button loading indicators for submissions
- progress indicators for multi-step operations

Avoid blank screens.

Example:

```text
Loading project...
[████████████░░░]
```

Do not use infinite loading without timeout/error handling.

---

# 27. Empty States

Empty states must explain:

1. what is empty
2. why it matters
3. what the user can do next

Example:

```text
No email templates yet

Create a reusable template for transactional emails.

[ Create Template ]
```

Avoid empty states that merely say "No data."

---

# 28. Error States

Error UI must be:

- understandable
- non-sensitive
- actionable
- consistent

Examples:

```text
Unable to load email logs.
[Retry]
```

For provider failure:

```text
Gmail connection could not be completed.
Check the provider configuration and try again.
```

Do not display:

- SQL errors
- stack traces
- filesystem paths
- OAuth secrets
- SMTP passwords
- internal class names

---

# 29. Success Feedback

Use:

- inline confirmation
- toast
- alert
- success panel

Choose the least disruptive mechanism.

Example:

```text
✓ Template published successfully.
```

Avoid excessive toast notifications.

---

# 30. Notification System

Notifications may include:

- provider connected
- provider disconnected
- email send result
- webhook failure
- security alert
- password change
- login/security event
- system announcement

Notifications must be fetched from the backend and marked read through API calls.

---

# 31. Tables

Tables are required for:

- email logs
- OTP logs
- API logs
- webhook logs
- projects
- templates
- API keys
- users
- provider connections

Table requirements:

- responsive behavior
- sortable columns where supported
- pagination
- search/filter
- loading state
- empty state
- error state
- accessible headers
- row actions

On mobile, dense tables may transform into stacked cards.

---

# 32. Pagination

Prefer server-side pagination for large datasets.

Frontend sends:

```text
?page=1&per_page=25
```

or the API's defined pagination contract.

UI must show:

- current page
- total when available
- next/previous
- page size when supported

Do not load thousands of logs just to paginate in JavaScript.

---

# 33. Search and Filters

Search should:

- debounce text input
- avoid unnecessary requests
- preserve filter state where appropriate
- show active filters
- support clear/reset

Example debounce target:

```js
setTimeout(loadResults, 300);
```

Use the backend for large dataset filtering.

---

# 34. Project Dashboard

Dashboard should prioritize:

- project identity
- email activity
- provider status
- usage
- recent email logs
- recent errors
- API status
- webhook status

Do not overload the dashboard with every available metric.

---

# 35. Provider UI

Provider-related screens:

- Add Gmail
- Gmail Connection Success
- Add SMTP
- SMTP Connection Test
- Provider Management
- Admin provider screens

Provider UI must show:

- provider type
- connection status
- last test
- last successful use where available
- health/error state
- disconnect/reconnect action

Secrets must be masked.

---

# 36. Gmail OAuth UI

Gmail flow:

```text
Add Gmail
   |
   v
Explain permissions
   |
   v
Start OAuth
   |
   v
Google authorization
   |
   v
Callback
   |
   v
Validate state
   |
   v
Store encrypted tokens
   |
   v
Connection success
```

The frontend must not receive or store the Gmail refresh token.

Use a backend-controlled OAuth flow.

---

# 37. SMTP UI

SMTP form may contain:

- host
- port
- encryption/security mode
- username
- password
- from name
- from email

Password fields must never be prefilled from stored secrets.

The backend must encrypt SMTP credentials.

Frontend should display:

```text
Password: ••••••••
```

not the real password.

---

# 38. Provider Test Flow

```text
User submits provider
        |
        v
Backend validates
        |
        v
Connection test
        |
   +----+----+
   |         |
Success     Failure
   |         |
Success UI  Safe error
```

Do not perform provider authentication directly from browser JavaScript.

---

# 39. Email Template UI

Template screens:

- Email Templates
- Create Template
- Template Editor
- Template Preview
- Template Variables

Template editor should support:

- subject
- HTML body
- optional plain-text body
- variables
- status
- version
- preview
- test email
- publish
- rollback
- duplicate
- delete

---

# 40. Template Variables

Example:

```text
{{name}}
{{email}}
{{verification_code}}
{{reset_url}}
```

Frontend may highlight recognized variables.

Unknown variables should be visibly flagged.

The backend remains authoritative for allowed variables and rendering.

---

# 41. HTML Template Editing

If a raw HTML editor is provided:

- use monospace font
- provide syntax-friendly formatting
- preserve exact user HTML
- prevent accidental destructive formatting
- provide preview
- sanitize where required by backend policy

Never execute user template HTML as application page HTML without isolation.

---

# 42. Template Preview Security

Preview must be isolated.

Recommended approach:

```text
Template HTML
     |
     v
Sandboxed preview
     |
     v
iframe / isolated rendering
```

Preview must not gain access to:

- parent DOM
- application cookies
- local storage
- API credentials
- privileged JavaScript

---

# 43. Email Send UI

Send email screen may support:

- recipient
- subject
- template
- variables
- direct HTML
- plain text
- reply-to
- test mode where supported

Before send:

```text
Validate
  ↓
Preview
  ↓
Confirm
  ↓
Send
```

For potentially destructive or high-volume actions, show explicit confirmation.

---

# 44. Test Email UI

Test email should clearly indicate:

```text
TEST EMAIL
```

Test operations must not be confused with production sends.

The backend must enforce test-mode behavior.

---

# 45. API Integration UI

API Integration should explain:

- base URL
- authentication
- project ID
- API key usage
- send endpoint
- OTP endpoints
- error handling
- rate limits
- request IDs

Provide copyable examples.

---

# 46. JavaScript Fetch Example

Frontend documentation may provide:

```js
const response = await fetch("https://api.example.com/v1/email/send", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "Authorization": "Bearer YOUR_API_KEY"
  },
  body: JSON.stringify({
    to: "user@example.com",
    subject: "Welcome",
    html: "<h1>Welcome</h1>"
  })
});

const result = await response.json();
```

Never hard-code real API keys in examples.

---

# 47. API Key UI

API key screens:

- list keys
- create key
- name key
- scopes
- expiry
- status
- last used
- revoke
- rotate where supported

After creation, a secret may be displayed once.

UI must clearly state:

```text
Copy this key now.
It will not be shown again.
```

Do not store private server API keys in browser storage.

---

# 48. Browser/API Key Warning

Browser-exposed keys are not equivalent to server secrets.

If the product supports browser integration:

- restrict scopes
- restrict origins where supported
- use rate limits
- expose only minimum necessary privileges
- clearly warn about public exposure

Private server keys must remain on trusted servers.

---

# 49. Webhook UI

Webhook settings should support:

- endpoint URL
- event selection
- enabled/disabled
- secret rotation
- test delivery
- delivery logs
- failure state

Display:

```text
HTTPS endpoint required
```

The backend performs SSRF validation and security checks.

---

# 50. Webhook Delivery UI

Show:

- event ID
- delivery ID
- endpoint
- status
- attempts
- response status
- duration
- created time
- next retry
- final result

Do not display webhook secrets.

---

# 51. Logs UI

Email log detail may show:

- request ID
- message ID
- status
- provider
- recipient
- sender
- subject where policy permits
- timestamps
- error code
- safe error message
- retry information

Sensitive data must be masked or omitted according to backend privacy policy.

---

# 52. Usage & Statistics

Charts may display:

- emails sent
- successful sends
- failed sends
- OTP volume
- API requests
- webhook deliveries
- provider usage
- daily/monthly trends

Charts must have:

- accessible labels
- text summaries where practical
- loading states
- empty states
- error states
- responsive sizing

Do not make color the only way to communicate status.

---

# 53. Admin Frontend

Admin UI is a separate privilege surface.

Admin screens include:

- Admin Dashboard
- Users
- User Details
- Add/Edit User
- Projects
- Project Details
- Providers
- Gmail/SMTP/Brevo/Mailtrap
- Logs
- Templates
- API Keys
- Usage
- Analytics
- Security Dashboard
- Blocked IPs
- Rate Limits
- Login Attempts
- Security/Audit Logs
- System Settings
- Admin Accounts
- Admin Profile
- Admin Security

Admin frontend must use the same security principles as the user panel, with stricter authorization.

---

# 54. Admin RBAC

Frontend may hide actions that the current admin cannot perform.

However:

```text
Hidden UI ≠ Authorization
```

Every admin mutation must be authorized by the backend.

Destructive admin actions should require:

- explicit confirmation
- clear target identity
- safe error handling
- audit logging by backend

---

# 55. Modals

Use modals for:

- confirmations
- compact forms
- destructive actions
- quick details
- test operations

Avoid placing long workflows inside modals.

Modals must:

- trap focus
- close predictably
- support Escape
- restore focus
- have accessible labels

---

# 56. Toasts

Toasts are appropriate for:

- saved
- copied
- connected
- disconnected
- published
- revoked

Do not use toasts as the only presentation for critical security errors.

---

# 57. Copy-to-Clipboard

Used for:

- API keys
- API URLs
- code examples
- webhook endpoint examples
- request IDs

After copy:

```text
Copied
```

Do not expose secrets unnecessarily.

---

# 58. Sensitive Data Rules

Never place these in:

- localStorage
- sessionStorage
- URLs
- DOM data attributes
- analytics events
- console logs

Sensitive data includes:

- passwords
- API key secrets
- OAuth tokens
- SMTP passwords
- webhook secrets
- recovery secrets

---

# 59. Browser Storage

Allowed candidates for local storage:

- non-sensitive UI preferences
- theme preference
- sidebar state
- table page size
- dismissed UI hints

Do not use browser storage as a secure credential vault.

---

# 60. Console Logging

Production frontend must not log:

- passwords
- API keys
- OAuth tokens
- SMTP credentials
- webhook secrets
- full authorization headers
- sensitive email content

Development logging must be controlled and removable/disabled in production.

---

# 61. XSS Prevention

Never inject untrusted content with:

```js
element.innerHTML = untrustedValue;
```

Prefer:

```js
element.textContent = untrustedValue;
```

If HTML rendering is required, it must use a controlled sanitization strategy and backend policy.

Template preview must remain isolated.

---

# 62. URL Safety

Do not blindly place user-controlled URLs into:

```html
<a href="...">
```

or:

```js
window.location = userValue;
```

Validate allowed URL schemes and rely on backend validation for server-side destinations.

---

# 63. Frontend Security Headers

Security headers are primarily a server responsibility.

The deployment must configure appropriate headers such as:

- Content-Security-Policy
- X-Content-Type-Options
- Referrer-Policy
- Permissions-Policy
- frame protection
- HTTPS transport protections

Frontend code must remain compatible with the final CSP.

Avoid unnecessary inline scripts if CSP policy disallows them.

---

# 64. Accessibility Standard

Target WCAG 2.2 AA principles where practical.

Requirements:

- keyboard navigation
- visible focus
- sufficient contrast
- semantic labels
- accessible names
- form error association
- screen-reader-friendly status messages
- reduced-motion support
- no color-only status
- touch-friendly controls

---

# 65. Keyboard Navigation

All important actions must be usable without a mouse.

Test:

- Tab
- Shift+Tab
- Enter
- Space
- Escape
- arrow keys where widgets require them

Focus must never become trapped outside an active modal/dialog.

---

# 66. Reduced Motion

Respect:

```css
@media (prefers-reduced-motion: reduce) {
  * {
    animation-duration: 0.01ms !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

Animations are enhancement, not required for functionality.

---

# 67. Responsive Breakpoints

Use Bootstrap's responsive system as the baseline.

Typical behavior:

```text
Mobile
  ↓
Tablet
  ↓
Desktop
  ↓
Wide Desktop
```

Do not design mobile as a shrunken desktop.

---

# 68. Mobile Navigation

On mobile:

- sidebar becomes off-canvas/drawer
- main content uses full width
- tables become scrollable or card-based
- action groups wrap
- forms stack vertically
- modals remain usable
- buttons have adequate touch targets

---

# 69. Responsive Forms

Desktop:

```text
[Label] [Input] [Input]
```

Mobile:

```text
Label
[Input]

Label
[Input]
```

Never require horizontal scrolling for ordinary forms.

---

# 70. Performance

Frontend performance priorities:

1. small initial payload
2. efficient CSS
3. deferred non-critical JavaScript
4. optimized images
5. cached static assets
6. minimal API requests
7. debounced search
8. server-side pagination
9. lazy loading
10. efficient DOM updates

Avoid unnecessary frontend libraries.

---

# 71. JavaScript Loading

Use:

```html
<script src="/assets/js/app.js" defer></script>
```

Load page-specific modules only when needed where practical.

Do not block first paint with unnecessary scripts.

---

# 72. Asset Optimization

Use:

- SVG for icons/logos
- WebP for raster imagery
- compressed images
- minified production CSS/JS
- cache-busting/versioned assets

Avoid shipping original design files to production.

---

# 73. CSS Architecture

Recommended order:

```text
variables
base
layout
components
utilities
responsive
accessibility overrides
```

Use CSS variables for design tokens.

Example:

```css
:root {
  --color-primary: #...;
  --color-surface: #...;
  --color-text: #...;
  --radius-sm: ...;
  --radius-md: ...;
  --space-1: ...;
}
```

Exact visual tokens are defined by the UI/UX design-system document.

---

# 74. Bootstrap Usage

Bootstrap is the layout and utility foundation.

Use:

- grid
- flex utilities
- spacing
- forms
- buttons
- cards
- tables
- modal
- offcanvas
- alerts

Do not blindly override Bootstrap globally.

Custom classes should be namespaced and purposeful.

---

# 75. JavaScript Modules

Prefer single-purpose modules:

```text
api.js
auth.js
projects.js
providers.js
templates.js
webhooks.js
tables.js
validation.js
ui.js
notifications.js
```

Avoid one giant `app.js` containing all business behavior.

---

# 76. State Management

A lightweight application state object is sufficient unless complexity proves otherwise.

Keep state:

- explicit
- serializable where useful
- scoped
- minimal

Avoid global mutable state for every DOM value.

Server data should have a clear owner.

---

# 77. Event Handling

Prefer event delegation for repeated dynamic elements.

Example:

```js
document.addEventListener("click", (event) => {
  const button = event.target.closest("[data-action]");
  if (!button) return;

  // Dispatch action.
});
```

Avoid attaching hundreds of duplicate handlers when delegation is appropriate.

---

# 78. Data Attributes

Use data attributes for UI behavior:

```html
<button
  type="button"
  data-action="delete-template"
  data-template-id="123">
  Delete
</button>
```

Do not put secrets in data attributes.

---

# 79. API Request Cancellation

Use `AbortController` for requests that may become stale.

Example:

```js
const controller = new AbortController();

fetch(url, {
  signal: controller.signal
});

// controller.abort();
```

This is especially useful for:

- search
- project switching
- rapidly changing filters
- page navigation

---

# 80. Race Conditions

When project context changes:

```text
Request A: Project A
Request B: Project B
```

A late response from A must not overwrite Project B UI.

Use:

- request cancellation
- request tokens
- active-context checks

This is mandatory for project-aware screens.

---

# 81. Error Normalization

Centralize API errors:

```js
function normalizeApiError(response, data) {
  return {
    status: response.status,
    code: data?.error?.code || "UNKNOWN_ERROR",
    message: data?.error?.message || "Something went wrong.",
    fields: data?.error?.fields || {},
    requestId: data?.request_id || null
  };
}
```

Never let every page invent its own error format.

---

# 82. Retry Rules

Frontend retries are limited.

Safe candidates:

- GET data refresh
- explicitly retryable provider status checks
- transient read operations

Do not blindly retry:

- email sends
- OTP sends
- password changes
- API key creation
- webhook mutations

unless the backend/API contract provides idempotency guarantees.

---

# 83. Idempotency UI

Where an endpoint supports idempotency:

- generate/store the idempotency key for the operation lifecycle
- prevent accidental duplicate submission
- preserve the key across safe retries

The backend remains authoritative.

---

# 84. Email Logs Privacy

The frontend should minimize exposure of:

- full message body
- recipient lists
- personal data
- authentication codes
- reset URLs

Display only what the product policy permits.

OTP values and recovery secrets must never be casually displayed in logs.

---

# 85. Template Editor Autosave

If autosave is implemented:

- debounce changes
- show saving state
- show saved state
- handle conflicts
- never silently overwrite newer versions

Autosave must not replace explicit versioning/publishing.

---

# 86. Unsaved Changes

For important editors:

```text
Dirty
 |
 v
Navigation requested
 |
 v
Confirm
 |
 +--> Leave
 +--> Stay
```

Do not block every navigation unnecessarily.

---

# 87. Accessibility for Editors

Template editors must provide:

- labels
- keyboard shortcuts where documented
- preview alternative
- error messaging
- focus management
- accessible publish/save actions

Do not make visual drag-and-drop the only interaction.

---

# 88. API Documentation Frontend

API docs should provide:

- endpoint
- method
- URL
- authentication
- request headers
- request body
- response
- errors
- examples
- rate limits
- request ID behavior

Provide copy buttons for code examples.

---

# 89. Code Example Security

Examples must use placeholders:

```text
YOUR_API_KEY
YOUR_PROJECT_ID
YOUR_TEMPLATE_ID
```

Never include real credentials.

---

# 90. Notification Polling

If real-time transport is not implemented, controlled polling may be used.

Polling must:

- have a sensible interval
- stop when page is hidden where appropriate
- avoid duplicate requests
- handle failures gracefully

WebSockets are not required by the locked architecture.

---

# 91. Health Status UI

Health indicators may show:

- API status
- provider connection status
- webhook health
- service availability

Status labels should not imply guarantees beyond backend health information.

---

# 92. Theme Support

If dark mode is implemented:

- use design-system tokens
- ensure contrast
- test all states
- preserve logos correctly
- avoid hard-coded colors

Theme preference may be stored as a non-sensitive UI preference.

---

# 93. Fonts

Primary UI:

**Inter**

Code/API:

**JetBrains Mono**

Font loading must:

- use optimized files
- preload only critical fonts
- provide fallback stacks
- avoid blocking rendering unnecessarily

---

# 94. Icons

Primary icon library:

**Lucide**

Rules:

- consistent size
- consistent stroke weight
- accessible labels
- no decorative icon without purpose
- icon-only buttons require accessible names

Provider logos use official/approved brand assets.

---

# 95. Clipboard and Sensitive Values

When copying an API key:

- provide explicit copy action
- do not automatically copy secrets without user action
- show confirmation
- avoid placing secrets in analytics/events

---

# 96. Browser DevTools Security

Production build should avoid verbose diagnostics.

Remove or disable:

- debug logs
- secret dumps
- API response dumps
- provider credential diagnostics
- stack traces

---

# 97. Frontend Testing

Minimum testing categories:

### Unit

- validation
- API error normalization
- state transitions
- formatting utilities

### Integration

- API client
- authentication flow
- project switching
- provider UI
- template flow
- webhook UI

### Browser/E2E

- registration
- login
- verification
- project creation
- provider connection flow
- template creation
- test email
- API key creation
- webhook setup
- logs
- admin access

---

# 98. Accessibility Testing

Test:

- keyboard-only navigation
- screen reader labels
- focus states
- contrast
- zoom to 200%
- mobile viewport
- reduced motion

Use automated accessibility testing where practical.

---

# 99. Performance Testing

Measure:

- first render
- largest contentful paint
- cumulative layout stability
- interaction responsiveness
- JavaScript bundle size
- image size
- API request count

Avoid optimizing based on assumptions; measure production-like pages.

---

# 100. Security Testing

Frontend security testing must include:

- XSS attempts
- unsafe URL input
- malformed API responses
- unauthorized route access
- stale project context
- token leakage checks
- secret exposure checks
- CSP compatibility
- CSRF behavior
- rate-limit UI behavior
- error-message leakage

---

# 101. Error Boundary Strategy

Every major page/module must fail gracefully.

A page-level failure should show:

```text
This section could not be loaded.

[Retry]
```

Do not allow one widget failure to break the entire application.

---

# 102. Offline/Network Failure

If the network is unavailable:

```text
Connection lost.
Please check your network and retry.
```

Do not falsely report an email as sent because the request failed locally.

---

# 103. Duplicate Actions

Disable or guard repeated actions for operations such as:

- send email
- send OTP
- publish template
- create API key
- connect provider
- delete resource

Backend idempotency/rate limits remain authoritative.

---

# 104. Destructive Actions

Confirmation should clearly state:

- what will be deleted/revoked
- whether recovery is possible
- affected project/resource
- consequences

Example:

```text
Revoke API key?

This key will stop working immediately.

[Cancel] [Revoke Key]
```

---

# 105. Data Refresh

Use explicit refresh controls for logs and dashboards where useful.

Avoid aggressive automatic refreshing that creates:

- excessive API traffic
- flickering
- race conditions
- confusing UI

---

# 106. Time and Date Formatting

Backend timestamps should be parsed consistently.

UI should clearly distinguish:

- relative time
- absolute time
- timezone

Example:

```text
2 minutes ago
Oct 5, 2026, 11:42 UTC
```

Do not silently reinterpret timestamps.

---

# 107. Number Formatting

Usage metrics should use consistent formatting:

```text
1,250
98.4%
2.3K
```

Do not change units unpredictably between screens.

---

# 108. Accessibility of Charts

Charts must provide an accessible textual summary.

Example:

```text
Email sends increased 18% compared with the previous 7-day period.
```

Charts must not be the only source of important information.

---

# 109. Frontend API Documentation Contract

Frontend developers must follow:

- endpoint paths from API specification
- request schema
- response schema
- error codes
- authentication rules
- pagination contract
- rate-limit headers
- idempotency rules

Do not invent endpoints inside frontend code.

---

# 110. Environment Configuration

Frontend configuration may contain public values such as:

- API base URL
- public application name
- public asset URL
- public environment label

Never expose:

- database credentials
- SMTP passwords
- OAuth client secrets
- private API keys
- webhook signing secrets

---

# 111. Production Build

Production build should:

- minify CSS/JS
- remove debug output
- optimize assets
- enable caching
- use HTTPS
- use production API endpoints
- disable development-only diagnostics
- verify CSP
- verify source maps policy

---

# 112. Deployment Cache Strategy

Static assets should use versioned filenames or cache-busting.

Example:

```text
app.2026.10.05.js
app.2026.10.05.css
```

or equivalent content hashing.

HTML should not become permanently stale when assets change.

---

# 113. Frontend Error Monitoring

If an error-monitoring service is used:

- do not send secrets
- scrub authorization headers
- scrub passwords
- scrub email content where required
- respect privacy policy
- include request IDs where safe

Third-party monitoring is optional and must not alter the core architecture.

---

# 114. Internationalization Readiness

The initial UI may use one language, but components should avoid hard-coding text in ways that make future localization impossible.

Prefer:

```js
t("template.saved")
```

if an i18n layer is introduced.

Do not introduce a full i18n framework unless needed.

---

# 115. Content Standards

UI copy should be:

- clear
- concise
- professional
- action-oriented
- consistent

Avoid technical jargon in user-facing error messages unless the target user is a developer.

---

# 116. Developer Documentation UI

Developer-facing screens may use:

- code blocks
- monospace font
- copy buttons
- HTTP method badges
- request/response examples
- endpoint grouping

Ensure code blocks remain readable on mobile.

---

# 117. Mobile API Documentation

On mobile:

- code blocks scroll horizontally
- endpoint details stack vertically
- copy actions remain accessible
- tables become cards or horizontal scroll containers

Never shrink code to unreadable text.

---

# 118. Frontend Component Inventory

Core reusable components:

- AppShell
- Header
- Sidebar
- Breadcrumbs
- PageHeader
- Button
- IconButton
- Card
- Badge
- Alert
- Toast
- Modal
- Drawer
- Dropdown
- Tabs
- FormField
- Input
- Select
- Textarea
- PasswordInput
- OTPInput
- SearchInput
- DataTable
- Pagination
- EmptyState
- LoadingSkeleton
- ErrorState
- ConfirmationDialog
- CodeBlock
- CopyButton
- ProviderCard
- StatusIndicator
- LogDetails
- MetricCard
- ChartContainer

---

# 119. Component Rules

Components must:

- have one clear responsibility
- avoid hidden global side effects
- expose predictable inputs
- handle loading/error states where appropriate
- be keyboard accessible
- reuse design tokens
- avoid duplicating business logic

---

# 120. Naming Conventions

HTML:

```text
kebab-case
```

CSS:

```text
component-name
component-name__element
component-name--modifier
```

JavaScript:

```text
camelCase
```

Classes:

```text
PascalCase
```

Constants:

```text
UPPER_SNAKE_CASE
```

---

# 121. Comments

Comments should explain **why**, not obvious syntax.

Good:

```js
// Cancel stale project requests so Project A cannot overwrite Project B.
```

Bad:

```js
// Set loading to true.
isLoading = true;
```

---

# 122. Frontend Code Quality Rules

- no duplicated API configuration
- no duplicated error handling
- no secrets in source
- no secrets in comments
- no arbitrary global variables
- no unsafe HTML injection
- no unbounded polling
- no giant page scripts
- no dead code
- no silent API failures
- no fake authorization
- no direct database assumptions

---

# 123. Frontend Security Rules

1. HTTPS only in production.
2. Never store passwords in browser storage.
3. Never store private API keys in browser storage.
4. Never expose OAuth secrets.
5. Never expose SMTP credentials.
6. Never expose webhook secrets.
7. Never trust client-side authorization.
8. Never treat CORS as authentication.
9. Never trust user HTML.
10. Avoid unsafe `innerHTML`.
11. Never put secrets in URLs.
12. Never log authorization headers.
13. Use CSRF protection for browser session mutations.
14. Use server validation for every mutation.
15. Mask sensitive provider values.
16. Protect template previews.
17. Handle stale project context safely.
18. Do not expose internal server errors.
19. Use secure external-link handling.
20. Do not send secrets to analytics.

---

# 124. Performance Rules

1. Minimize JavaScript.
2. Defer non-critical scripts.
3. Optimize images.
4. Use SVG for icons.
5. Use server-side pagination.
6. Debounce search.
7. Cancel stale requests.
8. Avoid unnecessary polling.
9. Cache safe static assets.
10. Avoid excessive DOM updates.
11. Lazy-load non-critical content.
12. Measure before optimizing.

---

# 125. Accessibility Rules

1. Semantic HTML.
2. Visible focus.
3. Keyboard access.
4. Accessible labels.
5. Proper form errors.
6. No color-only status.
7. Reduced motion.
8. Accessible dialogs.
9. Accessible tables.
10. Accessible charts.
11. Responsive text.
12. Adequate touch targets.

---

# 126. Definition of Done — Frontend

A frontend feature is complete only when:

- [ ] UI is implemented
- [ ] API contract is correct
- [ ] loading state exists
- [ ] empty state exists where relevant
- [ ] error state exists
- [ ] success feedback exists
- [ ] mobile behavior is tested
- [ ] keyboard behavior is tested
- [ ] accessibility labels exist
- [ ] no secrets are exposed
- [ ] validation is implemented
- [ ] server validation is respected
- [ ] project isolation is respected
- [ ] request race conditions are handled
- [ ] destructive actions are confirmed
- [ ] API errors are normalized
- [ ] request IDs are preserved where useful
- [ ] performance is acceptable
- [ ] production logging is safe
- [ ] code is maintainable
- [ ] tests are added where appropriate

---

# 127. Final Frontend Architecture Diagram

```text
                    BROWSER
                       |
        +--------------+--------------+
        |                             |
     HTML/CSS                      JavaScript
        |                             |
        |                  +----------+----------+
        |                  |                     |
        |               UI State              API Client
        |                  |                     |
        +------------------+---------------------+
                           |
                        Fetch/HTTPS
                           |
                           v
                  PHP REST API
                           |
        +------------------+------------------+
        |                  |                  |
      Auth             Projects           Services
        |                  |                  |
        |             Authorization       Email Engine
        |                  |                  |
        +------------------+------------------+
                           |
                      Provider Layer
                           |
                +----------+----------+
                |          |          |
              Gmail      SMTP     Optional
                                     Providers
```

---

# 128. Final Lock

The frontend architecture is FINAL and LOCKED.

The following principles cannot be bypassed:

- frontend is API-driven
- backend is authoritative
- projects are the primary isolation boundary
- authentication is server-controlled
- authorization is server-controlled
- CORS is not authentication
- browser storage is not a secret vault
- private API keys remain server-side
- browser-exposed keys require restricted scopes
- OAuth secrets remain server-side
- SMTP credentials remain encrypted and server-controlled
- webhook secrets remain protected
- template previews are isolated
- user HTML is untrusted
- server validation is mandatory
- CSRF applies to browser session mutations
- API contracts must match the REST specification
- logs must not expose secrets
- responsive behavior is required
- accessibility is required
- loading/empty/error states are required
- project context changes must prevent stale data races
- production debug output must be disabled
- destructive actions require confirmation
- frontend must not introduce a new architectural layer that conflicts with the locked backend design

**This document is the authoritative frontend implementation guide for the Email API Platform.**

**Status: FINAL / LOCKED**
