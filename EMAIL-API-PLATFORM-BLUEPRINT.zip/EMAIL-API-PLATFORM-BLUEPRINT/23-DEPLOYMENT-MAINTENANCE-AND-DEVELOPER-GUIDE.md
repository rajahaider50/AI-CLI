# 23 — Deployment, Maintenance & Developer Guide

**Project:** EMAIL API PLATFORM  
**Document:** 23 of 25  
**Status:** FINAL / LOCKED  
**Purpose:** Production deployment, environment management, maintenance, operations, troubleshooting, developer onboarding, upgrades, backup/recovery, monitoring, and operational governance.

---

## 1. Document Purpose

This document defines the operational and developer procedures required to build, deploy, operate, maintain, troubleshoot, upgrade, and safely extend the Email API Platform.

It converts the locked architecture into an executable engineering and operations guide.

This document does **not** change the architecture defined by the master blueprint. All decisions here are implementation and operational guidance for the existing architecture.

---

## 2. Architecture Lock

The platform remains a **PHP modular monolith** with:

- HTML/CSS/JavaScript frontend
- PHP 8.3+ backend
- REST/JSON API
- MySQL 8+
- PDO
- PHPMailer
- Gmail OAuth 2.0
- Custom SMTP
- Optional provider adapters
- Apache or Nginx
- PHP-FPM
- HTTPS
- Cron-based operational jobs
- Project-based isolation
- API-key authentication for API access
- Session authentication for the web panel

The platform must not be converted into microservices, mandatory Redis infrastructure, mandatory message queues, or Kubernetes merely because of this document.

---

## 3. Deployment Philosophy

Production deployment must be:

1. Repeatable
2. Documented
3. Reversible
4. Observable
5. Secure
6. Environment-aware
7. Migration-safe
8. Backup-aware
9. Minimal-privilege
10. Tested before release

No production deployment should depend on undocumented manual changes.

---

## 4. Supported Environments

### 4.1 Local Development

Purpose:

- Feature development
- Unit tests
- Integration tests
- UI development
- Provider sandbox/testing
- Database migration development

Recommended:

```text
PHP 8.3+
MySQL 8+
Composer
Git
Apache/Nginx or PHP development server
```

Debugging may be enabled locally.

Production credentials must never be used in local development.

### 4.2 Staging

Purpose:

- Release candidate validation
- Integration testing
- OAuth testing
- SMTP testing
- E2E testing
- Performance checks
- Migration validation
- Security regression testing

Staging should resemble production as closely as practical.

### 4.3 Production

Production must use:

- HTTPS
- PHP-FPM
- MySQL
- Production environment configuration
- Debug disabled
- Secure cookies
- Security headers
- Restricted filesystem permissions
- Real monitoring
- Backups
- Audit logging
- Provider credentials stored securely
- Controlled deployment access

---

## 5. Server Requirements

### Minimum baseline

- Linux server
- Apache 2.4+ or Nginx
- PHP 8.3+
- PHP-FPM where applicable
- MySQL 8+
- Composer
- OpenSSL
- Cron
- HTTPS certificate
- DNS configuration

### Required PHP capabilities

At minimum, verify the extensions required by the application and dependencies, including commonly required components such as:

- PDO
- PDO MySQL
- OpenSSL
- Mbstring
- JSON
- cURL
- Fileinfo
- Filter
- XML where required by dependencies

The exact extension set must be generated from Composer dependencies and application requirements rather than copied blindly between servers.

---

## 6. Recommended Production Layout

A production host should separate public and private application areas.

Example:

```text
/var/www/email-api/
├── app/
├── bootstrap/
├── config/
├── database/
├── resources/
├── routes/
├── storage/
├── vendor/
├── .env
└── public/
    ├── index.php
    ├── assets/
    └── favicon.ico
```

Only `public/` should be web-accessible.

The following must never be directly web-accessible:

- `.env`
- `config/`
- application source
- database migration files when sensitive
- private storage
- logs
- OAuth token files
- SMTP credentials
- backups
- Composer metadata where inappropriate

---

## 7. Domain and HTTPS

Recommended production routing:

```text
https://app.example.com
https://api.example.com
```

The implementation may use one domain with path-based routing if desired, but the public contract must remain consistent.

HTTPS is mandatory for:

- Login
- Registration
- Sessions
- API requests
- Gmail OAuth callbacks
- Provider credentials
- Webhooks
- Admin panel
- API key operations

HTTP should redirect to HTTPS or be rejected according to deployment policy.

---

## 8. DNS and TLS Checklist

Before production:

- DNS records resolve correctly
- Certificate is valid
- Certificate chain is valid
- HTTP redirects to HTTPS where appropriate
- TLS configuration is current
- Renewal process is working
- OAuth redirect URI exactly matches the registered URI
- Webhook URLs use HTTPS
- API URLs use HTTPS

Never disable TLS verification in production.

---

## 9. Environment Configuration

Use environment-specific configuration.

Example:

```env
APP_ENV=production
APP_DEBUG=false
APP_URL=https://app.example.com

DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=email_api
DB_USERNAME=email_api
DB_PASSWORD=CHANGE_ME

SESSION_SECURE=true
SESSION_HTTP_ONLY=true

MAIL_TIMEOUT=15

LOG_LEVEL=warning
```

Actual variable names must follow the application's configuration implementation.

### Rules

- Never commit production secrets.
- Never place secrets in JavaScript.
- Never expose `.env`.
- Never log environment secrets.
- Use different credentials per environment.
- Rotate compromised credentials immediately.

---

## 10. Secrets Management

Secrets include:

- Database passwords
- Encryption keys
- OAuth client secrets
- OAuth refresh/access tokens
- SMTP credentials
- API signing secrets
- Webhook secrets
- Session/encryption secrets
- Administrative credentials

Secrets that must be recoverable by the application must be encrypted at rest according to the security architecture.

API key secrets are not recoverable and must be stored as hashes.

Webhook signing secrets must be protected and never logged.

---

## 11. First-Time Deployment

Recommended sequence:

```text
1. Provision server
2. Configure DNS
3. Install PHP
4. Install MySQL
5. Install Composer
6. Configure web server
7. Deploy source
8. Install Composer dependencies
9. Create environment configuration
10. Create database
11. Run migrations
12. Create initial admin account securely
13. Set filesystem permissions
14. Configure HTTPS
15. Configure cron
16. Configure monitoring
17. Run production smoke tests
18. Enable production traffic
```

Do not expose the application publicly before security configuration is complete.

---

## 12. Composer Deployment

Use:

```bash
composer install --no-dev --prefer-dist --optimize-autoloader
```

The exact deployment command must match the application's lock file and release process.

Production must deploy from a committed `composer.lock`.

Do not run uncontrolled dependency upgrades directly on production.

---

## 13. Database Initialization

Create a dedicated database user with only required permissions.

Recommended principle:

```text
Application user
    ↓
Only required database/schema permissions
```

Avoid using the MySQL root account from the application.

Initial deployment must:

- Create schema
- Create indexes
- Create constraints
- Seed only safe required system data
- Create system configuration
- Create the first administrator through a secure procedure

---

## 14. Database Migrations

Every schema change must be represented by a migration.

A migration must be:

- Versioned
- Reviewable
- Tested
- Ordered
- Reproducible
- Safe to run once

Before a production migration:

1. Back up the database.
2. Test migration on staging.
3. Confirm rollback/recovery strategy.
4. Check table size and lock impact.
5. Schedule high-impact changes appropriately.
6. Run migration.
7. Verify schema.
8. Run smoke tests.

Never manually alter production schema without documenting the change.

---

## 15. Zero-Downtime Compatibility

When practical, use expand-and-contract migrations.

Example:

```text
Release A
    ↓
Add new nullable column
    ↓
Deploy compatible application
    ↓
Backfill data
    ↓
Switch application behavior
    ↓
Remove obsolete column in later release
```

Avoid deploying code that requires a schema change before the schema can support both old and new application versions.

---

## 16. File Permissions

Production permissions must follow least privilege.

Recommended principle:

```text
Web server:
    read application code
    write only required runtime directories

Application:
    write only required storage/log/temp areas

Secrets:
    restricted to the application/service account

Backups:
    inaccessible from the public web root
```

Do not use broad permissions such as `777`.

---

## 17. Web Server Configuration

The web server must:

- Point document root to `public/`
- Block access to private files
- Forward PHP requests to PHP-FPM where applicable
- Enable HTTPS
- Apply appropriate security headers
- Limit unsafe HTTP methods where appropriate
- Prevent directory listing
- Restrict oversized requests
- Return controlled errors
- Preserve request IDs where supported

---

## 18. PHP Production Configuration

Production should generally use:

```ini
display_errors = Off
log_errors = On
expose_php = Off
```

Additional PHP settings must be reviewed according to the application.

Do not hide errors by disabling logging.

Errors should be logged securely without exposing sensitive data.

---

## 19. PHP-FPM Operations

Monitor:

- Worker count
- Queue/backlog
- Slow requests
- Memory usage
- Process restarts
- Error rates

After PHP configuration changes:

```text
Validate configuration
        ↓
Reload PHP-FPM safely
        ↓
Run health check
        ↓
Run smoke tests
```

Avoid unnecessary full restarts during active traffic.

---

## 20. Cron and Scheduled Jobs

The platform may initially use cron for operational background work.

Examples:

```text
Retry failed webhook deliveries
Process scheduled maintenance
Clean expired sessions
Clean expired OTP records
Aggregate usage statistics
Process retryable email work if enabled
Clean temporary files
Rotate/maintain operational data
Run health checks
```

Cron jobs must be:

- Idempotent
- Lock-aware
- Logged
- Time-bounded
- Failure-aware
- Safe to rerun

Cron is an operational mechanism, not a reason to change the locked architecture.

---

## 21. Cron Locking

A job must prevent accidental overlapping execution where overlap could corrupt state.

Possible strategy:

```text
Acquire lock
   ↓
Run job
   ↓
Release lock
```

If the process crashes, locks must not permanently block future runs.

Database-backed or filesystem-backed locking may be used according to deployment constraints.

---

## 22. Deployment Process

Recommended release flow:

```text
Developer
   ↓
Git commit
   ↓
Automated tests
   ↓
Static analysis
   ↓
Build/package
   ↓
Staging deployment
   ↓
Migration test
   ↓
E2E + security regression
   ↓
Release approval
   ↓
Production deployment
   ↓
Migration
   ↓
Smoke test
   ↓
Monitoring
```

Never deploy untested changes directly to production.

---

## 23. Release Identification

Every deployment should have an identifiable version.

Example:

```text
v1.4.0
```

Record:

- Version
- Git commit
- Deployment timestamp
- Database migration version
- Operator/release process
- Important configuration changes

This makes rollback and incident investigation possible.

---

## 24. Atomic or Near-Atomic Releases

Prefer a release directory strategy where practical:

```text
releases/
├── 20261006-120000/
├── 20261005-180000/
└── 20261004-140000/

current -> releases/20261006-120000
```

The exact deployment mechanism may differ, but the goal is:

- consistent application files
- quick rollback
- no half-deployed source tree

---

## 25. Maintenance Mode

Maintenance mode is required for operations that cannot safely run while traffic is active.

Possible cases:

- major database migration
- emergency maintenance
- infrastructure migration
- security incident
- provider configuration repair

Maintenance mode should return a controlled response and must not leak internal details.

API clients should receive a stable error/status contract.

---

## 26. Health Checks

At minimum, provide:

### Application health

Checks that the application can boot and respond.

### Database health

Checks database connectivity.

### Provider health

Checks configured provider availability where safe.

### Dependency health

Checks required internal services/dependencies.

Do not expose sensitive diagnostics publicly.

Example conceptual endpoint:

```text
GET /api/v1/health
```

Public health responses should remain minimal.

Detailed operational diagnostics belong to authenticated/admin monitoring.

---

## 27. Monitoring

Monitor at least:

### Application

- HTTP error rate
- 4xx rate
- 5xx rate
- Response latency
- Request volume
- Request IDs

### Email

- Send attempts
- Accepted sends
- Failures
- Provider failures
- Retry counts
- Provider latency

### OTP

- Requests
- Verification success/failure
- Expiry
- Abuse/rate-limit events

### Webhooks

- Delivery success
- Delivery failure
- Retry count
- Response latency

### Security

- Failed logins
- Suspicious activity
- Blocked IPs
- Rate-limit events
- Admin security events

### Infrastructure

- CPU
- Memory
- Disk
- Database health
- PHP-FPM health

---

## 28. Logging

Use structured application logs where practical.

Each important request should have a request ID.

Example:

```text
request_id=req_01J...
```

Logs may include:

- timestamp
- severity
- request ID
- user/project context where appropriate
- event type
- safe operational metadata
- error code

Never log:

- passwords
- API key secrets
- OAuth tokens
- SMTP passwords
- webhook secrets
- raw authorization headers
- unnecessary email content
- sensitive personal information

---

## 29. Log Retention

Retention must balance:

- Security
- Debugging
- Compliance
- Storage
- Privacy

Different log categories may have different retention periods.

Retention must be configurable where required.

Deletion jobs must be safe, observable, and auditable.

---

## 30. Backup Strategy

Back up:

- MySQL database
- Required application configuration
- Encrypted operational secrets where recovery requires them
- Required uploaded assets
- Deployment metadata

Do not back up unnecessary temporary files.

Backups must be:

- Automated
- Encrypted where appropriate
- Access-controlled
- Tested
- Retained according to policy
- Separated from the primary failure domain when practical

---

## 31. Backup Verification

A backup that has never been restored is not a proven backup.

Regularly test:

```text
Backup
  ↓
Restore to isolated environment
  ↓
Verify schema
  ↓
Verify representative records
  ↓
Run application smoke tests
  ↓
Record result
```

---

## 32. Recovery Objectives

Define operational targets:

### RPO

How much data loss is acceptable.

### RTO

How long service restoration may take.

Actual targets depend on infrastructure and operational requirements and must be documented before production launch.

---

## 33. Disaster Recovery

A disaster recovery procedure should cover:

1. Detect outage
2. Classify incident
3. Secure affected credentials
4. Provision/recover infrastructure
5. Restore database
6. Restore required application configuration
7. Deploy known-good release
8. Run migrations carefully
9. Validate authentication
10. Validate provider connections
11. Validate email sending
12. Validate webhooks
13. Validate logs
14. Re-enable traffic
15. Monitor closely
16. Document incident

---

## 34. Rollback Strategy

Rollback must be considered before deployment.

Application rollback:

```text
current
  ↓
previous known-good release
```

Database rollback should not depend on destructive reverse migrations when restoration or forward-fix is safer.

Preferred approach:

- restore compatible backup when required
- deploy forward fix where possible
- avoid destructive emergency SQL

---

## 35. Security Incident Response

If a secret may be compromised:

```text
Identify
   ↓
Contain
   ↓
Revoke
   ↓
Rotate
   ↓
Investigate
   ↓
Patch
   ↓
Validate
   ↓
Monitor
   ↓
Document
```

Examples:

- Rotate database credentials
- Revoke API keys
- Rotate webhook secrets
- Revoke OAuth tokens
- Reset affected admin sessions
- Block suspicious IPs

Do not leave known-compromised credentials active while investigating.

---

## 36. API Key Incident Procedure

If an API key leaks:

1. Identify project/key.
2. Revoke key immediately.
3. Inspect recent API logs.
4. Check send activity.
5. Check usage spikes.
6. Check suspicious destinations if available.
7. Create replacement key.
8. Update client integration.
9. Review project security.
10. Record incident/audit event.

Never reveal the old secret again.

---

## 37. Gmail OAuth Maintenance

Gmail connections must support:

- Connection status
- Token refresh
- Token encryption
- Disconnect/revoke
- Reauthorization
- Failure detection
- Safe error handling

If refresh fails:

```text
Detect failure
   ↓
Mark connection requiring reauthorization
   ↓
Do not repeatedly hammer provider
   ↓
Notify user
   ↓
Allow secure reconnect
```

OAuth credentials must never be written to logs.

---

## 38. SMTP Maintenance

For SMTP providers:

- Store credentials securely
- Test connection
- Validate host/port/security mode
- Monitor send failures
- Support credential rotation
- Provide disconnect/update controls
- Never display stored passwords

SMTP errors should be normalized into safe platform error codes.

---

## 39. Optional Provider Maintenance

Brevo, Mailtrap, and future adapters must follow the provider contract.

Adding a provider should primarily require:

```text
Provider adapter
+
Provider configuration
+
Capability mapping
+
Tests
+
Admin/user UI integration
```

The core email engine must not be rewritten for every provider.

---

## 40. Dependency Maintenance

Dependencies must be reviewed regularly.

Process:

```text
Review
  ↓
Security advisories
  ↓
Compatibility check
  ↓
Update staging
  ↓
Run full tests
  ↓
Deploy
```

Do not perform blind mass upgrades in production.

Composer lock files must remain under version control.

---

## 41. PHP Version Upgrades

Before upgrading PHP:

1. Review supported versions.
2. Review application compatibility.
3. Review Composer dependencies.
4. Run test suite.
5. Run static analysis.
6. Run staging E2E tests.
7. Validate provider integrations.
8. Validate cron jobs.
9. Validate production configuration.
10. Prepare rollback.

Do not upgrade the runtime and application architecture simultaneously unless necessary.

---

## 42. MySQL Maintenance

Monitor:

- Storage
- Connections
- Slow queries
- Index usage
- Table growth
- Locks
- Transaction duration
- Backup status

Maintenance should include:

- Backup verification
- Index review
- Query review
- Retention cleanup
- Migration review
- Capacity planning

Avoid destructive table operations during peak traffic without a tested plan.

---

## 43. Database Growth Management

High-growth tables may include:

- email_logs
- otp_logs
- api_requests
- webhook_logs
- security_logs
- admin_logs
- usage_statistics

Use:

- Appropriate indexes
- Retention policies
- Archival strategies where required
- Pagination
- Aggregated statistics
- Query limits

Never solve database growth by blindly deleting recent operational evidence.

---

## 44. Email Log Maintenance

Email logs should retain enough information to support:

- Debugging
- Status tracking
- Usage reporting
- Provider troubleshooting
- Audit requirements

Avoid storing full message bodies indefinitely unless required.

Sensitive content should be minimized.

---

## 45. Webhook Maintenance

Monitor:

- Endpoint availability
- Failure rate
- Response codes
- Retry volume
- Delivery latency
- Repeated failures

A failing webhook must not cause the underlying email send to fail.

Webhook delivery is at-least-once and consumers must handle duplicate event delivery safely.

---

## 46. Template Maintenance

Templates should support:

- Versioning
- Draft/published states
- Preview
- Rollback
- Variable validation
- Project isolation

Published templates must remain stable until explicitly changed.

Never execute arbitrary template content as PHP/server-side code.

---

## 47. Storage Maintenance

Temporary files must have lifecycle cleanup.

Examples:

- temporary attachments
- generated previews
- temporary exports
- runtime cache

Do not allow user-controlled filenames to become filesystem paths without validation.

Prevent:

- path traversal
- executable uploads
- arbitrary file writes
- public access to private files

---

## 48. Cache Maintenance

Caching may be used for:

- configuration
- provider metadata
- template reads
- static assets
- non-sensitive derived data

Do not cache secrets or user-specific authorization data without a strict invalidation model.

Cache invalidation must occur after relevant updates.

---

## 49. Performance Maintenance

Monitor:

- API latency
- database latency
- provider latency
- template rendering time
- PHP-FPM resource use
- page load metrics

Performance improvements must not weaken:

- security
- authorization
- project isolation
- logging
- correctness

---

## 50. Developer Onboarding

A new developer should follow:

```text
Read 00 Master Blueprint
        ↓
Read 01 Project Overview
        ↓
Read 03 Architecture
        ↓
Read 04 Technology Stack
        ↓
Read 08/09 Database documents
        ↓
Read 10 Backend Architecture
        ↓
Read 11 API Specification
        ↓
Read relevant feature document
        ↓
Read 19 Security
        ↓
Read 22 Testing/QA
        ↓
Read this deployment guide
        ↓
Read 24 Development Rules
```

Do not start implementation from a single feature document without understanding the architecture.

---

## 51. Local Development Setup

Recommended sequence:

```text
Clone repository
    ↓
Install Composer dependencies
    ↓
Create local environment file
    ↓
Create local database
    ↓
Run migrations
    ↓
Create development account
    ↓
Configure local mail/test provider
    ↓
Start PHP/web server
    ↓
Run tests
```

Local configuration must never contain production secrets.

---

## 52. Git Workflow

Every feature should be traceable to a commit.

Recommended branch concepts:

```text
main
feature/*
fix/*
security/*
release/*
```

Exact branching policy may vary.

Rules:

- Small focused commits
- Meaningful messages
- No secrets
- No generated vendor directory unless explicitly required
- Review before merge
- Tests before merge

---

## 53. Pull Request Checklist

Before merge:

- Architecture unchanged unless explicitly approved
- Feature requirements satisfied
- Authorization reviewed
- Project isolation reviewed
- Input validation present
- Output serialization safe
- Error handling complete
- Logs redact secrets
- Tests added/updated
- Existing tests pass
- Static analysis passes
- Accessibility considered
- Responsive behavior considered
- API compatibility reviewed
- Documentation updated

---

## 54. Code Review Priorities

Reviewers should prioritize:

1. Security
2. Authorization
3. Project isolation
4. Data integrity
5. Secret handling
6. API compatibility
7. Error handling
8. Reliability
9. Performance
10. Maintainability

A visually correct feature is not complete if its authorization model is incorrect.

---

## 55. Adding a New API Endpoint

Required process:

```text
Define contract
    ↓
Define authentication
    ↓
Define authorization
    ↓
Define validation
    ↓
Implement controller
    ↓
Implement service logic
    ↓
Implement repository access
    ↓
Define errors
    ↓
Add logging
    ↓
Add tests
    ↓
Update API documentation
```

Do not allow controllers to bypass service/policy boundaries without a deliberate architectural reason.

---

## 56. Adding a New Provider

Required:

- Provider interface compatibility
- Configuration model
- Credential protection
- Capability declaration
- Adapter implementation
- Error normalization
- Timeout handling
- Retry policy
- Health behavior
- Logging
- Security review
- Unit/integration tests
- Admin configuration
- User configuration where applicable
- Documentation

The core API contract must remain stable.

---

## 57. Adding a New Database Table

Before creating a table:

- Define ownership
- Define relationships
- Define project scope if applicable
- Define primary key
- Define foreign keys
- Define uniqueness
- Define indexes
- Define retention
- Define privacy requirements
- Define migration
- Define backup/recovery implications

Avoid creating tables that duplicate existing domain concepts.

---

## 58. Adding a New Security-Sensitive Feature

Security-sensitive features require:

- Threat model
- Authentication decision
- Authorization decision
- Input validation
- Rate limiting where appropriate
- Audit events
- Safe errors
- Secret handling review
- Abuse cases
- Tests
- Documentation

Security must be designed before implementation.

---

## 59. Troubleshooting: 500 Errors

Check:

1. Application logs
2. Request ID
3. PHP-FPM logs
4. Web server logs
5. Recent deployment
6. Configuration
7. Database connectivity
8. Dependency status

Never show stack traces to users in production.

---

## 60. Troubleshooting: Database Connection

Check:

- Host
- Port
- Database name
- Username
- Password
- MySQL availability
- Firewall
- PHP PDO driver
- Connection limits
- DNS if remote

Do not solve production connection issues by granting unrestricted database privileges.

---

## 61. Troubleshooting: Email Send Failure

Inspect:

```text
Request ID
Message ID
Project
Provider
Provider response/error code
Retry state
Timeout
Authentication state
```

Determine whether the failure occurred during:

- Validation
- Template rendering
- Provider selection
- Provider authentication
- SMTP connection
- API request
- Provider acceptance

Do not automatically retry every failure.

---

## 62. Troubleshooting: Gmail Failure

Check:

- OAuth connection status
- Token refresh status
- Redirect URI
- OAuth client configuration
- Google account authorization
- Required scopes
- Provider/API availability
- Application logs

If authorization is invalid, require secure reauthorization rather than repeated failed attempts.

---

## 63. Troubleshooting: SMTP Failure

Check:

- Host
- Port
- TLS/SSL mode
- Username
- Credential validity
- DNS
- Firewall
- SMTP server limits
- Sender restrictions

Never log SMTP passwords.

---

## 64. Troubleshooting: Webhook Failure

Check:

- Endpoint URL
- HTTPS certificate
- DNS
- SSRF policy result
- Timeout
- Response code
- Retry count
- Signature verification
- Endpoint availability

Webhook failure must remain isolated from email delivery.

---

## 65. Troubleshooting: Login Problems

Check:

- Account status
- Email verification state
- Password validity
- Rate limiting
- Login attempt records
- Session configuration
- CSRF token for browser mutations
- Cookies/HTTPS

Do not reveal whether a sensitive account exists when an enumeration-safe response is required.

---

## 66. Troubleshooting: OTP Problems

Check:

- OTP generation
- Expiry
- Attempt count
- Resend throttling
- Delivery status
- User/project context
- Clock/time configuration

Never log the plaintext OTP.

---

## 67. Troubleshooting: Slow API

Investigate in order:

```text
Request
  ↓
PHP execution
  ↓
Database
  ↓
Template rendering
  ↓
Provider operation
  ↓
External network
```

Use request IDs and timing metrics to identify the slow layer.

---

## 68. Maintenance Windows

For planned maintenance:

- Announce expected impact
- Back up
- Confirm rollback
- Enable maintenance mode if needed
- Perform change
- Validate
- Monitor
- Close maintenance
- Document result

Do not leave maintenance mode enabled accidentally.

---

## 69. Routine Maintenance Checklist

### Daily/automated

- Application health
- Error rates
- Email failure rates
- Webhook failures
- Security events
- Disk usage
- Database health
- Backup status

### Weekly

- Review security events
- Review failed provider operations
- Review unusual usage
- Review dependency advisories
- Review storage growth

### Monthly

- Restore-test a backup
- Review accounts/admin access
- Review API key activity
- Review provider connections
- Review retention
- Review performance
- Review operational documentation

Exact cadence may be adjusted to operational risk.

---

## 70. Capacity Planning

Track:

- Users
- Projects
- API requests
- Emails
- OTP requests
- Webhook deliveries
- Database size
- Storage
- CPU
- Memory
- Provider quotas

Scale based on measured bottlenecks.

Do not introduce new infrastructure simply because it is fashionable.

---

## 71. Scaling Path

The architecture should scale in stages:

```text
Stage 1
Single application + MySQL

Stage 2
Better PHP-FPM capacity + DB tuning

Stage 3
Separate database resources/replicas where justified

Stage 4
Dedicated worker/queue infrastructure if measured need exists

Stage 5
Additional application instances/load balancing
```

The modular monolith remains the core architecture unless an explicit future architecture decision changes it.

---

## 72. Operational Safety Rules

Never:

- Disable authentication to fix an operational issue
- Disable authorization to simplify debugging
- Print secrets for troubleshooting
- Enable production debug output
- Run destructive SQL without backup
- Use root DB credentials in application code
- Bypass project isolation
- Disable TLS verification
- Accept arbitrary webhook URLs without SSRF protection
- Deploy without rollback planning

---

## 73. Developer Debugging Rules

Local debugging may use detailed errors.

Production debugging must use:

```text
Request ID
+
Structured logs
+
Safe diagnostic metadata
+
Admin-only operational information
```

Never ask users to paste:

- passwords
- API key secrets
- OAuth tokens
- SMTP passwords
- webhook secrets

---

## 74. Production Smoke Test

After deployment:

### Application

- Home loads
- Login works
- Registration works
- Verification works
- Dashboard works

### API

- Authentication works
- API key works
- Project authorization works
- Send endpoint works
- Error contract works

### Email

- Gmail test
- SMTP test
- Template send
- Test email

### Security

- HTTPS
- Secure cookies
- CSRF
- CORS
- Rate limits
- Admin access

### Operations

- Logs
- Health endpoint
- Cron
- Backup
- Monitoring

---

## 75. Release Acceptance Gate

A release is production-ready only when:

- Tests pass
- Security checks pass
- Migration is validated
- Backup exists
- Rollback plan exists
- Configuration is verified
- Provider integrations are tested
- Smoke tests pass
- Monitoring is ready
- Documentation is updated

---

## 76. Documentation Maintenance

Documentation must be updated when:

- Architecture changes
- API contracts change
- Database schema changes
- Security controls change
- Deployment requirements change
- Provider behavior changes
- New operational procedures are introduced

Do not allow implementation to silently diverge from the blueprint.

---

## 77. Change Management

Every significant change should identify:

```text
What changed?
Why?
Which documents are affected?
Which APIs are affected?
Which database objects are affected?
Which security controls are affected?
How was it tested?
How is it deployed?
How is it rolled back?
```

---

## 78. Final Developer Rules

1. Follow the locked architecture.
2. Keep projects isolated.
3. Enforce authorization server-side.
4. Never trust frontend checks.
5. Never expose private API keys.
6. Hash API key secrets.
7. Encrypt recoverable provider credentials.
8. Protect webhook secrets.
9. Validate all input.
10. Serialize output intentionally.
11. Use prepared SQL.
12. Protect browser mutations with CSRF.
13. Treat CORS as a browser policy, not authentication.
14. Use HTTPS.
15. Rate-limit sensitive operations.
16. Never log secrets.
17. Never expose production stack traces.
18. Keep provider logic behind adapters.
19. Keep email logic centralized.
20. Keep webhooks isolated from email success.
21. Make retries bounded and safe.
22. Make background jobs idempotent.
23. Version database changes.
24. Test migrations.
25. Back up before risky operations.
26. Test restores.
27. Keep Composer lock files.
28. Test before deployment.
29. Review security before release.
30. Preserve API compatibility.
31. Keep public files under `public/`.
32. Avoid broad filesystem permissions.
33. Keep production debug disabled.
34. Monitor failures and unusual activity.
35. Document operational changes.
36. Prefer measured scaling.
37. Avoid unnecessary infrastructure complexity.
38. Keep code modular and maintainable.
39. Never bypass security architecture for convenience.
40. Update the blueprint when an approved architecture decision changes.

---

## 79. Final Deployment Checklist

```text
[ ] DNS configured
[ ] HTTPS active
[ ] Public root points to public/
[ ] PHP version verified
[ ] Required PHP extensions verified
[ ] Composer dependencies installed
[ ] composer.lock deployed
[ ] Production environment configured
[ ] Debug disabled
[ ] Database created
[ ] Database user restricted
[ ] Migrations tested
[ ] Migrations applied
[ ] Filesystem permissions reviewed
[ ] Cron configured
[ ] Cron locking verified
[ ] Health checks verified
[ ] Monitoring configured
[ ] Logging configured
[ ] Secrets protected
[ ] Backups configured
[ ] Restore procedure tested
[ ] OAuth configuration verified
[ ] SMTP configuration verified
[ ] Webhook security verified
[ ] API rate limits verified
[ ] Admin security verified
[ ] Production smoke tests passed
[ ] Rollback plan confirmed
```

---

## 80. Final Definition of Done

The deployment and operational implementation is complete when:

- A clean production server can be provisioned repeatably.
- Application files are separated from the public web root.
- Production secrets are protected.
- Database migrations are versioned and tested.
- Backups are automated and restore-tested.
- HTTPS is enforced.
- PHP and web-server configuration is hardened.
- Cron jobs are safe and observable.
- Monitoring covers application, email, webhook, security, and infrastructure health.
- Deployment versions are traceable.
- Rollback is possible.
- Incident response procedures are documented.
- Developers can onboard without architectural guesswork.
- New providers can be added through the adapter model.
- New API features follow the established authorization, validation, logging, and testing flow.
- Operational maintenance cannot bypass the security architecture.
- Production smoke tests pass.
- Documentation matches the implemented system.

---

## 81. Final Architecture Relationship

This document is operational guidance for:

```text
00 Master Blueprint
        ↓
01 Project Overview
        ↓
03 System Architecture
        ↓
04 Technology Stack
        ↓
08 Database Architecture
09 Database Schema
        ↓
10 Backend PHP Architecture
        ↓
11 REST API Specification
        ↓
12 Authentication & OTP
13 Email Engine
14 Email Providers
15 Template Engine
16 Projects/API Keys/Webhooks
17 User Panel
18 Admin Panel
19 Security Architecture
20 Frontend Development Guide
21 Responsive/Accessibility/Performance
22 Testing/QA/Error Handling
        ↓
23 Deployment/Maintenance/Developer Guide
        ↓
24 Development Rules Checklist
```

All implementation and operations must remain consistent with the complete 25-document blueprint.

---

# FINAL LOCK

**23-DEPLOYMENT-MAINTENANCE-AND-DEVELOPER-GUIDE.md is FINAL / LOCKED.**

The document establishes:

- Production deployment procedures
- Environment separation
- Server configuration
- HTTPS/TLS requirements
- PHP-FPM operations
- Composer deployment
- Database migrations
- File permissions
- Cron operations
- Health checks
- Monitoring
- Logging
- Backups and restore testing
- Disaster recovery
- Rollback
- Security incident response
- Provider maintenance
- Dependency maintenance
- Developer onboarding
- Git/code review workflow
- Feature/provider/database extension procedures
- Troubleshooting
- Routine maintenance
- Capacity planning
- Scaling guidance
- Production smoke testing
- Release acceptance
- Documentation/change management
- 40 non-negotiable developer/operations rules
- Final deployment checklist
- Definition of Done

**No component may bypass the locked security, authorization, project-isolation, provider-adapter, API, database, testing, or operational architecture.**

**Next document:** `24-DEVELOPMENT-RULES-CHECKLIST.md`
