# 06 — SCREENS AND NAVIGATION

**Project:** Email API Platform  
**Document:** 06-SCREENS-AND-NAVIGATION.md  
**Status:** FINAL / LOCKED  
**Document Set:** 6 of 25  
**Coverage:** 93 screens, navigation hierarchy, route conventions, screen responsibilities, access rules, and primary user flows.

---

## 1. Purpose

This document is the authoritative screen inventory and navigation specification for the Email API Platform.

It converts the locked product scope into an implementable information architecture. It defines:

- All 93 screens and their purpose
- Public, authentication, user, admin, and system areas
- Navigation hierarchy
- Route and URL conventions
- Page-level actions
- Screen relationships and transitions
- Role and permission boundaries
- Responsive navigation behavior
- Shared screen states and implementation rules

The inventory is locked at **93 screens**. Do not add, remove, rename, or merge screens casually. Any genuine scope change must be documented and approved before implementation.

---

# 2. Navigation Principles

## 2.1 Task-oriented navigation

Navigation must help users reach a task quickly. Group related functions together and avoid exposing backend module names as navigation labels.

## 2.2 Consistent location

Every authenticated screen must make the following clear:

- Current product area
- Current project context, when relevant
- Current page
- Available page-level actions

## 2.3 Project context

Project-scoped screens must make the active project visible. Project-specific actions and data must not silently operate on another project.

## 2.4 Role separation

Public, user, and admin navigation are distinct access areas. Hiding a link is not authorization; the backend must enforce permissions for every protected route and API operation.

## 2.5 Responsive behavior

- Desktop: persistent or collapsible sidebar for authenticated areas.
- Tablet: compact sidebar or off-canvas navigation.
- Mobile: drawer navigation with a clear close action and visible current-page state.
- Public pages: responsive top navigation.
- Auth pages: focused layout with minimal navigation.

---

# 3. Screen Inventory Summary

| Area | Screen range | Count |
|---|---:|---:|
| Public | 1–10 | 10 |
| Authentication | 11–17 | 7 |
| User panel | 18–50 | 33 |
| Admin panel | 51–87 | 37 |
| System | 88–93 | 6 |
| **Total** | **1–93** | **93** |

The counts above are fixed and must remain consistent with the master blueprint.

---

# 4. Global Navigation Architecture

## 4.1 Public navigation

Primary navigation:

- Home
- Features
- How It Works
- Providers
- API Documentation
- Pricing
- FAQ
- Contact

Account actions:

- Login
- Register

Legal pages are linked from the footer:

- Privacy Policy
- Terms & Conditions

## 4.2 User navigation

Recommended sidebar groups:

**Overview**
- Dashboard

**Workspace**
- Projects
- Email Services
- Email Templates
- Email Send

**Developer**
- API Integration
- API Keys
- API Documentation
- Webhooks

**Activity**
- Email Logs
- OTP Logs
- Usage & Statistics
- Notifications

**Account**
- Profile Settings
- Security Settings
- Active Sessions

The sidebar may use collapsible groups, but the labels and destination screens must remain recognizable.

## 4.3 Admin navigation

Recommended admin sidebar groups:

**Overview**
- Admin Dashboard

**Accounts and Workspaces**
- Users
- Projects

**Email Infrastructure**
- Email Providers
- Gmail Connections
- SMTP Connections
- Brevo Connections
- Mailtrap Connections
- Templates

**Monitoring**
- Email Logs
- OTP Logs
- API Logs
- Webhook Logs
- API Usage
- Analytics
- System Statistics

**Security**
- Security Dashboard
- Blocked IPs
- Rate Limits
- Login Attempts
- Security/Audit Logs

**Configuration**
- System Settings
- Email Settings
- OTP Settings
- API Settings
- General Settings

**Administration**
- Admin Accounts
- Admin Profile
- Admin Security

Admin navigation must only be rendered for authorized admin accounts.

---

# 5. URL and Route Conventions

Use predictable, lowercase, hyphenated paths. Routes below are recommended canonical paths; implementation may add a consistent application prefix without changing their meaning.

## 5.1 Public routes

| Screen | Recommended route |
|---|---|
| Home | `/` |
| Features | `/features` |
| How It Works | `/how-it-works` |
| Providers | `/providers` |
| API Documentation | `/docs` |
| Pricing | `/pricing` |
| FAQ | `/faq` |
| Contact | `/contact` |
| Privacy Policy | `/privacy` |
| Terms & Conditions | `/terms` |

## 5.2 Authentication routes

| Screen | Recommended route |
|---|---|
| Login | `/login` |
| Register | `/register` |
| Email Verification | `/verify-email` |
| OTP Verification | `/verify-otp` |
| Forgot Password | `/forgot-password` |
| Reset Password | `/reset-password` |
| Account Recovery | `/account-recovery` |

Verification and reset routes must use short-lived, purpose-bound server-issued tokens or codes. Do not put secrets into analytics events or application logs.

## 5.3 User routes

| Screen | Recommended route |
|---|---|
| User Dashboard | `/app/dashboard` |
| Projects | `/app/projects` |
| Create Project | `/app/projects/new` |
| Project Overview | `/app/projects/{project_id}` |
| Project Settings | `/app/projects/{project_id}/settings` |
| Email Services | `/app/projects/{project_id}/email-services` |
| Add Gmail | `/app/projects/{project_id}/providers/gmail/connect` |
| Gmail Connection Success | `/app/projects/{project_id}/providers/gmail/success` |
| Add SMTP | `/app/projects/{project_id}/providers/smtp/new` |
| SMTP Connection Test | `/app/projects/{project_id}/providers/smtp/test` |
| Provider Management | `/app/projects/{project_id}/providers` |
| Email Templates | `/app/projects/{project_id}/templates` |
| Create Template | `/app/projects/{project_id}/templates/new` |
| Template Editor | `/app/projects/{project_id}/templates/{template_id}/edit` |
| Template Preview | `/app/projects/{project_id}/templates/{template_id}/preview` |
| Template Variables | `/app/projects/{project_id}/templates/{template_id}/variables` |
| Email Send | `/app/projects/{project_id}/send` |
| Test Email | `/app/projects/{project_id}/send/test` |
| API Integration | `/app/projects/{project_id}/integration` |
| API Keys | `/app/projects/{project_id}/api-keys` |
| API Key Create | `/app/projects/{project_id}/api-keys/new` |
| API Documentation | `/app/docs` |
| Email Logs | `/app/projects/{project_id}/logs/email` |
| Email Log Details | `/app/projects/{project_id}/logs/email/{log_id}` |
| OTP Logs | `/app/projects/{project_id}/logs/otp` |
| Usage & Statistics | `/app/projects/{project_id}/usage` |
| Webhooks | `/app/projects/{project_id}/webhooks` |
| Webhook Settings | `/app/projects/{project_id}/webhooks/{webhook_id}/settings` |
| Notifications | `/app/notifications` |
| Profile Settings | `/app/settings/profile` |
| Security Settings | `/app/settings/security` |
| Password Change | `/app/settings/password` |
| Active Sessions | `/app/settings/sessions` |

The active project identifier must be validated against the authenticated user's project membership on every request.

## 5.4 Admin routes

| Screen | Recommended route |
|---|---|
| Admin Dashboard | `/admin` |
| Users | `/admin/users` |
| User Details | `/admin/users/{user_id}` |
| Add User | `/admin/users/new` |
| Edit User | `/admin/users/{user_id}/edit` |
| Projects | `/admin/projects` |
| Project Details | `/admin/projects/{project_id}` |
| Project Management | `/admin/projects/{project_id}/manage` |
| Email Providers | `/admin/providers` |
| Gmail Connections | `/admin/providers/gmail` |
| SMTP Connections | `/admin/providers/smtp` |
| Brevo Connections | `/admin/providers/brevo` |
| Mailtrap Connections | `/admin/providers/mailtrap` |
| Email Logs | `/admin/logs/email` |
| Email Log Details | `/admin/logs/email/{log_id}` |
| OTP Logs | `/admin/logs/otp` |
| API Logs | `/admin/logs/api` |
| Webhook Logs | `/admin/logs/webhooks` |
| Templates | `/admin/templates` |
| Template Details | `/admin/templates/{template_id}` |
| API Keys | `/admin/api-keys` |
| API Usage | `/admin/api-usage` |
| Analytics | `/admin/analytics` |
| System Statistics | `/admin/statistics` |
| Security Dashboard | `/admin/security` |
| Blocked IPs | `/admin/security/blocked-ips` |
| Rate Limits | `/admin/security/rate-limits` |
| Login Attempts | `/admin/security/login-attempts` |
| Security/Audit Logs | `/admin/security/audit-logs` |
| System Settings | `/admin/settings` |
| Email Settings | `/admin/settings/email` |
| OTP Settings | `/admin/settings/otp` |
| API Settings | `/admin/settings/api` |
| General Settings | `/admin/settings/general` |
| Admin Accounts | `/admin/administrators` |
| Admin Profile | `/admin/profile` |
| Admin Security | `/admin/security/account` |

## 5.5 System routes

| Screen | Recommended route |
|---|---|
| 404 | Framework/application not-found handler |
| 403 | `/errors/403` |
| 429 Rate Limited | `/errors/429` |
| 500 Server Error | `/errors/500` |
| Maintenance | `/maintenance` |
| API Error Response | REST API error contract; not a normal HTML page |

Error handlers must preserve the correct HTTP status code. A custom error page must not convert an error into HTTP 200.

---

# 6. Public Screens — 10

## 1. Home — `/`

**Purpose:** Explain the platform quickly and guide visitors toward registration or documentation.

**Primary content:**
- Product headline and concise value proposition
- Primary CTA: Get Started / Register
- Secondary CTA: View API Documentation
- How the platform works summary
- Provider support overview
- Key capabilities
- Developer integration example
- Trust/security summary
- Footer links

**Primary actions:** Register, Login, View Documentation.

**Navigation:** Public header and footer.

## 2. Features — `/features`

**Purpose:** Present the product's capabilities in understandable groups.

**Content:**
- Email sending
- Templates and variables
- Projects and API keys
- Gmail and SMTP providers
- OTP and verification flows
- Logs and usage
- Webhooks
- Security and administration

**Actions:** Register, View Documentation.

## 3. How It Works — `/how-it-works`

**Purpose:** Explain the end-to-end integration model.

**Core flow:**

`HTML website/app → JavaScript Fetch → PHP REST API → email engine → provider → recipient`

**Content:**
- Create an account
- Create a project
- Connect an email provider
- Generate an API key
- Call the API from a website/app
- Inspect delivery logs

**Actions:** Get Started, View API Documentation.

## 4. Providers — `/providers`

**Purpose:** Explain supported email delivery connections.

**Content:**
- Gmail OAuth connection
- Custom SMTP
- Optional provider adapter availability
- Provider-specific setup overview
- Security notes

**Actions:** Register, Read Documentation.

The public page must distinguish core supported providers from optional/future adapter support.

## 5. API Documentation — `/docs`

**Purpose:** Provide public technical integration documentation.

**Content:**
- Introduction
- Authentication
- Send email endpoint
- OTP endpoints
- Templates
- Request examples
- Response examples
- Error format
- Rate limits
- Security recommendations

**Actions:** Copy code, navigate documentation sections, Register.

Documentation examples must use fake credentials and safe placeholder values.

## 6. Pricing — `/pricing`

**Purpose:** Explain plan or usage information.

**Content:**
- Plan comparison, if commercial plans are enabled
- Usage limits, if configured
- Feature availability
- Billing/support notes, if applicable

**Actions:** Get Started, Contact.

Do not invent commercial limits in the UI. Pricing values must come from an approved product configuration.

## 7. FAQ — `/faq`

**Purpose:** Answer common product and integration questions.

Suggested topics:
- Does my website need PHP?
- How does the JavaScript integration work?
- Which providers are supported?
- How are API keys protected?
- Can I use multiple projects?
- How do templates work?
- How can I troubleshoot a failed email?
- What are OTP expiry and attempt limits?

**Actions:** Open documentation, Contact, Register.

## 8. Contact — `/contact`

**Purpose:** Provide a contact route.

**Content:** Contact form and approved contact details.

**Requirements:** Server-side validation, abuse/rate limiting, clear success/error feedback, and privacy-conscious logging.

## 9. Privacy Policy — `/privacy`

**Purpose:** Explain personal data handling, storage, retention, security, and user rights.

The policy must be reviewed and approved for the actual operating jurisdiction and deployment model before launch.

## 10. Terms & Conditions — `/terms`

**Purpose:** Define acceptable use, account responsibilities, provider limitations, service conditions, and liability terms.

The terms must be legally reviewed before production use.

---

# 7. Authentication Screens — 7

Authentication pages use a focused layout with minimal navigation.

## 11. Login — `/login`

**Purpose:** Authenticate an existing user.

**Fields:** Email and password.

**Actions:** Login, Forgot Password, Register.

**States:** Invalid credentials, validation error, rate limited, submitting, success.

Do not reveal unnecessary account existence information.

## 12. Register — `/register`

**Purpose:** Create a user account.

**Fields:** Name, email, password, and required consent fields.

**Actions:** Create Account, Login.

**States:** Validation, duplicate/invalid registration response, submitting, registration success.

Server-side password policy and abuse controls are authoritative.

## 13. Email Verification — `/verify-email`

**Purpose:** Verify account email ownership.

**Content:** Verification instructions and current verification state.

**Actions:** Verify, Resend Verification, Return to Login.

Resend operations must be rate limited.

## 14. OTP Verification — `/verify-otp`

**Purpose:** Verify a short-lived one-time code for its declared purpose.

**Content:** Code input, purpose context, expiry guidance, retry/resend state.

**Actions:** Verify Code, Resend where permitted.

Never reveal the expected OTP or expose it in browser logs.

## 15. Forgot Password — `/forgot-password`

**Purpose:** Start password recovery.

**Fields:** Email.

**Action:** Request Reset.

Use a consistent response that does not unnecessarily reveal whether an account exists.

## 16. Reset Password — `/reset-password`

**Purpose:** Set a new password using a valid, unexpired, purpose-bound reset token.

**Fields:** New password and confirmation.

**Actions:** Reset Password, Return to Login.

Invalidate or consume the reset token according to the authentication specification.

## 17. Account Recovery — `/account-recovery`

**Purpose:** Provide the defined recovery route when ordinary login or verification cannot be completed.

**Content:** Recovery guidance and approved support/reverification path.

**Actions:** Start Recovery, Return to Login.

Do not create an undocumented bypass around verification or account security.

---

# 8. User Panel Screens — 33

All user screens require an authenticated user session. Project-scoped pages additionally require authorization for the selected project.

## 18. User Dashboard — `/app/dashboard`

**Purpose:** Give a high-level view of account and project activity.

**Content:**
- Project count/summary
- Email activity summary
- Provider connection health
- Recent email outcomes
- Usage summary
- Important notifications/security alerts
- Quick actions

**Actions:** Create Project, Connect Provider, Send Test Email, View Logs.

## 19. Projects — `/app/projects`

**Purpose:** List projects owned by or shared with the user.

**Content:** Project name, status, creation date, activity summary, actions.

**Actions:** Create Project, Open Project, Edit Settings, Delete where authorized.

Support search and pagination when the collection grows.

## 20. Create Project — `/app/projects/new`

**Purpose:** Create a project/workspace boundary for email configuration and API access.

**Fields:** Project name and any approved optional metadata.

**Actions:** Create Project, Cancel.

After creation, navigate to Project Overview.

## 21. Project Overview — `/app/projects/{project_id}`

**Purpose:** Show the selected project's operational summary.

**Content:** Project identity, provider status, templates, API keys summary, recent email activity, usage.

**Actions:** Project Settings, Manage Providers, Create Template, API Integration, View Logs.

## 22. Project Settings — `/app/projects/{project_id}/settings`

**Purpose:** Manage project-level settings.

**Content:** Project name, approved configuration, status, and destructive project controls.

**Actions:** Save Changes, Delete Project.

Deletion requires confirmation and must explain related data consequences.

## 23. Email Services — `/app/projects/{project_id}/email-services`

**Purpose:** Entry point for configuring email providers.

**Content:** Supported provider cards, current connection status, provider setup guidance.

**Actions:** Add Gmail, Add SMTP, Manage Providers.

## 24. Add Gmail — `/app/projects/{project_id}/providers/gmail/connect`

**Purpose:** Start the Gmail OAuth authorization process.

**Content:** Permission explanation, account/provider context, security notice.

**Actions:** Connect Gmail / Authorize, Cancel.

The backend creates and validates OAuth state. Tokens must not be handled as ordinary client-side settings.

## 25. Gmail Connection Success — `/app/projects/{project_id}/providers/gmail/success`

**Purpose:** Confirm the result of a Gmail OAuth connection.

**Content:** Connected account identifier where safe, connection status, next-step guidance.

**Actions:** Continue to Provider Management, Test Connection.

Do not treat a client redirect alone as proof of a successful connection; confirm server-side OAuth completion.

## 26. Add SMTP — `/app/projects/{project_id}/providers/smtp/new`

**Purpose:** Configure a custom SMTP provider.

**Fields:**
- SMTP host
- Port
- Encryption mode
- Username
- Password/secret
- From address
- From name

**Actions:** Test Connection, Save Provider, Cancel.

Secrets must be encrypted at rest and masked after saving.

## 27. SMTP Connection Test — `/app/projects/{project_id}/providers/smtp/test`

**Purpose:** Show the result of an SMTP connectivity/authentication test.

**Content:** Test status, safe diagnostic summary, timestamp, relevant error guidance.

**Actions:** Retry Test, Edit SMTP Settings, Return to Providers.

Do not expose credentials or sensitive server internals in diagnostic messages.

## 28. Provider Management — `/app/projects/{project_id}/providers`

**Purpose:** Manage configured providers for the current project.

**Content:** Provider list, type, status, last test, default/priority selection where supported.

**Actions:** Add Provider, Test, Edit, Set Default, Disconnect.

Disconnecting a provider requires confirmation and must explain impact on future sends.

## 29. Email Templates — `/app/projects/{project_id}/templates`

**Purpose:** List and manage project templates.

**Content:** Template name, subject, update date, status/version summary.

**Actions:** Create, Edit, Preview, Duplicate, Delete.

Support search and pagination.

## 30. Create Template — `/app/projects/{project_id}/templates/new`

**Purpose:** Create a new email template.

**Fields:** Template name, subject, HTML/body content, optional description.

**Actions:** Save Template, Cancel.

Validate template ownership and project association server-side.

## 31. Template Editor — `/app/projects/{project_id}/templates/{template_id}/edit`

**Purpose:** Edit an existing template.

**Content:** Name, subject, HTML editor, variable guidance, save state.

**Actions:** Save, Preview, Test Email, View Variables.

Warn about unsaved changes before navigation where practical.

## 32. Template Preview — `/app/projects/{project_id}/templates/{template_id}/preview`

**Purpose:** Render a safe preview of a template with sample variable values.

**Content:** Subject preview and rendered email body.

**Actions:** Return to Editor, Send Test.

Preview rendering must sanitize and isolate untrusted HTML appropriately.

## 33. Template Variables — `/app/projects/{project_id}/templates/{template_id}/variables`

**Purpose:** Explain available variables and their usage.

**Content:** Variable name, description, sample value, required/optional state where defined.

**Actions:** Copy Variable, Return to Editor.

Variable definitions must match the template engine contract.

## 34. Email Send — `/app/projects/{project_id}/send`

**Purpose:** Provide a guided manual email send interface.

**Fields:** Recipient, sender configuration where permitted, subject/content or template, variables, metadata.

**Actions:** Send Email, Preview, Test.

Display request outcome and log reference. Prevent duplicate submissions while a request is processing.

## 35. Test Email — `/app/projects/{project_id}/send/test`

**Purpose:** Send a controlled test message using the selected project/provider configuration.

**Fields:** Test recipient and approved test options.

**Actions:** Send Test, Return.

Clearly distinguish a test send from production transactional traffic.

## 36. API Integration — `/app/projects/{project_id}/integration`

**Purpose:** Help developers connect a static HTML website or JavaScript application to the platform.

**Content:**
- Project/API endpoint context
- API authentication explanation
- JavaScript Fetch example
- Request body example
- Response example
- Security warning about public browser environments
- Links to API keys and documentation

**Actions:** Copy Example, Manage API Keys, Open Documentation.

Important: a secret API key must not be embedded in public browser JavaScript. The product must distinguish publishable/client-safe credentials, if ever introduced, from secret server-side credentials. The core API's security model must not be weakened to make browser examples appear convenient.

## 37. API Keys — `/app/projects/{project_id}/api-keys`

**Purpose:** List and manage keys belonging to the selected project.

**Content:** Key label, prefix/identifier, created date, last used, status.

**Actions:** Create Key, Revoke Key.

Never show stored secret material again after initial creation.

## 38. API Key Create — `/app/projects/{project_id}/api-keys/new`

**Purpose:** Generate a new project API key.

**Fields:** Key name/label and approved scope/permissions if supported.

**Actions:** Generate Key, Cancel, Copy Secret after generation.

Display the full secret only once. Explain secure storage and revocation.

## 39. API Documentation — `/app/docs`

**Purpose:** Provide authenticated, project-contextual integration documentation.

**Content:** API reference, project-specific examples where safe, authentication instructions, endpoints, error handling.

**Actions:** Copy code, navigate sections, open API Integration.

Do not insert a real secret key into a shareable code sample.

## 40. Email Logs — `/app/projects/{project_id}/logs/email`

**Purpose:** Monitor email requests and delivery outcomes.

**Content:** Time, recipient, subject, provider, status, request ID.

**Actions:** Search, Filter, Open Details, Export only if supported.

Pagination is required for large result sets.

## 41. Email Log Details — `/app/projects/{project_id}/logs/email/{log_id}`

**Purpose:** Inspect one email operation.

**Content:** Request ID, timestamps, recipient, subject, provider, status, safe provider response, error summary, relevant metadata.

**Actions:** Back to Logs, Retry only if a safe retry workflow is explicitly supported.

Do not expose provider credentials, full secrets, or unnecessary personal data.

## 42. OTP Logs — `/app/projects/{project_id}/logs/otp`

**Purpose:** Monitor OTP issuance and verification outcomes.

**Content:** Time, purpose, masked recipient/reference, expiry state, attempt state, delivery status.

**Actions:** Search, Filter, View safe details where implemented.

Never display OTP values.

## 43. Usage & Statistics — `/app/projects/{project_id}/usage`

**Purpose:** Show project usage and trends.

**Content:** Email volume, success/failure counts, OTP activity, API request counts, date range.

**Actions:** Change date range, filter supported metrics.

Metrics must be derived from stored usage/log data and clearly identify their time window.

## 44. Webhooks — `/app/projects/{project_id}/webhooks`

**Purpose:** List project webhook endpoints and event subscriptions.

**Content:** Endpoint URL, enabled state, subscribed events, last delivery summary.

**Actions:** Create Webhook, Edit Settings, Disable/Delete, View Delivery Logs where available.

Webhook secrets must be displayed only according to the security policy.

## 45. Webhook Settings — `/app/projects/{project_id}/webhooks/{webhook_id}/settings`

**Purpose:** Configure one webhook endpoint.

**Content:** URL, event subscriptions, enabled state, signing/secret guidance, retry behavior summary.

**Actions:** Save, Test Delivery where supported, Disable, Delete.

Validate endpoint URLs and protect outbound delivery against server-side request forgery.

## 46. Notifications — `/app/notifications`

**Purpose:** Show account and project notifications.

**Content:** Notification type, summary, timestamp, read/unread state, related destination.

**Actions:** Mark Read, Mark All Read, Open Related Item.

Do not place secrets or OTP values in notifications.

## 47. Profile Settings — `/app/settings/profile`

**Purpose:** Manage personal account profile details.

**Content:** Name, email display/verification state, approved profile fields.

**Actions:** Save Changes, Start Email Change Verification if supported.

Email changes require verification and must not silently change login identity.

## 48. Security Settings — `/app/settings/security`

**Purpose:** Central location for account security controls.

**Content:** Password/security status, verification state, session overview, relevant security guidance.

**Actions:** Change Password, Manage Sessions.

Only expose security controls actually implemented by the backend.

## 49. Password Change — `/app/settings/password`

**Purpose:** Change the authenticated user's password.

**Fields:** Current password and new password/confirmation as required by the authentication policy.

**Actions:** Update Password, Cancel.

Reauthentication and session invalidation behavior must follow the authentication specification.

## 50. Active Sessions — `/app/settings/sessions`

**Purpose:** Show active account sessions.

**Content:** Session/device summary, approximate metadata, last activity, current-session indicator.

**Actions:** Revoke Session, Revoke Other Sessions where supported.

Never expose raw session identifiers or session tokens.

---

# 9. Admin Panel Screens — 37

All admin routes require a valid admin session and server-side permission checks. Sensitive operations should require elevated permission and audit logging.

## 51. Admin Dashboard — `/admin`

**Purpose:** Provide a system-wide operational overview.

**Content:** User/project counts, email activity, provider health, API activity, failures, security alerts, system status.

**Actions:** Navigate to monitoring, users, providers, security, and settings.

## 52. Users — `/admin/users`

**Purpose:** Search and manage registered users.

**Content:** User identifier, name, email, status, verification state, registration date.

**Actions:** Search, Filter, Open Details, Add User if permitted.

## 53. User Details — `/admin/users/{user_id}`

**Purpose:** Inspect one user account and related operational context.

**Content:** Profile summary, account status, projects, verification state, relevant activity.

**Actions:** Edit, Suspend/Activate, View Projects, View Audit Context.

Sensitive personal data must be limited to what administrators need.

## 54. Add User — `/admin/users/new`

**Purpose:** Create a user account through an authorized administrative workflow.

**Fields:** Approved account identity fields and initial status.

**Actions:** Create User, Cancel.

Do not create an undocumented password-sharing or verification bypass.

## 55. Edit User — `/admin/users/{user_id}/edit`

**Purpose:** Modify permitted user account fields.

**Content:** Editable identity/status fields and validation.

**Actions:** Save, Cancel.

All changes must be audited.

## 56. Projects — `/admin/projects`

**Purpose:** Search and inspect projects across the platform.

**Content:** Project, owner, status, provider summary, creation date.

**Actions:** Search, Filter, Open Details.

## 57. Project Details — `/admin/projects/{project_id}`

**Purpose:** Inspect one project.

**Content:** Owner, project status, safe provider metadata, usage, templates, activity.

**Actions:** Open Management, View Logs, Review Configuration.

Do not reveal provider secrets in admin summaries.

## 58. Project Management — `/admin/projects/{project_id}/manage`

**Purpose:** Perform authorized administrative project actions.

**Content:** Project state, ownership context, allowed controls.

**Actions:** Update status, perform approved maintenance actions.

High-impact changes require confirmation and audit records.

## 59. Email Providers — `/admin/providers`

**Purpose:** Provide a global view of configured provider types and provider subsystem health.

**Content:** Provider types, enabled state, aggregate status, configuration summary.

**Actions:** Open provider-specific connection lists, manage allowed global settings.

## 60. Gmail Connections — `/admin/providers/gmail`

**Purpose:** Monitor Gmail OAuth connections.

**Content:** Safe account identifiers, owner/project relationship, status, last health check.

**Actions:** Inspect, disable/revoke according to policy.

Never expose OAuth access or refresh tokens.

## 61. SMTP Connections — `/admin/providers/smtp`

**Purpose:** Monitor custom SMTP configurations.

**Content:** Host/port where safe, owner/project, connection state, last test.

**Actions:** Inspect safe metadata, disable connection where authorized.

Never reveal SMTP passwords.

## 62. Brevo Connections — `/admin/providers/brevo`

**Purpose:** Monitor optional Brevo adapter connections if the adapter is enabled.

**Content:** Connection metadata, status, associated project, safe diagnostics.

**Actions:** Inspect, enable/disable adapter according to permissions.

If the adapter is not configured, show an explicit unavailable/not-enabled state rather than fake records.

## 63. Mailtrap Connections — `/admin/providers/mailtrap`

**Purpose:** Monitor optional Mailtrap adapter connections if enabled.

**Content:** Connection metadata, status, associated project, safe diagnostics.

**Actions:** Inspect, enable/disable adapter according to permissions.

If the adapter is not configured, show an explicit unavailable/not-enabled state.

## 64. Email Logs — `/admin/logs/email`

**Purpose:** Monitor email operations across projects.

**Content:** Time, project, owner, recipient (masked where appropriate), provider, status, request ID.

**Actions:** Search, filter, inspect details.

Access to message content must be permission-controlled and minimized.

## 65. Email Log Details — `/admin/logs/email/{log_id}`

**Purpose:** Inspect one email operation for support or incident response.

**Content:** Safe request metadata, provider outcome, status, timing, error summary.

**Actions:** Return to list, approved diagnostic actions.

All access to sensitive details should be logged where required.

## 66. OTP Logs — `/admin/logs/otp`

**Purpose:** Monitor OTP issuance and verification behavior system-wide.

**Content:** Time, purpose, project/user reference, masked destination, status, expiry and attempt metadata.

**Actions:** Search, filter, inspect safe metadata.

Never display actual OTP values.

## 67. API Logs — `/admin/logs/api`

**Purpose:** Monitor API request activity.

**Content:** Time, project, endpoint, HTTP method, response status, latency, request ID, rate-limit outcome.

**Actions:** Search, filter, inspect request metadata.

Do not log authorization headers or API secrets.

## 68. Webhook Logs — `/admin/logs/webhooks`

**Purpose:** Monitor webhook delivery attempts.

**Content:** Time, project, endpoint reference, event type, attempt count, response status, delivery state.

**Actions:** Search, filter, inspect delivery metadata.

Do not expose signing secrets.

## 69. Templates — `/admin/templates`

**Purpose:** Search and inspect templates across projects.

**Content:** Template, project, owner, updated date, status.

**Actions:** Search, filter, inspect details.

## 70. Template Details — `/admin/templates/{template_id}`

**Purpose:** Inspect a selected template and its metadata.

**Content:** Project association, template metadata, version information where available.

**Actions:** Inspect, perform explicitly authorized administrative actions.

Avoid rendering unsafe template HTML in the admin shell.

## 71. API Keys — `/admin/api-keys`

**Purpose:** Monitor API key metadata and status.

**Content:** Key identifier/prefix, project, owner, creation date, last used, status.

**Actions:** Inspect metadata, revoke if authorized.

Never display full API secrets.

## 72. API Usage — `/admin/api-usage`

**Purpose:** Monitor API consumption across the platform.

**Content:** Request volume, status distribution, project/user breakdown, time range.

**Actions:** Filter, change date range, inspect usage.

## 73. Analytics — `/admin/analytics`

**Purpose:** Present aggregate product and operational trends.

**Content:** User growth, project activity, email volume, delivery outcomes, provider distribution, API activity.

**Actions:** Date range and supported filters.

Clearly label aggregation windows and avoid presenting incomplete data as final.

## 74. System Statistics — `/admin/statistics`

**Purpose:** Show system-level operational statistics.

**Content:** Application health, database connectivity, queue/cron status where implemented, provider health, error rates, resource metrics where safely available.

**Actions:** Refresh, navigate to related monitoring pages.

Do not expose infrastructure secrets or sensitive internal paths.

## 75. Security Dashboard — `/admin/security`

**Purpose:** Provide an overview of security signals.

**Content:** Login failures, blocked IPs, rate-limit events, suspicious activity signals, recent security/audit events.

**Actions:** Open blocked IPs, login attempts, rate limits, audit logs.

Do not claim automated threat detection unless it is actually implemented.

## 76. Blocked IPs — `/admin/security/blocked-ips`

**Purpose:** Manage IP blocks.

**Content:** IP/network identifier, reason, created date, expiry/state, actor.

**Actions:** Add Block, Remove Block, Search.

Validate IP/CIDR input and audit changes.

## 77. Rate Limits — `/admin/security/rate-limits`

**Purpose:** View and manage configured rate-limit policies.

**Content:** Policy name, scope, limit/window, enabled state.

**Actions:** Edit approved policy, save, reset only if supported.

Changes must not silently disable critical abuse protection.

## 78. Login Attempts — `/admin/security/login-attempts`

**Purpose:** Inspect authentication attempts for abuse and troubleshooting.

**Content:** Time, account reference, outcome, safe IP/device metadata, reason category.

**Actions:** Search, filter, inspect.

Avoid unnecessary exposure of personal or device-identifying information.

## 79. Security/Audit Logs — `/admin/security/audit-logs`

**Purpose:** Provide an auditable record of important account and administrative events.

**Content:** Actor, action, target, timestamp, result, safe metadata.

**Actions:** Search, filter, inspect.

Audit records should be append-only from the application perspective and protected against unauthorized modification.

## 80. System Settings — `/admin/settings`

**Purpose:** Provide the entry point for global configuration.

**Content:** Configuration categories and current safe status.

**Actions:** Open Email, OTP, API, and General Settings.

## 81. Email Settings — `/admin/settings/email`

**Purpose:** Configure approved global email behavior.

**Content:** Global sending defaults, sender policy, provider behavior, approved limits.

**Actions:** Save settings, test configuration where supported.

Never expose or store credentials as plaintext.

## 82. OTP Settings — `/admin/settings/otp`

**Purpose:** Configure global OTP policy.

**Content:** Expiry policy, attempt limits, resend controls, purpose policy.

**Actions:** Save settings.

Changes must preserve security constraints and be audited.

## 83. API Settings — `/admin/settings/api`

**Purpose:** Configure global API behavior.

**Content:** API version/status, rate-limit defaults, CORS allowlist, request limits, approved operational settings.

**Actions:** Save settings.

CORS is not authentication and must not be presented as a replacement for API authorization.

## 84. General Settings — `/admin/settings/general`

**Purpose:** Manage general platform settings.

**Content:** Platform name, public configuration, maintenance mode entry point, approved operational preferences.

**Actions:** Save Settings.

Sensitive configuration changes require audit logging.

## 85. Admin Accounts — `/admin/administrators`

**Purpose:** Manage authorized administrator accounts.

**Content:** Admin identity, role, status, last activity.

**Actions:** Add/edit/disable admin according to permission.

Require strong authentication and least-privilege roles.

## 86. Admin Profile — `/admin/profile`

**Purpose:** Manage the current administrator's profile.

**Content:** Profile identity and approved account fields.

**Actions:** Save Changes.

## 87. Admin Security — `/admin/security/account`

**Purpose:** Manage the current administrator's security.

**Content:** Password/security status, active admin sessions, security guidance.

**Actions:** Change Password, Manage Sessions.

Admin account security must not be weaker than ordinary user security.

---

# 10. System Screens — 6

System screens may be rendered outside the normal application shell when appropriate, but must preserve branding and correct HTTP semantics.

## 88. 404 — Not Found

**Purpose:** Explain that the requested page or resource does not exist.

**Content:** Clear message and navigation recovery.

**Actions:** Return Home or Dashboard, depending on authentication state.

HTTP status: `404`.

## 89. 403 — Forbidden

**Purpose:** Explain that the current user is not authorized to access the requested resource.

**Content:** Short explanation and safe navigation route.

**Actions:** Return to an allowed page.

HTTP status: `403`.

Do not reveal whether a protected resource exists if that would disclose sensitive information.

## 90. 429 — Rate Limited

**Purpose:** Explain that a request was temporarily rate limited.

**Content:** Clear retry guidance and a retry-after value when the server provides one.

**Actions:** Retry after the allowed interval.

HTTP status: `429`.

Do not encourage repeated immediate retries.

## 91. 500 — Server Error

**Purpose:** Show a safe response to an unexpected server failure.

**Content:** Generic message, support/request reference where available.

**Actions:** Retry later, return to a safe page.

HTTP status: `500`.

Do not expose stack traces, SQL errors, filesystem paths, or secrets.

## 92. Maintenance — `/maintenance`

**Purpose:** Inform users that the platform is temporarily unavailable for maintenance.

**Content:** Maintenance message and expected availability information only when confirmed.

**Actions:** Retry later.

Use an appropriate service-unavailable status, normally `503`, when the server is in maintenance mode.

## 93. API Error Response

**Purpose:** Return consistent machine-readable errors for API clients.

**Requirements:**
- Correct HTTP status
- Stable error code
- Human-readable message
- Request/correlation ID
- Optional safe details
- No stack trace or secret material

Example shape:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The request contains invalid fields.",
    "details": {
      "to": "A valid recipient address is required."
    }
  },
  "request_id": "req_example"
}
```

The exact response contract is finalized in `11-REST-API-SPECIFICATION.md`.

---

# 11. Screen Access and Permission Matrix

| Area | Visitor | User | Admin |
|---|---:|---:|---:|
| Public pages | Yes | Yes | Yes |
| Authentication | Yes | Session/account-dependent | Session/account-dependent |
| User dashboard | No | Yes | Only through a separately authorized support/admin workflow, if implemented |
| User projects | No | Own/authorized projects | Admin permission only |
| User providers | No | Own/authorized projects | Admin permission only |
| User templates | No | Own/authorized projects | Admin permission only |
| User logs/usage | No | Own/authorized projects | Admin permission only |
| User profile/security | No | Own account | Own admin account is separate |
| Admin dashboard | No | No | Yes |
| Admin management | No | No | Permission-dependent |
| System error pages | As needed | As needed | As needed |

Important rules:

- A user must never access another user's project by changing a URL identifier.
- Admin access must be checked server-side on every request.
- Administrative roles should follow least privilege.
- Admin account/session controls must remain separate from ordinary user authorization.
- Unauthorized API access must return the defined API error response.

---

# 12. Core Navigation Flows

## 12.1 First-time user journey

```text
Home
  → Register
  → Email Verification
  → Login
  → User Dashboard
  → Create Project
  → Project Overview
  → Email Services
  → Add Gmail or Add SMTP
  → Provider Management
  → API Keys
  → API Integration
  → Test Email
  → Email Logs
```

## 12.2 Gmail connection journey

```text
Project Overview
  → Email Services
  → Add Gmail
  → OAuth authorization
  → Server-side callback/state validation
  → Gmail Connection Success
  → Provider Management
  → Test/health check
```

A failed authorization must return a safe failure state and must not create a false connected status.

## 12.3 SMTP connection journey

```text
Project Overview
  → Email Services
  → Add SMTP
  → Enter SMTP configuration
  → SMTP Connection Test
  → Save Provider
  → Provider Management
```

A failed test should return the user to editable configuration with safe diagnostic guidance.

## 12.4 Template journey

```text
Project Overview
  → Email Templates
  → Create Template
  → Template Editor
  → Template Variables
  → Template Preview
  → Test Email
  → Email Logs
```

## 12.5 API integration journey

```text
Project Overview
  → API Integration
  → API Keys
  → API Key Create
  → Securely copy secret once
  → API Documentation
  → Integrate through an appropriate trusted execution environment
  → Test request
  → Email Logs
```

A secret key must not be embedded in a public static website's JavaScript. If browser-originated sending is required, it must use a deliberately designed restricted/public credential and server-enforced abuse controls; it must not reuse a secret server API key.

## 12.6 Troubleshooting journey

```text
User Dashboard
  → Email Logs
  → Email Log Details
  → Inspect safe error information
  → Provider Management
  → Test Provider
  → Retry through supported workflow
```

## 12.7 Account security journey

```text
Profile Settings
  → Security Settings
  → Password Change
  → Active Sessions
  → Revoke selected session(s)
```

## 12.8 Admin investigation journey

```text
Admin Dashboard
  → Security Dashboard
  → Login Attempts / Blocked IPs / Audit Logs
  → Inspect relevant event
  → Perform authorized action
  → Audit action recorded
```

---

# 13. Project Context Rules

Project context is required for all project-scoped features.

The interface must:

- Display the active project name or identifier.
- Preserve project context when navigating between project pages.
- Validate that the user is authorized for the project.
- Avoid silently falling back to another project.
- Show a clear project-not-found or forbidden state when access fails.
- Scope lists, logs, templates, providers, API keys, and webhooks to the active project.

If a user has no projects, the Projects screen and dashboard should provide a clear Create Project action.

---

# 14. Navigation Behavior and History

## 14.1 Browser navigation

Back/forward navigation should behave predictably. Forms with unsaved changes should warn users before discarding work when practical.

## 14.2 Deep links

Authenticated deep links must:

- Preserve the intended destination after successful login where safe.
- Re-check authorization after login.
- Avoid redirect loops.
- Reject unsafe external redirect targets.

## 14.3 Breadcrumbs

Use breadcrumbs on deep project and admin detail pages where they materially improve orientation.

Example:

`Projects > Project Name > Email Templates > Template Name`

Do not add breadcrumbs to every simple page if they create noise.

## 14.4 Active navigation

Active navigation must reflect the current route and remain accessible to screen readers.

---

# 15. Search, Filters, and Pagination

Use consistent list behavior across Projects, Templates, Logs, Users, API Keys, and administrative lists.

Where applicable:

- Search input
- Filter controls
- Sortable columns
- Pagination
- Clear filters action
- Loading state
- Empty state
- Error state

Filter state may be represented in query parameters when useful for shareable/reloadable views. Never put secrets or sensitive personal data in URLs.

Pagination must be server-backed for potentially large datasets.

---

# 16. Screen State Requirements

Each data-driven screen must consider these states where relevant:

| State | Expected behavior |
|---|---|
| Initial loading | Skeleton, spinner, or clear progress |
| Populated | Show authorized data |
| Empty | Explain absence and provide next action |
| Error | Safe explanation and retry/recovery |
| Forbidden | Deny access without leaking data |
| Not found | Correct not-found handling |
| Submitting | Prevent duplicate submissions |
| Success | Confirm completion and next step |
| Disabled | Explain unavailable action where useful |

A screen is not complete when only its populated state exists.

---

# 17. Responsive Navigation Specification

## Desktop

- Sidebar visible by default in user/admin panels.
- Main content uses a readable maximum width where appropriate.
- Page actions align consistently with page heading.

## Tablet

- Sidebar may collapse to compact mode.
- Navigation labels remain available through accessible disclosure.
- Data tables adapt without hiding essential actions.

## Mobile

- Sidebar becomes an off-canvas drawer.
- Drawer closes after navigation where appropriate.
- Main content uses a single-column layout.
- Page actions wrap or stack.
- Forms use full available width.
- Tables use the responsive strategy from the UI/UX design system.
- Breadcrumbs may collapse but must not remove context entirely.

---

# 18. Route Implementation and Security Rules

1. Routes are not security boundaries by themselves.
2. Every protected route requires server-side authentication.
3. Every project route requires project authorization.
4. Every admin route requires admin authorization and permission checks.
5. IDs from URLs must be validated and queried within the caller's authorized scope.
6. State-changing operations must use appropriate HTTP methods and CSRF protections for cookie-authenticated browser flows.
7. OAuth callback state must be validated server-side.
8. Sensitive tokens must not be placed in ordinary query strings.
9. Return URLs must be validated against open redirects.
10. API errors must follow the API specification.
11. HTML error pages must use correct HTTP status codes.
12. Navigation visibility must never substitute for backend authorization.

---

# 19. Naming and Consistency Rules

- Use the exact screen names in this document.
- Use lowercase hyphenated route paths.
- Use stable resource identifiers in route parameters.
- Use one canonical route for each screen.
- Do not create duplicate screens for the same task.
- Keep public, user, and admin route namespaces separate.
- Keep route labels understandable and task-oriented.
- Keep route authorization rules close to route definitions and enforce them centrally.

---

# 20. Screen Completion Checklist

Before a screen is considered complete, verify:

### Information architecture
- Correct screen name
- Correct route
- Correct navigation group
- Correct project context
- Correct page hierarchy

### Permissions
- Authentication enforced
- Resource ownership checked
- Admin permission checked where applicable
- Unauthorized access handled safely

### UI/UX
- Correct design system components
- Responsive layout
- Loading, empty, and error states
- Clear primary action
- Accessible labels and keyboard behavior

### Data
- Correct project/user scope
- No secret values exposed
- Pagination/filtering where needed
- Safe error and success feedback

### Navigation
- Back/forward behavior
- Breadcrumbs where useful
- Active navigation state
- Deep-link handling
- Safe redirects

---

# 21. Locked Screen Inventory

The following is the authoritative 93-screen inventory.

## Public — 10

1. Home
2. Features
3. How It Works
4. Providers
5. API Documentation
6. Pricing
7. FAQ
8. Contact
9. Privacy Policy
10. Terms & Conditions

## Authentication — 7

11. Login
12. Register
13. Email Verification
14. OTP Verification
15. Forgot Password
16. Reset Password
17. Account Recovery

## User — 33

18. User Dashboard
19. Projects
20. Create Project
21. Project Overview
22. Project Settings
23. Email Services
24. Add Gmail
25. Gmail Connection Success
26. Add SMTP
27. SMTP Connection Test
28. Provider Management
29. Email Templates
30. Create Template
31. Template Editor
32. Template Preview
33. Template Variables
34. Email Send
35. Test Email
36. API Integration
37. API Keys
38. API Key Create
39. API Documentation
40. Email Logs
41. Email Log Details
42. OTP Logs
43. Usage & Statistics
44. Webhooks
45. Webhook Settings
46. Notifications
47. Profile Settings
48. Security Settings
49. Password Change
50. Active Sessions

## Admin — 37

51. Admin Dashboard
52. Users
53. User Details
54. Add User
55. Edit User
56. Projects
57. Project Details
58. Project Management
59. Email Providers
60. Gmail Connections
61. SMTP Connections
62. Brevo Connections
63. Mailtrap Connections
64. Email Logs
65. Email Log Details
66. OTP Logs
67. API Logs
68. Webhook Logs
69. Templates
70. Template Details
71. API Keys
72. API Usage
73. Analytics
74. System Statistics
75. Security Dashboard
76. Blocked IPs
77. Rate Limits
78. Login Attempts
79. Security/Audit Logs
80. System Settings
81. Email Settings
82. OTP Settings
83. API Settings
84. General Settings
85. Admin Accounts
86. Admin Profile
87. Admin Security

## System — 6

88. 404
89. 403
90. 429 Rate Limited
91. 500 Server Error
92. Maintenance
93. API Error Response

**Total: 93 screens.**

---

# 22. Relationship to Other Documents

- `00-MASTER-BLUEPRINT.md` — overall product authority
- `01-PROJECT-OVERVIEW.md` — product purpose and user journeys
- `02-FINAL-SCOPE-AND-FEATURES.md` — locked feature scope
- `03-SYSTEM-ARCHITECTURE.md` — application architecture
- `04-TECHNOLOGY-STACK.md` — approved technology
- `05-UI-UX-DESIGN-SYSTEM.md` — visual and interaction rules
- `06-SCREENS-AND-NAVIGATION.md` — this screen and navigation specification
- `07-ASSETS-ICONS-FONTS-LOGOS.md` — asset standards
- `08-DATABASE-ARCHITECTURE.md` — database architecture
- `09-DATABASE-SCHEMA.md` — database schema
- `10-BACKEND-PHP-ARCHITECTURE.md` — backend structure
- `11-REST-API-SPECIFICATION.md` — API contracts

Later documents must implement these screens and routes consistently. If a later technical requirement reveals a conflict, document the conflict and resolve it explicitly; do not silently change the locked screen inventory.

---

# 23. Final Navigation Lock

The platform has five navigation areas:

1. Public
2. Authentication
3. User
4. Admin
5. System/error handling

The screen inventory remains fixed at:

- 10 public screens
- 7 authentication screens
- 33 user screens
- 37 admin screens
- 6 system screens

**TOTAL: 93 SCREENS — FINAL / LOCKED**

This document is the implementation reference for screen naming, routes, navigation hierarchy, page responsibilities, access boundaries, and primary user journeys.
