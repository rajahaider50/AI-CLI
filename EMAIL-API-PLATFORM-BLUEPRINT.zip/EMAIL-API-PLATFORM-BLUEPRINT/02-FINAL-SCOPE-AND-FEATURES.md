# EMAIL API PLATFORM — FINAL SCOPE & FEATURES

**Document ID:** 02  
**Filename:** `02-FINAL-SCOPE-AND-FEATURES.md`  
**Status:** FINAL / LOCKED  
**Project:** EMAIL-API-PLATFORM-BLUEPRINT  
**Primary Purpose:** Define the complete approved product scope, feature inventory, screen inventory, module boundaries, API areas, security requirements, provider scope, and explicit exclusions.

---

## 1. Document Status

This document is the authoritative scope definition for the Email API Platform.

The scope defined here is **FINAL / LOCKED**.

Future implementation work must follow this document unless the project owner explicitly authorizes a scope revision. Development documents may explain, refine, or implement these requirements, but they must not silently add or remove product scope.

### 1.1 Scope Principles

The platform must:

- Provide a professional EmailJS-style email API service.
- Allow static HTML websites and HTML/JavaScript applications to send email through HTTPS.
- Keep PHP on the server side only.
- Support Gmail and Custom SMTP as the primary email providers.
- Keep the provider architecture extensible for additional providers.
- Support projects, templates, API keys, logs, webhooks, usage, notifications, authentication, OTP, and administration.
- Be secure by default.
- Be responsive across mobile, tablet, laptop, and desktop.
- Use a modular architecture that permits future expansion without redesigning the core API.
- Prefer free or low-cost infrastructure and open-source components where practical.

---

# 2. Product Scope Summary

## 2.1 Product Definition

The Email API Platform is a self-hosted PHP-based email delivery platform that exposes a secure REST API for websites and web applications.

A client application sends an HTTPS request containing project/API credentials and email data. The server validates the request, resolves the project and provider, processes the requested template or message, sends the email through the selected provider, records the result, and optionally triggers webhook events.

### Core flow

```text
Static HTML / Web App
        |
        | HTTPS + JavaScript Fetch
        v
PHP REST API
        |
        +--> Authentication / API Key Validation
        |
        +--> Project Validation
        |
        +--> Template Engine
        |
        +--> Email Engine
        |
        +--> Provider Adapter
        |
        +--> Gmail / SMTP / Optional Provider
        |
        +--> Email Logs / Usage / Webhooks
        |
        v
Recipient Email
```

The client website does **not** need PHP.

---

# 3. Locked Product Numbers

The approved product scope contains the following fixed counts.

| Area | Locked Count |
|---|---:|
| Documentation files | 25 |
| Total screens/states | 93 |
| Core modules | 24 |
| User features | 29 |
| API feature areas | 14 |
| Security features | 25 |
| Admin features | 25 |
| Primary email providers | 2 |
| Optional email providers | 2 |

### Primary Providers

1. Gmail
2. Custom SMTP

### Optional Providers

1. Brevo
2. Mailtrap

The optional providers must use the same provider-adapter architecture as the primary providers.

---

# 4. Target Users

## 4.1 Website Developers

Developers who need to add email sending to:

- Static HTML websites
- Landing pages
- Portfolio websites
- Documentation sites
- Marketing websites
- Small business websites
- Client websites
- JavaScript applications

## 4.2 Web Application Developers

Developers building:

- SaaS applications
- Dashboards
- Admin panels
- Authentication systems
- Contact systems
- Notification systems
- Registration systems
- Password recovery workflows

## 4.3 Small Businesses

Businesses that need:

- Contact form delivery
- Notification emails
- Verification emails
- Customer communication
- Transactional messages

## 4.4 Platform Administrators

Administrators responsible for:

- User management
- Provider management
- Security monitoring
- Email monitoring
- API monitoring
- Usage monitoring
- System configuration
- Audit management

---

# 5. Core Product Capabilities

The final platform scope includes:

1. User authentication
2. Email verification
3. OTP system
4. Password recovery
5. User profile management
6. Project management
7. Gmail integration
8. SMTP integration
9. Optional provider engine
10. Email template engine
11. Template variables
12. Email sending engine
13. REST API
14. API key system
15. Webhook system
16. Email logs
17. OTP logs
18. Usage analytics
19. Rate limiting
20. Security system
21. Session management
22. Notification system
23. Admin management
24. System configuration

These 24 modules form the core implementation boundary.

---

# 6. Complete User Feature Scope

The platform provides exactly 29 approved user-facing feature areas.

## 6.1 Unlimited Projects

Users can create and manage multiple independent projects.

Each project represents a separate application, website, product, or integration.

Project isolation must apply to:

- API keys
- Templates
- Providers
- Email logs
- OTP logs
- Webhooks
- Usage
- Project settings

## 6.2 Unlimited Templates

Users can create multiple reusable email templates within projects.

Templates may contain:

- Subject
- HTML body
- Plain-text body where supported
- Variables
- Sender configuration
- Reply-to configuration
- Metadata

## 6.3 HTML Email Templates

The template system must support HTML email content.

The platform must treat template HTML as controlled email content and apply appropriate validation/sanitization policies.

## 6.4 Custom HTML

Users can create custom HTML messages rather than relying exclusively on predefined templates.

## 6.5 Template Variables

Templates may contain dynamic variables.

Example:

```text
{{name}}
{{email}}
{{verification_code}}
{{company}}
{{reset_link}}
```

Variable substitution must occur server-side.

## 6.6 Template Preview

Users can preview templates before sending.

Preview functionality must support representative variable values.

## 6.7 Duplicate Template

Users can duplicate an existing template.

The duplicate receives its own identity and can be edited independently.

## 6.8 Delete Template

Users can delete templates subject to the platform's data-retention and audit rules.

Deletion must not unintentionally delete historical email logs.

## 6.9 Gmail Connection

Users can connect Gmail through OAuth 2.0.

OAuth credentials/tokens must be handled securely and must never be exposed to client-side JavaScript.

## 6.10 SMTP Connection

Users can configure a custom SMTP provider.

Configuration may include:

- Host
- Port
- Encryption/security mode
- Username
- Password
- Authentication method where applicable
- Sender address
- Sender name

SMTP secrets must be stored securely.

## 6.11 Provider Testing

Users can test a provider connection before using it for production email.

The system must return a clear success or failure result.

## 6.12 Test Email

Users can send a test message to validate:

- Provider connection
- Sender configuration
- Template rendering
- Email delivery request

## 6.13 API Keys

Users can create and manage API keys.

API keys must be treated as credentials and protected accordingly.

## 6.14 Project-Based API Keys

API keys must belong to projects.

This ensures project-level isolation and makes credential rotation manageable.

## 6.15 REST API

The platform exposes a JSON REST API over HTTPS.

The API must use predictable:

- HTTP methods
- URLs
- status codes
- request structures
- response structures
- error formats

## 6.16 JavaScript Fetch Integration

Static websites must be able to call the API using browser JavaScript.

Example architecture:

```javascript
fetch("https://api.example.com/v1/email/send", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "X-API-Key": "YOUR_PROJECT_API_KEY"
  },
  body: JSON.stringify({
    template_id: "welcome",
    to: "user@example.com",
    variables: {
      name: "User"
    }
  })
});
```

The actual production endpoint and authentication rules are defined in the API specification document.

## 6.17 Email Sending

The platform must support transactional email sending.

Supported message concepts include:

- Recipient
- Sender
- Reply-to
- Subject
- HTML content
- Text content where supported
- Template
- Variables
- Project
- Provider
- Metadata

## 6.18 OTP Sending

The system must generate and send one-time verification codes.

OTP policies include:

- Expiration
- Attempt limits
- Rate limits
- Secure generation
- Verification status
- Logging

## 6.19 Verification Email

The system supports email verification workflows.

A verification message may contain:

- Verification code
- Verification link
- Expiration information
- User-specific variables

## 6.20 Password Reset Email

The platform supports password recovery emails.

Reset workflows must use secure, expiring tokens and must not expose sensitive account information.

## 6.21 Email Logs

Email requests and delivery attempts must be logged.

Logs may include:

- Project
- Template
- Provider
- Recipient
- Request status
- Provider status
- Error information
- Timestamp
- Request identifier

Sensitive credentials and secrets must never be logged.

## 6.22 OTP Logs

OTP events must be recorded for operational and security visibility.

Logs should support:

- Request
- Send
- Verify
- Failure
- Expiration
- Attempt count
- Timestamp

OTP values themselves must not be stored in plaintext when avoidable.

## 6.23 Usage Statistics

Users can view project-level usage information.

Possible metrics include:

- Email requests
- Successful sends
- Failed sends
- OTP requests
- API requests
- Provider usage
- Time-based activity

## 6.24 Webhooks

Users can configure webhook endpoints for supported events.

Webhook functionality includes:

- Endpoint configuration
- Event selection
- Enable/disable state
- Delivery logs
- Retry handling
- Signature verification support

## 6.25 Notifications

The platform provides system notifications for important events.

Examples:

- Provider connected
- Provider test failed
- API key created
- Security event
- Account event
- System warning

## 6.26 Profile Management

Users can manage profile information such as:

- Name
- Display information
- Email where policy permits
- Account preferences

## 6.27 Password Management

Users can:

- Change password
- Recover password
- Complete password reset workflows

## 6.28 Active Sessions

Users can view and revoke active sessions.

Session management must support security-focused revocation.

## 6.29 Security Controls

Users can manage supported security settings, including session and account-security controls.

---

# 7. Complete Screen and State Scope

The platform contains exactly 93 approved screens/states.

## 7.1 Public Screens — 10

| # | Screen |
|---:|---|
| 1 | Home |
| 2 | Features |
| 3 | How It Works |
| 4 | Providers |
| 5 | API Documentation |
| 6 | Pricing |
| 7 | FAQ |
| 8 | Contact |
| 9 | Privacy Policy |
| 10 | Terms & Conditions |

## 7.2 Authentication Screens — 7

| # | Screen |
|---:|---|
| 11 | Login |
| 12 | Register |
| 13 | Email Verification |
| 14 | OTP Verification |
| 15 | Forgot Password |
| 16 | Reset Password |
| 17 | Account Recovery |

## 7.3 User Panel Screens — 33

| # | Screen |
|---:|---|
| 18 | User Dashboard |
| 19 | Projects |
| 20 | Create Project |
| 21 | Project Overview |
| 22 | Project Settings |
| 23 | Email Services |
| 24 | Add Gmail |
| 25 | Gmail Connection Success |
| 26 | Add SMTP |
| 27 | SMTP Connection Test |
| 28 | Provider Management |
| 29 | Email Templates |
| 30 | Create Template |
| 31 | Template Editor |
| 32 | Template Preview |
| 33 | Template Variables |
| 34 | Email Send |
| 35 | Test Email |
| 36 | API Integration |
| 37 | API Keys |
| 38 | API Key Create |
| 39 | API Documentation |
| 40 | Email Logs |
| 41 | Email Log Details |
| 42 | OTP Logs |
| 43 | Usage & Statistics |
| 44 | Webhooks |
| 45 | Webhook Settings |
| 46 | Notifications |
| 47 | Profile Settings |
| 48 | Security Settings |
| 49 | Password Change |
| 50 | Active Sessions |

## 7.4 Admin Panel Screens — 37

| # | Screen |
|---:|---|
| 51 | Admin Dashboard |
| 52 | Users |
| 53 | User Details |
| 54 | Add User |
| 55 | Edit User |
| 56 | Projects |
| 57 | Project Details |
| 58 | Project Management |
| 59 | Email Providers |
| 60 | Gmail Connections |
| 61 | SMTP Connections |
| 62 | Brevo Connections |
| 63 | Mailtrap Connections |
| 64 | Email Logs |
| 65 | Email Log Details |
| 66 | OTP Logs |
| 67 | API Logs |
| 68 | Webhook Logs |
| 69 | Templates |
| 70 | Template Details |
| 71 | API Keys |
| 72 | API Usage |
| 73 | Analytics |
| 74 | System Statistics |
| 75 | Security Dashboard |
| 76 | Blocked IPs |
| 77 | Rate Limits |
| 78 | Login Attempts |
| 79 | Security/Audit Logs |
| 80 | System Settings |
| 81 | Email Settings |
| 82 | OTP Settings |
| 83 | API Settings |
| 84 | General Settings |
| 85 | Admin Accounts |
| 86 | Admin Profile |
| 87 | Admin Security |

## 7.5 System Error/State Screens — 6

| # | Screen |
|---:|---|
| 88 | 404 Not Found |
| 89 | 403 Forbidden |
| 90 | 429 Rate Limited |
| 91 | 500 Server Error |
| 92 | Maintenance |
| 93 | API Error Response |

---

# 8. Core Module Scope

Exactly 24 core modules are approved.

## 8.1 User Authentication

Responsibilities:

- Registration
- Login
- Logout
- Authentication state
- Credential validation
- Account security

## 8.2 Email Verification

Responsibilities:

- Verification token/code generation
- Verification delivery
- Verification validation
- Expiration
- Status tracking

## 8.3 OTP System

Responsibilities:

- OTP generation
- Secure storage/representation
- Sending
- Verification
- Expiration
- Attempt limits
- Rate limiting

## 8.4 Password Recovery

Responsibilities:

- Forgot-password requests
- Reset tokens
- Reset email
- Token expiration
- Password update

## 8.5 User Profile

Responsibilities:

- User information
- Preferences
- Profile updates

## 8.6 Project Management

Responsibilities:

- Create project
- Read project
- Update project
- Delete/archive project as defined
- Project settings
- Project isolation

## 8.7 Gmail Integration

Responsibilities:

- OAuth authorization
- Token storage
- Token refresh
- Gmail send operation
- Connection status
- Error handling

## 8.8 SMTP Integration

Responsibilities:

- SMTP configuration
- Secure credential storage
- Connection testing
- Message sending
- Error handling

## 8.9 Optional Provider Engine

Initial optional provider adapters:

- Brevo
- Mailtrap

The engine must be designed so additional providers can be added without rewriting the email engine.

## 8.10 Email Template Engine

Responsibilities:

- Template CRUD
- Template versions
- Rendering
- Validation
- Preview
- Template selection

## 8.11 Template Variables

Responsibilities:

- Variable parsing
- Variable validation
- Variable substitution
- Missing-variable handling
- Preview data

## 8.12 Email Sending Engine

Responsibilities:

- Request normalization
- Message construction
- Provider selection
- Send operation
- Retry policy where applicable
- Result normalization
- Logging

## 8.13 REST API

Responsibilities:

- Routing
- Request parsing
- Authentication
- Validation
- Response formatting
- Error handling
- Versioning

## 8.14 API Key System

Responsibilities:

- API key generation
- Hashing/storage
- Validation
- Rotation
- Revocation
- Project association
- Last-used tracking

## 8.15 Webhook System

Responsibilities:

- Endpoint management
- Event delivery
- Signing
- Retry policy
- Delivery logs

## 8.16 Email Logs

Responsibilities:

- Send-event logging
- Result logging
- Error logging
- Search/filtering
- Project isolation

## 8.17 OTP Logs

Responsibilities:

- OTP event logging
- Verification outcomes
- Attempt tracking
- Security visibility

## 8.18 Usage Analytics

Responsibilities:

- Usage aggregation
- Project statistics
- Time-based metrics
- Admin reporting

## 8.19 Rate Limiting

Responsibilities:

- API limits
- Login limits
- OTP limits
- IP controls
- Project controls
- Configurable policy

## 8.20 Security System

Responsibilities:

- Security controls
- Input validation
- Headers
- CORS
- Abuse protection
- Audit integration

## 8.21 Session Management

Responsibilities:

- Secure session creation
- Session rotation
- Session expiration
- Revocation
- Active-session display

## 8.22 Notification System

Responsibilities:

- User notifications
- System notifications
- Security notices
- Read/unread state

## 8.23 Admin Management

Responsibilities:

- Admin accounts
- Admin roles/policies
- Admin authentication
- Admin security
- Admin activity logging

## 8.24 System Configuration

Responsibilities:

- Global settings
- Email settings
- OTP settings
- API settings
- Maintenance mode
- Security configuration

---

# 9. API Scope

Exactly 14 API feature areas are approved.

## 9.1 Authentication API

Supports authenticated application operations according to the final API security model.

## 9.2 Send Email API

Primary transactional email endpoint family.

## 9.3 Send OTP API

Generates and sends OTP messages.

## 9.4 Verify OTP API

Validates submitted OTP codes.

## 9.5 Template API

Provides template operations.

## 9.6 Project API

Provides project operations where appropriate.

## 9.7 Provider API

Provides provider connection/configuration operations where permitted.

## 9.8 API Key Authentication

Provides credential-based API authentication for project integrations.

## 9.9 Webhook API

Provides webhook configuration and supported operations.

## 9.10 Logs API

Provides authorized access to email/API/OTP log information.

## 9.11 Usage API

Provides project usage/statistics information.

## 9.12 Health Check API

Provides service-health information suitable for monitoring.

## 9.13 Error API

Provides standardized error response structures.

## 9.14 Rate Limit API

Provides appropriate rate-limit information, including response headers and/or supported endpoint information.

Detailed endpoint paths, request schemas, response schemas, status codes, authentication headers, pagination, and examples are defined in:

`11-REST-API-SPECIFICATION.md`

---

# 10. Security Scope

Exactly 25 security feature areas are approved.

| # | Security Feature |
|---:|---|
| 1 | Password Hashing |
| 2 | Secure Sessions |
| 3 | CSRF Protection |
| 4 | XSS Protection |
| 5 | SQL Injection Protection |
| 6 | Prepared Statements |
| 7 | API Key Authentication |
| 8 | API Key Hashing |
| 9 | OAuth 2.0 |
| 10 | Encrypted OAuth Tokens |
| 11 | Encrypted SMTP Credentials |
| 12 | Rate Limiting |
| 13 | Login Attempt Protection |
| 14 | OTP Attempt Limiting |
| 15 | OTP Expiry |
| 16 | IP Blocking |
| 17 | Suspicious Activity Detection |
| 18 | Session Revocation |
| 19 | Audit Logs |
| 20 | Admin Activity Logs |
| 21 | Secure Headers |
| 22 | HTTPS Enforcement |
| 23 | CORS Control |
| 24 | Input Validation |
| 25 | Output Sanitization |

Security implementation must follow the detailed security architecture document.

---

# 11. Admin Scope

Exactly 25 admin feature areas are approved.

1. User Management
2. User Suspend/Activate
3. User Verification
4. Project Management
5. Template Management
6. Provider Management
7. Gmail Management
8. SMTP Management
9. Email Logs
10. OTP Logs
11. API Logs
12. Webhook Logs
13. API Key Management
14. Usage Monitoring
15. Analytics
16. IP Blocking
17. Rate Limit Management
18. Security Logs
19. Audit Logs
20. System Settings
21. Email Settings
22. OTP Settings
23. API Settings
24. Maintenance Mode
25. Admin Management

---

# 12. Provider Scope

## 12.1 Primary Provider: Gmail

Gmail must be implemented through OAuth 2.0 rather than requiring users to expose a Gmail password to the platform.

The provider adapter must isolate Gmail-specific behavior from the generic email engine.

## 12.2 Primary Provider: Custom SMTP

SMTP must support common secure configurations.

Expected security modes include:

- TLS
- STARTTLS where supported
- Appropriate secure SMTP configurations

The exact supported combinations depend on the SMTP library and server.

## 12.3 Optional Provider: Brevo

Brevo is an optional adapter.

It must not become a hard dependency of the core platform.

## 12.4 Optional Provider: Mailtrap

Mailtrap is an optional adapter, primarily useful for development/testing workflows.

It must remain modular.

## 12.5 Provider Adapter Contract

All providers should conform to a common internal contract conceptually similar to:

```text
connect()
validateConfiguration()
testConnection()
send()
disconnect()
getStatus()
normalizeError()
```

The exact PHP interface is defined in the backend/email-engine/provider documentation.

---

# 13. Project Scope

Projects are a central isolation boundary.

Each project may contain:

- Project metadata
- Project settings
- Providers
- Templates
- API keys
- Webhooks
- Email logs
- OTP logs
- Usage statistics

### Project isolation requirement

A user must not be able to accidentally access another project's:

- API keys
- Provider credentials
- Templates
- Logs
- Webhook settings
- Usage data

Project identifiers must be validated on every applicable request.

---

# 14. Template Scope

The template system supports:

- HTML templates
- Subject templates
- Variables
- Preview
- Duplicate
- Delete
- Versioning
- Project association
- Provider-independent content

Example:

```html
<h1>Welcome {{name}}</h1>
<p>Your account has been created successfully.</p>
```

The template engine must separate:

1. Template storage
2. Template validation
3. Variable processing
4. Rendering
5. Email transport

This prevents provider-specific logic from contaminating template functionality.

---

# 15. Email Sending Scope

The email engine must support a normalized message model.

Conceptually:

```text
EmailRequest
    |
    +-- project
    +-- provider
    +-- template
    +-- recipient(s)
    +-- sender
    +-- reply_to
    +-- subject
    +-- html
    +-- text
    +-- variables
    +-- metadata
```

The engine then converts the normalized message into the format required by the selected provider.

### Required behavior

- Validate request
- Authenticate request
- Resolve project
- Resolve provider
- Resolve template if applicable
- Render variables
- Construct email
- Send
- Capture provider result
- Log result
- Update usage
- Trigger supported webhook events
- Return normalized API response

---

# 16. OTP Scope

OTP is a security-sensitive subsystem.

Required behavior:

- Cryptographically secure OTP generation
- Configurable code length
- Expiration
- Attempt limits
- Rate limiting
- Purpose/context association
- Verification
- Used/invalidated state
- Security logging

OTP values must never be exposed in ordinary application logs.

The exact OTP configuration belongs in the system settings and OTP architecture.

---

# 17. Webhook Scope

Supported webhook concepts include:

- Endpoint URL
- Event subscriptions
- Active/inactive state
- Secret/signature
- Delivery status
- Retry attempts
- Delivery timestamps
- Error information

Potential event categories include:

```text
email.sent
email.failed
otp.sent
otp.verified
provider.connected
provider.failed
security.event
```

The exact event catalog is finalized in the webhook/API documentation.

Webhook delivery must not block the primary email request unnecessarily when asynchronous processing is available.

---

# 18. Logging Scope

The platform requires operational and security logging.

## 18.1 Email Logs

Track email activity.

## 18.2 OTP Logs

Track OTP lifecycle events.

## 18.3 API Logs

Track API requests and outcomes.

## 18.4 Webhook Logs

Track webhook delivery.

## 18.5 Security Logs

Track security-related events.

## 18.6 Admin Logs

Track privileged administrative actions.

### Logging rule

Never log:

- Passwords
- OAuth client secrets
- OAuth access tokens
- OAuth refresh tokens
- SMTP passwords
- API key plaintext
- OTP plaintext
- Other sensitive credentials

Sensitive values must be redacted, hashed, encrypted, or excluded according to their purpose.

---

# 19. Database Scope

The database model must support the approved feature set.

Principal entities include:

```text
users
user_profiles
email_verifications
otp_codes
sessions
projects
project_settings
providers
user_providers
gmail_connections
smtp_connections
templates
template_versions
api_keys
api_requests
email_logs
otp_logs
webhooks
webhook_logs
notifications
usage_statistics
login_attempts
blocked_ips
security_logs
admin_users
admin_logs
system_settings
```

The database design must preserve:

- Referential integrity
- Project isolation
- Secure credential handling
- Auditability
- Query performance
- Appropriate indexing
- Controlled retention

Detailed table definitions belong in:

- `08-DATABASE-ARCHITECTURE.md`
- `09-DATABASE-SCHEMA.md`

---

# 20. Frontend Scope

The frontend uses:

- HTML5
- CSS3
- JavaScript ES6+
- Bootstrap 5.3+
- Fetch API
- Responsive CSS
- CSS variables
- Lightweight CSS animation
- GSAP only where useful

### UI icon policy

Primary icon library:

- Lucide

Brand/technology icons:

- Simple Icons
- Official provider SVG assets where appropriate

### Typography

Primary font:

- Inter

Code/API typography:

- JetBrains Mono

The frontend must not depend on a heavy JavaScript framework unless explicitly approved later. The locked baseline is HTML/CSS/JavaScript with Bootstrap.

---

# 21. Responsive Scope

The interface must work across:

- Small mobile screens
- Large mobile screens
- Tablets
- Small laptops
- Large laptops
- Desktop monitors
- Large desktop displays

Supported interaction modes:

- Touch
- Mouse
- Keyboard

The layout must support both portrait and landscape orientations where applicable.

Important interfaces such as tables, logs, API examples, forms, navigation, dashboards, and editors must remain usable on narrow screens.

---

# 22. Accessibility Scope

The platform must target practical WCAG-aligned accessibility.

Required practices include:

- Semantic HTML
- Keyboard navigation
- Visible focus states
- Accessible labels
- Appropriate contrast
- Form error messaging
- Logical heading hierarchy
- Accessible buttons
- Accessible dialogs
- Screen-reader-friendly status messages
- Reduced-motion consideration

Accessibility must be considered during component development rather than added only at the end.

---

# 23. Asset Scope

Approved asset policy:

### Preferred formats

```text
SVG > WebP > PNG > JPG
```

### Brand assets

- Platform logo variants
- Gmail logo
- SMTP/technology representations
- Brevo logo
- Mailtrap logo
- Technology logos where needed

### Logo variants

Six main platform logo variants are required.

### Favicon/app icon sizes

Required target sizes include:

- 16×16
- 32×32
- 48×48
- 180×180
- 192×192
- 512×512

### Original assets

Where needed, the project may include original:

- Illustrations
- Empty states
- Loading graphics
- API graphics
- Security graphics
- Email graphics

---

# 24. Performance Scope

The platform should be designed for efficient operation.

### Frontend

- Minimize unnecessary JavaScript
- Lazy-load non-critical assets
- Optimize images
- Avoid excessive animation
- Reduce layout shifts
- Use efficient API requests

### Backend

- Use PDO/prepared statements
- Add appropriate database indexes
- Avoid unnecessary queries
- Normalize reusable service logic
- Use provider adapters
- Keep logging efficient
- Avoid blocking operations where asynchronous processing is appropriate

### Email processing

The architecture should allow future queue/worker processing without redesigning the public API.

---

# 25. Security Boundaries

The client application must never receive:

- Gmail OAuth secrets
- OAuth refresh tokens
- SMTP passwords
- Internal provider credentials
- Database credentials
- Server secrets
- Admin credentials

The client should receive only the minimum information required to perform its authorized API operations.

### Important distinction

A project API key is an integration credential. It must not be treated as a replacement for internal provider credentials.

Provider credentials remain server-side.

---

# 26. Authentication Scope

User authentication includes:

- Registration
- Login
- Logout
- Email verification
- OTP verification where applicable
- Forgot password
- Reset password
- Account recovery
- Session management

Authentication must use secure server-side session handling.

Passwords must be hashed using modern password hashing mechanisms available in PHP.

---

# 27. API Authentication Scope

Project API access must use API credentials.

The platform must support:

- API key generation
- Secure storage
- Validation
- Revocation
- Rotation
- Project association
- Last-used information
- Usage tracking

Plaintext API keys should not be stored in the database when a secure hash-based verification design can be used.

---

# 28. Rate-Limiting Scope

Rate limiting applies to security-sensitive and abuse-prone operations.

Minimum areas:

- Login
- Registration where appropriate
- OTP send
- OTP verification
- Password recovery
- Email send API
- API requests
- Webhooks where relevant

Rate limits may consider:

- IP
- User
- Project
- API key
- Endpoint
- Time window

Administrative configuration belongs in the admin/system settings layer.

---

# 29. Error Handling Scope

The platform must use consistent errors.

System states include:

- 404
- 403
- 429
- 500
- Maintenance
- API error responses

API errors should provide a stable structure such as:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The request is invalid.",
    "details": {}
  },
  "request_id": "req_..."
}
```

Sensitive internal error details must not be exposed to clients.

---

# 30. Notifications Scope

Notifications support operational and security feedback.

Examples:

- Successful provider connection
- Provider connection failure
- API key creation
- Security event
- Account event
- System warning
- Webhook failure

Notifications should support:

- Read/unread state
- Timestamp
- Type
- Message
- Optional action/reference

---

# 31. Admin Scope Boundaries

Administrators can manage the platform, but admin capabilities must be separated from ordinary user capabilities.

Admin access must require:

- Dedicated admin authentication policy
- Strong security controls
- Session protection
- Audit logging
- Role/policy enforcement where implemented

Administrative actions must be traceable.

---

# 32. Explicitly Out of Scope

The following are not part of the locked initial product scope unless separately approved.

## 32.1 Full Marketing Automation

Not included:

- Complex campaign builder
- Marketing journeys
- Customer segmentation
- Marketing automation workflows

## 32.2 Full Newsletter Platform

Not included:

- Subscriber management suite
- Newsletter campaign scheduling
- Mailing-list marketing engine
- Advanced campaign analytics

## 32.3 Native Mobile Applications

Not included in the initial scope:

- Native Android app
- Native iOS app

The web application must remain responsive and mobile-friendly.

## 32.4 Desktop Applications

Not included:

- Native Windows app
- Native macOS app
- Native Linux desktop app

## 32.5 Full Visual Drag-and-Drop Email Builder

The initial template system supports HTML templates and editing, but a complex commercial-grade drag-and-drop email designer is outside the locked scope.

## 32.6 Advanced AI Email Generation

Not included:

- AI copywriter
- AI template generation
- AI spam optimization
- AI personalization engine

## 32.7 Full CRM

Not included:

- Customer relationship management
- Sales pipeline
- Contact scoring
- Sales automation

## 32.8 Full Billing Platform

Pricing/public pricing may be displayed, but a full commercial billing/subscription platform is not part of the initial locked implementation unless explicitly added later.

## 32.9 Multi-Region Infrastructure

The initial product is not required to provide:

- Multi-region deployment
- Global traffic routing
- Geo-distributed databases
- Multi-region failover

The architecture should not prevent future support.

## 32.10 Enterprise SSO

Enterprise SSO protocols such as SAML/OIDC-based organization login are outside the initial scope unless separately approved.

## 32.11 Advanced Organization/Team Management

The initial scope is centered on individual user accounts and project isolation.

A complete organization/team/role hierarchy is not required unless separately approved.

## 32.12 Guaranteed Email Delivery

The platform can submit email to a provider and report provider/API outcomes, but it cannot guarantee inbox placement or recipient-side delivery beyond what the provider reports.

---

# 33. Scope Invariants

The following must remain true throughout development.

## Invariant 1 — Client Independence

A static HTML website must be able to use the service without installing PHP on the client website.

## Invariant 2 — Server-Side Secrets

Provider credentials remain server-side.

## Invariant 3 — Provider Modularity

Adding a provider must not require rewriting the core email engine.

## Invariant 4 — Project Isolation

Project data and credentials must remain isolated.

## Invariant 5 — API Stability

The public API must use versioning and predictable response contracts.

## Invariant 6 — Security by Default

Security controls cannot be treated as optional decoration.

## Invariant 7 — Logging Without Secrets

Operational visibility must never require storing plaintext credentials.

## Invariant 8 — Responsive UI

All major user and admin interfaces must remain usable on mobile.

## Invariant 9 — Documentation Consistency

All subsequent documents must follow this locked scope.

## Invariant 10 — No Silent Feature Creep

Developers must not introduce major new product features simply because they are technically convenient.

---

# 34. Feature-to-Module Mapping

| Feature | Primary Module |
|---|---|
| Authentication | User Authentication |
| Email verification | Email Verification |
| OTP | OTP System |
| Password reset | Password Recovery |
| Profile | User Profile |
| Projects | Project Management |
| Gmail | Gmail Integration |
| SMTP | SMTP Integration |
| Brevo/Mailtrap | Optional Provider Engine |
| Templates | Email Template Engine |
| Variables | Template Variables |
| Email sending | Email Sending Engine |
| REST API | REST API |
| API keys | API Key System |
| Webhooks | Webhook System |
| Email logs | Email Logs |
| OTP logs | OTP Logs |
| Usage | Usage Analytics |
| Rate limits | Rate Limiting |
| Security | Security System |
| Sessions | Session Management |
| Notifications | Notification System |
| Admin | Admin Management |
| Global configuration | System Configuration |

---

# 35. Feature-to-Documentation Mapping

| Scope Area | Primary Document |
|---|---|
| Product overview | `01-PROJECT-OVERVIEW.md` |
| Final scope | `02-FINAL-SCOPE-AND-FEATURES.md` |
| Architecture | `03-SYSTEM-ARCHITECTURE.md` |
| Technology | `04-TECHNOLOGY-STACK.md` |
| UI/UX | `05-UI-UX-DESIGN-SYSTEM.md` |
| Screens/navigation | `06-SCREENS-AND-NAVIGATION.md` |
| Assets | `07-ASSETS-ICONS-FONTS-LOGOS.md` |
| DB architecture | `08-DATABASE-ARCHITECTURE.md` |
| DB schema | `09-DATABASE-SCHEMA.md` |
| PHP backend | `10-BACKEND-PHP-ARCHITECTURE.md` |
| REST API | `11-REST-API-SPECIFICATION.md` |
| Auth/OTP | `12-AUTHENTICATION-AND-OTP.md` |
| Email engine | `13-EMAIL-ENGINE.md` |
| Providers | `14-EMAIL-PROVIDERS.md` |
| Templates | `15-TEMPLATE-ENGINE.md` |
| Projects/API keys/webhooks | `16-PROJECTS-API-KEYS-WEBHOOKS.md` |
| User panel | `17-USER-PANEL.md` |
| Admin panel | `18-ADMIN-PANEL.md` |
| Security | `19-SECURITY-ARCHITECTURE.md` |
| Frontend | `20-FRONTEND-DEVELOPMENT-GUIDE.md` |
| Responsive/accessibility/performance | `21-RESPONSIVE-ACCESSIBILITY-PERFORMANCE.md` |
| Testing/QA/errors | `22-TESTING-QA-AND-ERROR-HANDLING.md` |
| Deployment/maintenance | `23-DEPLOYMENT-MAINTENANCE-AND-DEVELOPER-GUIDE.md` |
| Development checklist | `24-DEVELOPMENT-RULES-CHECKLIST.md` |

---

# 36. Definition of Scope Completion

The scope is considered fully implemented only when:

- All approved core modules exist.
- All approved user features are implemented.
- All required screens/states exist.
- Gmail integration works according to the provider specification.
- SMTP integration works according to the provider specification.
- Optional provider adapters are implemented according to the approved provider plan.
- Templates render correctly.
- Variables are processed safely.
- Email sending works through the normalized email engine.
- API keys work securely.
- REST endpoints follow the approved contract.
- Logs are recorded without exposing secrets.
- OTP workflows are secure and rate-limited.
- Webhooks operate according to the supported event model.
- Usage statistics are available.
- User sessions are protected.
- Security controls are implemented.
- Admin functions are protected and audited.
- Responsive interfaces work across target screen sizes.
- Accessibility requirements are addressed.
- Error states are implemented.
- Testing covers normal, invalid, unauthorized, abusive, and failure scenarios.
- Deployment documentation is complete.

---

# 37. Scope Acceptance Checklist

## Product

- [ ] Product identity approved
- [ ] Target users approved
- [ ] Main use cases approved
- [ ] Scope boundaries approved

## Screens

- [ ] 10 public screens
- [ ] 7 authentication screens
- [ ] 33 user screens
- [ ] 37 admin screens
- [ ] 6 system/error states
- [ ] Total = 93

## Modules

- [ ] 24 core modules defined
- [ ] Module responsibilities documented
- [ ] Module boundaries preserved

## Features

- [ ] 29 user features
- [ ] 14 API areas
- [ ] 25 security features
- [ ] 25 admin features

## Providers

- [ ] Gmail
- [ ] Custom SMTP
- [ ] Brevo
- [ ] Mailtrap
- [ ] Provider adapter architecture

## Security

- [ ] Authentication security
- [ ] API key protection
- [ ] OAuth security
- [ ] SMTP credential protection
- [ ] OTP security
- [ ] Rate limiting
- [ ] Session protection
- [ ] Audit logging
- [ ] Secure headers
- [ ] HTTPS
- [ ] CORS
- [ ] Input validation
- [ ] Output sanitization

## UI

- [ ] Responsive design
- [ ] Accessibility
- [ ] Inter typography
- [ ] JetBrains Mono for code/API
- [ ] Lucide icons
- [ ] Approved logo/asset strategy

---

# 38. Final Scope Declaration

This document establishes the approved product scope for the Email API Platform.

The product is intentionally focused:

> **A secure, self-hosted, developer-friendly email API platform that allows static websites and web applications to send transactional email through Gmail or SMTP without requiring PHP on the client website.**

The architecture must remain modular, secure, documented, and extensible.

The approved initial scope is:

```text
93 Screens / States
24 Core Modules
29 User Features
14 API Feature Areas
25 Security Features
25 Admin Features
2 Primary Providers
2 Optional Providers
25 Documentation Files
```

These numbers are the project baseline.

Any future change to these numbers or to the major product boundaries requires explicit scope approval.

---

# 39. Next Document

The next document in the locked documentation sequence is:

```text
03-SYSTEM-ARCHITECTURE.md
```

That document will define the complete system architecture, including frontend/client flow, PHP application layers, REST API flow, authentication boundaries, provider adapters, email engine, database interaction, logging, webhooks, security boundaries, deployment topology, and extensibility model.

**Status: FINAL / LOCKED**
