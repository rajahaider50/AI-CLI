# 13 — Email Engine

**Project:** Email API Platform  
**Document:** `13-EMAIL-ENGINE.md`  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Audience:** Backend developers, frontend developers, QA, security reviewers, DevOps  
**Related documents:** 00–12 and 14–24 in the master blueprint

---

## 1. Purpose

This document defines the authoritative architecture and operating contract for the Email Engine.

The Email Engine is the central application service responsible for turning an approved email request into a controlled delivery attempt through a configured provider such as Gmail, SMTP, or a future provider adapter.

The Email Engine is intentionally separated from:

- REST controllers;
- authentication;
- template editing UI;
- database repositories;
- provider-specific SDK details;
- webhooks;
- frontend code.

Its responsibility is to provide one consistent email-sending pipeline regardless of the provider selected.

Core responsibilities:

- accept normalized email-send requests;
- validate sending context;
- resolve project/provider configuration;
- render templates;
- validate recipients and sender identity;
- construct the final message;
- select a provider adapter;
- send through the provider;
- normalize provider results/errors;
- create email logs;
- support idempotency;
- expose delivery state;
- trigger webhook events;
- record usage;
- enforce sending security and limits.

---

# 2. Locked Email Engine Principles

1. The Email Engine is the single application-level entry point for email delivery.
2. REST controllers must not send email directly.
3. Template rendering must happen before provider delivery.
4. Provider-specific code must remain behind adapters.
5. Provider credentials never leave the provider/security layer.
6. Sender identity must be validated against project/provider policy.
7. Recipient addresses must be validated before delivery.
8. Email content must never be executed as server-side code.
9. Email-send requests must be logged safely.
10. Secrets must never appear in email logs.
11. Provider exceptions must be normalized into platform-level errors.
12. Timeouts must be bounded.
13. Rate limits must be enforced before expensive provider operations.
14. Idempotency must protect supported send operations from accidental duplicates.
15. Database state must remain consistent with the actual send lifecycle.
16. Failed sends must be distinguishable from queued, processing, and successful sends.
17. The engine must support synchronous sending and remain compatible with future background processing.
18. Webhooks must be emitted from normalized delivery events, not provider-specific internals.
19. Usage counters must be updated consistently.
20. The engine must remain provider-neutral.
21. All security-sensitive behavior must be centrally enforced.
22. The engine must not bypass the authentication/authorization architecture.
23. The engine must be testable without contacting real providers.
24. The engine must be observable through request IDs and message IDs.
25. Future provider adapters must not require changes to the core email API contract.

---

# 3. High-Level Architecture

```text
REST API / Dashboard
        │
        ▼
Email Controller
        │
        ▼
Email Send Service
        │
        ├── Authorization / Project Policy
        ├── Rate Limit Service
        ├── Idempotency Service
        ├── Template Service
        ├── Validation Service
        ├── Provider Resolver
        └── Usage Service
                │
                ▼
          Email Engine
                │
        ┌───────┼────────┐
        │       │        │
     Message  Logging  Events
     Builder    │        │
        │       │        └── Webhooks
        ▼       ▼
 Provider Adapter
        │
 ┌──────┼───────────────┐
 │      │               │
Gmail  SMTP       Optional Providers
 │      │               │
 └──────┼───────────────┘
        ▼
  External Mail Service
        │
        ▼
    Recipient
```

---

# 4. Email Lifecycle

The canonical lifecycle is:

```text
REQUESTED
   ↓
VALIDATING
   ↓
PREPARED
   ↓
QUEUED* / PROCESSING
   ↓
SENDING
   ↓
SENT
```

Failure states may include:

```text
FAILED
CANCELLED
```

`QUEUED` is architecture-compatible even when the initial deployment performs synchronous sending.

The deployed system must clearly distinguish:

- accepted;
- processing;
- sent;
- failed.

---

# 5. Message Identity

Every send operation should receive an internal message identifier.

Example:

```text
msg_01JEXAMPLE123
```

The message ID is used to correlate:

```text
API request
→ email log
→ provider attempt
→ webhook
→ usage event
```

Provider-specific message IDs may also be stored separately.

Example:

```text
message_id: msg_...
provider_message_id: <provider-id>
```

Never use a provider message ID as the only internal identifier.

---

# 6. Request ID vs Message ID

These are separate concepts.

### Request ID

Identifies the HTTP/API operation.

```text
req_...
```

### Message ID

Identifies the email delivery object.

```text
msg_...
```

One request may create:

- one message;
- multiple recipient deliveries;
- a batch according to the platform's supported semantics.

The relationship must be recorded.

---

# 7. Canonical Email Send Input

The Email Engine should receive a normalized internal DTO rather than a raw HTTP request.

Conceptual structure:

```text
EmailSendRequest
├── project_id
├── request_id
├── idempotency_key
├── provider_id
├── from
├── to[]
├── cc[]
├── bcc[]
├── reply_to
├── subject
├── html
├── text
├── template_id
├── variables
├── attachments[]
├── metadata
└── options
```

The DTO should contain only validated values.

---

# 8. Template-Based Send

Preferred flow:

```text
API request
   ↓
template_id + variables
   ↓
Load active template/version
   ↓
Validate required variables
   ↓
Render subject
   ↓
Render HTML
   ↓
Render text fallback
   ↓
Create normalized EmailSendRequest
   ↓
Provider delivery
```

Template rendering belongs to the Template Engine, while the Email Engine owns the final delivery pipeline.

---

# 9. Direct HTML Send

The API may support direct content:

```json
{
  "to": [
    {
      "email": "recipient@example.com",
      "name": "John"
    }
  ],
  "subject": "Welcome",
  "html": "<h1>Hello John</h1>",
  "text": "Hello John"
}
```

Direct content must still pass:

- validation;
- size limits;
- sender policy;
- recipient policy;
- rate limits;
- security checks;
- logging;
- provider selection.

HTML is email content, not executable server code.

---

# 10. Subject Rendering

Subjects may contain template variables:

```text
Welcome {{name}}
```

The rendered result must be:

- bounded in length;
- safely encoded;
- free from header injection;
- normalized before provider submission.

Never permit CR/LF injection into email headers.

---

# 11. Recipient Processing

Supported recipient groups:

```text
to
cc
bcc
```

Each recipient may contain:

```json
{
  "email": "john@example.com",
  "name": "John"
}
```

The engine must:

1. validate email syntax;
2. normalize safe representations;
3. reject malformed recipients;
4. enforce recipient-count limits;
5. prevent header injection;
6. apply project/provider policies.

---

# 12. Sender Identity

The sender is security-sensitive.

The engine must not blindly trust:

```json
{
  "from": {
    "email": "anything@example.com"
  }
}
```

Instead it resolves the sender through:

```text
Project policy
      ↓
Provider configuration
      ↓
Allowed sender identity
      ↓
Email Engine
```

For Gmail, the sender must comply with the authorized account/provider capabilities.

For SMTP, sender policy must be consistent with the configured SMTP account/server.

---

# 13. Reply-To

Optional:

```json
{
  "reply_to": {
    "email": "support@example.com",
    "name": "Support"
  }
}
```

Validate reply-to addresses separately.

Never permit arbitrary header injection through `reply_to`.

---

# 14. Provider Resolution

Provider selection follows:

```text
Explicit provider_id
       ↓
Validate provider belongs to project
       ↓
Validate provider active
       ↓
Validate provider supports email operation
       ↓
Use adapter
```

If no provider is explicitly selected:

```text
Project default provider
       ↓
Provider Resolver
       ↓
Active provider
```

If no valid provider exists:

```text
PROVIDER_NOT_CONFIGURED
```

---

# 15. Provider Adapter Contract

Every provider adapter must implement a consistent contract.

Conceptually:

```text
ProviderAdapter
├── getType()
├── validateConfiguration()
├── testConnection()
├── send(EmailMessage)
├── normalizeError()
└── getCapabilities()
```

The exact PHP interface is defined by the backend implementation, but the contract must remain provider-neutral.

---

# 16. Gmail Adapter

The Gmail adapter handles Gmail-specific authorization and delivery.

Responsibilities:

- obtain authorized account configuration;
- use encrypted OAuth credentials;
- refresh access tokens where required;
- construct provider-compatible messages;
- send through the approved Gmail API/transport;
- normalize provider responses;
- report provider message ID;
- never expose OAuth tokens.

The Email Engine must not contain Gmail OAuth implementation details.

---

# 17. SMTP Adapter

The SMTP adapter handles:

- host;
- port;
- encryption;
- username;
- encrypted password;
- connection;
- authentication;
- message transmission;
- connection timeout;
- error normalization.

PHPMailer is the approved email transport library from the technology stack.

SMTP credentials must be decrypted only at the point required for provider communication and must never be logged.

---

# 18. Optional Provider Adapters

Optional providers such as Brevo and Mailtrap remain behind the same adapter contract.

Adding a provider should require:

1. adapter implementation;
2. provider configuration model;
3. provider-specific validation;
4. capability declaration;
5. error normalization;
6. tests;
7. admin/provider UI integration;
8. documentation.

The core send pipeline must not be rewritten.

---

# 19. Email Message Builder

The Message Builder transforms normalized content into a provider-neutral message object.

Responsibilities:

- subject;
- sender;
- recipients;
- reply-to;
- HTML;
- plain text;
- attachments;
- safe headers.

It must not:

- access raw HTTP input;
- query arbitrary database tables;
- decide project authorization;
- contain provider SDK code.

---

# 20. HTML Email Safety

Email HTML is not the same as application HTML.

The platform should support normal email HTML while preventing server-side code execution.

Never execute:

```text
<?php ... ?>
```

or any dynamic server-side template code embedded in email content.

Do not allow template variables to invoke arbitrary methods or functions.

The template engine must use a controlled variable substitution/rendering model.

---

# 21. Plain-Text Fallback

Where possible, HTML email should have a plain-text representation.

Options:

1. explicit `text` content;
2. controlled HTML-to-text conversion;
3. template-provided text version.

The fallback should remain readable and should not expose raw HTML markup unnecessarily.

---

# 22. Email Headers

Only approved headers may be generated.

Examples:

```text
From
To
Cc
Bcc
Reply-To
Subject
Message-ID
Date
```

Provider adapters may add transport-required headers.

Clients must not be allowed to inject arbitrary SMTP/system headers without explicit security review.

---

# 23. Header Injection Protection

Reject or safely normalize untrusted values containing:

```text
\r
\n
```

especially in:

- subject;
- sender name;
- sender email;
- recipient name;
- reply-to.

This is mandatory.

---

# 24. Attachments

If enabled, attachments are represented internally as:

```text
Attachment
├── filename
├── content
├── content_type
└── disposition
```

Security controls:

- maximum total size;
- maximum individual size;
- maximum count;
- MIME validation;
- decoded size validation;
- request-body limits;
- memory limits;
- timeout controls.

Do not trust a client-provided MIME type without validation.

---

# 25. Attachment Policy

The initial platform may keep attachment support restricted or disabled until explicitly enabled.

If enabled:

- dangerous/unexpected formats may be blocked;
- executable content should be treated as high risk;
- filenames must be sanitized;
- path traversal must be impossible;
- attachments must never be written to arbitrary filesystem locations.

Recommended safe filename normalization:

```text
invoice.pdf
```

Not:

```text
../../invoice.php
```

---

# 26. Template Variables

Variables are resolved before delivery.

Example:

```html
<h1>Hello {{name}}</h1>
<p>Your code is {{otp}}</p>
```

Input:

```json
{
  "name": "John",
  "otp": "123456"
}
```

Output:

```html
<h1>Hello John</h1>
<p>Your code is 123456</p>
```

Variable processing must not evaluate arbitrary expressions.

---

# 27. Required Variables

Templates may declare required variables.

If a required variable is missing:

```text
TEMPLATE_VARIABLE_INVALID
```

The engine must stop before provider delivery.

Never send a partially rendered security-sensitive message unless explicitly permitted by the template contract.

---

# 28. Provider Capability Model

Providers may differ in capabilities.

Example:

```text
supports_html
supports_text
supports_attachments
supports_cc
supports_bcc
supports_reply_to
supports_oauth
supports_test_connection
```

The Email Engine should check capability compatibility before sending.

If an unsupported feature is requested:

```text
PROVIDER_CAPABILITY_UNSUPPORTED
```

The error must be normalized and safe.

---

# 29. Email Send Validation Pipeline

Canonical order:

```text
Authenticate
    ↓
Authorize project
    ↓
Validate API request
    ↓
Apply rate limits
    ↓
Validate idempotency
    ↓
Resolve project
    ↓
Resolve provider
    ↓
Validate provider status
    ↓
Load/render template
    ↓
Validate sender
    ↓
Validate recipients
    ↓
Validate content
    ↓
Validate attachments
    ↓
Build message
    ↓
Create/prepare log
    ↓
Send
    ↓
Normalize result
    ↓
Update log
    ↓
Usage update
    ↓
Webhook event
    ↓
Return response
```

---

# 30. Pre-Send Checks

Before contacting the provider, verify:

- project exists;
- project is active;
- API key/session is authorized;
- required scope exists;
- provider exists;
- provider is active;
- provider configuration is valid;
- sender is permitted;
- recipients are valid;
- message content is valid;
- size limits are satisfied;
- rate limits permit sending;
- idempotency state permits sending.

---

# 31. Rate Limiting

Email sending is an abuse-sensitive operation.

Limits may apply to:

- API key;
- project;
- user;
- IP;
- recipient;
- provider;
- time window.

Example conceptual policy:

```text
project email limit
+
API key limit
+
IP limit
```

The exact limits are configuration, not hard-coded business logic.

---

# 32. Quota vs Rate Limit

These are different.

### Rate limit

Controls short-term request frequency.

Example:

```text
100 requests/minute
```

### Usage/quota limit

Controls total permitted usage.

Example:

```text
10,000 emails/month
```

The engine must keep the concepts separate.

---

# 33. Idempotency

Email sending can create expensive and user-visible duplicates.

Support:

```http
Idempotency-Key: unique-value
```

The key is scoped to the authenticated project/API context.

Flow:

```text
Receive key
   ↓
Lookup existing operation
   ↓
Same request?
 ┌─┴─────────┐
Yes          No
 │            │
Return       Create
original     operation
result
```

If the same key is reused with a materially different payload:

```text
409 CONFLICT
```

---

# 34. Email Log Lifecycle

Recommended log states:

```text
requested
processing
sent
failed
cancelled
```

Additional delivery states can be introduced later.

The log should record:

- message ID;
- request ID;
- project;
- provider;
- template;
- sender;
- recipient metadata;
- status;
- timestamps;
- provider message ID;
- normalized error code;
- safe error summary;
- metadata;
- duration.

---

# 35. Sensitive Email Log Data

Never log:

- API key;
- password;
- OAuth token;
- SMTP password;
- session secret;
- raw OTP;
- provider credential;
- arbitrary authorization header.

Message body storage must follow the platform's privacy/retention policy.

If full content is stored, access must be tightly controlled.

---

# 36. Recipient Privacy in Logs

The logging layer should avoid unnecessarily exposing sensitive recipient data.

Where appropriate, UI/log views may mask:

```text
j***@example.com
```

while authorized backend processes retain the minimum necessary information.

Do not expose BCC recipients to unauthorized users or webhook consumers.

---

# 37. Send Result Model

Provider-neutral result:

```text
EmailSendResult
├── success
├── status
├── message_id
├── provider_message_id
├── provider_type
├── accepted_count
├── rejected_count
├── error_code
├── error_message
└── metadata
```

The public API serializer decides which fields are safe to expose.

---

# 38. Provider Error Normalization

Provider errors must map to platform errors.

Example:

```text
Gmail auth error
        ↓
PROVIDER_AUTH_FAILED

SMTP timeout
        ↓
PROVIDER_TIMEOUT

Invalid recipient
        ↓
INVALID_RECIPIENT

Provider quota
        ↓
PROVIDER_RATE_LIMITED / PROVIDER_QUOTA_EXCEEDED
```

Do not return raw PHPMailer/Gmail SDK exceptions to API clients.

---

# 39. Retry Policy

Not every failure should be retried.

### Potentially retryable

- network timeout;
- temporary provider outage;
- temporary connection failure;
- provider 5xx-like failure;
- rate-limit response after appropriate delay.

### Usually non-retryable

- invalid recipient;
- invalid sender;
- authentication configuration failure;
- invalid template;
- malformed message;
- policy rejection.

Retries must be bounded.

---

# 40. Synchronous Sending

The initial deployment may perform:

```text
API request
   ↓
Email Engine
   ↓
Provider
   ↓
Response
```

Advantages:

- simpler deployment;
- no mandatory queue infrastructure;
- easier initial operations;
- immediate result.

The architecture must still isolate the send operation so it can later be moved to a worker.

---

# 41. Queue-Compatible Design

A future queue can use:

```text
API
 ↓
Create message record
 ↓
Queue job
 ↓
Worker
 ↓
Email Engine
 ↓
Provider
```

The Email Engine itself should not depend on the existence of Redis, RabbitMQ, Kafka, or another mandatory queue.

This preserves the locked technology decision.

---

# 42. Background Processing

If future background processing is enabled:

- message state must be transactional;
- jobs must be idempotent;
- retries must be bounded;
- duplicate sends must be prevented;
- worker failures must be recoverable;
- provider timeouts must be bounded;
- logs must remain correlated with message/request IDs.

---

# 43. Timeouts

External provider operations must use bounded timeouts.

Separate where appropriate:

```text
DNS/connect timeout
TLS/connection timeout
write timeout
read timeout
overall operation timeout
```

Do not allow an external provider to block a PHP worker indefinitely.

---

# 44. Connection Management

SMTP connections must be managed safely.

The implementation must:

- configure connection timeout;
- configure encryption correctly;
- authenticate securely;
- close resources when appropriate;
- avoid leaking connections;
- avoid logging credentials.

Gmail API calls must use appropriate HTTP client timeouts and token refresh behavior.

---

# 45. Provider Health

Provider status may be:

```text
connected
disconnected
error
disabled
unknown
```

A provider test should not be performed on every email send unless explicitly required.

Routine sending should rely on stored configuration and bounded provider communication.

---

# 46. Provider Configuration Validation

Before activation:

```text
Validate credentials
        ↓
Validate connection
        ↓
Validate sender
        ↓
Mark provider active
```

A provider with invalid credentials should not silently become the default provider.

---

# 47. Default Provider

Each project may define one default provider.

Rules:

- default must belong to project;
- default must be active;
- default must support required email capability;
- deleting the default requires selecting another valid provider or leaving project without a default.

The Email Engine must return a controlled error when no valid provider is available.

---

# 48. Template and Provider Relationship

Templates should remain provider-neutral.

A template defines:

- name;
- subject;
- HTML;
- text;
- variables.

Provider selection occurs at send time unless a project explicitly defines a provider association.

This keeps templates reusable across Gmail and SMTP.

---

# 49. Test Email

Endpoint:

```http
POST /api/v1/projects/{project_id}/providers/{provider_id}/test
```

A test email should:

- verify provider configuration;
- use a controlled subject;
- use a controlled message;
- obey rate limits;
- be logged as a test operation;
- not accidentally trigger production transactional workflows.

Example subject:

```text
Email API Platform — Provider Test
```

---

# 50. OTP Integration

OTP sending uses the same Email Engine.

Flow:

```text
OTP Service
    ↓
Generate secure OTP
    ↓
Select OTP template
    ↓
Render variables
    ↓
Email Engine
    ↓
Provider Adapter
    ↓
Recipient
```

The OTP value must never appear in engine debug logs.

---

# 51. Verification Email Integration

Email verification also uses the Email Engine.

Flow:

```text
Authentication Service
       ↓
Generate verification token
       ↓
Template Engine
       ↓
Email Engine
       ↓
Provider
```

The raw verification token must not be written to logs.

---

# 52. Password Reset Integration

Password reset follows the same architecture:

```text
Password Recovery
      ↓
Generate reset token
      ↓
Template
      ↓
Email Engine
      ↓
Provider
```

The reset token is secret and must be protected.

---

# 53. Webhook Events

After a normalized email state change, the engine may emit:

```text
email.requested
email.processing
email.sent
email.failed
```

The webhook system handles:

- signing;
- retries;
- delivery;
- logs.

The Email Engine emits a domain event; it does not implement webhook HTTP delivery directly.

---

# 54. Usage Events

Successful and failed operations should update usage statistics.

Examples:

```text
email.requested
email.sent
email.failed
```

Usage counting must have a clearly defined semantic.

Do not count one email multiple times because of internal retry attempts unless the product explicitly defines attempts as usage.

---

# 55. Transaction Strategy

A send operation may involve:

```text
database
+
external provider
```

These cannot be placed inside one true distributed transaction.

Therefore:

1. create/prepare local state;
2. perform provider operation;
3. record normalized result;
4. update related usage/events;
5. commit local state appropriately.

The implementation must tolerate provider success followed by a local failure and provide reconciliation/observability mechanisms where necessary.

---

# 56. Failure Scenario: Provider Succeeds, Database Update Fails

Potential state:

```text
Provider → SENT
Database → still PROCESSING
```

The system must not assume that a local database failure means the provider did not send.

Use:

- provider message ID;
- request ID;
- message ID;
- safe reconciliation strategy;
- operational logs.

Do not automatically resend blindly after uncertain outcomes.

This is a critical duplicate-email prevention rule.

---

# 57. Failure Scenario: Network Timeout

A timeout may mean:

```text
provider did not receive message
```

or:

```text
provider received message but response was lost
```

Therefore, blindly retrying can duplicate email.

Retry policy must consider provider semantics and idempotency capabilities.

---

# 58. Email Status Semantics

### `requested`

The platform accepted the request.

### `processing`

The engine is preparing or sending.

### `sent`

The provider accepted the message according to the platform's delivery contract.

### `failed`

The engine determined the operation failed.

### `cancelled`

The operation was intentionally stopped before delivery where cancellation is supported.

Do not claim final mailbox delivery unless the provider supplies a verified delivery event.

---

# 59. Delivery vs Acceptance

The platform should distinguish:

```text
provider accepted
```

from:

```text
recipient mailbox delivered
```

The Email Engine primarily manages provider submission.

Future provider/webhook integrations may introduce:

```text
delivered
bounced
complained
opened
clicked
```

These are separate delivery events and should not be falsely inferred from a successful SMTP/API submission.

---

# 60. Email Metadata

Clients may send safe application metadata:

```json
{
  "metadata": {
    "order_id": "ORD-123",
    "user_reference": "USR-456"
  }
}
```

Metadata must be:

- size-limited;
- validated;
- non-executable;
- safe for logging;
- protected from sensitive secret storage.

Do not use arbitrary metadata as an authorization mechanism.

---

# 61. Message Tags

If supported in the future, tags may assist:

- analytics;
- usage;
- reporting;
- filtering.

Tags must remain bounded and validated.

They must not contain credentials or unrestricted sensitive data.

---

# 62. Email Content Privacy

Email bodies can contain personal or confidential information.

The platform should provide configurable retention behavior.

Possible policy:

```text
Store metadata by default
Store content only when explicitly required/configured
```

If content is stored:

- restrict dashboard access;
- protect admin access;
- apply retention;
- redact sensitive fields where possible;
- never expose content through unauthorized APIs.

---

# 63. HTML Sanitization

The platform must distinguish between:

1. email HTML that is intentionally authored by a trusted project owner;
2. HTML supplied by an untrusted public client.

For untrusted content, the platform may need a sanitization policy.

At minimum:

- no server-side execution;
- no PHP execution;
- no arbitrary filesystem operations;
- no template expression execution.

The exact HTML sanitization policy must remain compatible with legitimate email markup.

---

# 64. Email Size Limits

Define limits for:

- subject;
- HTML;
- text;
- recipient count;
- headers;
- metadata;
- attachment count;
- attachment size;
- total message size.

Reject oversized messages before provider communication.

Example error:

```text
PAYLOAD_TOO_LARGE
```

---

# 65. API-to-Engine Boundary

The controller should perform:

```text
HTTP parsing
authentication context
basic validation
DTO creation
```

Then:

```text
EmailSendService::send(...)
```

takes responsibility for business rules.

Avoid:

```php
// Controller
$phpMailer->send();
```

Preferred:

```php
$result = $emailService->send($request);
```

The service then delegates to the engine/provider layer.

---

# 66. Recommended PHP Service Structure

Conceptual:

```text
src/
├── Email/
│   ├── EmailEngine.php
│   ├── EmailSendService.php
│   ├── EmailMessage.php
│   ├── EmailSendRequest.php
│   ├── EmailSendResult.php
│   ├── MessageBuilder.php
│   ├── ProviderResolver.php
│   ├── Provider/
│   │   ├── ProviderAdapterInterface.php
│   │   ├── GmailProvider.php
│   │   ├── SmtpProvider.php
│   │   └── ...
│   └── Validation/
│       └── EmailValidator.php
```

Exact project namespaces may vary, but the responsibility boundaries must remain.

---

# 67. Dependency Injection

The Email Engine should receive dependencies through the application's dependency-injection/container architecture.

Conceptually:

```text
EmailEngine
 ├── ProviderResolver
 ├── TemplateService
 ├── EmailLogRepository
 ├── UsageService
 ├── WebhookEventDispatcher
 ├── RateLimitService
 ├── IdempotencyService
 └── Logger
```

Do not instantiate global provider clients throughout unrelated controllers.

---

# 68. Logging Strategy

The engine should produce structured operational logs such as:

```text
email.request.accepted
email.template.rendered
email.provider.selected
email.provider.send.started
email.provider.send.success
email.provider.send.failed
email.webhook.event.created
```

Each should carry safe correlation metadata.

Never include secrets.

---

# 69. Error Handling

Internal exceptions should be classified.

Example:

```text
TemplateException
ProviderException
ValidationException
AuthorizationException
RateLimitException
IdempotencyException
EmailEngineException
```

The API layer maps them to stable public error codes.

---

# 70. Exception Boundary

Provider exceptions must be caught at the provider boundary.

Bad:

```text
SMTPException → API response
```

Good:

```text
SMTPException
      ↓
SMTP Adapter
      ↓
ProviderResult / normalized ProviderException
      ↓
Email Engine
      ↓
API Error Mapper
      ↓
EMAIL_SEND_FAILED
```

---

# 71. Testing Architecture

The Email Engine must be testable without sending real email.

Use fake/mock adapters.

Example:

```text
FakeProvider
    ↓
accept message
    ↓
return controlled result
```

Test scenarios:

- success;
- provider failure;
- timeout;
- invalid recipient;
- provider unavailable;
- duplicate idempotency key;
- template failure;
- sender violation;
- rate limit;
- oversized payload.

---

# 72. Provider Contract Tests

Every adapter must pass a common provider contract suite.

Required tests:

```text
configuration validation
connection test
successful send
provider error normalization
timeout handling
capability reporting
message construction
credential protection
```

Adding a new provider without passing the shared contract suite is not complete.

---

# 73. Integration Tests

Integration tests should cover:

```text
REST API
   ↓
Authentication
   ↓
Project authorization
   ↓
Template
   ↓
Email Engine
   ↓
Fake Provider
   ↓
Email Log
   ↓
Usage
   ↓
Webhook Event
```

This validates the full internal pipeline without contacting production mail infrastructure.

---

# 74. Security Tests

Test:

- header injection;
- invalid recipient;
- malicious template variables;
- server-side code injection attempts;
- oversized HTML;
- oversized attachments;
- unauthorized project;
- revoked API key;
- insufficient API scope;
- provider credential leakage;
- log secret leakage;
- duplicate sends;
- concurrent sends;
- rate-limit bypass.

---

# 75. Performance

The engine should:

- validate early;
- avoid unnecessary database queries;
- reuse configured services;
- avoid repeated provider configuration reads;
- use indexed lookups;
- avoid loading huge email content unnecessarily;
- use bounded memory;
- use provider timeouts;
- avoid excessive logging.

A future queue/worker deployment should be able to reuse the same engine.

---

# 76. Caching

Potential cache candidates:

- non-sensitive provider metadata;
- project configuration;
- template versions;
- capability information.

Never cache secrets in an unsafe shared cache.

Cache invalidation is required after:

- provider changes;
- template updates;
- project settings changes;
- API key/security changes where relevant.

---

# 77. Configuration

Engine configuration should come from centralized configuration.

Examples:

```text
EMAIL_MAX_RECIPIENTS
EMAIL_MAX_BODY_SIZE
EMAIL_MAX_ATTACHMENT_SIZE
EMAIL_PROVIDER_TIMEOUT
EMAIL_RATE_LIMIT
EMAIL_IDEMPOTENCY_TTL
EMAIL_LOG_RETENTION
```

Environment-specific secrets remain outside source control.

---

# 78. Environment Separation

Development, staging, and production must use separate:

- provider credentials;
- OAuth applications where appropriate;
- SMTP credentials;
- API keys;
- databases;
- webhook destinations.

Never point development tests at production mail credentials accidentally.

---

# 79. Test Mode

A controlled test mode may use a fake provider:

```text
FAKE_EMAIL_PROVIDER=true
```

or equivalent configuration.

In test mode:

- no real emails are sent;
- email messages can be inspected in test output;
- logs still follow the normal security rules.

Production must not accidentally run in fake-provider mode.

---

# 80. Development Mail Safety

Development environments should preferably use a safe mail sandbox or fake provider.

Never send automated tests to real customers.

The Email Engine should make provider substitution easy.

---

# 81. Cron and Maintenance

The initial architecture does not require a mandatory external queue.

Cron may support:

- cleanup of expired OTPs;
- cleanup of old idempotency records;
- cleanup of temporary attachments;
- log retention;
- usage aggregation;
- webhook retry processing if implemented asynchronously;
- maintenance tasks.

Cron must not be the only mechanism protecting real-time authentication or rate limits.

---

# 82. Retry Worker Compatibility

If future retries are processed by cron/worker:

```text
failed/transient
      ↓
retry eligibility
      ↓
scheduled retry
      ↓
Email Engine
      ↓
Provider
```

The retry system must use the same engine and provider adapters rather than creating a second sending implementation.

---

# 83. Webhook Event Architecture

The Email Engine should publish domain events:

```text
EmailSent
EmailFailed
```

The Webhook Service converts these to external webhook requests.

This separation prevents:

```text
email sending
```

from being blocked unnecessarily by a slow webhook destination.

---

# 84. Usage Accounting

Usage should be updated according to the product's official counting semantics.

Recommended baseline:

- one accepted email message counts as one email send;
- internal provider retry attempts do not create additional user-facing usage counts;
- failed validation does not count as a successful send;
- provider failures are separately tracked.

Exact billing/quota behavior must remain consistent with the pricing/usage policy.

---

# 85. Message Deduplication

Deduplication may use:

```text
project_id
+
idempotency_key
```

Never deduplicate solely by:

```text
recipient + subject + body
```

because legitimate repeated emails can have identical content.

---

# 86. Multiple Recipients

The implementation must define whether:

```text
one request with 10 recipients
```

is:

- one message with multiple recipients; or
- 10 individual delivery records.

The internal model should preserve recipient-level observability where practical.

BCC handling must preserve privacy.

---

# 87. Batch Sending

If batch email is introduced later, it must not silently change the semantics of `/send-email`.

A future endpoint may be:

```text
POST /send-email/batch
```

with separate limits and usage rules.

Batch sending must remain idempotent and rate-limited.

---

# 88. Provider Failover

Automatic provider failover is not mandatory for the initial deployment.

If introduced later:

```text
Primary provider
      ↓
Failure classification
      ↓
Failover policy
      ↓
Secondary provider
```

Only clearly retryable failures should trigger failover.

Failover can cause duplicates when provider outcome is uncertain, so it requires explicit idempotency/reconciliation design.

---

# 89. Provider Priority

Future projects may define:

```text
primary
secondary
disabled
```

The Email Engine should not automatically switch providers unless the project has an explicit failover policy.

---

# 90. Email Engine Metrics

Recommended internal metrics:

```text
emails_requested
emails_sent
emails_failed
provider_failures
provider_timeouts
template_failures
validation_failures
rate_limited_sends
duplicate_requests
average_send_duration
provider_send_duration
```

Metrics must not include secret values.

---

# 91. Operational Alerts

Potential alerts:

- sudden provider failure increase;
- Gmail authorization failures;
- SMTP connection failures;
- unusual send volume;
- repeated OTP/email abuse;
- webhook failures;
- database logging failures;
- worker/cron failures.

Alerts should be actionable and should not expose secrets.

---

# 92. Recovery Procedures

If a provider is failing:

1. inspect provider status;
2. inspect normalized error rates;
3. confirm credentials;
4. test provider connection;
5. check provider limits;
6. inspect message logs;
7. avoid uncontrolled retries;
8. disable provider if necessary;
9. select a valid alternative only if configured;
10. record administrative/security changes.

---

# 93. Email Engine Endpoint Mapping

| Function | API |
|---|---|
| Send email | `POST /send-email` |
| Send OTP | `POST /otp/send` |
| Verify OTP | `POST /otp/verify` |
| Test provider | `POST /projects/{id}/providers/{provider_id}/test` |
| Email logs | `GET /projects/{id}/email-logs` |
| Email log detail | `GET /projects/{id}/email-logs/{log_id}` |
| Usage | `GET /projects/{id}/usage` |
| Webhook management | `/projects/{id}/webhooks` |

---

# 94. End-to-End Example

A static website submits:

```javascript
fetch("https://api.example.com/api/v1/send-email", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    "X-API-Key": "eak_live_...",
    "Idempotency-Key": crypto.randomUUID()
  },
  body: JSON.stringify({
    template_id: "tpl_welcome",
    to: [
      {
        email: "customer@example.com",
        name: "Customer"
      }
    ],
    variables: {
      name: "Customer"
    }
  })
});
```

The platform performs:

```text
HTTPS
 ↓
API key authentication
 ↓
Project authorization
 ↓
Rate limit
 ↓
Idempotency
 ↓
Template lookup
 ↓
Variable validation
 ↓
Template rendering
 ↓
Provider resolution
 ↓
Sender validation
 ↓
Recipient validation
 ↓
Message construction
 ↓
Email log
 ↓
Gmail/SMTP adapter
 ↓
Provider
 ↓
Normalized result
 ↓
Email log update
 ↓
Usage update
 ↓
Webhook event
 ↓
JSON response
```

The client never needs PHP.

---

# 95. Example Successful Result

```json
{
  "success": true,
  "data": {
    "message_id": "msg_01JEXAMPLE123",
    "status": "sent",
    "provider": "gmail"
  },
  "meta": {
    "request_id": "req_01JEXAMPLE456"
  }
}
```

If deferred:

```json
{
  "success": true,
  "data": {
    "message_id": "msg_01JEXAMPLE123",
    "status": "queued"
  },
  "meta": {
    "request_id": "req_01JEXAMPLE456"
  }
}
```

---

# 96. Example Failed Result

```json
{
  "success": false,
  "error": {
    "code": "EMAIL_SEND_FAILED",
    "message": "The email could not be sent.",
    "details": {
      "reason": "PROVIDER_UNAVAILABLE"
    }
  },
  "meta": {
    "request_id": "req_01JEXAMPLE456"
  }
}
```

No provider stack trace or credential information is returned.

---

# 97. Email Engine Security Checklist

- [ ] Provider credentials never reach controllers.
- [ ] Provider credentials never reach API responses.
- [ ] API keys never enter provider logs.
- [ ] OAuth tokens are encrypted.
- [ ] SMTP passwords are encrypted.
- [ ] Header injection is blocked.
- [ ] Recipient validation is enforced.
- [ ] Sender policy is enforced.
- [ ] Template execution is impossible.
- [ ] HTML content is handled safely.
- [ ] Attachment limits are enforced.
- [ ] Rate limits are enforced before provider calls.
- [ ] Idempotency is implemented.
- [ ] Provider errors are normalized.
- [ ] Timeouts are bounded.
- [ ] Sensitive email logs are protected.
- [ ] OTP values are never logged.
- [ ] Webhook payloads are safe.
- [ ] Project isolation is enforced.
- [ ] API scopes are enforced.
- [ ] Audit events are recorded.
- [ ] Duplicate-send scenarios are tested.

---

# 98. Definition of Done

The Email Engine is complete only when:

- [ ] A normalized email DTO exists.
- [ ] Email Engine service exists.
- [ ] Provider adapter interface exists.
- [ ] Gmail adapter works.
- [ ] SMTP adapter works.
- [ ] Optional adapters can be added without core rewrites.
- [ ] Template rendering integrates correctly.
- [ ] Direct HTML email works if enabled.
- [ ] Plain-text fallback works.
- [ ] Recipient validation works.
- [ ] Sender validation works.
- [ ] Attachment controls work if enabled.
- [ ] Rate limits work.
- [ ] Idempotency works.
- [ ] Email logs are created/updated correctly.
- [ ] Provider errors are normalized.
- [ ] Timeouts are bounded.
- [ ] Usage is updated.
- [ ] Webhook events are emitted.
- [ ] OTP uses the same engine.
- [ ] Verification/reset emails use the same engine.
- [ ] Fake provider tests pass.
- [ ] Provider contract tests pass.
- [ ] Security tests pass.
- [ ] Duplicate-send scenarios are covered.
- [ ] Production secrets are protected.

---

# 99. Non-Negotiable Email Engine Rules

1. Never send email directly from controllers.
2. Never bypass the Email Engine for normal platform email.
3. Never expose provider credentials.
4. Never expose OAuth tokens.
5. Never log SMTP passwords.
6. Never log raw OTP values.
7. Never execute template content as code.
8. Never permit header injection.
9. Never trust arbitrary sender identity.
10. Never skip recipient validation.
11. Never allow unbounded attachments.
12. Never allow unbounded email body size.
13. Never retry uncertain provider outcomes blindly.
14. Never duplicate-send because of a local database failure.
15. Always use bounded provider timeouts.
16. Always normalize provider errors.
17. Always preserve request/message correlation IDs.
18. Always enforce project isolation.
19. Always enforce sending rate limits.
20. Always support idempotency for duplicate-sensitive sends.
21. Always keep provider logic behind adapters.
22. Always keep templates provider-neutral.
23. Always make the engine testable without real email.
24. Always record safe email lifecycle state.
25. Always distinguish provider acceptance from confirmed mailbox delivery.
26. Always use the same engine for OTP/verification/reset emails.
27. Always keep usage accounting consistent.
28. Always emit normalized domain events for webhooks.
29. Always protect sensitive email logs.
30. Keep this architecture synchronized with documents 10, 11, 12, 14, 15, 16, 19, 22, and 23.

---

# 100. Final Lock

This document defines the **locked Email Engine architecture** for the Email API Platform.

It establishes one provider-neutral delivery pipeline for:

- transactional email;
- HTML email;
- template email;
- OTP email;
- verification email;
- password-reset email;
- test email.

The engine is compatible with:

- PHP 8.3+;
- PDO/MySQL;
- PHPMailer;
- Gmail OAuth;
- SMTP;
- optional provider adapters;
- REST/JSON;
- project API keys;
- templates;
- webhooks;
- usage statistics;
- logs;
- the security architecture.

The initial deployment does **not** require Redis, RabbitMQ, Kafka, Kubernetes, or a mandatory external queue. The design remains compatible with future asynchronous processing.

Future providers and delivery improvements must preserve the core Email Engine contract.

**Status: FINAL / LOCKED.**

**Next document:** `14-EMAIL-PROVIDERS.md`
