# 07 — ASSETS, ICONS, FONTS & LOGOS

**Project:** Email API Platform  
**Document:** 07-ASSETS-ICONS-FONTS-LOGOS.md  
**Status:** FINAL / LOCKED  
**Document Set:** 7 of 25  
**Scope:** Brand assets, logos, provider marks, icons, fonts, illustrations, image formats, naming, folders, usage rules, optimization, accessibility, and asset governance.

---

# 1. Purpose

This document defines the complete asset system for the Email API Platform.

It establishes the approved rules for:

- Product logos
- Logo variants
- Favicon and app icons
- Provider logos
- Interface icons
- Technology/brand icons
- Fonts
- Illustrations
- Empty-state graphics
- Loading graphics
- API/security/email graphics
- Image formats
- Asset naming
- Asset directory structure
- Optimization
- Responsive usage
- Accessibility
- Licensing and attribution
- Frontend loading strategy
- Asset quality control

The objective is to maintain a professional, recognizable, lightweight visual system without accumulating inconsistent or duplicated assets.

**Asset architecture is FINAL / LOCKED.**

---

# 2. Asset Design Principles

## 2.1 Use the smallest appropriate asset

Prefer vector assets when the graphic is naturally vector-based.

Priority:

1. SVG
2. WebP
3. PNG
4. JPG

Use raster formats only when they provide a meaningful advantage.

## 2.2 Prefer existing approved systems

Do not recreate common interface icons manually when an approved icon system already exists.

Use:

- Lucide for interface icons
- Simple Icons for technology/brand marks where appropriate
- Official provider SVG assets for provider branding

## 2.3 Brand accuracy

Provider and technology logos must preserve their recognizable official form.

Do not:

- Stretch
- Skew
- Rotate
- Arbitrarily recolor
- Add effects that change the brand
- Combine logos into misleading marks

## 2.4 Performance first

Assets must be optimized without visibly reducing quality.

Avoid:

- Huge PNGs for simple graphics
- Uncompressed photographs
- Duplicate icon files
- Multiple copies of identical assets
- Fonts loaded unnecessarily
- Large decorative animations

## 2.5 Accessibility first

Decorative assets must be hidden from assistive technology.

Meaningful images require useful alternative text.

Icon-only controls require accessible names.

---

# 3. Approved Asset Stack

The project uses the following locked asset baseline.

| Asset category | Approved system |
|---|---|
| Interface icons | Lucide |
| Technology/brand icons | Simple Icons where appropriate |
| Provider logos | Official provider SVG assets |
| Primary font | Inter |
| Monospace font | JetBrains Mono |
| Vector graphics | SVG |
| Optimized images | WebP |
| Transparent raster | PNG |
| Photographic raster | JPG |
| Product illustrations | Original/custom project assets |
| UI animation | CSS first, selective GSAP |
| Favicon/app icons | Project-generated approved variants |

No competing icon library should be introduced without an explicit scope decision.

---

# 4. Brand Asset System

## 4.1 Product Logo Variants

The platform has **six primary logo variants**.

The six variants should cover the following contexts:

1. Primary horizontal logo
2. Horizontal logo for dark backgrounds
3. Horizontal logo for light backgrounds
4. Compact/stacked logo
5. Compact/stacked logo for dark backgrounds
6. Symbol-only mark

The final visual artwork must preserve the same underlying brand identity across variants.

## 4.2 Logo Variant Purpose

### Variant 1 — Primary Horizontal

Use for:

- Public website header
- Documentation header
- Marketing pages
- Desktop authentication
- Default application branding

### Variant 2 — Dark Background

Use when the normal logo lacks sufficient contrast on a dark surface.

### Variant 3 — Light Background

Use when the dark-compatible mark is required against a light surface.

### Variant 4 — Compact/Stacked

Use where horizontal space is limited but the full brand identity is still required.

### Variant 5 — Compact/Stacked Dark

Use on dark backgrounds.

### Variant 6 — Symbol-only

Use for:

- Favicon
- App icon
- Compact sidebar
- Small product identity placements
- Loading/launcher contexts where appropriate

---

# 5. Logo Usage Rules

## 5.1 Clear Space

Maintain a consistent clear-space area around the logo.

No text, button, border, image, or other graphic should visually collide with the mark.

## 5.2 Minimum Size

Do not scale a logo below the point where:

- Text becomes unreadable
- Symbol details disappear
- Brand recognition is reduced

Use the symbol-only mark when the available area is too small for a full wordmark.

## 5.3 Prohibited Changes

Never:

- Stretch the logo
- Compress the logo
- Rotate the logo
- Apply arbitrary gradients
- Add shadows that alter the mark
- Change proportions
- Replace approved colors with arbitrary colors
- Place the logo on a visually conflicting background

---

# 6. Logo File Formats

Preferred formats:

```text
SVG
```

Secondary fallback:

```text
PNG
```

Use SVG for UI and web contexts whenever possible.

PNG variants may be generated for environments that do not support SVG or require raster assets.

Avoid JPG for logos because it introduces unnecessary compression artifacts and does not preserve transparency well.

---

# 7. Favicon and App Icon System

The product requires the following standard sizes:

| Size | Primary use |
|---:|---|
| 16×16 | Browser favicon |
| 32×32 | Browser/desktop favicon |
| 48×48 | Larger browser/shortcut contexts |
| 180×180 | Apple touch icon |
| 192×192 | Web app/PWA icon |
| 512×512 | High-resolution PWA/store/launcher contexts |

The symbol-only logo variant should be the basis for favicon/app icon artwork.

## 7.1 Favicon Requirements

Favicon artwork must:

- Remain recognizable at 16×16
- Avoid tiny text
- Use adequate contrast
- Preserve transparent or approved background treatment
- Avoid unnecessary detail

---

# 8. Provider Logos

The platform's provider system includes:

- Gmail
- Custom SMTP
- Optional Brevo
- Optional Mailtrap

Provider logos must be displayed using approved official brand assets where the provider has a recognizable brand mark.

## 8.1 Gmail

Use the official Gmail/Google-compatible brand mark.

Do not recreate the Gmail icon manually.

## 8.2 SMTP

SMTP is a protocol rather than a single company.

Do not use a fake "SMTP company logo."

Represent custom SMTP using an appropriate interface icon, such as a mail/server/network concept from Lucide, with the text label **Custom SMTP**.

## 8.3 Brevo

Use the approved official Brevo brand asset when the optional provider adapter is enabled.

## 8.4 Mailtrap

Use the approved official Mailtrap brand asset when the optional provider adapter is enabled.

If an optional adapter is disabled, the UI must not imply that the integration is operational.

---

# 9. Provider Logo Rules

Provider logos should appear:

- In provider cards
- Provider selection controls
- Connection status areas
- Admin provider lists
- Public provider overview

Do not use provider logos as the sole status indicator.

Example:

```text
[Gmail icon] Gmail
Connected
```

not:

```text
[Gmail icon only]
```

Provider logo and textual provider name should remain available for accessibility.

---

# 10. Interface Icon System

## Primary System: Lucide

Lucide is the authoritative interface icon system.

Use it for:

- Navigation
- Actions
- Settings
- Security
- Projects
- Templates
- Logs
- Webhooks
- Notifications
- User/account controls
- Status support
- Search/filter controls

Examples of suitable concepts:

| UI purpose | Icon concept |
|---|---|
| Dashboard | Layout/dashboard |
| Projects | Folder |
| Templates | File/text |
| Email | Mail |
| API | Code/terminal |
| API key | Key |
| Webhook | Webhook |
| Security | Shield |
| Settings | Settings |
| Users | Users |
| Logs | List/file |
| Search | Search |
| Filter | Sliders/filter |
| Success | Check |
| Warning | Triangle alert |
| Error | Circle alert |
| Copy | Copy |
| Delete | Trash |
| Edit | Pencil |
| View | Eye |
| Hide | Eye-off |
| Lock | Lock |
| Session | Monitor/device |
| Notification | Bell |

The exact icon choice may vary where Lucide provides a more semantically accurate symbol.

---

# 11. Icon Sizing

Use consistent icon sizing.

Recommended baseline:

| Context | Size |
|---|---:|
| Tiny metadata | 14px |
| Standard UI | 16px |
| Buttons/navigation | 18–20px |
| Major section | 20–24px |
| Empty-state illustration icon | 32–48px |

Do not mix unrelated icon sizes within the same component without a clear hierarchy.

---

# 12. Icon Accessibility

## Decorative icons

Use:

```html
aria-hidden="true"
```

when the adjacent text already communicates the same meaning.

## Icon-only controls

Use an accessible name:

```html
<button type="button" aria-label="Copy API key">
  ...
</button>
```

A tooltip may supplement the label but must not replace accessibility semantics.

---

# 13. Technology and Brand Icons

Simple Icons may be used for technology and brand references where appropriate.

Examples include:

- PHP
- MySQL
- JavaScript
- HTML5
- CSS3
- Bootstrap
- Git
- Apache
- Nginx

Do not use technology logos merely as decoration.

If a technology is not materially relevant to a screen, omit the logo.

---

# 14. Fonts

## 14.1 Primary Font — Inter

Inter is the product's primary UI font.

Use for:

- Body
- Headings
- Navigation
- Buttons
- Forms
- Tables
- Alerts
- Dashboard content
- Marketing content

## 14.2 Monospace — JetBrains Mono

Use for:

- Code
- JSON
- API endpoints
- Request IDs
- Error codes
- API key identifiers
- Technical examples
- Terminal-style content

Do not use monospace for ordinary body text.

---

# 15. Font Loading Strategy

Prefer self-hosting approved font files where licensing and project distribution requirements permit.

Recommended loading approach:

```css
@font-face {
  font-family: "Inter";
  src: url("/assets/fonts/inter-var.woff2") format("woff2");
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}
```

Use variable fonts where practical to reduce file count.

JetBrains Mono should be loaded only where required by the application or documentation.

## 15.1 Font Performance

- Prefer WOFF2.
- Avoid unnecessary font weights.
- Use `font-display: swap`.
- Avoid loading duplicate font families.
- Avoid loading unused language subsets.
- Test layout shift caused by font replacement.

---

# 16. Typography Asset Rules

The design system should use semantic weights rather than arbitrary weight changes.

Suggested roles:

- Regular: body
- Medium: labels and navigation emphasis
- Semibold: headings and important UI
- Bold: major display emphasis where required

Do not use dozens of weights simply to create visual variation.

---

# 17. Illustration System

The platform may use original/custom illustrations for:

- API integration
- Email delivery
- Security
- Authentication
- Empty states
- Provider setup
- Developer workflows
- System errors
- Onboarding

Illustrations must share a coherent visual language.

## 17.1 Illustration Style

Preferred characteristics:

- Simple
- Technical
- Clean
- Professional
- Minimal
- Scalable
- Accessible
- Consistent with the brand

Avoid overly playful cartoon styling that conflicts with the platform's developer-oriented identity.

---

# 18. Empty-State Assets

Custom empty-state graphics may be used when they improve comprehension.

Examples:

```text
No Projects
No Templates
No Providers
No API Keys
No Email Logs
No Webhooks
No Notifications
```

Every empty-state graphic must support, not replace, the explanatory text and primary action.

---

# 19. Loading Assets

Loading should primarily use CSS or Bootstrap-compatible indicators.

Do not create a separate image asset for every loading state.

Use custom loading graphics only for:

- Branded application startup
- Special full-page processing
- Major asynchronous workflows where a graphic genuinely improves understanding

Avoid animated GIFs.

Prefer SVG/CSS animation where animation is necessary.

---

# 20. Security Illustrations

Security-related graphics should communicate:

- Protection
- Verification
- Access control
- Session safety
- API key protection
- Provider credential safety

They must not imply guarantees the system does not actually provide.

For example, a lock illustration is acceptable as a visual metaphor, but product copy must still describe the actual security controls.

---

# 21. API Illustrations

API graphics may use concepts such as:

- Code brackets
- Request/response
- Server
- Webhook
- Mail delivery
- Authentication

Use Lucide icons for small UI contexts and custom SVG illustrations for larger marketing/onboarding contexts.

---

# 22. Email Illustrations

Email graphics may represent:

- Sending
- Delivery
- Templates
- Verification
- OTP
- Notifications
- Failed delivery

Do not use provider logos as generic email illustrations.

---

# 23. Image Formats

## SVG

Preferred for:

- Logos
- Icons
- Illustrations
- Provider marks
- Simple diagrams

Benefits:

- Small for vector artwork
- Scalable
- Sharp at all resolutions

## WebP

Preferred for:

- Photographic or complex raster imagery
- Marketing imagery
- Larger raster graphics

## PNG

Use for:

- Transparent raster images
- Screenshots where lossless quality is needed
- Raster artwork that does not compress well to WebP

## JPG

Use primarily for:

- Photographic content
- Large images where transparency is unnecessary

Do not use JPG for logos, icons, or simple UI graphics.

---

# 24. Asset Directory Structure

Recommended public asset structure:

```text
public/
└── assets/
    ├── brand/
    │   ├── logo/
    │   ├── favicon/
    │   └── app-icons/
    │
    ├── icons/
    │   ├── ui/
    │   ├── technology/
    │   └── status/
    │
    ├── providers/
    │   ├── gmail/
    │   ├── smtp/
    │   ├── brevo/
    │   └── mailtrap/
    │
    ├── fonts/
    │   ├── inter/
    │   └── jetbrains-mono/
    │
    ├── illustrations/
    │   ├── api/
    │   ├── email/
    │   ├── security/
    │   ├── authentication/
    │   ├── providers/
    │   ├── empty-states/
    │   ├── errors/
    │   └── onboarding/
    │
    └── images/
        ├── marketing/
        ├── documentation/
        └── screenshots/
```

The directory structure should remain predictable and should not mix source files with generated build artifacts.

---

# 25. Source vs Distribution Assets

Where custom assets are created, distinguish:

```text
design/source/
```

from production-ready:

```text
public/assets/
```

Source design files do not need to be publicly accessible.

Production assets must be optimized and named consistently.

---

# 26. Asset Naming Convention

Use lowercase, descriptive, hyphen-separated names.

Preferred:

```text
logo-horizontal.svg
logo-horizontal-dark.svg
logo-symbol.svg
favicon-32.png
provider-gmail.svg
provider-brevo.svg
illustration-api-integration.svg
illustration-email-delivery.svg
empty-projects.svg
```

Avoid:

```text
IMG001.png
newlogo-final2.svg
asset-copy-final-final.svg
icon1.svg
```

Do not encode temporary design iteration names into production assets.

---

# 27. Logo Naming Matrix

Recommended naming:

```text
logo-horizontal.svg
logo-horizontal-dark.svg
logo-horizontal-light.svg

logo-compact.svg
logo-compact-dark.svg
logo-compact-light.svg

logo-symbol.svg
```

If the six approved variants use different internal artwork conventions, preserve the six-variant requirement while keeping filenames descriptive.

---

# 28. Favicon Naming Matrix

Recommended:

```text
favicon-16.png
favicon-32.png
favicon-48.png
apple-touch-icon-180.png
icon-192.png
icon-512.png
```

Where a web manifest is used, reference the approved 192px and 512px icons.

---

# 29. Provider Naming Matrix

Recommended:

```text
provider-gmail.svg
provider-smtp.svg
provider-brevo.svg
provider-mailtrap.svg
```

Because SMTP is a protocol, `provider-smtp.svg` should be a neutral custom/product asset rather than a third-party brand mark.

---

# 30. Illustration Naming Matrix

Examples:

```text
illustration-api-integration.svg
illustration-email-delivery.svg
illustration-security.svg
illustration-authentication.svg
illustration-provider-setup.svg

empty-projects.svg
empty-templates.svg
empty-providers.svg
empty-api-keys.svg
empty-email-logs.svg
empty-webhooks.svg

error-404.svg
error-403.svg
error-429.svg
error-500.svg
maintenance.svg
```

---

# 31. Image Optimization

Before production:

- Remove unnecessary metadata.
- Compress raster images.
- Minify SVG markup.
- Remove unused SVG definitions.
- Optimize path data where safe.
- Resize oversized images.
- Use responsive image dimensions.
- Avoid loading images larger than their display size.

Do not optimize an asset in a way that changes an official provider logo's approved appearance.

---

# 32. SVG Security

SVG files must be treated as potentially active content when sourced externally.

Production SVG assets should:

- Come from trusted sources
- Be reviewed before use
- Avoid scripts
- Avoid embedded arbitrary external resources
- Be sanitized where required
- Not contain hidden malicious payloads

Do not upload arbitrary user-provided SVG files directly into trusted application asset directories.

---

# 33. External Asset Policy

External third-party asset URLs should not become an uncontrolled runtime dependency.

Prefer:

- Local approved assets
- Version-controlled files
- Approved package assets
- Official provider assets

If an external asset must be used, document:

- Source
- License
- Version
- Update process
- Fallback behavior

---

# 34. Brand Asset Licensing

Every third-party brand asset must have an acceptable usage basis.

Maintain a simple asset inventory containing:

| Asset | Source | License/usage basis | Version/date | Local copy |
|---|---|---|---|---|
| Gmail logo | Approved official source | Provider brand usage terms | Recorded during acquisition | Yes |
| Brevo logo | Approved official source | Provider brand usage terms | Recorded during acquisition | Yes |
| Mailtrap logo | Approved official source | Provider brand usage terms | Recorded during acquisition | Yes |
| Simple Icons marks | Approved project dependency/source | Project-compatible license | Locked dependency | Yes |
| Lucide | Approved project dependency/source | Project-compatible license | Locked dependency | Yes |

Legal review should be performed before public commercial launch where required.

---

# 35. Asset Accessibility Rules

## Meaningful image

Use meaningful alt text.

Example:

```html
<img
  src="/assets/illustrations/api/illustration-api-integration.svg"
  alt="JavaScript request connecting a website to the email API">
```

## Decorative image

Use empty alt:

```html
<img
  src="/assets/illustrations/..."
  alt=""
  aria-hidden="true">
```

## Logos

If the logo is a link, its accessible name should identify the product.

Do not duplicate the same information through unnecessary visible and screen-reader text.

---

# 36. Responsive Asset Rules

Assets must remain usable across:

- Small mobile
- Large mobile
- Tablet
- Laptop
- Desktop
- Large desktop

For responsive illustrations:

- Avoid fixed dimensions that overflow.
- Use responsive SVG viewBoxes.
- Preserve aspect ratio.
- Use CSS `max-width: 100%`.
- Provide appropriate raster sizes when SVG is unavailable.

For logos, switch to compact/symbol variants when space becomes constrained.

---

# 37. Dark/Light Surface Rules

Where the product supports both light and dark surfaces:

- Use the approved light-background logo on light surfaces.
- Use the approved dark-background logo on dark surfaces.
- Do not apply CSS filters to provider logos to fake a dark-mode version.
- Preserve provider brand colors unless official dark-mode artwork exists.
- Ensure icon contrast meets accessibility requirements.

---

# 38. Asset Loading Performance

## Critical assets

Load early:

- Primary UI font
- Primary logo where visible above the fold
- Critical interface icons

## Noncritical assets

Lazy-load where appropriate:

- Large marketing illustrations
- Below-the-fold images
- Documentation screenshots
- Heavy decorative imagery

Avoid lazy-loading an asset that is immediately visible and necessary for layout stability.

---

# 39. Caching

Static assets should use cache-friendly URLs.

Recommended production strategy:

```text
asset-name.<version-or-hash>.ext
```

or a framework/build system that provides equivalent immutable cache busting.

Long-lived caching is preferred for immutable assets.

When assets change, the URL/version must change so clients do not receive stale content indefinitely.

---

# 40. Content Security Policy Considerations

The asset strategy must remain compatible with the application's Content Security Policy.

Prefer local resources.

If external fonts, images, or scripts are allowed, explicitly document the required origins rather than broadly allowing all sources.

Do not weaken CSP merely to accommodate an unapproved asset source.

---

# 41. Asset and Component Relationship

Assets must support the UI component system defined in `05-UI-UX-DESIGN-SYSTEM.md`.

Examples:

- Button icons → Lucide
- Navigation icons → Lucide
- Provider cards → approved provider SVG
- Empty states → custom empty-state illustration + Lucide/action icon
- API documentation → JetBrains Mono + code UI
- Public hero → approved logo + custom illustration where useful

Do not create image assets to replace standard UI components.

---

# 42. Icon State Rules

Icons must not be used as the only indicator of state.

Correct:

```text
✓ Connected
```

Incorrect:

```text
[green check icon only]
```

Correct:

```text
⚠ SMTP connection needs attention
```

The actual implementation should use accessible semantic markup and approved icons rather than relying on emoji.

---

# 43. Error and Status Assets

Use icons consistently:

- Success → check/confirmation icon
- Warning → alert/triangle
- Error → alert/error icon
- Information → info icon
- Pending → clock/loading concept
- Security → shield/lock concept

Status icons supplement text and color rather than replacing them.

---

# 44. Documentation Assets

API documentation may include:

- Code examples
- Architecture diagrams
- Request/response diagrams
- Provider setup diagrams
- Integration illustrations

Documentation graphics should prioritize clarity over decoration.

Where a diagram contains exact technical relationships, maintain it as a source-controlled asset and update it when architecture changes.

---

# 45. Screenshot Assets

Screenshots may be used for:

- Documentation
- Public product explanation
- Tutorials
- Onboarding

Screenshots must:

- Avoid real user data
- Avoid real API keys
- Avoid real email addresses where privacy is a concern
- Use controlled demonstration accounts/data
- Be updated when the UI materially changes

---

# 46. Generated vs Hand-authored Assets

## Hand-authored/custom

Use for:

- Product logo
- Product symbol
- Product illustrations
- Empty states
- Branded diagrams

## Library-provided

Use for:

- Interface icons
- Technology icons where appropriate

## Provider-provided

Use for:

- Gmail
- Brevo
- Mailtrap
- Other supported branded providers

Do not redraw official provider logos unless explicitly permitted and necessary.

---

# 47. Asset Quality Checklist

Before an asset enters production:

### Visual
- Correct proportions
- Correct contrast
- Correct branding
- No accidental artifacts
- Appropriate dimensions

### Technical
- Correct format
- Optimized file size
- No unnecessary metadata
- No embedded scripts in SVG
- Correct filename
- Correct directory

### Accessibility
- Alt strategy defined
- Decorative state marked appropriately
- Icon-only use has accessible name

### Legal
- Source recorded
- License/usage basis recorded
- Provider branding reviewed where required

### Performance
- Correct resolution
- Appropriate compression
- No duplicate asset
- Caching strategy compatible

---

# 48. Asset Review Checklist for Developers

Before committing an asset:

1. Does an approved asset already exist?
2. Can Lucide handle this icon?
3. Can an existing provider/technology asset be reused?
4. Is SVG appropriate?
5. Is the asset optimized?
6. Is the name descriptive?
7. Is the asset stored in the correct directory?
8. Is its license/source known?
9. Does it require alt text?
10. Does it work on the intended background?
11. Does it remain usable on mobile?
12. Does it introduce an unnecessary runtime dependency?

If an existing approved asset can satisfy the requirement, do not create another.

---

# 49. Prohibited Asset Practices

Do not:

1. Add random icon libraries.
2. Mix Font Awesome, Material Icons, Bootstrap Icons, and Lucide without an approved reason.
3. Download unknown SVGs and place them directly into production.
4. Use provider logos from unverified sources.
5. Use arbitrary copyrighted artwork.
6. Store secrets inside image metadata or filenames.
7. Use JPG for simple logos/icons.
8. Load large images when a small SVG would work.
9. Use animated GIFs for normal UI feedback.
10. Use external image hosts without approval.
11. Use CSS filters to counterfeit official provider branding.
12. Duplicate identical assets under different names.
13. Commit temporary design exports.
14. Put source design files into the public asset directory.
15. Use color-only status graphics.
16. Create an asset when an existing approved icon is sufficient.

---

# 50. Asset Versioning and Maintenance

When an asset changes:

- Update its version/hash.
- Verify all references.
- Check light/dark contexts.
- Check mobile rendering.
- Check accessibility.
- Check cache invalidation.
- Update asset inventory if the source or license changed.

Do not silently replace an official provider logo with a materially different artwork.

---

# 51. Recommended Asset Inventory

The initial product should maintain at least the following logical groups.

## Brand

```text
6 logo variants
6 favicon/app icon sizes
```

## Providers

```text
Gmail
Custom SMTP representation
Brevo
Mailtrap
```

## Interface

```text
Lucide icon system
Status icon set
```

## Technology

```text
PHP
MySQL
JavaScript
HTML5
CSS3
Bootstrap
Git
Apache
Nginx
```

Only technology marks that are actually shown in the product should be bundled into the production interface.

## Custom illustrations

Recommended initial set:

```text
API integration
Email delivery
Security
Authentication
Provider setup
Email template
Empty projects
Empty templates
Empty providers
Empty API keys
Empty email logs
Empty webhooks
404
403
429
500
Maintenance
```

The exact number of custom illustrations may be reduced when a reusable component or Lucide icon communicates the state more effectively.

---

# 52. HTML Asset Usage Examples

## Logo

```html
<a href="/" class="brand">
  <img
    src="/assets/brand/logo/logo-horizontal.svg"
    alt="Email API Platform">
</a>
```

## Decorative illustration

```html
<img
  src="/assets/illustrations/api/illustration-api-integration.svg"
  alt=""
  aria-hidden="true">
```

## Provider logo

```html
<img
  src="/assets/providers/gmail/provider-gmail.svg"
  alt=""
  aria-hidden="true">

<span>Gmail</span>
```

## Icon-only action

```html
<button type="button" aria-label="Copy API key">
  <!-- Lucide Copy icon -->
</button>
```

The actual icon implementation may use inline SVG, an approved icon package, or an equivalent approved method.

---

# 53. CSS Asset Usage

Prefer semantic variables and component classes.

Example:

```css
.brand-logo {
  display: block;
  max-width: 100%;
  height: auto;
}

.provider-logo {
  width: 24px;
  height: 24px;
  object-fit: contain;
}

.illustration {
  display: block;
  width: 100%;
  max-width: 480px;
  height: auto;
}
```

Avoid hard-coding asset-specific dimensions throughout unrelated components.

---

# 54. Font CSS Baseline

Recommended baseline:

```css
:root {
  --font-sans: "Inter", sans-serif;
  --font-mono: "JetBrains Mono", monospace;
}

html,
body {
  font-family: var(--font-sans);
}

code,
pre,
.api-code,
.technical-value {
  font-family: var(--font-mono);
}
```

The final production CSS must include appropriate fallbacks.

---

# 55. Build and Deployment Rules

Production builds should:

- Minify CSS/JS where appropriate.
- Optimize images.
- Preserve SVG accessibility where needed.
- Generate/cache-busted asset URLs where supported.
- Exclude source design files from public directories.
- Exclude unused assets from production packages.
- Verify asset MIME types.
- Serve assets with appropriate caching headers.
- Serve over HTTPS.

---

# 56. Security Considerations

Asset handling must not create a security bypass.

Important rules:

- Do not trust uploaded SVGs.
- Do not permit arbitrary executable content through asset upload.
- Do not place private documents in public asset directories.
- Do not include API keys in screenshots.
- Do not include OAuth tokens in documentation graphics.
- Do not embed sensitive URLs in public illustrations.
- Do not expose server filesystem paths in asset errors.
- Validate upload MIME type and content where user uploads are supported.

---

# 57. Relationship to UI/UX Design System

`05-UI-UX-DESIGN-SYSTEM.md` defines how assets appear.

This document defines what assets are allowed, how they are stored, and how they are maintained.

Together they establish:

```text
Brand
  ↓
Assets
  ↓
Design Tokens
  ↓
Components
  ↓
Screens
  ↓
Navigation
```

The visual identity must remain consistent throughout the product.

---

# 58. Relationship to Technology Stack

This document follows the locked technology decisions from `04-TECHNOLOGY-STACK.md`:

- HTML5
- CSS3
- Bootstrap 5.3+
- JavaScript ES6+
- Fetch API
- CSS variables
- Selective GSAP
- Lucide
- Simple Icons
- Inter
- JetBrains Mono
- SVG/WebP/PNG/JPG

No additional visual framework is required.

---

# 59. Final Asset Governance

The project should maintain one authoritative asset location.

Developers must:

- Reuse approved assets.
- Keep names stable.
- Keep third-party assets documented.
- Optimize before production.
- Avoid unnecessary duplicates.
- Review branding changes.
- Keep public assets separate from private files.
- Maintain accessibility metadata/usage.
- Test assets across supported viewport sizes and backgrounds.

---

# 60. Definition of Done — Assets

An asset system is complete when:

- Six logo variants are defined.
- Six required favicon/app icon sizes are defined.
- Provider asset rules are defined.
- Lucide is established as the primary UI icon system.
- Simple Icons/official provider assets are defined for brand contexts.
- Inter and JetBrains Mono are established.
- SVG/WebP/PNG/JPG usage is defined.
- Asset directories are defined.
- Naming conventions are defined.
- Accessibility rules are defined.
- Optimization rules are defined.
- Licensing/source tracking is defined.
- Responsive/dark-surface rules are defined.
- Security rules for SVG and uploaded assets are defined.
- No competing asset system is required.

---

# 61. Non-Negotiable Asset Rules

1. Lucide is the primary interface icon system.
2. Inter is the primary UI font.
3. JetBrains Mono is the primary technical/code font.
4. SVG is preferred for vector assets.
5. WebP is preferred for optimized raster imagery.
6. PNG is used when lossless transparency is required.
7. JPG is primarily for photography.
8. Six primary logo variants remain part of the product specification.
9. Favicon/app icon targets remain 16, 32, 48, 180, 192, and 512.
10. Provider logos must use approved official/provider-compatible assets.
11. Custom SMTP must not be represented as a third-party company logo.
12. Do not mix competing icon libraries.
13. Do not expose sensitive data in screenshots or graphics.
14. Do not place private assets in public directories.
15. Do not use untrusted SVG files directly.
16. All meaningful images need appropriate alternative text.
17. Decorative images must not add unnecessary screen-reader noise.
18. Asset filenames must be descriptive and stable.
19. Production assets must be optimized.
20. Asset changes must preserve the locked brand system.

---

# 62. Final Asset Lock

The Email API Platform asset system is defined around:

- **6 primary logo variants**
- **6 favicon/app icon sizes**
- **Gmail, Custom SMTP, Brevo, and Mailtrap provider representations**
- **Lucide interface icons**
- **Simple Icons/official technology and provider marks**
- **Inter**
- **JetBrains Mono**
- **SVG-first vector strategy**
- **WebP/PNG/JPG raster strategy**
- **Original/custom product illustrations**
- **Centralized asset directories**
- **Consistent naming and optimization**
- **Accessibility and security controls**
- **License/source tracking**

**STATUS: FINAL / LOCKED**

Future implementation should add only assets that fit this system. It must not introduce an alternative icon library, typography system, branding system, or uncontrolled external asset dependency without an explicit project-level scope decision.
