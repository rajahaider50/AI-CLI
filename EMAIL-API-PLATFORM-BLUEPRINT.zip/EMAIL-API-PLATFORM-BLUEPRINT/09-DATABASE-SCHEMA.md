# 09 — DATABASE SCHEMA

**Project:** Self-Hosted Email API Platform  
**Status:** FINAL / LOCKED  
**Database:** MySQL 8+  
**Engine:** InnoDB  
**Character Set:** `utf8mb4`  
**Access:** PHP PDO + prepared statements  
**Parent:** `08-DATABASE-ARCHITECTURE.md`

## 1. Purpose

This document converts the locked database architecture into an implementation-ready relational schema. It defines the principal tables, columns, data types, keys, constraints, indexes, relationships, lifecycle values, secret-handling requirements, and migration order.

The schema must remain consistent with the locked 93-screen, 24-module, modular-monolith Email API Platform architecture.

## 2. Global Conventions

- MySQL 8+.
- InnoDB for all core tables.
- `utf8mb4` character set.
- UTC timestamps.
- Internal IDs: `BIGINT UNSIGNED AUTO_INCREMENT`.
- Boolean values: `TINYINT(1)`.
- Structured variable data: `JSON`.
- Email addresses: `VARCHAR(320)`.
- IP addresses: `VARCHAR(45)`.
- Passwords/API keys/OTP/token secrets are never stored as plaintext.
- OAuth/SMTP/webhook secrets are encrypted when they must be recovered.
- All SQL uses PDO prepared statements.
- Public APIs must not expose internal database records blindly.

Recommended collation:

```text
utf8mb4_0900_ai_ci
```

## 3. Core Table Inventory

| # | Table |
|---:|---|
| 1 | `users` |
| 2 | `user_profiles` |
| 3 | `email_verifications` |
| 4 | `otp_codes` |
| 5 | `sessions` |
| 6 | `projects` |
| 7 | `project_settings` |
| 8 | `providers` |
| 9 | `user_providers` |
| 10 | `gmail_connections` |
| 11 | `smtp_connections` |
| 12 | `templates` |
| 13 | `template_versions` |
| 14 | `api_keys` |
| 15 | `api_requests` |
| 16 | `email_logs` |
| 17 | `otp_logs` |
| 18 | `webhooks` |
| 19 | `webhook_logs` |
| 20 | `notifications` |
| 21 | `usage_statistics` |
| 22 | `login_attempts` |
| 23 | `blocked_ips` |
| 24 | `security_logs` |
| 25 | `admin_users` |
| 26 | `admin_logs` |
| 27 | `system_settings` |

## 4. `users`

Primary application identity.

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `email` | VARCHAR(320) | NO | — |
| `password_hash` | VARCHAR(255) | NO | — |
| `status` | VARCHAR(32) | NO | `pending` |
| `email_verified_at` | DATETIME | YES | NULL |
| `last_login_at` | DATETIME | YES | NULL |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |
| `deleted_at` | DATETIME | YES | NULL |

Statuses: `pending`, `active`, `suspended`, `disabled`.

Constraints:

```text
PRIMARY KEY (id)
UNIQUE (email)
INDEX (status)
```

## 5. `user_profiles`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `user_id` | BIGINT UNSIGNED | NO | — |
| `display_name` | VARCHAR(150) | YES | NULL |
| `first_name` | VARCHAR(100) | YES | NULL |
| `last_name` | VARCHAR(100) | YES | NULL |
| `avatar_url` | VARCHAR(2048) | YES | NULL |
| `timezone` | VARCHAR(64) | NO | `UTC` |
| `locale` | VARCHAR(16) | NO | `en` |
| `preferences` | JSON | YES | NULL |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |

Constraints:

```text
PRIMARY KEY (id)
UNIQUE (user_id)
FK user_id → users.id
```

## 6. `email_verifications`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `user_id` | BIGINT UNSIGNED | NO | — |
| `token_hash` | CHAR(64) | NO | — |
| `expires_at` | DATETIME | NO | — |
| `consumed_at` | DATETIME | YES | NULL |
| `attempt_count` | INT UNSIGNED | NO | 0 |
| `created_at` | DATETIME | NO | — |

Indexes:

```text
(user_id, created_at)
(token_hash)
(expires_at)
```

Raw verification tokens are never persisted.

## 7. `otp_codes`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `user_id` | BIGINT UNSIGNED | YES | NULL |
| `project_id` | BIGINT UNSIGNED | YES | NULL |
| `purpose` | VARCHAR(50) | NO | — |
| `destination` | VARCHAR(320) | NO | — |
| `code_hash` | CHAR(64) | NO | — |
| `expires_at` | DATETIME | NO | — |
| `attempt_count` | INT UNSIGNED | NO | 0 |
| `max_attempts` | INT UNSIGNED | NO | 5 |
| `consumed_at` | DATETIME | YES | NULL |
| `created_at` | DATETIME | NO | — |

Purposes:

```text
email_verification
login
password_reset
account_recovery
custom
```

Indexes:

```text
(user_id, created_at)
(project_id, created_at)
(destination)
(expires_at)
```

Plaintext OTP values are never stored.

## 8. `sessions`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `user_id` | BIGINT UNSIGNED | NO | — |
| `session_token_hash` | CHAR(64) | NO | — |
| `ip_address` | VARCHAR(45) | YES | NULL |
| `user_agent` | VARCHAR(1024) | YES | NULL |
| `last_activity_at` | DATETIME | NO | — |
| `expires_at` | DATETIME | NO | — |
| `revoked_at` | DATETIME | YES | NULL |
| `created_at` | DATETIME | NO | — |

Constraints:

```text
PRIMARY KEY (id)
UNIQUE (session_token_hash)
FK user_id → users.id
```

Indexes:

```text
(user_id)
(expires_at)
(last_activity_at)
```

## 9. `projects`

Primary project/isolation boundary.

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `user_id` | BIGINT UNSIGNED | NO | — |
| `name` | VARCHAR(150) | NO | — |
| `slug` | VARCHAR(150) | NO | — |
| `status` | VARCHAR(32) | NO | `active` |
| `description` | TEXT | YES | NULL |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |
| `deleted_at` | DATETIME | YES | NULL |

Statuses: `active`, `suspended`, `archived`.

Constraints:

```text
PRIMARY KEY (id)
UNIQUE (user_id, slug)
FK user_id → users.id
```

Indexes:

```text
(user_id)
(user_id, status)
```

## 10. `project_settings`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `project_id` | BIGINT UNSIGNED | NO | — |
| `default_provider_id` | BIGINT UNSIGNED | YES | NULL |
| `default_from_email` | VARCHAR(320) | YES | NULL |
| `default_from_name` | VARCHAR(150) | YES | NULL |
| `default_reply_to` | VARCHAR(320) | YES | NULL |
| `allowed_origins` | JSON | YES | NULL |
| `api_settings` | JSON | YES | NULL |
| `notification_settings` | JSON | YES | NULL |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |

Constraints:

```text
PRIMARY KEY (id)
UNIQUE (project_id)
FK project_id → projects.id
```

`default_provider_id` must be validated as belonging to the same project.

## 11. `providers`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `code` | VARCHAR(50) | NO | — |
| `name` | VARCHAR(100) | NO | — |
| `description` | TEXT | YES | NULL |
| `status` | VARCHAR(32) | NO | `active` |
| `capabilities` | JSON | YES | NULL |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |

Provider codes:

```text
gmail
smtp
brevo
mailtrap
```

`brevo` and `mailtrap` are optional integrations; Gmail and SMTP are primary.

Constraint:

```text
UNIQUE (code)
```

## 12. `user_providers`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `project_id` | BIGINT UNSIGNED | NO | — |
| `provider_id` | BIGINT UNSIGNED | NO | — |
| `name` | VARCHAR(150) | NO | — |
| `status` | VARCHAR(32) | NO | `pending` |
| `is_default` | TINYINT(1) | NO | 0 |
| `last_tested_at` | DATETIME | YES | NULL |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |
| `deleted_at` | DATETIME | YES | NULL |

Statuses:

```text
pending
active
testing
error
expired
disconnected
disabled
```

Indexes:

```text
(project_id)
(project_id, status)
(provider_id)
```

## 13. `gmail_connections`

Encrypted Gmail OAuth material.

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `user_provider_id` | BIGINT UNSIGNED | NO | — |
| `google_account_email` | VARCHAR(320) | YES | NULL |
| `access_token_encrypted` | TEXT | YES | NULL |
| `refresh_token_encrypted` | TEXT | NO | — |
| `token_expires_at` | DATETIME | YES | NULL |
| `scopes` | JSON | YES | NULL |
| `encryption_version` | SMALLINT UNSIGNED | NO | 1 |
| `key_version` | SMALLINT UNSIGNED | NO | 1 |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |

Constraints:

```text
PRIMARY KEY (id)
UNIQUE (user_provider_id)
FK user_provider_id → user_providers.id
```

## 14. `smtp_connections`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `user_provider_id` | BIGINT UNSIGNED | NO | — |
| `host` | VARCHAR(255) | NO | — |
| `port` | SMALLINT UNSIGNED | NO | 587 |
| `encryption` | VARCHAR(20) | NO | `starttls` |
| `username` | VARCHAR(320) | YES | NULL |
| `password_encrypted` | TEXT | YES | NULL |
| `authentication_mode` | VARCHAR(32) | NO | `login` |
| `from_email` | VARCHAR(320) | YES | NULL |
| `from_name` | VARCHAR(150) | YES | NULL |
| `encryption_version` | SMALLINT UNSIGNED | NO | 1 |
| `key_version` | SMALLINT UNSIGNED | NO | 1 |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |

Encryption values:

```text
none
starttls
ssl
```

Constraints:

```text
UNIQUE (user_provider_id)
FK user_provider_id → user_providers.id
```

## 15. `templates`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `project_id` | BIGINT UNSIGNED | NO | — |
| `name` | VARCHAR(150) | NO | — |
| `slug` | VARCHAR(150) | NO | — |
| `subject` | VARCHAR(998) | YES | NULL |
| `status` | VARCHAR(32) | NO | `draft` |
| `current_version_id` | BIGINT UNSIGNED | YES | NULL |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |
| `deleted_at` | DATETIME | YES | NULL |

Statuses: `draft`, `active`, `archived`.

Constraints:

```text
UNIQUE (project_id, slug)
FK project_id → projects.id
```

The `current_version_id` FK is added after `template_versions` exists.

## 16. `template_versions`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `template_id` | BIGINT UNSIGNED | NO | — |
| `version_number` | INT UNSIGNED | NO | — |
| `subject` | VARCHAR(998) | YES | NULL |
| `html_body` | MEDIUMTEXT | NO | — |
| `text_body` | MEDIUMTEXT | YES | NULL |
| `variables_schema` | JSON | YES | NULL |
| `created_by` | BIGINT UNSIGNED | YES | NULL |
| `created_at` | DATETIME | NO | — |

Constraints:

```text
UNIQUE (template_id, version_number)
FK template_id → templates.id
FK created_by → users.id
```

Versions are immutable.

## 17. `api_keys`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `project_id` | BIGINT UNSIGNED | NO | — |
| `name` | VARCHAR(150) | NO | — |
| `key_prefix` | VARCHAR(32) | NO | — |
| `key_hash` | CHAR(64) | NO | — |
| `permissions` | JSON | YES | NULL |
| `last_used_at` | DATETIME | YES | NULL |
| `expires_at` | DATETIME | YES | NULL |
| `revoked_at` | DATETIME | YES | NULL |
| `created_at` | DATETIME | NO | — |

Constraints:

```text
UNIQUE (key_hash)
FK project_id → projects.id
```

Indexes:

```text
(project_id)
(key_prefix)
```

The complete API secret is displayed only once at creation.

## 18. `api_requests`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `project_id` | BIGINT UNSIGNED | YES | NULL |
| `api_key_id` | BIGINT UNSIGNED | YES | NULL |
| `user_id` | BIGINT UNSIGNED | YES | NULL |
| `request_id` | CHAR(36) | NO | — |
| `method` | VARCHAR(10) | NO | — |
| `route` | VARCHAR(255) | NO | — |
| `status_code` | SMALLINT UNSIGNED | NO | — |
| `ip_address` | VARCHAR(45) | YES | NULL |
| `user_agent` | VARCHAR(1024) | YES | NULL |
| `request_size` | INT UNSIGNED | YES | NULL |
| `response_size` | INT UNSIGNED | YES | NULL |
| `duration_ms` | INT UNSIGNED | YES | NULL |
| `created_at` | DATETIME | NO | — |

Indexes:

```text
(project_id, created_at)
(request_id)
(status_code, created_at)
(api_key_id, created_at)
```

Raw request bodies are not stored by default.

## 19. `email_logs`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `project_id` | BIGINT UNSIGNED | NO | — |
| `provider_connection_id` | BIGINT UNSIGNED | YES | NULL |
| `template_id` | BIGINT UNSIGNED | YES | NULL |
| `api_key_id` | BIGINT UNSIGNED | YES | NULL |
| `request_id` | CHAR(36) | YES | NULL |
| `message_id` | VARCHAR(255) | YES | NULL |
| `to_address` | VARCHAR(320) | NO | — |
| `from_address` | VARCHAR(320) | YES | NULL |
| `reply_to` | VARCHAR(320) | YES | NULL |
| `subject` | VARCHAR(998) | YES | NULL |
| `status` | VARCHAR(32) | NO | `queued` |
| `provider_status` | VARCHAR(100) | YES | NULL |
| `provider_message_id` | VARCHAR(255) | YES | NULL |
| `error_code` | VARCHAR(100) | YES | NULL |
| `error_message` | TEXT | YES | NULL |
| `attempt_count` | INT UNSIGNED | NO | 0 |
| `queued_at` | DATETIME | YES | NULL |
| `sent_at` | DATETIME | YES | NULL |
| `failed_at` | DATETIME | YES | NULL |
| `created_at` | DATETIME | NO | — |

Statuses:

```text
queued
processing
sent
failed
cancelled
```

Indexes:

```text
(project_id, created_at)
(project_id, status, created_at)
(request_id)
(provider_message_id)
(template_id)
```

Email bodies are intentionally excluded from the default operational log schema.

## 20. `otp_logs`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `project_id` | BIGINT UNSIGNED | NO | — |
| `user_id` | BIGINT UNSIGNED | YES | NULL |
| `request_id` | CHAR(36) | YES | NULL |
| `purpose` | VARCHAR(50) | NO | — |
| `destination` | VARCHAR(320) | NO | — |
| `status` | VARCHAR(32) | NO | — |
| `attempt_count` | INT UNSIGNED | NO | 0 |
| `provider_connection_id` | BIGINT UNSIGNED | YES | NULL |
| `error_code` | VARCHAR(100) | YES | NULL |
| `created_at` | DATETIME | NO | — |
| `verified_at` | DATETIME | YES | NULL |
| `expired_at` | DATETIME | YES | NULL |

Statuses:

```text
sent
verified
failed
expired
blocked
```

Indexes:

```text
(project_id, created_at)
(project_id, status, created_at)
(request_id)
```

## 21. `webhooks`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `project_id` | BIGINT UNSIGNED | NO | — |
| `name` | VARCHAR(150) | NO | — |
| `url` | VARCHAR(2048) | NO | — |
| `secret_encrypted` | TEXT | NO | — |
| `events` | JSON | NO | — |
| `status` | VARCHAR(32) | NO | `active` |
| `failure_count` | INT UNSIGNED | NO | 0 |
| `last_success_at` | DATETIME | YES | NULL |
| `last_failure_at` | DATETIME | YES | NULL |
| `encryption_version` | SMALLINT UNSIGNED | NO | 1 |
| `key_version` | SMALLINT UNSIGNED | NO | 1 |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |

Statuses: `active`, `disabled`, `failing`.

## 22. `webhook_logs`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `webhook_id` | BIGINT UNSIGNED | NO | — |
| `event_type` | VARCHAR(100) | NO | — |
| `event_id` | CHAR(36) | NO | — |
| `attempt_number` | INT UNSIGNED | NO | 1 |
| `request_id` | CHAR(36) | YES | NULL |
| `response_status` | SMALLINT UNSIGNED | YES | NULL |
| `response_time_ms` | INT UNSIGNED | YES | NULL |
| `response_body_excerpt` | TEXT | YES | NULL |
| `status` | VARCHAR(32) | NO | — |
| `error_message` | TEXT | YES | NULL |
| `next_retry_at` | DATETIME | YES | NULL |
| `created_at` | DATETIME | NO | — |

Statuses:

```text
pending
success
failed
retrying
cancelled
```

Response bodies are bounded diagnostic excerpts only.

## 23. `notifications`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `user_id` | BIGINT UNSIGNED | NO | — |
| `project_id` | BIGINT UNSIGNED | YES | NULL |
| `type` | VARCHAR(50) | NO | — |
| `title` | VARCHAR(255) | NO | — |
| `message` | TEXT | NO | — |
| `severity` | VARCHAR(20) | NO | `info` |
| `read_at` | DATETIME | YES | NULL |
| `created_at` | DATETIME | NO | — |

Severity: `info`, `success`, `warning`, `error`.

Indexes:

```text
(user_id, created_at)
(user_id, read_at)
(project_id, created_at)
```

## 24. `usage_statistics`

Daily project aggregation.

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `project_id` | BIGINT UNSIGNED | NO | — |
| `usage_date` | DATE | NO | — |
| `emails_sent` | BIGINT UNSIGNED | NO | 0 |
| `emails_failed` | BIGINT UNSIGNED | NO | 0 |
| `otp_sent` | BIGINT UNSIGNED | NO | 0 |
| `otp_verified` | BIGINT UNSIGNED | NO | 0 |
| `api_requests` | BIGINT UNSIGNED | NO | 0 |
| `api_errors` | BIGINT UNSIGNED | NO | 0 |
| `webhook_deliveries` | BIGINT UNSIGNED | NO | 0 |
| `webhook_failures` | BIGINT UNSIGNED | NO | 0 |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |

Constraint:

```text
UNIQUE (project_id, usage_date)
```

## 25. `login_attempts`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `user_id` | BIGINT UNSIGNED | YES | NULL |
| `email` | VARCHAR(320) | NO | — |
| `ip_address` | VARCHAR(45) | YES | NULL |
| `user_agent` | VARCHAR(1024) | YES | NULL |
| `success` | TINYINT(1) | NO | 0 |
| `failure_reason` | VARCHAR(100) | YES | NULL |
| `created_at` | DATETIME | NO | — |

Indexes:

```text
(email, created_at)
(ip_address, created_at)
(user_id, created_at)
```

## 26. `blocked_ips`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `ip_address` | VARCHAR(45) | NO | — |
| `reason` | VARCHAR(255) | YES | NULL |
| `scope` | VARCHAR(32) | NO | `global` |
| `expires_at` | DATETIME | YES | NULL |
| `created_by` | BIGINT UNSIGNED | YES | NULL |
| `created_at` | DATETIME | NO | — |

Scopes:

```text
global
login
api
admin
```

Indexes:

```text
UNIQUE (ip_address, scope)
(expires_at)
```

`created_by` references `admin_users.id`.

## 27. `security_logs`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `user_id` | BIGINT UNSIGNED | YES | NULL |
| `project_id` | BIGINT UNSIGNED | YES | NULL |
| `admin_user_id` | BIGINT UNSIGNED | YES | NULL |
| `event_type` | VARCHAR(100) | NO | — |
| `severity` | VARCHAR(20) | NO | `info` |
| `ip_address` | VARCHAR(45) | YES | NULL |
| `user_agent` | VARCHAR(1024) | YES | NULL |
| `request_id` | CHAR(36) | YES | NULL |
| `metadata` | JSON | YES | NULL |
| `created_at` | DATETIME | NO | — |

Severity: `info`, `warning`, `critical`.

Indexes:

```text
(user_id, created_at)
(project_id, created_at)
(event_type, created_at)
(admin_user_id, created_at)
```

Never put passwords, tokens, API secrets, SMTP passwords, or OTP values into `metadata`.

## 28. `admin_users`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `email` | VARCHAR(320) | NO | — |
| `password_hash` | VARCHAR(255) | NO | — |
| `name` | VARCHAR(150) | NO | — |
| `role` | VARCHAR(32) | NO | `admin` |
| `status` | VARCHAR(32) | NO | `active` |
| `last_login_at` | DATETIME | YES | NULL |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |

Roles: `super_admin`, `admin`, `support`, `auditor`.

Statuses: `active`, `suspended`, `disabled`.

Constraint:

```text
UNIQUE (email)
```

## 29. `admin_logs`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `admin_user_id` | BIGINT UNSIGNED | NO | — |
| `action` | VARCHAR(100) | NO | — |
| `target_type` | VARCHAR(100) | YES | NULL |
| `target_id` | BIGINT UNSIGNED | YES | NULL |
| `ip_address` | VARCHAR(45) | YES | NULL |
| `request_id` | CHAR(36) | YES | NULL |
| `metadata` | JSON | YES | NULL |
| `created_at` | DATETIME | NO | — |

Indexes:

```text
(admin_user_id, created_at)
(target_type, target_id)
(action, created_at)
```

## 30. `system_settings`

| Column | Type | Null | Default |
|---|---|---:|---|
| `id` | BIGINT UNSIGNED | NO | AUTO_INCREMENT |
| `setting_key` | VARCHAR(150) | NO | — |
| `setting_value` | JSON | YES | NULL |
| `is_secret` | TINYINT(1) | NO | 0 |
| `description` | VARCHAR(500) | YES | NULL |
| `created_at` | DATETIME | NO | — |
| `updated_at` | DATETIME | NO | — |

Constraint:

```text
UNIQUE (setting_key)
```

Platform secrets should normally remain in deployment/environment secret storage.

# 31. Relationship Matrix

| Parent | Child | Relationship |
|---|---|---|
| users | user_profiles | 1:1 |
| users | email_verifications | 1:N |
| users | otp_codes | 1:N |
| users | sessions | 1:N |
| users | projects | 1:N |
| users | login_attempts | 1:N |
| users | notifications | 1:N |
| projects | project_settings | 1:1 |
| providers | user_providers | 1:N |
| projects | user_providers | 1:N |
| user_providers | gmail_connections | 1:1 |
| user_providers | smtp_connections | 1:1 |
| projects | templates | 1:N |
| templates | template_versions | 1:N |
| projects | api_keys | 1:N |
| projects | api_requests | 1:N |
| projects | email_logs | 1:N |
| projects | otp_logs | 1:N |
| projects | webhooks | 1:N |
| webhooks | webhook_logs | 1:N |
| projects | notifications | 1:N |
| projects | usage_statistics | 1:N |
| admin_users | admin_logs | 1:N |

# 32. Foreign-Key Map

```text
user_profiles.user_id → users.id
email_verifications.user_id → users.id
otp_codes.user_id → users.id
otp_codes.project_id → projects.id
sessions.user_id → users.id
projects.user_id → users.id
project_settings.project_id → projects.id

user_providers.project_id → projects.id
user_providers.provider_id → providers.id
gmail_connections.user_provider_id → user_providers.id
smtp_connections.user_provider_id → user_providers.id

templates.project_id → projects.id
template_versions.template_id → templates.id
template_versions.created_by → users.id

api_keys.project_id → projects.id
api_requests.project_id → projects.id
api_requests.api_key_id → api_keys.id
api_requests.user_id → users.id

email_logs.project_id → projects.id
email_logs.provider_connection_id → user_providers.id
email_logs.template_id → templates.id
email_logs.api_key_id → api_keys.id

otp_logs.project_id → projects.id
otp_logs.user_id → users.id
otp_logs.provider_connection_id → user_providers.id

webhooks.project_id → projects.id
webhook_logs.webhook_id → webhooks.id

notifications.user_id → users.id
notifications.project_id → projects.id
usage_statistics.project_id → projects.id

login_attempts.user_id → users.id
blocked_ips.created_by → admin_users.id

security_logs.user_id → users.id
security_logs.project_id → projects.id
security_logs.admin_user_id → admin_users.id
admin_logs.admin_user_id → admin_users.id
```

# 33. Cross-Entity Integrity

Foreign keys alone cannot enforce every business rule.

Examples:

```text
project_settings.default_provider_id
```

must reference a provider connection belonging to the same project.

Likewise:

```text
email_logs.template_id
email_logs.api_key_id
email_logs.provider_connection_id
```

must belong to the same project.

The service layer must validate project ownership before writes.

# 34. Delete Strategy

Default core policy:

```text
ON DELETE RESTRICT
```

unless a child has no meaningful independent lifecycle.

Prefer soft deletion for:

```text
users
projects
templates
user_providers
```

API keys are revoked rather than destroyed.

Historical email/security/admin records should not disappear merely because a user or project is archived.

Do not use blanket cascading deletes.

# 35. Template Current-Version Constraint

`templates.current_version_id` references `template_versions.id`.

Migration sequence:

1. create `templates`;
2. create `template_versions`;
3. add the `current_version_id` FK;
4. create/update versions transactionally.

# 36. Lifecycle Rules

## Project

```text
active → suspended → active
active → archived
```

## Provider

```text
pending → testing → active
active → error
active → disconnected
active → disabled
```

## API key

```text
active → revoked
active → expired
```

## Template

```text
draft → active → archived
```

## Email

```text
queued → processing → sent
queued → failed
processing → failed
queued → cancelled
```

## Webhook

```text
pending → success
pending → failed → retrying → success
```

Status transitions belong to service-layer business logic.

# 37. Project Isolation Rule

Every project-scoped query must establish:

```text
authenticated user
    ↓
authorized project
    ↓
resource.project_id
```

Example:

```sql
SELECT *
FROM templates
WHERE id = :template_id
  AND project_id = :project_id
  AND deleted_at IS NULL;
```

Never authorize a resource using only its numeric ID.

# 38. API Key Authentication

```text
incoming key
    ↓
extract prefix
    ↓
find candidate active keys
    ↓
securely verify supplied secret against key_hash
    ↓
check revoked_at
    ↓
check expires_at
    ↓
check project status
    ↓
authorize permissions
```

The plaintext secret is never stored.

# 39. OTP Verification

Validate:

```text
code_hash
purpose
destination
expires_at
consumed_at
attempt_count
max_attempts
```

Successful consumption must be transactional so concurrent requests cannot reuse the same OTP.

# 40. Template Versioning

New content creates a new `template_versions` record.

Recommended transaction:

```text
BEGIN
  lock template
  determine next version
  INSERT template_versions
  UPDATE templates.current_version_id
COMMIT
```

The unique `(template_id, version_number)` constraint prevents duplicates.

# 41. Usage Aggregation

Exactly one logical usage row exists for:

```text
(project_id, usage_date)
```

Counters are updated atomically.

This table powers dashboards without repeatedly scanning raw logs.

# 42. Index Strategy

High-priority indexes:

```text
users(email) UNIQUE

projects(user_id, slug) UNIQUE
projects(user_id, status)

user_providers(project_id, status)

templates(project_id, slug) UNIQUE
templates(project_id, status)

api_keys(project_id)
api_keys(key_prefix)
api_keys(key_hash) UNIQUE

api_requests(project_id, created_at)
api_requests(request_id)

email_logs(project_id, created_at)
email_logs(project_id, status, created_at)
email_logs(request_id)
email_logs(provider_message_id)

otp_logs(project_id, created_at)
otp_logs(project_id, status, created_at)

webhook_logs(webhook_id, created_at)

notifications(user_id, created_at)

usage_statistics(project_id, usage_date) UNIQUE

login_attempts(email, created_at)
login_attempts(ip_address, created_at)

security_logs(user_id, created_at)
security_logs(project_id, created_at)
security_logs(event_type, created_at)
```

Do not create indexes speculatively on every column.

# 43. High-Volume Tables

Expected growth leaders:

```text
email_logs
api_requests
webhook_logs
security_logs
login_attempts
otp_logs
```

They require time-aware indexes, project indexes where applicable, pagination, bounded payloads, and retention policies.

Partitioning is not mandatory initially.

# 44. Retention/Cleanup

Use `created_at` and `expires_at` for cleanup.

High-volume cleanup should be batched:

```text
small DELETE batch
    ↓
COMMIT
    ↓
repeat
```

Avoid huge single-transaction deletions.

Exact production retention periods are deployment policy and must be documented before launch.

# 45. Secret Classification

| Data | Storage |
|---|---|
| User password | Password hash |
| Admin password | Password hash |
| API secret | Hash |
| OTP | Hash/protected |
| Session token | Hash/protected |
| Verification token | Hash |
| Gmail access token | Encrypted |
| Gmail refresh token | Encrypted |
| SMTP password | Encrypted |
| Webhook secret | Encrypted |
| Encryption key | Deployment secret storage |
| Normal email metadata | Protected relational value |
| Security metadata | Sanitized JSON |

Encryption keys must be separated appropriately from ciphertext.

# 46. Encryption Metadata

Encrypted credential records should include:

```text
encryption_version
key_version
```

Use a modern authenticated-encryption implementation supplied by the platform/library. Never invent custom cryptography.

# 47. Database Access Architecture

Required flow:

```text
Controller
   ↓
Service
   ↓
Repository
   ↓
PDO
   ↓
MySQL
```

Controllers handle HTTP concerns.

Services own business rules and transactions.

Repositories own persistence queries.

# 48. Transaction Boundaries

Use transactions for related local changes:

```text
create project
    → project + settings

create template
    → template + initial version

revoke API key
    → key state + audit event

consume OTP
    → OTP state + verification outcome
```

Never hold a DB transaction open while waiting for SMTP/Gmail/network calls.

Preferred email flow:

```text
validate
  ↓
create email log
  ↓
commit
  ↓
provider call
  ↓
update email result
```

# 49. Example SQL — Users

```sql
CREATE TABLE users (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    email VARCHAR(320) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'pending',
    email_verified_at DATETIME NULL,
    last_login_at DATETIME NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    deleted_at DATETIME NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email),
    KEY idx_users_status (status)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;
```

# 50. Example SQL — Projects

```sql
CREATE TABLE projects (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(150) NOT NULL,
    slug VARCHAR(150) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'active',
    description TEXT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL,
    deleted_at DATETIME NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_projects_user_slug (user_id, slug),
    KEY idx_projects_user (user_id),
    KEY idx_projects_user_status (user_id, status),

    CONSTRAINT fk_projects_user
        FOREIGN KEY (user_id) REFERENCES users(id)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;
```

# 51. Example SQL — API Keys

```sql
CREATE TABLE api_keys (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    project_id BIGINT UNSIGNED NOT NULL,
    name VARCHAR(150) NOT NULL,
    key_prefix VARCHAR(32) NOT NULL,
    key_hash CHAR(64) NOT NULL,
    permissions JSON NULL,
    last_used_at DATETIME NULL,
    expires_at DATETIME NULL,
    revoked_at DATETIME NULL,
    created_at DATETIME NOT NULL,

    PRIMARY KEY (id),
    UNIQUE KEY uq_api_keys_hash (key_hash),
    KEY idx_api_keys_project (project_id),
    KEY idx_api_keys_prefix (key_prefix),

    CONSTRAINT fk_api_keys_project
        FOREIGN KEY (project_id) REFERENCES projects(id)
)
ENGINE=InnoDB
DEFAULT CHARACTER SET=utf8mb4
COLLATE=utf8mb4_0900_ai_ci;
```

# 52. Example SQL — Email Log Indexes

```sql
CREATE INDEX idx_email_logs_project_created
    ON email_logs (project_id, created_at);

CREATE INDEX idx_email_logs_project_status_created
    ON email_logs (project_id, status, created_at);

CREATE INDEX idx_email_logs_request_id
    ON email_logs (request_id);

CREATE INDEX idx_email_logs_provider_message
    ON email_logs (provider_message_id);
```

# 53. Database Security Rules

Use separate conceptual database accounts:

```text
runtime application account
migration/deployment account
DBA/administration account
```

The application must never run as MySQL root.

MySQL should normally be reachable only from the application host/network.

Database credentials must never be committed to Git.

# 54. Query Safety

Unsafe:

```php
$sql = "SELECT * FROM users WHERE email = '$email'";
```

Required:

```php
$stmt = $pdo->prepare(
    'SELECT * FROM users WHERE email = :email'
);

$stmt->execute([
    'email' => $email
]);
```

Dynamic SQL identifiers must use strict allowlists.

# 55. Pagination

Large datasets must always be paginated.

Use `LIMIT` and preferably cursor/keyset pagination for high-volume logs.

# 56. API/Database Boundary

Never return raw database rows directly.

Map database records to API resources/DTOs so internal fields such as:

```text
password_hash
key_hash
access_token_encrypted
refresh_token_encrypted
password_encrypted
secret_encrypted
```

can never accidentally appear in API responses.

# 57. Admin/Database Boundary

Admin users may inspect operational information but never plaintext secrets.

Allowed examples:

```text
SMTP host
SMTP port
username
connection status
last tested
```

Never expose:

```text
SMTP password
OAuth refresh token
API key secret
webhook secret
application encryption key
```

# 58. Audit Requirements

Sensitive operations must create security/admin records:

- login/security events;
- password changes;
- API key creation/revocation;
- provider connect/disconnect;
- credential changes;
- session revocation;
- project status changes;
- user suspension;
- admin changes;
- security setting changes.

Audit records should identify:

```text
who
what
when
where
target
request_id where available
```

# 59. Migration Order

Recommended:

```text
001_users
002_user_profiles
003_email_verifications
004_projects
005_project_settings
006_providers
007_user_providers
008_gmail_connections
009_smtp_connections
010_templates
011_template_versions
012_api_keys
013_api_requests
014_email_logs
015_otp_codes
016_otp_logs
017_webhooks
018_webhook_logs
019_notifications
020_usage_statistics
021_sessions
022_login_attempts
023_blocked_ips
024_security_logs
025_admin_users
026_admin_logs
027_system_settings
028_template_current_version_fk
029_additional_indexes_constraints
```

# 60. Migration Rules

Every schema change must be version-controlled, deterministic, tested against MySQL 8+, documented, and reviewed.

Avoid destructive changes during rolling deployments.

Preferred evolution:

```text
add nullable field
    ↓
deploy compatible code
    ↓
backfill
    ↓
add constraint
    ↓
remove obsolete structure later
```

# 61. Backup and Restore

Production requires:

- automated backups;
- protected backup storage;
- backup encryption;
- defined retention;
- restore testing;
- documented recovery procedures.

Credential encryption keys must be protected separately from database backups.

# 62. Testing Requirements

Schema tests must cover:

- duplicate user email rejection;
- project ownership;
- project isolation;
- duplicate project slug per user;
- template uniqueness;
- template version uniqueness;
- API key uniqueness;
- usage-date uniqueness;
- system-setting uniqueness;
- foreign-key integrity;
- OTP one-time consumption;
- transaction rollback;
- soft deletion;
- revoked API keys;
- expired credentials;
- audit record creation.

# 63. Performance Requirements

The schema must support:

- indexed project/time queries;
- paginated logs;
- aggregated dashboard statistics;
- efficient API key lookup;
- efficient session/OTP expiration checks;
- batched retention cleanup.

Do not repeatedly scan all email logs for dashboard loads, store huge message bodies by default, create unnecessary indexes, or hold transactions during external provider calls.

# 64. Schema-to-Module Mapping

| Module | Primary tables |
|---|---|
| User Authentication | `users`, `sessions`, `login_attempts` |
| Email Verification | `email_verifications` |
| OTP | `otp_codes`, `otp_logs` |
| Password Recovery | `otp_codes`, `email_verifications` |
| User Profile | `user_profiles` |
| Project Management | `projects`, `project_settings` |
| Gmail | `providers`, `user_providers`, `gmail_connections` |
| SMTP | `providers`, `user_providers`, `smtp_connections` |
| Template Engine | `templates`, `template_versions` |
| Email Engine | `email_logs` |
| REST API | `api_requests` |
| API Keys | `api_keys` |
| Webhooks | `webhooks`, `webhook_logs` |
| Usage | `usage_statistics` |
| Notifications | `notifications` |
| Security | `blocked_ips`, `security_logs` |
| Administration | `admin_users`, `admin_logs` |
| System | `system_settings` |

# 65. Future Provider Compatibility

Provider architecture remains:

```text
providers
    ↓
user_providers
    ↓
provider-specific connection
```

A future provider can add a registry record, provider-specific connection storage when required, and an adapter without redesigning projects, templates, API keys, email logs, webhooks, or usage statistics.

# 66. Future Queue Compatibility

Queues are not mandatory for the initial system.

Existing fields support future asynchronous processing:

```text
status
attempt_count
queued_at
sent_at
failed_at
next_retry_at
```

A future queue must not unnecessarily duplicate business truth.

# 67. Future Partitioning

Partitioning is not required initially.

Potential candidates if measured growth justifies it:

```text
email_logs
api_requests
webhook_logs
security_logs
login_attempts
otp_logs
```

Any partitioning change requires workload measurement, query testing, migration planning, and backup/restore testing.

# 68. Production Checklist

- [ ] MySQL 8+.
- [ ] InnoDB.
- [ ] `utf8mb4`.
- [ ] All 27 core tables defined.
- [ ] Primary keys defined.
- [ ] Foreign keys reviewed.
- [ ] Unique constraints reviewed.
- [ ] Project isolation enforced.
- [ ] High-volume indexes created.
- [ ] Secret fields protected.
- [ ] Password hashing implemented.
- [ ] API key hashing implemented.
- [ ] OTP protection implemented.
- [ ] OAuth/SMTP/webhook encryption implemented.
- [ ] UTC timestamps enforced.
- [ ] Soft-delete rules implemented.
- [ ] Migration runner implemented.
- [ ] Backup automation enabled.
- [ ] Restore test completed.
- [ ] Runtime DB account uses least privilege.
- [ ] Sensitive database errors are not exposed.

# 69. Definition of Done

This schema is complete when:

1. all 27 locked principal tables are implementation-defined;
2. all core columns have defined types and nullability;
3. primary, foreign, and unique keys are documented;
4. indexes support expected queries;
5. project isolation is enforced;
6. secret handling is explicit;
7. lifecycle/status rules are consistent;
8. migration order is established;
9. backup/recovery requirements are satisfied;
10. the schema remains fully consistent with `08-DATABASE-ARCHITECTURE.md`.

# 70. Final Lock

This document is **FINAL / LOCKED**.

It remains consistent with:

- the 25-document blueprint structure;
- 93 screens;
- 24 core modules;
- 29 user features;
- 14 API feature areas;
- 25 security features;
- PHP 8.3+;
- MySQL 8+;
- Gmail + Custom SMTP primary providers;
- optional Brevo + Mailtrap;
- project-based isolation;
- modular-monolith architecture.

**Next document:** `10-BACKEND-PHP-ARCHITECTURE.md`
