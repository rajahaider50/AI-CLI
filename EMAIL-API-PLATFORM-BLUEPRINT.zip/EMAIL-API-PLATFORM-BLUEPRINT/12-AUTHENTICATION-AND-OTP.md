# 12 — Authentication and OTP

**Project:** Email API Platform  
**Document:** `12-AUTHENTICATION-AND-OTP.md`  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Audience:** Backend developers, frontend developers, QA, security reviewers, DevOps  
**Related documents:** 00–11 and 13–24 in the master blueprint

---

## 1. Purpose

This document defines the complete authentication, authorization-adjacent identity flow, email verification, OTP, password recovery, session management, account recovery, and authentication security model for the Email API Platform.

The system must provide secure authentication for dashboard users while keeping project API-key authentication separate from user-session authentication.

Core identity flows:

- user registration;
- email verification;
- login;
- logout;
- password change;
- forgot password;
- password reset;
- OTP generation;
- OTP verification;
- OTP expiration;
- OTP attempt limits;
- OTP resend throttling;
- active-session management;
- session revocation;
- account recovery;
- security notifications;
- audit/security logging.

---

# 2. Locked Authentication Principles

1. Passwords are never stored in plaintext.
2. Passwords are hashed using PHP's password hashing API with a modern supported algorithm.
3. Authentication uses secure server-side sessions for the dashboard.
4. Session cookies are `Secure`, `HttpOnly`, and use an appropriate `SameSite` policy.
5. Session identifiers are rotated after successful authentication.
6. CSRF protection is mandatory for cookie-authenticated state-changing requests.
7. Login attempts are rate-limited.
8. OTP generation uses a cryptographically secure random source.
9. OTP values are never written to logs.
10. OTPs expire automatically.
11. OTP attempts are limited.
12. OTPs are single-use.
13. OTP resends are throttled.
14. Password-reset tokens are single-use and time-limited.
15. Authentication failures must not unnecessarily reveal whether an account exists.
16. Sensitive authentication events are audited.
17. Sessions can be individually revoked.
18. Users can revoke all active sessions.
19. Suspicious activity can trigger additional controls.
20. API keys are not substitutes for dashboard sessions.
21. Project API keys never grant administrative privileges.
22. Secrets are never returned after their one-time creation/display flow.
23. Authentication state is checked on every protected request.
24. Authorization remains separate from authentication.
25. Authentication behavior must remain consistent across web and API layers.

---

# 3. Identity Model

The platform has two primary identity contexts.

## 3.1 Dashboard user

Represents a registered platform user.

Typical identifiers:

```text
user_id
email
name
password_hash
email_verified_at
status
created_at
updated_at
```

A user can own or access projects according to the platform's project authorization model.

## 3.2 Project API client

Represents an external application using a project API key.

Example:

```http
X-API-Key: eak_live_...
```

The API key belongs to a project, not directly to a browser session.

The API key may be restricted by:

- project;
- scope;
- status;
- origin policy;
- rate limit;
- expiration.

---

# 4. Authentication Architecture

```text
                    ┌────────────────────┐
                    │   Dashboard User   │
                    └─────────┬──────────┘
                              │
                         Login / OTP
                              │
                              ▼
                    ┌────────────────────┐
                    │ Authentication     │
                    │ Service             │
                    └─────────┬──────────┘
                              │
                    ┌─────────┴─────────┐
                    │ Secure Session     │
                    │ + CSRF Protection  │
                    └─────────┬─────────┘
                              │
                              ▼
                       Protected Panel
                              │
                              ▼
                   Projects / Providers /
                   Templates / API Keys

External Application
        │
        ▼
   X-API-Key
        │
        ▼
 API Authentication
        │
        ▼
 Project + Scope Policy
        │
        ▼
 Email / OTP / Template APIs
```

---

# 5. User Registration

Endpoint:

```http
POST /api/v1/auth/register
```

Request:

```json
{
  "name": "Example User",
  "email": "user@example.com",
  "password": "StrongPasswordHere"
}
```

## 5.1 Registration validation

Validate:

- name required;
- safe length;
- email syntax;
- normalized email representation;
- password policy;
- duplicate account handling;
- account status rules.

Do not accept:

- executable content;
- malformed email;
- empty password;
- unbounded input;
- known invalid Unicode/control input where prohibited.

## 5.2 Password policy

The platform should enforce a practical password policy that prioritizes length and resistance to guessing.

Minimum requirements should be defined centrally and applied consistently.

Recommended baseline:

- minimum 12 characters;
- maximum accepted length sufficiently high to support passphrases;
- no forced periodic password changes without a security reason;
- breached/common-password screening where available;
- reject passwords that are clearly unsafe.

Never truncate passwords silently.

## 5.3 Registration process

```text
Receive registration
       ↓
Validate fields
       ↓
Normalize email
       ↓
Check account state
       ↓
Hash password
       ↓
Create user
       ↓
Create email-verification token
       ↓
Send verification email
       ↓
Create security/audit event
       ↓
Return safe response
```

---

# 6. Email Normalization

Email addresses must be handled consistently.

At minimum:

- trim surrounding whitespace;
- validate syntax;
- normalize the domain portion appropriately;
- use a consistent database comparison strategy.

Do not arbitrarily modify provider-specific local parts.

The canonical account email representation must be documented and used consistently for uniqueness checks.

---

# 7. Password Hashing

Use PHP's password hashing API:

```php
password_hash($password, PASSWORD_DEFAULT);
```

Verification:

```php
password_verify($password, $passwordHash);
```

The implementation should use the strongest practical algorithm supported by the production PHP version and deployment requirements.

Never implement a custom password-hashing algorithm.

Never use:

```text
MD5
SHA1
plain SHA-256
reversible encryption
```

as the sole password-storage mechanism.

---

# 8. Password Rehashing

On successful login:

```php
password_needs_rehash(...)
```

may be used to upgrade an older password hash.

Flow:

```text
Verify password
      ↓
Successful?
      ↓
Check hash parameters
      ↓
Needs rehash?
      ↓
Create new hash
      ↓
Update database
```

This permits security improvements without forcing all users to reset passwords immediately.

---

# 9. Email Verification

Email verification confirms ownership of the registered email address.

Endpoint:

```http
POST /api/v1/auth/verify-email
```

Request:

```json
{
  "token": "verification-token"
}
```

## 9.1 Verification token requirements

The token must be:

- cryptographically random;
- sufficiently long;
- time-limited;
- single-use;
- securely represented in storage;
- invalidated after successful use.

The raw token should not be stored unnecessarily.

## 9.2 Verification lifecycle

```text
Registration
   ↓
Generate token
   ↓
Store secure token representation
   ↓
Send email
   ↓
User opens verification link
   ↓
Submit token
   ↓
Validate
   ↓
Mark email verified
   ↓
Invalidate token
   ↓
Record audit event
```

---

# 10. Resend Verification

Endpoint:

```http
POST /api/v1/auth/resend-verification
```

This endpoint must be rate-limited.

Recommended controls:

- per-account cooldown;
- per-IP rate limit;
- maximum sends per period;
- token invalidation/rotation;
- abuse monitoring.

Responses should avoid revealing unnecessary account-existence information.

---

# 11. Login

Endpoint:

```http
POST /api/v1/auth/login
```

Request:

```json
{
  "email": "user@example.com",
  "password": "StrongPasswordHere"
}
```

## 11.1 Login process

```text
Receive credentials
        ↓
Validate request
        ↓
Apply IP/account rate limit
        ↓
Load user
        ↓
Verify password
        ↓
Check account status
        ↓
Check required verification/security state
        ↓
Rotate session ID
        ↓
Create authenticated session
        ↓
Record successful login
        ↓
Return safe response
```

## 11.2 Failed login

Do not reveal:

```text
Email does not exist.
Password is wrong.
```

as separate externally observable account-enumeration responses.

Prefer a generic message:

```text
Invalid email or password.
```

Timing differences should be minimized where practical.

---

# 12. Login Attempt Protection

Track appropriate metadata:

- IP address;
- timestamp;
- success/failure;
- user reference where safely available;
- request ID;
- user-agent metadata where justified.

Do not create unlimited detailed records that become a privacy or storage problem.

Controls may include:

- progressive delays;
- temporary account/IP throttling;
- CAPTCHA/challenge integration if later introduced;
- suspicious-login detection;
- security notifications.

Avoid permanent lockouts that can become denial-of-service tools.

---

# 13. Account Status

Recommended user statuses:

```text
pending
active
suspended
disabled
```

Behavior:

| Status | Login |
|---|---|
| pending | Restricted until required verification |
| active | Allowed |
| suspended | Denied |
| disabled | Denied |

Suspension/disablement must invalidate appropriate sessions and credentials.

---

# 14. Secure Sessions

Dashboard authentication uses server-side sessions.

The browser receives a session cookie; the server maintains the authoritative authentication state.

Cookie requirements:

```text
Secure
HttpOnly
SameSite=Lax or stricter where compatible
```

Cookie naming should avoid unnecessarily revealing implementation details.

The session must not contain excessive sensitive data.

Prefer storing a session identifier and retrieving authoritative state server-side.

---

# 15. Session Rotation

Rotate the session identifier after:

- successful login;
- privilege escalation;
- sensitive account recovery;
- password reset;
- other authentication-boundary transitions.

This protects against session fixation.

---

# 16. Session Record

The `sessions` domain may contain:

```text
id
user_id
session_token_hash / session identifier representation
ip_address
user_agent
created_at
last_activity_at
expires_at
revoked_at
```

Do not store raw session credentials unnecessarily.

---

# 17. Session Expiration

Support:

- idle timeout;
- absolute maximum lifetime;
- explicit logout;
- manual revocation;
- password/security-event invalidation.

Timeout values should be configurable centrally.

Do not keep sessions alive indefinitely.

---

# 18. Logout

Endpoint:

```http
POST /api/v1/auth/logout
```

Logout must:

1. authenticate current session;
2. revoke/invalidate session;
3. clear session cookie;
4. record appropriate event;
5. prevent reuse.

A logout response must not expose session secrets.

---

# 19. Active Sessions

List:

```http
GET /api/v1/auth/sessions
```

Revoke one:

```http
DELETE /api/v1/auth/sessions/{session_id}
```

Revoke all:

```http
POST /api/v1/auth/sessions/revoke-all
```

Safe session metadata may include:

- approximate location information derived from IP where appropriate;
- browser/device description;
- last activity;
- created time;
- current-session marker.

Do not expose raw IP data unless justified by the product/security design.

---

# 20. Password Change

Endpoint:

```http
POST /api/v1/auth/change-password
```

Request:

```json
{
  "current_password": "CurrentPassword",
  "new_password": "NewStrongPassword"
}
```

Flow:

```text
Authenticate session
       ↓
Verify current password
       ↓
Validate new password
       ↓
Hash new password
       ↓
Update password
       ↓
Revoke selected/all other sessions
       ↓
Record security event
       ↓
Notify user
```

The current session may remain active if the security policy permits; all other sessions should normally be revoked after a password change.

---

# 21. Forgot Password

Endpoint:

```http
POST /api/v1/auth/forgot-password
```

Request:

```json
{
  "email": "user@example.com"
}
```

The response should not reveal whether the account exists.

Example:

```json
{
  "success": true,
  "data": {
    "message": "If an eligible account exists, password recovery instructions will be sent."
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

---

# 22. Password Reset Token

Password reset tokens must be:

- cryptographically random;
- high entropy;
- single-use;
- short-lived;
- securely stored/represented;
- invalidated after use;
- invalidated after appropriate security changes.

Recommended lifecycle:

```text
Forgot password request
        ↓
Generate token
        ↓
Store secure representation
        ↓
Send reset email
        ↓
User submits token + new password
        ↓
Validate token
        ↓
Change password
        ↓
Invalidate token
        ↓
Revoke sessions
        ↓
Notify user
```

---

# 23. Account Recovery

Account recovery is intended for users who cannot complete normal login/recovery steps.

Possible controlled recovery signals:

- verified email;
- previously verified account information;
- recovery token;
- security verification;
- administrator-assisted recovery where explicitly supported.

Recovery must not provide a mechanism for bypassing identity verification.

Do not implement secret questions as the sole security factor.

---

# 24. OTP System Overview

The OTP subsystem is used for:

- login verification;
- email verification where configured;
- account recovery;
- password/security confirmation;
- application-level OTP sending;
- other approved verification purposes.

The OTP system must be purpose-bound.

Example purposes:

```text
login
email_verification
password_reset
account_recovery
transactional
```

A code generated for one purpose must not automatically be valid for another.

---

# 25. OTP Generation

OTP values must be generated with a cryptographically secure random generator.

For a six-digit numeric OTP, use a secure random integer range rather than predictable pseudo-random functions.

Conceptually:

```text
000000–999999
```

The implementation must preserve leading zeroes.

Do not use:

```text
rand()
mt_rand()
timestamp-based codes
user ID + timestamp
```

as the security source.

---

# 26. OTP Storage

Do not store plaintext OTP values where avoidable.

Recommended model:

```text
OTP plaintext
     ↓
secure representation/hash
     ↓
database
```

At verification time:

```text
submitted code
     ↓
secure comparison/verification
     ↓
valid?
```

Store metadata such as:

- OTP ID;
- user/project reference;
- purpose;
- destination;
- creation time;
- expiration time;
- attempt count;
- maximum attempts;
- status;
- verified time;
- consumed time.

Never log the actual OTP.

---

# 27. OTP Expiration

OTP validity must be short.

Recommended baseline:

```text
5 minutes
```

The exact TTL may be configurable by OTP purpose, but must remain within a security-reviewed range.

Expired OTPs must fail verification.

An expired OTP must never be revived.

---

# 28. OTP Attempt Limits

Every OTP must have a maximum verification-attempt count.

Recommended baseline:

```text
5 attempts
```

After the limit:

```text
OTP_ATTEMPTS_EXCEEDED
```

The OTP becomes invalid.

Attempt counters must be updated safely under concurrency to prevent race-condition bypasses.

---

# 29. OTP Resend Rules

Resending must not simply create unlimited valid codes.

Recommended behavior:

```text
Request OTP
   ↓
Cooldown check
   ↓
Generate new OTP
   ↓
Invalidate prior OTP for same purpose/context
   ↓
Send new OTP
   ↓
Record event
```

Recommended baseline:

```text
60-second resend cooldown
```

Additional limits:

- per account;
- per IP;
- per project;
- per destination;
- per time window.

---

# 30. OTP Verification

Endpoint:

```http
POST /api/v1/otp/verify
```

Request:

```json
{
  "otp_id": "otp_...",
  "code": "123456"
}
```

Verification order:

1. validate request;
2. authenticate context where required;
3. load OTP;
4. verify purpose/context;
5. check status;
6. check expiration;
7. check attempts;
8. securely compare/verify code;
9. increment attempt count safely;
10. consume on success;
11. record verification event.

A successful OTP can never be reused.

---

# 31. OTP API — Send

Endpoint:

```http
POST /api/v1/otp/send
```

Example:

```json
{
  "channel": "email",
  "recipient": {
    "email": "user@example.com",
    "name": "John"
  },
  "purpose": "login",
  "template_id": "tpl_otp"
}
```

The server generates the code.

Response:

```json
{
  "success": true,
  "data": {
    "otp_id": "otp_...",
    "expires_in": 300,
    "status": "sent"
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

Never return:

```json
{
  "code": "123456"
}
```

from the production send endpoint.

---

# 32. OTP Delivery

The OTP system should use the Email Engine rather than implementing an independent mail-sending stack.

Flow:

```text
OTP Service
    ↓
Create OTP
    ↓
Template Engine
    ↓
Email Engine
    ↓
Provider Adapter
    ↓
Gmail / SMTP / Optional Provider
    ↓
Recipient
```

This keeps provider behavior, logging, retries, and security centralized.

---

# 33. OTP Delivery Failure

If email delivery fails:

- mark OTP appropriately;
- record delivery failure;
- do not reveal provider credentials;
- return a controlled error;
- permit a safe retry according to rate limits.

Do not treat an unconfirmed provider acceptance as successful OTP delivery unless the email engine's contract explicitly defines that state.

---

# 34. OTP Security Context

OTP records must be bound to the correct context.

Depending on use case:

```text
user_id
project_id
purpose
recipient
otp_id
```

A code created for one project must not be usable in another project.

A code created for one user must not be accepted for another user.

A code created for one purpose must not satisfy a different purpose.

---

# 35. Login OTP / Step-Up Verification

If OTP is required for login:

```text
Email + Password
       ↓
Credentials valid
       ↓
OTP required
       ↓
Send OTP
       ↓
User submits OTP
       ↓
Verify
       ↓
Create authenticated session
```

Do not create a fully privileged authenticated session before required second-step verification is complete.

A temporary pre-authentication state may be used.

---

# 36. Pre-Authentication State

When a login requires OTP, use a restricted temporary state:

```text
pre_auth_id
user_id
purpose
expires_at
```

This state must not provide access to normal dashboard resources.

It expires quickly.

After successful OTP verification:

```text
pre-auth
   ↓
session rotation
   ↓
authenticated session
```

---

# 37. Email Verification vs OTP

These concepts must remain logically distinct.

### Email verification

Confirms account email ownership.

### OTP

Confirms possession of a short-lived code for a specific purpose.

They may share infrastructure, but:

- tokens/codes;
- purposes;
- expiration;
- audit events;
- endpoint semantics

must remain correctly scoped.

---

# 38. Authentication Rate Limits

Recommended categories:

```text
login
registration
password recovery
password reset
email verification resend
OTP send
OTP verify
session operations
```

Each may have separate limits.

Rate limits should consider:

- IP;
- account;
- destination;
- project;
- endpoint;
- successful/failed outcomes.

Do not rely on a single global IP limit.

---

# 39. Brute-Force Protection

Controls should include:

- request rate limits;
- progressive delays;
- OTP attempt limits;
- password verification throttling;
- suspicious activity logging;
- session invalidation after sensitive events.

Avoid permanent automatic account lockout based solely on failed password attempts because attackers could intentionally lock legitimate users out.

---

# 40. CSRF Protection

All cookie-authenticated state-changing requests require CSRF protection.

Protected methods include:

```text
POST
PUT
PATCH
DELETE
```

The CSRF token must be:

- unpredictable;
- associated with the authenticated session;
- validated server-side;
- rejected when missing/invalid.

Safe read-only requests may not require CSRF tokens.

---

# 41. Same-Origin and CORS

Dashboard authentication should normally use a controlled first-party origin.

CORS configuration must be explicit.

Never assume CORS protects against authentication attacks.

CORS controls browser cross-origin behavior; authentication and authorization remain server-side responsibilities.

---

# 42. Security Notifications

Notify users after important events where appropriate:

- new login;
- password change;
- password reset;
- email address change;
- session revocation;
- suspicious login;
- security setting change.

Notifications must not contain sensitive secrets.

Example:

```text
Your password was changed successfully.
If you did not perform this action, secure your account immediately.
```

---

# 43. Email Address Change

If supported, changing the account email must require strong authentication.

Recommended flow:

```text
Authenticated user
       ↓
Request new email
       ↓
Re-authenticate
       ↓
Send verification to new email
       ↓
Verify
       ↓
Update email
       ↓
Invalidate old verification state
       ↓
Audit + notify
```

The new address must not become fully trusted before verification.

---

# 44. Re-Authentication

Require re-authentication for high-risk actions such as:

- changing password;
- changing account email;
- revealing sensitive credential metadata;
- creating/revoking highly privileged credentials;
- destructive security actions.

Re-authentication should be time-limited.

---

# 45. API Key Authentication vs User Authentication

These must never be conflated.

| Feature | User Session | Project API Key |
|---|---|---|
| Dashboard | Yes | No |
| User profile | Yes | No |
| Admin | No, separate admin auth | No |
| Email send | Via dashboard | Yes |
| OTP API | Via authorized dashboard/service | Yes |
| Project-scoped | Through user authorization | Directly |
| CSRF | Required for mutations | Not cookie-based |
| Browser exposure | Session cookie | Only intentionally scoped client keys |

---

# 46. API Key Creation Security

Creating an API key requires an authenticated dashboard session.

Example endpoint:

```http
POST /api/v1/projects/{project_id}/api-keys
```

Request:

```json
{
  "name": "Production Website",
  "scopes": [
    "email:send",
    "otp:send"
  ]
}
```

Response may show the secret exactly once:

```json
{
  "success": true,
  "data": {
    "id": "key_...",
    "name": "Production Website",
    "key": "eak_live_...",
    "scopes": [
      "email:send",
      "otp:send"
    ]
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

After the response, the full key cannot be recovered from the database.

---

# 47. API Key Revocation

Endpoint:

```http
DELETE /api/v1/projects/{project_id}/api-keys/{key_id}
```

Revocation must take effect immediately or within a documented short propagation period.

A revoked key must receive:

```text
API_KEY_REVOKED
```

or the appropriate authentication error.

---

# 48. Session Revocation After Security Events

Revoke sessions after:

- password reset;
- account suspension;
- explicit revoke-all;
- serious suspicious activity;
- administrator security action.

The policy may preserve the current session for low-risk changes, but security-sensitive transitions should favor revocation.

---

# 49. Audit Events

Authentication-related audit event types include:

```text
user.registered
user.email_verified
user.login.success
user.login.failed
user.logout
user.password_changed
user.password_reset_requested
user.password_reset
user.email_changed
session.created
session.revoked
session.revoke_all
otp.created
otp.sent
otp.failed
otp.verified
otp.expired
api_key.created
api_key.revoked
security.suspicious_activity
```

Audit events must not contain:

- passwords;
- raw OTP codes;
- API key secrets;
- OAuth tokens;
- SMTP passwords.

---

# 50. Authentication Error Codes

Core codes:

```text
AUTHENTICATION_REQUIRED
INVALID_CREDENTIALS
ACCOUNT_PENDING
ACCOUNT_SUSPENDED
ACCOUNT_DISABLED
EMAIL_NOT_VERIFIED
INVALID_VERIFICATION_TOKEN
VERIFICATION_TOKEN_EXPIRED
VERIFICATION_RATE_LIMITED
PASSWORD_RESET_TOKEN_INVALID
PASSWORD_RESET_TOKEN_EXPIRED
OTP_INVALID
OTP_EXPIRED
OTP_ATTEMPTS_EXCEEDED
OTP_RATE_LIMITED
REAUTHENTICATION_REQUIRED
SESSION_EXPIRED
SESSION_REVOKED
CSRF_INVALID
INVALID_API_KEY
API_KEY_REVOKED
API_KEY_EXPIRED
INSUFFICIENT_SCOPE
```

Error messages must remain safe and non-enumerating.

---

# 51. Authentication Database Relationships

Primary related entities:

```text
users
user_profiles
email_verifications
otp_codes
sessions
login_attempts
security_logs
notifications
api_keys
projects
admin_users
admin_logs
```

Logical relationships:

```text
users
 ├── user_profiles
 ├── email_verifications
 ├── otp_codes
 ├── sessions
 ├── login_attempts
 ├── security_logs
 ├── notifications
 ├── projects
 └── api_keys (through projects)
```

The exact foreign keys and indexes are defined by documents 08 and 09.

---

# 52. Transaction Boundaries

Use database transactions where multiple state changes must remain atomic.

Examples:

### Password reset

```text
Validate reset token
↓
Update password
↓
Invalidate token
↓
Revoke sessions
↓
Commit
```

### OTP verification

```text
Load OTP
↓
Validate state
↓
Increment/consume atomically
↓
Record verification event
↓
Commit
```

Concurrency controls must prevent two simultaneous requests from successfully consuming the same OTP.

---

# 53. OTP Concurrency Protection

A vulnerable implementation could allow:

```text
Request A → reads OTP as unused
Request B → reads OTP as unused
Request A → verifies
Request B → verifies
```

Prevent this through transaction/locking or an equivalent atomic state transition.

The state transition must effectively be:

```text
unused → consumed
```

only once.

---

# 54. Timing and Comparison

Security-sensitive comparisons should use safe comparison methods.

Avoid naïve comparisons for secrets where timing behavior matters.

Use platform-supported secure comparison mechanisms.

Do not expose whether a token matched partially.

---

# 55. Authentication Logging

Log useful metadata:

```text
request_id
user_id where safely known
event
timestamp
success/failure
security classification
IP metadata where justified
user-agent metadata where justified
```

Redact:

```text
password
OTP
API key
session secret
reset token
verification token
OAuth token
SMTP password
```

---

# 56. Privacy and Retention

Authentication logs should follow the platform's retention policy.

Do not retain security data indefinitely without a justified purpose.

Retention should consider:

- security investigations;
- legal requirements;
- operational needs;
- privacy;
- storage cost.

Sensitive authentication data should have shorter retention where practical.

---

# 57. Account Suspension

When a user is suspended:

```text
User status → suspended
        ↓
Invalidate active sessions
        ↓
Restrict dashboard access
        ↓
Restrict affected API credentials as defined
        ↓
Record audit event
```

Project resources must remain isolated and recoverable according to the platform's administrative policy.

---

# 58. Account Deletion

Account deletion must respect:

- ownership relationships;
- project lifecycle;
- logs;
- audit requirements;
- provider credentials;
- OAuth tokens;
- SMTP credentials;
- webhooks;
- API keys;
- legal/retention requirements.

Sensitive credentials must be securely destroyed when the account/project is permanently deleted.

Deletion must not leave active API credentials behind.

---

# 59. Authentication API Matrix

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/auth/register` | Create account |
| POST | `/auth/login` | Authenticate user |
| POST | `/auth/logout` | End current session |
| POST | `/auth/verify-email` | Verify email |
| POST | `/auth/resend-verification` | Resend verification |
| POST | `/auth/forgot-password` | Start recovery |
| POST | `/auth/reset-password` | Complete recovery |
| POST | `/auth/change-password` | Change password |
| GET | `/auth/sessions` | List sessions |
| DELETE | `/auth/sessions/{id}` | Revoke session |
| POST | `/auth/sessions/revoke-all` | Revoke sessions |
| POST | `/otp/send` | Generate/send OTP |
| POST | `/otp/verify` | Verify OTP |

---

# 60. Example Login Response

```json
{
  "success": true,
  "data": {
    "user": {
      "id": "usr_123",
      "name": "Example User",
      "email": "user@example.com",
      "email_verified": true
    }
  },
  "meta": {
    "request_id": "req_01JEXAMPLE123"
  }
}
```

The session is established through the secure cookie mechanism rather than exposing a reusable session token in JSON.

---

# 61. Example Login Failure

```http
401 Unauthorized
```

```json
{
  "success": false,
  "error": {
    "code": "INVALID_CREDENTIALS",
    "message": "Invalid email or password."
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

Do not disclose whether the email exists.

---

# 62. Example OTP Failure

Expired:

```json
{
  "success": false,
  "error": {
    "code": "OTP_EXPIRED",
    "message": "The verification code has expired."
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

Too many attempts:

```json
{
  "success": false,
  "error": {
    "code": "OTP_ATTEMPTS_EXCEEDED",
    "message": "The verification code is no longer valid."
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

---

# 63. Security Testing

Authentication testing must include:

### Passwords
- weak passwords;
- long passwords;
- Unicode input;
- password rehashing;
- wrong-password attempts.

### Sessions
- fixation;
- replay;
- expiration;
- revocation;
- cookie flags;
- concurrent sessions.

### CSRF
- missing token;
- invalid token;
- cross-origin attempts.

### OTP
- brute force;
- expired code;
- replay;
- resend abuse;
- concurrent verification;
- cross-user verification;
- cross-project verification;
- wrong-purpose verification.

### Recovery
- token reuse;
- expired token;
- token enumeration;
- account enumeration;
- reset session behavior.

### API keys
- revoked key;
- expired key;
- wrong project;
- insufficient scope;
- leaked key handling.

---

# 64. Production Authentication Checklist

- [ ] Passwords use secure password hashing.
- [ ] Passwords are never logged.
- [ ] Registration validation is centralized.
- [ ] Email verification is enabled.
- [ ] Verification tokens expire.
- [ ] Verification tokens are single-use.
- [ ] Login rate limiting is active.
- [ ] Account enumeration is minimized.
- [ ] Session IDs rotate after login.
- [ ] Cookies use Secure.
- [ ] Cookies use HttpOnly.
- [ ] Cookies use appropriate SameSite.
- [ ] Session expiration is configured.
- [ ] Sessions can be revoked.
- [ ] Password reset tokens are single-use.
- [ ] Password reset tokens expire.
- [ ] Password reset revokes appropriate sessions.
- [ ] CSRF protection is active.
- [ ] OTP generation uses CSPRNG.
- [ ] OTP values are not logged.
- [ ] OTPs expire.
- [ ] OTPs are single-use.
- [ ] OTP attempts are limited.
- [ ] OTP resends are throttled.
- [ ] OTP context is validated.
- [ ] API keys are project-scoped.
- [ ] API keys are hashed/stored securely.
- [ ] API keys are displayed only when appropriate.
- [ ] Security events are audited.
- [ ] Sensitive authentication data has retention rules.
- [ ] Suspended users lose access.
- [ ] Deleted accounts cannot leave active credentials.

---

# 65. Definition of Done

Authentication and OTP are complete only when:

- [ ] Registration works.
- [ ] Email verification works.
- [ ] Login works.
- [ ] Logout works.
- [ ] Password change works.
- [ ] Forgot-password works.
- [ ] Password reset works.
- [ ] Account recovery is controlled.
- [ ] Secure sessions work.
- [ ] Session revocation works.
- [ ] Login attempt protection works.
- [ ] OTP generation works.
- [ ] OTP delivery works through the Email Engine.
- [ ] OTP verification works.
- [ ] OTP expiration works.
- [ ] OTP attempt limits work.
- [ ] OTP resend throttling works.
- [ ] OTP purpose/context binding works.
- [ ] CSRF protection works.
- [ ] API key authentication remains separate.
- [ ] Security events are logged.
- [ ] Secrets are never logged.
- [ ] Automated security tests pass.
- [ ] Production configuration has secure cookie/HTTPS settings.
- [ ] Authentication behavior matches the REST API contract.

---

# 66. Non-Negotiable Authentication Rules

1. Never store plaintext passwords.
2. Never log passwords.
3. Never use MD5/SHA-1 as password storage.
4. Never create predictable OTPs.
5. Never log OTP values.
6. Never allow OTP reuse.
7. Never allow expired OTPs.
8. Never allow unlimited OTP attempts.
9. Never allow unlimited OTP resends.
10. Never expose reset tokens unnecessarily.
11. Never reuse password-reset tokens.
12. Never trust a session without server-side validation.
13. Always rotate sessions after login.
14. Always protect cookie-authenticated mutations with CSRF.
15. Always use Secure and HttpOnly session cookies.
16. Always enforce project/API-key separation.
17. Always minimize account enumeration.
18. Always rate-limit authentication endpoints.
19. Always audit security-sensitive authentication events.
20. Always revoke sessions after appropriate security events.
21. Always use atomic state transitions for OTP consumption.
22. Always bind OTPs to purpose and context.
23. Never grant dashboard access through a project API key.
24. Never grant admin access through a normal project API key.
25. Never expose provider credentials through authentication responses.
26. Never return raw session secrets in JSON.
27. Never expose internal authentication exceptions.
28. Always use centralized authentication services.
29. Always test unauthorized and concurrent access paths.
30. Keep authentication behavior synchronized with documents 09, 10, 11, 13, 16, and 19.

---

# 67. Final Lock

This document defines the **locked authentication and OTP architecture** for the Email API Platform.

It is fully aligned with:

- PHP 8.3+;
- REST/JSON API;
- secure dashboard sessions;
- project API keys;
- MySQL;
- Gmail/SMTP email delivery;
- the Email Engine;
- template infrastructure;
- webhooks;
- security/audit logs;
- the 93-screen scope;
- the locked database architecture;
- the locked backend architecture.

Future authentication improvements must be additive or explicitly versioned. No implementation should bypass the centralized authentication, session, OTP, authorization, rate-limit, or security architecture defined here.

**Status: FINAL / LOCKED.**

**Next document:** `13-EMAIL-ENGINE.md`
