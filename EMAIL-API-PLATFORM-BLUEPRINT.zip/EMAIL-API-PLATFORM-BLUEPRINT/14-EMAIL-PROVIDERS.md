# 14 — EMAIL PROVIDERS

**Project:** Email API Platform  
**Document:** Email Provider Architecture, Integrations, Credentials, Testing, Failover & Operations  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Parent Architecture:** `00-MASTER-BLUEPRINT.md`  
**Related:** `10-BACKEND-PHP-ARCHITECTURE.md`, `13-EMAIL-ENGINE.md`, `15-TEMPLATE-ENGINE.md`, `19-SECURITY-ARCHITECTURE.md`

---

## 1. Document Purpose

This document defines the complete provider layer for the Email API Platform.

The provider layer is responsible for connecting the platform's email engine to external email delivery systems while keeping the rest of the application provider-agnostic.

The platform must support:

- Gmail / Google OAuth 2.0
- Custom SMTP
- Optional Brevo
- Optional Mailtrap
- Provider connection testing
- Provider health/status
- Provider capability detection
- Credential encryption and secure storage
- Project-level provider isolation
- Default-provider selection
- Provider failover compatibility
- Provider error normalization
- Provider logging and auditability

The email engine must never contain provider-specific business logic beyond calling the normalized provider contract.

---

# 2. Locked Provider Strategy

The provider architecture is a **provider-adapter model**.

```text
                 ┌─────────────────────────┐
                 │      REST API Request   │
                 └────────────┬────────────┘
                              │
                              ▼
                 ┌─────────────────────────┐
                 │       Email Engine      │
                 └────────────┬────────────┘
                              │
                              ▼
                 ┌─────────────────────────┐
                 │ Provider Resolver       │
                 │ / Policy Engine         │
                 └────────────┬────────────┘
                              │
              ┌───────────────┼────────────────┐
              │               │                │
              ▼               ▼                ▼
       ┌────────────┐  ┌────────────┐   ┌────────────┐
       │ Gmail      │  │ SMTP       │   │ Optional   │
       │ Adapter    │  │ Adapter    │   │ Adapters   │
       └─────┬──────┘  └─────┬──────┘   └─────┬──────┘
             │               │                │
             ▼               ▼                ▼
         Google SMTP      SMTP Server     Brevo/Mailtrap
```

### Non-negotiable rule

The core email engine must not directly depend on Gmail, SMTP, Brevo, Mailtrap, or any other provider SDK.

Provider-specific behavior belongs inside provider adapters.

---

# 3. Supported Providers

## 3.1 Gmail

Primary production provider for users who want to connect a Google account.

Integration method:

- OAuth 2.0
- Google authorization
- Access token
- Refresh token
- Token expiry handling
- Authorized sender/account
- Provider capability checks

Recommended use:

- Personal projects
- Small applications
- Developer testing
- Low/medium transactional email workloads

Gmail is not treated as a generic SMTP credential form when OAuth is selected.

---

## 3.2 Custom SMTP

Primary generic provider.

Users can connect:

- Host
- Port
- Encryption
- Authentication mode
- Username
- Password
- From name
- From email

Typical configurations include:

- Gmail SMTP
- Outlook SMTP
- Yahoo SMTP
- cPanel mail servers
- Hosting-provider SMTP
- Business mail servers
- Private SMTP servers

The platform must not assume that a custom SMTP server is Gmail.

---

## 3.3 Brevo

Optional provider adapter.

The architecture must support an API-based provider adapter so Brevo can be enabled without changing the core email engine.

Typical authentication:

- API key

The exact provider credentials and API behavior must be isolated inside the Brevo adapter.

Brevo remains optional and must not be required for the core platform to operate.

---

## 3.4 Mailtrap

Optional provider adapter.

Mailtrap is useful for:

- Development
- QA
- Staging
- Safe email inspection
- Non-production testing

It must be possible to configure a project so test/staging traffic uses a non-production provider.

Mailtrap must never be hard-coded as the default production provider.

---

# 4. Provider Abstraction

Every provider implements a normalized contract.

Recommended PHP interface:

```php
interface EmailProviderInterface
{
    public function send(EmailMessage $message): ProviderSendResult;

    public function testConnection(): ProviderConnectionResult;

    public function validateConfiguration(): ProviderValidationResult;

    public function getCapabilities(): ProviderCapabilities;

    public function getHealth(): ProviderHealth;

    public function getProviderType(): string;
}
```

The exact method signatures may be refined during implementation, but the architectural responsibility must remain unchanged.

---

# 5. Provider Adapter Responsibilities

Each adapter is responsible for:

1. Validating provider configuration.
2. Loading/decrypting credentials through the credential service.
3. Establishing the provider connection.
4. Translating the canonical email DTO into provider-specific format.
5. Sending the message.
6. Returning normalized results.
7. Translating provider-specific errors.
8. Reporting capabilities.
9. Reporting connection health.
10. Supporting connection tests.
11. Preventing credential leakage into logs.
12. Providing enough metadata for email logging.

The adapter must not:

- Render application UI.
- Handle user sessions.
- Decide project authorization.
- Create API keys.
- Manage templates.
- Bypass rate limits.
- Write arbitrary database records outside its defined service/repository boundaries.

---

# 6. Canonical Provider Lifecycle

```text
Provider Created
      ↓
Configuration Entered
      ↓
Credentials Validated
      ↓
Connection Tested
      ↓
Provider Enabled
      ↓
Provider Available
      ↓
Selected as Default / Fallback
      ↓
Email Sent
      ↓
Result Logged
      ↓
Health Updated
```

Failure path:

```text
Provider Request
      ↓
Connection / Authentication Failure
      ↓
Normalize Provider Error
      ↓
Record Provider Failure
      ↓
Update Health
      ↓
Retry or Failover Policy
      ↓
Return Final Result
```

---

# 7. Provider States

A provider connection should have a normalized lifecycle state.

Recommended states:

```text
PENDING
TESTING
CONNECTED
ACTIVE
DEGRADED
AUTH_REQUIRED
DISABLED
FAILED
REVOKED
```

### PENDING

Configuration exists but has not successfully passed connection testing.

### TESTING

A connection test is currently executing.

### CONNECTED

Credentials were validated successfully.

### ACTIVE

Provider is enabled and usable for normal sending.

### DEGRADED

Provider is usable but recent failures indicate instability.

### AUTH_REQUIRED

Credentials require user action, such as an expired/revoked OAuth authorization.

### DISABLED

Provider has been intentionally disabled.

### FAILED

Connection or configuration is currently unusable.

### REVOKED

Authorization was explicitly revoked or invalidated.

---

# 8. Provider Database Relationship

Provider records are project-scoped.

Conceptually:

```text
users
  │
  └── projects
        │
        ├── providers
        │     ├── gmail_connections
        │     └── smtp_connections
        │
        ├── templates
        ├── api_keys
        ├── email_logs
        └── webhooks
```

A provider must never accidentally become available to another project.

Every provider operation must verify:

```text
authenticated user
        ↓
project membership/ownership
        ↓
provider belongs to project
        ↓
provider is enabled
        ↓
provider can be used
```

---

# 9. Gmail OAuth 2.0

## 9.1 Gmail Connection Flow

```text
User
 ↓
Add Gmail
 ↓
Platform creates OAuth state
 ↓
Redirect to Google authorization
 ↓
User grants required permission
 ↓
Google redirects to callback
 ↓
Validate state
 ↓
Exchange authorization code
 ↓
Receive access + refresh tokens
 ↓
Encrypt tokens
 ↓
Store Gmail connection
 ↓
Fetch authorized account identity
 ↓
Test provider
 ↓
Mark provider ACTIVE
```

---

## 9.2 OAuth Security

The OAuth implementation must include:

- Cryptographically strong state value.
- State expiration.
- State tied to authenticated user/session/project.
- Callback validation.
- Authorization-code exchange only on the server.
- HTTPS callback.
- Refresh-token encryption at rest.
- Access-token expiry tracking.
- Refresh-token rotation handling when applicable.
- Revocation detection.
- No token values in logs.
- No token values in API responses.
- No token values in frontend storage.

OAuth client secrets belong only on the server.

---

# 10. Gmail Token Storage

Never store raw Gmail tokens as normal plaintext database fields.

Use application-level encryption.

Conceptual fields:

```text
encrypted_access_token
encrypted_refresh_token
access_token_expires_at
google_account_email
google_subject_id
scopes
status
last_success_at
last_failure_at
```

The encryption key must be external to the database.

Recommended production approach:

```text
Environment / secret manager
          ↓
Encryption service
          ↓
Encrypted database value
```

---

# 11. Gmail Token Refresh

Before sending:

```text
Is access token valid?
       │
   ┌───┴───┐
   │       │
  YES      NO
   │       │
   │    Refresh token
   │       │
   │    Refresh success?
   │       │
   │   ┌───┴────┐
   │  YES       NO
   │   │         │
   └───┘      AUTH_REQUIRED
```

If refresh fails because authorization was revoked:

- Mark provider `AUTH_REQUIRED` or `REVOKED`.
- Do not continuously retry a permanently invalid credential.
- Record normalized provider error.
- Notify the project owner.
- Require reconnection.

---

# 12. Gmail Sender Validation

The platform must not assume that any arbitrary `From` address can be used.

The adapter must respect the identity authorized by the connected Google account and provider restrictions.

Recommended behavior:

```text
Connected Gmail account
        ↓
Default From identity
        ↓
Optional verified/allowed alias
        ↓
Validate requested sender
        ↓
Send
```

If a requested sender is not allowed, return a clear normalized validation/provider error.

---

# 13. Custom SMTP

## 13.1 SMTP Configuration

Minimum configuration:

```text
host
port
encryption
authentication
username
password
from_name
from_email
```

Possible encryption values:

```text
none
tls
ssl
```

The actual supported combinations must be validated rather than blindly accepted.

---

# 14. SMTP Connection Flow

```text
User
 ↓
Add SMTP
 ↓
Enter configuration
 ↓
Validate input
 ↓
Encrypt password
 ↓
Create temporary provider object
 ↓
Connect to SMTP server
 ↓
Authenticate
 ↓
Optional sender verification
 ↓
Connection test result
 ↓
Save/activate provider
```

Connection testing should occur before presenting the provider as active.

---

# 15. SMTP Security

SMTP passwords must:

- Never be returned to frontend clients.
- Never be written to normal logs.
- Never be included in exception messages.
- Be encrypted at rest.
- Be decrypted only when required.
- Be handled in memory for the shortest practical duration.

Database compromise must not expose SMTP credentials in plaintext.

---

# 16. SMTP Host Validation

The server must validate:

- Host is present.
- Port is valid.
- Encryption mode is supported.
- Authentication configuration is valid.
- Username/password requirements match the authentication mode.
- Host does not contain malformed input.

The platform should not attempt arbitrary internal-network access without an explicit security policy.

Production deployments should consider SSRF protections when users can configure arbitrary provider hosts.

---

# 17. SMTP SSRF Protection

Custom SMTP creates a potential server-side network abuse surface.

The provider connection layer must consider:

- Private IP ranges.
- Loopback addresses.
- Link-local addresses.
- Cloud metadata endpoints.
- Internal hostnames.
- Restricted ports.
- DNS rebinding scenarios.
- IPv4 and IPv6 validation.

A configurable allow/deny policy should be available for production environments.

Do not disable SSRF protection simply because the user supplied the SMTP hostname.

---

# 18. SMTP TLS Validation

TLS must be verified by default.

Do not introduce an insecure option such as:

```text
verify_peer = false
```

as a normal user-facing setting.

If an exceptional administrative override is ever required, it must be:

- Explicit.
- Restricted.
- Audited.
- Disabled by default.

---

# 19. Provider Capabilities

Each adapter reports capabilities.

Example:

```text
supports_html
supports_plain_text
supports_attachments
supports_reply_to
supports_cc
supports_bcc
supports_custom_headers
supports_oauth
supports_smtp_auth
supports_api
supports_test_connection
supports_provider_message_id
supports_webhooks
```

The email engine uses capabilities to validate requests before sending.

---

# 20. Provider Connection Testing

Every provider should support a safe connection test.

Connection test means:

```text
Configuration
   ↓
Authentication
   ↓
Provider reachability
   ↓
Credential validity
   ↓
Capability check
   ↓
Normalized result
```

A connection test should not automatically send a real email unless the user explicitly selects **Send Test Email**.

---

# 21. SMTP Test vs Test Email

These are separate actions.

### Test Connection

Checks:

- Network reachability.
- TLS.
- Authentication.
- Basic provider configuration.

### Send Test Email

Checks:

- Full message construction.
- Template/rendering pipeline.
- Sender.
- Recipient.
- Provider adapter.
- Actual provider acceptance.

Both should be available from the provider UI.

---

# 22. Provider Selection

Provider resolution should follow a predictable policy.

Example:

```text
Explicit provider ID
       ↓
Project default provider
       ↓
Configured fallback provider
       ↓
No provider
       ↓
Provider configuration error
```

An API request should be able to specify a provider only if the project has permission to use it.

A user must not reference another project's provider ID.

---

# 23. Default Provider

Each project may have one default provider.

Rules:

- Only one active default per project.
- Disabled provider cannot remain default.
- Failed/auth-required provider may be prevented from becoming default.
- Changing the default is audited.
- Existing email logs retain the actual provider used.

---

# 24. Fallback Providers

The architecture supports provider failover.

Example:

```text
Primary: Gmail
      ↓
Temporary provider failure
      ↓
Retry policy
      ↓
Fallback: SMTP
      ↓
Final result
```

Failover must not occur for every error.

Do not fail over automatically for:

- Invalid recipient.
- Invalid message.
- Template errors.
- Authentication configuration errors that are permanent.
- Policy violations.
- Suppression/blocking conditions.

Failover is appropriate mainly for transient infrastructure/provider failures.

---

# 25. Retry Classification

Provider errors should be normalized into categories:

```text
TRANSIENT
AUTHENTICATION
CONFIGURATION
VALIDATION
RATE_LIMITED
QUOTA_EXCEEDED
RECIPIENT_REJECTED
CONTENT_REJECTED
NETWORK
UNKNOWN
```

Typical policy:

| Category | Retry | Failover |
|---|---:|---:|
| TRANSIENT | Yes | Possible |
| NETWORK | Yes | Possible |
| RATE_LIMITED | Delayed | Possible |
| QUOTA_EXCEEDED | Usually delayed | Possible |
| AUTHENTICATION | No until fixed | Possible if fallback |
| CONFIGURATION | No | Possible |
| VALIDATION | No | No |
| RECIPIENT_REJECTED | No | No |
| CONTENT_REJECTED | No | No |

Final behavior remains controlled by the email engine.

---

# 26. Provider Error Normalization

Provider-specific exceptions must never leak directly to API clients.

Example:

```text
Google error
    ↓
Gmail adapter
    ↓
ProviderErrorNormalizer
    ↓
Normalized error
    ↓
Email engine
    ↓
REST API response
```

Normalized fields:

```text
code
category
message
retryable
provider
provider_status
provider_message_id
safe_details
```

Never expose:

- OAuth tokens.
- SMTP passwords.
- Internal stack traces.
- Internal hostnames.
- Encryption keys.
- Raw credential payloads.

---

# 27. Provider Message IDs

When a provider returns a message identifier, store it safely.

Example:

```text
provider_message_id
```

This is useful for:

- Troubleshooting.
- Provider correlation.
- Delivery investigation.
- Support.
- Logs.

Do not treat provider acceptance as guaranteed final inbox delivery.

---

# 28. Provider Health

Provider health should track:

```text
status
last_success_at
last_failure_at
consecutive_failures
recent_failure_rate
last_error_code
last_error_category
```

Health is operational metadata, not a substitute for delivery analytics.

---

# 29. Health State Rules

Example:

```text
ACTIVE
  ↓ repeated transient failures
DEGRADED
  ↓ persistent failures
FAILED
```

Recovery:

```text
FAILED
  ↓ successful connection/send
ACTIVE
```

Authentication failure:

```text
ACTIVE
  ↓ revoked credential
AUTH_REQUIRED
```

Health transitions should be logged.

---

# 30. Provider Rate Limits

Provider limits and platform limits are different.

### Platform limits

Protect the user's project and infrastructure.

### Provider limits

Imposed by Gmail, SMTP server, Brevo, Mailtrap, or another external service.

The provider adapter should return enough information for the email engine to distinguish them.

Never pretend that a platform rate-limit response is a provider quota response.

---

# 31. Gmail Quota Handling

Gmail limits can vary by account type and provider policy.

The platform must not hard-code a universal daily sending number as a guaranteed limit.

Instead:

- Detect provider quota/rate errors.
- Normalize the error.
- Log the event.
- Apply retry/backoff where appropriate.
- Inform the project owner.
- Optionally use a configured fallback provider.

---

# 32. SMTP Quota Handling

SMTP servers vary widely.

The platform should handle:

- Connection limits.
- Authentication throttling.
- Per-minute limits.
- Daily limits.
- Provider-specific rejection responses.

Do not infer a quota unless the provider explicitly communicates it.

---

# 33. Provider Credential Rotation

Users should be able to rotate credentials without deleting the project.

Recommended flow:

```text
Existing provider
      ↓
Edit credentials
      ↓
Validate new credentials
      ↓
Connection test
      ↓
Activate new credentials
      ↓
Retire old credentials
      ↓
Audit event
```

Do not replace working credentials with untested credentials when avoidable.

---

# 34. Provider Disablement

Disabling a provider:

- Stops new sends through that provider.
- Does not delete historical logs.
- Does not delete templates.
- Does not delete the project.
- Preserves encrypted credentials unless the user explicitly removes them.
- Removes provider from default selection if necessary.
- Creates an audit event.

---

# 35. Provider Deletion

Deletion must be explicit.

Before deletion:

```text
Confirm provider
      ↓
Check if default
      ↓
Check active sends
      ↓
Revoke/cleanup credentials where applicable
      ↓
Delete or soft-delete connection
      ↓
Preserve historical references
      ↓
Audit deletion
```

Historical email logs should continue to identify the provider used.

Prefer soft deletion for provider records where operational/audit requirements justify it.

---

# 36. Gmail Disconnect

Disconnecting Gmail should:

- Revoke authorization when supported/appropriate.
- Delete or invalidate stored OAuth tokens.
- Mark provider `REVOKED` or disabled.
- Prevent future sends.
- Preserve historical email logs.
- Create an audit record.

No token should remain usable after disconnect.

---

# 37. SMTP Disconnect

Disconnecting SMTP should:

- Remove/invalidate encrypted credentials.
- Disable the provider.
- Prevent future sends.
- Preserve historical logs.
- Audit the action.

---

# 38. Optional Provider Adapter Contract

Brevo and Mailtrap should use the same normalized provider interface.

```text
BrevoAdapter
     │
     ├── configuration validation
     ├── credential handling
     ├── send
     ├── test connection
     ├── capabilities
     ├── health
     └── error normalization
```

The core email engine should not know how Brevo authentication works.

The same rule applies to Mailtrap.

---

# 39. Provider Configuration UI

Provider management should expose:

- Provider name.
- Provider type.
- Connection status.
- Default status.
- Last successful connection.
- Last failure.
- Health indicator.
- Test Connection.
- Send Test Email.
- Edit.
- Disable.
- Delete.
- Reconnect.
- Credential status without revealing secrets.

Never display complete passwords, refresh tokens, or API keys after initial entry.

---

# 40. Add Gmail Screen

Required fields/actions:

```text
Connect Google Account
Provider display name
Project
Authorized Google account
Scopes/permissions summary
Connection status
Connect / Reconnect
```

The UI should clearly explain what authorization is being granted.

---

# 41. Add SMTP Screen

Fields:

```text
Provider Name
SMTP Host
SMTP Port
Encryption
Authentication
Username
Password
From Name
From Email
```

Actions:

```text
Test Connection
Save Provider
Cancel
```

The UI should show safe validation errors without revealing secrets.

---

# 42. Provider Test Result UI

Success example:

```text
Connection successful
Authentication successful
Provider is ready for sending
```

Failure example:

```text
Connection failed
Category: Authentication
Action: Recheck username/password
```

Do not show raw PHP/PHPMailer exception text to normal users.

---

# 43. Provider API Endpoints

Conceptual endpoints:

```http
GET    /api/v1/projects/{project}/providers
POST   /api/v1/projects/{project}/providers
GET    /api/v1/projects/{project}/providers/{provider}
PATCH  /api/v1/projects/{project}/providers/{provider}
DELETE /api/v1/projects/{project}/providers/{provider}

POST   /api/v1/projects/{project}/providers/{provider}/test
POST   /api/v1/projects/{project}/providers/{provider}/test-email

POST   /api/v1/projects/{project}/providers/{provider}/enable
POST   /api/v1/projects/{project}/providers/{provider}/disable
POST   /api/v1/projects/{project}/providers/{provider}/set-default
POST   /api/v1/projects/{project}/providers/{provider}/reconnect
```

Exact request/response schemas are defined in `11-REST-API-SPECIFICATION.md`.

---

# 44. Provider Authorization

Every provider endpoint must enforce:

```text
Authentication
      ↓
Project access
      ↓
Provider ownership
      ↓
Permission
      ↓
Action validation
```

Provider IDs must be treated as untrusted input.

Never rely on the frontend to enforce project isolation.

---

# 45. Provider Secrets and API Responses

Provider detail endpoints may return:

```json
{
  "id": "provider_123",
  "type": "smtp",
  "status": "active",
  "host": "smtp.example.com",
  "port": 587,
  "username": "user@example.com",
  "password": null
}
```

Never return the actual secret.

Use metadata such as:

```text
configured: true
```

rather than exposing credentials.

---

# 46. Provider Repository Layer

Recommended responsibilities:

```text
ProviderRepository
GmailConnectionRepository
SmtpConnectionRepository
```

Repositories handle persistence.

They must not:

- Send emails.
- Perform OAuth redirects.
- Render UI.
- Decide API authorization.
- Contain provider business logic.

---

# 47. Provider Service Layer

Recommended services:

```text
ProviderService
ProviderResolver
ProviderHealthService
ProviderCredentialService
ProviderTestService
ProviderErrorNormalizer
ProviderFailoverService
GmailOAuthService
SmtpConnectionService
```

These services coordinate provider operations while preserving boundaries.

---

# 48. Provider Directory Structure

Recommended structure:

```text
src/
├── Providers/
│   ├── Contracts/
│   │   └── EmailProviderInterface.php
│   ├── DTO/
│   │   ├── ProviderConfig.php
│   │   ├── ProviderCapabilities.php
│   │   ├── ProviderHealth.php
│   │   └── ProviderSendResult.php
│   ├── Exceptions/
│   │   └── ProviderException.php
│   ├── Gmail/
│   │   ├── GmailProvider.php
│   │   ├── GmailOAuthService.php
│   │   └── GmailErrorMapper.php
│   ├── Smtp/
│   │   ├── SmtpProvider.php
│   │   └── SmtpErrorMapper.php
│   ├── Brevo/
│   │   ├── BrevoProvider.php
│   │   └── BrevoErrorMapper.php
│   ├── Mailtrap/
│   │   ├── MailtrapProvider.php
│   │   └── MailtrapErrorMapper.php
│   └── ProviderResolver.php
```

---

# 49. PHPMailer Boundary

PHPMailer is an implementation dependency for SMTP sending.

Use it behind the SMTP adapter.

Correct:

```text
EmailEngine
    ↓
ProviderResolver
    ↓
SmtpProvider
    ↓
PHPMailer
    ↓
SMTP server
```

Incorrect:

```text
Controller
    ↓
PHPMailer directly
```

This preserves testability and provider abstraction.

---

# 50. Provider SDK Boundary

Third-party provider SDKs must remain inside their provider adapter.

Example:

```text
Brevo SDK
   ↓
BrevoProvider
   ↓
EmailProviderInterface
```

The rest of the application must not import provider SDK classes.

---

# 51. Provider Configuration Validation

Validation occurs at multiple levels.

### UI validation

Fast user feedback.

### API validation

Never trust browser validation.

### Service validation

Business rules.

### Adapter validation

Provider-specific requirements.

### Transport validation

Network/authentication/TLS.

All layers may reject invalid input, but error responses must remain normalized.

---

# 52. Provider Name vs Provider Type

Store both where useful.

Example:

```text
name: "Production Gmail"
type: "gmail"
```

Another:

```text
name: "Company SMTP"
type: "smtp"
```

This allows human-readable labels without losing machine-readable provider identity.

---

# 53. Multiple Providers Per Project

A project may contain multiple provider connections.

Example:

```text
Project: My Store

Providers:
├── Production Gmail
├── Backup SMTP
└── Staging Mailtrap
```

Only the selected/default/fallback policy determines which provider handles a message.

---

# 54. Environment Separation

Production and development must not accidentally share production credentials.

Recommended:

```text
Development project
 → Mailtrap / test SMTP

Staging project
 → Mailtrap / staging SMTP

Production project
 → Gmail / production SMTP / Brevo
```

Project-level separation is preferred over environment checks scattered throughout the email engine.

---

# 55. Test Mode

The platform may support a project/provider test mode.

Test mode should:

- Prevent accidental real-recipient sends where configured.
- Clearly label test messages.
- Use a safe provider when configured.
- Be visible in project settings.
- Be audited.

Do not silently redirect production email to a test provider.

---

# 56. Provider Metadata

Store non-secret operational metadata such as:

```text
provider_id
project_id
type
display_name
status
is_default
created_at
updated_at
last_success_at
last_failure_at
failure_count
configuration_version
```

Sensitive credentials remain in dedicated encrypted storage.

---

# 57. Provider Audit Events

Audit:

- Provider created.
- Provider updated.
- Provider connected.
- Provider disconnected.
- Provider enabled.
- Provider disabled.
- Provider set as default.
- Provider credentials rotated.
- Gmail OAuth authorized.
- Gmail OAuth revoked.
- SMTP test passed.
- SMTP test failed.
- Provider deleted.
- Provider failover occurred when security/operations policy requires it.

---

# 58. Provider Logging

Logs should include:

```text
request_id
message_id
project_id
provider_id
provider_type
operation
result
normalized_error_code
duration_ms
created_at
```

Never log:

```text
SMTP password
OAuth refresh token
OAuth access token
API secret
Authorization header
full sensitive payload
```

---

# 59. Provider Performance

Provider operations should have timeouts.

Do not allow a provider connection to block a PHP worker indefinitely.

Track:

- Connection duration.
- Authentication duration.
- Send duration.
- Failure duration.
- Retry count.

Slow providers should be visible through metrics/logs.

---

# 60. Provider Concurrency

The provider layer must be safe under concurrent requests.

Avoid:

- Shared mutable credential state.
- Global provider objects containing request-specific data.
- Cross-request token leakage.
- Unsafe temporary files.
- Non-isolated message state.

Each send should use request/message-specific data.

---

# 61. Provider Idempotency

Provider integrations must cooperate with the email engine's idempotency strategy.

Do not assume that retrying a provider request is always safe.

Potential ambiguous outcome:

```text
SMTP accepted message
       ↓
Network timeout before application receives response
       ↓
Application does not know final result
```

The system must record this as an ambiguous provider outcome and avoid unsafe duplicate retries where possible.

---

# 62. Provider Failover Safety

Failover must consider duplicate-send risk.

Example:

```text
Primary provider
   ↓
Unknown result
   ↓
Immediate fallback
   ↓
Potential duplicate
```

Therefore failover decisions must use the email engine's delivery state and idempotency policy.

---

# 63. Provider Health Dashboard

User panel should show:

```text
Provider
Type
Status
Default
Last successful send
Last failure
Recent health
```

Admin panel may show aggregate:

```text
Provider
Projects
Success rate
Failure rate
Latency
Auth failures
Rate-limit events
```

Do not expose another user's credentials.

---

# 64. Admin Provider Controls

Admins may manage provider metadata and operational status according to role permissions.

Admin actions must be audited.

Recommended controls:

- View provider metadata.
- Disable provider.
- Enable provider.
- Inspect health.
- Inspect normalized failures.
- Review connection history.
- Review usage.
- Review security events.

Admins should not casually expose plaintext user credentials.

---

# 65. Provider Privacy

Provider information can reveal:

- Email addresses.
- Service names.
- Infrastructure details.
- Account identities.

Access must follow project/user/admin authorization.

Logs and analytics should minimize sensitive data.

---

# 66. Provider Data Retention

Historical provider references should remain available for email-log integrity.

Credential data should have stricter retention.

When a provider is disconnected:

```text
Operational credentials → invalidate/remove
Historical provider metadata → retain as required
Email logs → retain according to log policy
Audit records → retain according to audit policy
```

---

# 67. Backup Considerations

Database backups may contain encrypted provider credentials.

Therefore:

- Backups must be protected.
- Encryption keys must be stored separately.
- Backup access must be restricted.
- Restore procedures must preserve encryption-key availability.
- Credential rotation must be possible after a suspected compromise.

A database backup alone must not be enough to decrypt provider secrets.

---

# 68. Provider Migration

Changing provider should not require changing:

- Templates.
- API clients.
- Frontend integration.
- Email request schema.

Only provider configuration/selection changes.

Example:

```text
API client
   ↓
send email
   ↓
Provider Resolver
   ↓
Gmail → SMTP
```

The API contract remains stable.

---

# 69. Adding a New Provider

Future provider implementation checklist:

1. Create adapter.
2. Implement provider interface.
3. Create provider DTO/config validation.
4. Add credential strategy.
5. Add error mapper.
6. Add capability declaration.
7. Add health handling.
8. Add connection test.
9. Add send test.
10. Add database configuration if needed.
11. Add UI configuration.
12. Add API provider type.
13. Add unit tests.
14. Add integration tests.
15. Add security review.
16. Add documentation.
17. Register adapter.
18. Run regression suite.

No core email-engine rewrite should be required.

---

# 70. Provider Registry

Use a provider registry/factory.

Concept:

```php
$registry->register('gmail', GmailProvider::class);
$registry->register('smtp', SmtpProvider::class);
$registry->register('brevo', BrevoProvider::class);
$registry->register('mailtrap', MailtrapProvider::class);
```

Then:

```text
provider type
     ↓
registry
     ↓
adapter
```

This keeps provider resolution explicit and testable.

---

# 71. Provider Factory Rules

Factory must:

- Validate supported provider type.
- Resolve correct adapter.
- Inject required services.
- Never bypass project authorization.
- Never return disabled providers for sending.
- Never silently fall back to another provider.

Fallback belongs to the explicit provider policy layer.

---

# 72. Provider Connection Test API Response

Example success:

```json
{
  "success": true,
  "data": {
    "status": "connected",
    "provider": "smtp",
    "message": "Connection successful"
  }
}
```

Example failure:

```json
{
  "success": false,
  "error": {
    "code": "PROVIDER_AUTHENTICATION_FAILED",
    "category": "authentication",
    "message": "The provider credentials could not be authenticated."
  }
}
```

No sensitive provider response should be exposed.

---

# 73. Provider Send Result

Normalized result:

```json
{
  "accepted": true,
  "provider": "gmail",
  "provider_message_id": "provider-generated-id",
  "retryable": false
}
```

Possible failure:

```json
{
  "accepted": false,
  "provider": "smtp",
  "error_category": "transient",
  "error_code": "PROVIDER_TEMPORARY_FAILURE",
  "retryable": true
}
```

The exact API envelope is finalized in the REST API specification.

---

# 74. Provider Test Email

A test email should use the same core email pipeline:

```text
Test Email Request
       ↓
Authorization
       ↓
Provider validation
       ↓
Message construction
       ↓
Email Engine
       ↓
Selected Provider
       ↓
Provider send
       ↓
Email Log
```

Do not implement a completely separate send path.

---

# 75. Provider and Templates

Providers must not know how templates are authored.

Correct:

```text
Template Engine
     ↓
Rendered EmailMessage
     ↓
Email Engine
     ↓
Provider
```

This allows one template to work with Gmail, SMTP, Brevo, or Mailtrap.

---

# 76. Provider and API Keys

API keys authenticate the project/client.

Providers authenticate the platform to the external email service.

These credentials are separate.

```text
Client API Key
      ↓
Platform authentication

Provider Credential
      ↓
External email service authentication
```

Never confuse the two.

---

# 77. Provider and Webhooks

Provider webhook support is optional.

If a provider supports delivery/bounce events, its adapter may expose normalized events.

Future normalized events may include:

```text
delivered
bounced
complained
rejected
opened
clicked
```

Provider-specific event formats must be normalized before reaching the core webhook/event system.

---

# 78. Provider Webhook Security

If inbound provider webhooks are implemented:

- Verify provider signatures.
- Validate timestamps/replay protection where supported.
- Authenticate source according to provider method.
- Normalize event payload.
- Store raw payload only under controlled retention/security policy.
- Never trust webhook input as authenticated merely because it comes from an HTTP request.

---

# 79. Provider API Security

Outbound provider calls should use:

- HTTPS/TLS.
- Minimum required scopes.
- Short-lived access tokens where supported.
- Secure credential storage.
- Strict timeouts.
- Safe redirects.
- No credential leakage in URLs.
- No secret-bearing query strings.

---

# 80. Provider Error UX

Normal users need actionable messages.

Bad:

```text
SMTP Error 535 5.7.8 Authentication Credentials Invalid
```

Better:

```text
Authentication failed.
Check the SMTP username and password, then test the connection again.
```

Developer/admin diagnostics can retain normalized technical details under access control.

---

# 81. Provider Monitoring

Recommended metrics:

```text
provider_send_total
provider_send_success_total
provider_send_failure_total
provider_connection_test_total
provider_connection_failure_total
provider_latency_ms
provider_auth_failure_total
provider_rate_limit_total
provider_failover_total
```

Metrics must not contain credentials or message bodies.

---

# 82. Provider Alerts

Optional operational alerts:

- High provider failure rate.
- Repeated authentication failures.
- Provider unavailable.
- Excessive latency.
- Repeated rate limits.
- Gmail authorization revoked.
- SMTP connection failures.

Alerts should be rate-limited to prevent alert storms.

---

# 83. Provider Testing Matrix

Every provider adapter should be tested for:

### Configuration

- Missing credentials.
- Invalid credentials.
- Invalid host.
- Invalid port.
- Unsupported encryption.
- Missing sender.

### Connection

- Success.
- Authentication failure.
- TLS failure.
- DNS failure.
- Timeout.

### Sending

- Plain text.
- HTML.
- Reply-to.
- CC/BCC where supported.
- Attachments where supported.
- Unicode.
- Invalid recipient.
- Provider rejection.

### Failure

- Temporary error.
- Permanent error.
- Rate limit.
- Quota.
- Network interruption.
- Ambiguous timeout.

---

# 84. Gmail Testing

Gmail integration tests should cover:

- OAuth state validation.
- Callback handling.
- Code exchange.
- Token encryption.
- Token refresh.
- Expired access token.
- Revoked refresh token.
- Authorized account identity.
- Sender validation.
- Send success.
- Provider rejection.
- Rate/quota errors.

Do not use real production credentials in automated tests.

---

# 85. SMTP Testing

SMTP tests should cover:

- TLS.
- SSL.
- Authentication.
- Authentication failure.
- Invalid certificate.
- DNS failure.
- Timeout.
- Port failure.
- Sender rejection.
- Recipient rejection.
- HTML email.
- Attachments.
- Connection cleanup.

Use a controlled test SMTP server for automated integration tests.

---

# 86. Mailtrap Testing

Mailtrap should be suitable for:

- Local development.
- Staging.
- Template preview/send verification.
- Automated integration environments.

Production credentials should never be embedded in source code or committed to Git.

---

# 87. Brevo Testing

Brevo adapter tests should cover:

- API credential validation.
- Successful send.
- Authentication failure.
- Rate limit.
- Invalid recipient.
- Provider rejection.
- API timeout.
- Error normalization.

Use test credentials or mocked HTTP responses in CI.

---

# 88. Mock Provider

The platform should have a fake/mock provider for automated tests.

Example:

```php
final class FakeEmailProvider implements EmailProviderInterface
{
    // deterministic test behavior
}
```

It can simulate:

```text
success
transient failure
authentication failure
rate limit
timeout
unknown failure
```

This avoids making the test suite depend on external providers.

---

# 89. Provider Contract Tests

Every adapter must pass the same contract test suite.

Example:

```text
ProviderContractTest
      ↓
Gmail
SMTP
Brevo
Mailtrap
Fake
```

This guarantees consistent behavior across adapters.

---

# 90. Provider Security Checklist

Before production:

- [ ] Credentials encrypted.
- [ ] OAuth tokens encrypted.
- [ ] Secrets absent from logs.
- [ ] Provider IDs project-scoped.
- [ ] SSRF controls enabled for arbitrary SMTP.
- [ ] TLS verified.
- [ ] Timeouts configured.
- [ ] Provider errors normalized.
- [ ] API responses sanitized.
- [ ] Rate limits active.
- [ ] Audit events enabled.
- [ ] Disconnect invalidates credentials.
- [ ] Backup encryption strategy verified.
- [ ] Admin access restricted.
- [ ] Test credentials separated from production.
- [ ] No secrets in Git.
- [ ] No secrets in frontend code.
- [ ] No secrets in URLs.
- [ ] Provider webhooks verified where applicable.

---

# 91. Provider Operational Checklist

Before enabling a provider:

- [ ] Configuration valid.
- [ ] Connection test successful.
- [ ] Sender identity valid.
- [ ] Test email successful.
- [ ] Provider marked active.
- [ ] Default/fallback policy reviewed.
- [ ] Logging verified.
- [ ] Error handling verified.
- [ ] Monitoring enabled.
- [ ] Project ownership verified.

---

# 92. Provider Selection Decision Tree

```text
Need production email?
        │
        ├── Existing Google account?
        │       └── Gmail OAuth
        │
        ├── Existing SMTP service?
        │       └── Custom SMTP
        │
        ├── API email provider?
        │       └── Brevo adapter
        │
        └── Development/testing?
                └── Mailtrap/test SMTP
```

The user remains responsible for choosing a provider appropriate to their volume, policies, and deliverability requirements.

---

# 93. Deliverability Boundary

The platform sends email through providers but does not guarantee inbox placement.

Deliverability depends on factors such as:

- Provider reputation.
- Sender reputation.
- Domain authentication.
- SPF.
- DKIM.
- DMARC.
- Recipient reputation.
- Content.
- Provider policies.
- Bounce/complaint rates.

The platform should provide guidance but must not claim guaranteed inbox delivery.

---

# 94. Domain Authentication Guidance

For custom domains, users should configure provider-recommended:

- SPF.
- DKIM.
- DMARC.

The platform may provide documentation links/instructions but should not fabricate DNS values.

Provider-specific DNS records must come from the actual provider configuration.

---

# 95. Sender Reputation

The platform should avoid encouraging:

- Spam.
- Bulk abuse.
- Unsolicited campaigns.
- Credential harvesting.
- Phishing.
- Malicious automation.

Provider connections exist for legitimate application email.

Abuse controls remain part of the security architecture.

---

# 96. Abuse Prevention

Recommended controls:

- Project rate limits.
- Account rate limits.
- API key rate limits.
- Recipient limits.
- Daily usage monitoring.
- Suspicious activity detection.
- Blocked IP management.
- Admin review.
- Provider disablement.
- Audit logs.

These controls protect both the platform and connected provider accounts.

---

# 97. Provider Credentials in Source Control

Never commit:

```text
Google client secret
OAuth token
SMTP password
Brevo API key
Mailtrap token
Encryption key
```

Use environment variables or a secret manager.

Example:

```env
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
APP_ENCRYPTION_KEY=
```

User/provider credentials belong in encrypted database storage, not static source files.

---

# 98. Provider Configuration Versioning

Provider configurations may be versioned conceptually so credential rotations can be audited.

Example:

```text
configuration_version: 1
configuration_version: 2
```

Do not retain obsolete plaintext secrets.

If historical versions are retained, they must remain encrypted and subject to retention rules.

---

# 99. Provider Migration and Backward Compatibility

Provider changes must preserve:

- Existing API clients.
- Existing templates.
- Existing projects.
- Existing logs.
- Existing webhook configuration.

A provider adapter may evolve internally without changing the public send API.

---

# 100. Provider Documentation Requirements

Each provider must have documentation covering:

1. What it is.
2. How to connect it.
3. Required credentials.
4. Required permissions.
5. Connection test.
6. Test email.
7. Sender requirements.
8. Common errors.
9. Rate/quota behavior.
10. Disconnect/reconnect.
11. Security notes.
12. Production recommendations.

---

# 101. Definition of Done

The provider module is complete when:

- Gmail OAuth works.
- SMTP works.
- Optional adapters fit the same contract.
- Provider credentials are encrypted.
- Provider/project isolation is enforced.
- Connection tests work.
- Test emails use the core email engine.
- Provider errors are normalized.
- Health states work.
- Default provider works.
- Failover architecture is supported.
- Audit logging works.
- Provider logs do not leak secrets.
- SSRF protections are addressed for custom SMTP.
- Provider contract tests pass.
- UI states are responsive and accessible.
- API authorization is enforced.
- Production deployment requirements are documented.

---

# 102. Non-Negotiable Provider Rules

1. Never expose provider secrets to frontend clients.
2. Never log OAuth tokens.
3. Never log SMTP passwords.
4. Never bypass project isolation.
5. Never let controllers send email directly.
6. Never let the email engine depend on one provider.
7. Never hard-code Gmail as the only provider.
8. Never assume all SMTP servers behave identically.
9. Never disable TLS verification by default.
10. Never ignore SSRF risks for arbitrary SMTP.
11. Never expose raw provider exceptions to users.
12. Never retry permanent provider errors indefinitely.
13. Never fail over blindly after ambiguous sends.
14. Never store credentials in plaintext.
15. Never commit secrets to Git.
16. Never trust frontend validation alone.
17. Never return secrets from provider APIs.
18. Never delete historical logs merely because a provider is disconnected.
19. Never make Mailtrap a production default.
20. Never require Brevo for core operation.
21. Never make provider-specific logic part of templates.
22. Never make provider-specific logic part of public API clients.
23. Always normalize provider errors.
24. Always use timeouts.
25. Always audit sensitive provider changes.
26. Always test credentials before activation when practical.
27. Always preserve API compatibility when changing providers.
28. Always separate client API keys from provider credentials.
29. Always encrypt provider secrets at rest.
30. Always design new providers as adapters.

---

# 103. Final Provider Architecture

```text
                 ┌──────────────────────────┐
                 │        Client App        │
                 │ HTML / JS / Fetch        │
                 └────────────┬─────────────┘
                              │
                              ▼
                 ┌──────────────────────────┐
                 │       REST API           │
                 │ Auth / Project / API Key │
                 └────────────┬─────────────┘
                              │
                              ▼
                 ┌──────────────────────────┐
                 │      Email Engine        │
                 │ DTO / Template / Policy  │
                 └────────────┬─────────────┘
                              │
                              ▼
                 ┌──────────────────────────┐
                 │    Provider Resolver     │
                 │ Default / Explicit /     │
                 │ Fallback / Health        │
                 └────────────┬─────────────┘
                              │
            ┌─────────────────┼─────────────────┐
            │                 │                 │
            ▼                 ▼                 ▼
      ┌───────────┐     ┌───────────┐     ┌───────────┐
      │   Gmail   │     │   SMTP    │     │ Optional  │
      │  Adapter  │     │  Adapter  │     │ Adapters  │
      └─────┬─────┘     └─────┬─────┘     └─────┬─────┘
            │                 │                 │
            ▼                 ▼                 ▼
        Google            SMTP Server      Brevo/Mailtrap
            │                 │                 │
            └─────────────────┼─────────────────┘
                              │
                              ▼
                    ┌──────────────────┐
                    │ Email Log / Usage│
                    │ Audit / Webhooks  │
                    └──────────────────┘
```

---

# 104. Final Lock

This document establishes the provider architecture for the Email API Platform.

The following decisions are locked:

- Gmail OAuth is the primary Google integration.
- Custom SMTP is the primary generic integration.
- Brevo and Mailtrap are optional adapters.
- Provider adapters implement a normalized contract.
- Provider-specific logic remains isolated.
- Provider credentials are encrypted.
- OAuth tokens are encrypted.
- SMTP secrets are encrypted.
- Provider access is project-scoped.
- Provider health is tracked.
- Provider connection testing is mandatory before activation where practical.
- Test email uses the core email engine.
- Default and fallback provider policies are explicit.
- Provider errors are normalized.
- Retry/failover behavior is controlled by the email engine.
- SSRF protections are required for arbitrary SMTP hosts.
- PHPMailer is used behind the SMTP adapter.
- Third-party provider SDKs remain inside their adapters.
- Historical logs remain provider-aware.
- Provider changes must not break the public API.
- New providers must be added through the adapter architecture.

**STATUS: FINAL / LOCKED**

**Next document:** `15-TEMPLATE-ENGINE.md`
