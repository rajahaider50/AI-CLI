# 16 — PROJECTS, API KEYS & WEBHOOKS

**Project:** Email API Platform  
**Document:** Project Management, API Key Security, Webhook Architecture, Permissions, Events & Integration  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Parent Architecture:** `00-MASTER-BLUEPRINT.md`  
**Related:** `09-DATABASE-SCHEMA.md`, `10-BACKEND-PHP-ARCHITECTURE.md`, `11-REST-API-SPECIFICATION.md`, `13-EMAIL-ENGINE.md`, `14-EMAIL-PROVIDERS.md`, `15-TEMPLATE-ENGINE.md`, `19-SECURITY-ARCHITECTURE.md`

---

## 1. Document Purpose

This document defines the complete architecture for:

- Projects
- Project settings
- Project isolation
- Project lifecycle
- Project API keys
- API key permissions/scopes
- API key hashing and rotation
- API authentication
- Key revocation
- Key usage tracking
- Webhooks
- Webhook endpoints
- Webhook events
- Webhook signing
- Webhook delivery
- Retry and backoff
- Webhook logs
- Delivery security
- Project-level authorization
- Developer integration flows

The architecture is designed so a static HTML/JavaScript application can securely communicate with the platform through a project API key without requiring PHP on the client website.

---

# 2. Locked Architecture

The core relationship is:

```text
User
 │
 └── Project
      │
      ├── Project Settings
      ├── Providers
      ├── Templates
      ├── API Keys
      ├── Email Logs
      ├── OTP Logs
      ├── Webhooks
      ├── Usage
      └── Notifications
```

Project is the primary isolation boundary.

Every resource belonging to a project must be authorized through the project context.

---

# 3. Project Concept

A project represents one application, website, service, or logical email environment.

Examples:

```text
My Portfolio
My SaaS App
E-commerce Store
Mobile App Backend
Contact Form
Production Website
```

A user can own multiple projects.

---

# 4. Multi-Project Model

Example:

```text
User: Raja

Projects
├── Personal Website
├── SaaS Application
├── E-commerce Store
└── Testing Project
```

Each project has independent:

- Providers
- Templates
- API keys
- Webhooks
- Logs
- Usage
- Settings

One project's API key must never access another project's resources.

---

# 5. Project Lifecycle

Recommended states:

```text
ACTIVE
SUSPENDED
ARCHIVED
DELETED
```

### ACTIVE

Normal operation.

### SUSPENDED

Sending/API operations may be blocked by user/admin/security policy.

### ARCHIVED

Project is retained but inactive.

### DELETED

Project is permanently removed according to retention policy, or marked for deletion.

---

# 6. Project Creation

Flow:

```text
User Dashboard
      ↓
Create Project
      ↓
Name
      ↓
Optional description
      ↓
Environment/settings
      ↓
Create
      ↓
Project ID generated
      ↓
Default settings created
      ↓
Project Overview
```

Project creation should be transactional.

---

# 7. Project Identity

Recommended fields:

```text
project_id
user_id
name
slug
description
status
environment
created_at
updated_at
```

Project IDs should be non-guessable where possible.

Example:

```text
project_8f31c2...
```

---

# 8. Project Slug

A project may have a human-readable slug.

Example:

```text
my-saas-app
```

Slug rules:

- Lowercase.
- Predictable normalization.
- Unique according to platform policy.
- No secrets.
- No sensitive information.

Authorization must never rely only on the slug.

---

# 9. Project Environment

Recommended values:

```text
development
staging
production
```

Environment is metadata and policy context.

It must not replace authentication or authorization.

---

# 10. Project Settings

Typical settings:

```text
project_name
environment
timezone
default_provider_id
test_mode
email_rate_limit
daily_email_limit
webhook_retry_policy
log_retention
notification_preferences
```

Sensitive provider credentials are not stored directly in generic project settings.

---

# 11. Project Default Provider

A project may select one default provider.

```text
Project
  ↓
Default Provider
  ↓
Email Engine
```

Changing the default provider must be audited.

A disabled provider cannot remain the active default.

---

# 12. Project Isolation

Every request must establish:

```text
Authenticated identity
        ↓
Project context
        ↓
Resource ownership
        ↓
Permission
        ↓
Action
```

Never trust:

```text
project_id
template_id
provider_id
webhook_id
api_key_id
```

from the client without relationship checks.

---

# 13. Cross-Project Access Prevention

Example attack:

```http
GET /api/v1/projects/project_B/templates
Authorization: Bearer key_for_project_A
```

The server must reject the request.

Correct behavior:

```text
API key belongs to Project A
requested project = Project B
→ 403 / authorization error
```

Do not leak whether the requested resource exists if policy requires resource hiding.

---

# 14. Project Roles

Initial architecture may use:

```text
owner
member
```

Optional future roles:

```text
developer
analyst
billing
security
admin
```

Role expansion must preserve least privilege.

---

# 15. Project Owner

Owner may normally:

- Update project.
- Manage members where enabled.
- Manage providers.
- Manage templates.
- Create/revoke API keys.
- Manage webhooks.
- View logs.
- View usage.
- Manage project security.

Admin privileges are separate from project ownership.

---

# 16. Project Settings Authorization

Changing project settings requires explicit project permission.

Examples:

```text
project:update
project:settings
provider:manage
template:manage
api_key:manage
webhook:manage
```

The exact permission registry is controlled by the authorization layer.

---

# 17. Project API Keys

API keys authenticate programmatic clients.

Architecture:

```text
Static HTML / JS
       ↓
HTTPS Fetch
       ↓
Project API Key
       ↓
REST API
       ↓
Project authorization
       ↓
Requested operation
```

The API key is not a provider credential.

---

# 18. API Key Design

Recommended key structure:

```text
public prefix + secret
```

Example concept:

```text
eapi_live_xxxxxxxxxxxxxxxxx
```

The exact format may be changed during implementation, but it should provide:

- Environment indication where useful.
- Public identifier/prefix.
- High-entropy secret.
- Human-readable identification.

---

# 19. API Key Generation

API keys must be generated using a cryptographically secure random source.

Do not use:

```text
rand()
mt_rand()
timestamps
user IDs
project IDs
predictable hashes
```

Use PHP's secure random facilities.

---

# 20. API Key Storage

Never store the full API key in plaintext.

Store:

```text
key_id
public_prefix
secret_hash
project_id
name
scopes
status
created_at
expires_at
last_used_at
last_used_ip
```

The secret should be shown only once when the key is created, if the product chooses one-time display.

---

# 21. API Key Hashing

Use a password-style secure hashing algorithm suitable for secret verification.

The server receives:

```text
presented API key
```

Then:

```text
Extract key identifier/prefix
        ↓
Lookup key record
        ↓
Verify secret against stored hash
        ↓
Check status/expiry
        ↓
Load project
        ↓
Check scopes
```

Do not use reversible encryption merely to store API keys.

---

# 22. API Key Encryption vs Hashing

API key secret:

```text
Hash
```

Provider credentials:

```text
Encryption
```

Reason:

- API key secrets only need verification.
- Provider credentials must sometimes be recovered for outbound provider authentication.

These are intentionally different security models.

---

# 23. API Key Display

After creation:

```text
API Key Created

eapi_live_••••••••••••

Copy now.
This secret will not be shown again.
```

The platform must not expose the secret later through normal API responses.

---

# 24. API Key Names

Allow human-readable names:

```text
Production Website
Local Development
Mobile App
Staging Frontend
Contact Form
```

Names must not contain the secret.

---

# 25. API Key Scopes

Use least-privilege permissions.

Recommended initial scopes:

```text
email:send
otp:send
otp:verify
template:read
template:use
project:read
logs:read
usage:read
webhook:manage
```

Management scopes should be granted only where required.

---

# 26. Send-Only Key

Typical static website key:

```text
email:send
template:use
```

It should not automatically have:

```text
provider:manage
api_key:manage
project:update
```

This protects the platform if a browser-exposed key is copied.

---

# 27. Browser API Key Risk

Important:

A key embedded in frontend JavaScript is not a true secret.

Example:

```javascript
fetch("https://api.example.com/v1/email/send", {
  headers: {
    "Authorization": "Bearer eapi_live_..."
  }
});
```

Users can inspect browser code/network traffic.

Therefore browser-facing keys must be:

- Narrowly scoped.
- Rate-limited.
- Project-limited.
- Revocable.
- Monitored.

Never put provider credentials in browser code.

---

# 28. Recommended Browser Security Model

For static websites:

```text
Browser
 ↓
Restricted project API key
 ↓
Send-only API endpoint
 ↓
Server-side validation
 ↓
Rate limiting
 ↓
Email Engine
```

For higher-security applications:

```text
Browser
 ↓
Application backend
 ↓
Private API key
 ↓
Email API
```

Private API keys should never be exposed to browsers.

---

# 29. API Key Expiration

Keys may optionally have:

```text
expires_at
```

If expired:

```text
API_KEY_EXPIRED
```

No request should proceed.

Production keys may be long-lived only when the project's security policy allows it.

---

# 30. API Key Status

Recommended:

```text
ACTIVE
REVOKED
EXPIRED
SUSPENDED
```

Only `ACTIVE` keys can authenticate.

---

# 31. API Key Rotation

Rotation flow:

```text
Create replacement key
       ↓
Deploy replacement
       ↓
Verify usage
       ↓
Revoke old key
```

Do not force an outage by revoking the old key before the replacement is deployed unless compromise requires immediate revocation.

---

# 32. Emergency Revocation

If a key is leaked:

```text
Revoke immediately
      ↓
Invalidate authentication
      ↓
Audit event
      ↓
Review recent usage
      ↓
Generate replacement
      ↓
Investigate abuse
```

Security dashboard should make revocation easy.

---

# 33. API Key Last-Used Tracking

Track:

```text
last_used_at
last_used_ip
last_used_user_agent
```

where policy permits.

This helps identify:

- Unused keys.
- Unexpected clients.
- Leaks.
- Suspicious activity.

Do not store excessive request metadata unnecessarily.

---

# 34. API Key Usage Logs

Each authenticated API request may record:

```text
request_id
api_key_id
project_id
endpoint
method
status_code
duration_ms
ip
user_agent
created_at
```

Do not store the raw API key.

---

# 35. API Authentication Flow

```text
HTTP request
    ↓
Read Authorization header
    ↓
Validate Bearer format
    ↓
Extract key identifier
    ↓
Lookup key
    ↓
Verify hash
    ↓
Check status
    ↓
Check expiration
    ↓
Load project
    ↓
Check project state
    ↓
Load scopes
    ↓
Continue request
```

---

# 36. API Authentication Header

Canonical form:

```http
Authorization: Bearer YOUR_PROJECT_API_KEY
```

Do not support multiple ambiguous authentication mechanisms unless explicitly required.

---

# 37. API Key Error Responses

Possible codes:

```text
API_KEY_MISSING
API_KEY_INVALID
API_KEY_EXPIRED
API_KEY_REVOKED
API_KEY_SUSPENDED
API_KEY_SCOPE_DENIED
PROJECT_SUSPENDED
```

Avoid revealing sensitive internal details.

---

# 38. API Key Rate Limiting

Rate limits should consider:

```text
API key
Project
User
IP
Endpoint
```

Example:

```text
Browser key:
100 requests/minute

Server key:
project-configured limit
```

Exact limits are configurable and documented elsewhere.

---

# 39. API Key Abuse Detection

Monitor:

- Sudden request spikes.
- Geographic anomalies where relevant.
- High error rates.
- Repeated authentication failures.
- Excessive recipient volume.
- Suspicious endpoint patterns.
- Rapid requests from many IPs.

Security events should be generated where thresholds are exceeded.

---

# 40. Project Usage Limits

Project-level limits may include:

```text
emails_per_minute
emails_per_hour
emails_per_day
api_requests_per_minute
preview_requests
webhook_deliveries
```

Limits should be enforced server-side.

---

# 41. Project Suspension

If a project is suspended:

```text
API authentication may succeed
        ↓
Project state check
        ↓
Operations blocked
```

The API should return a clear project-status error.

Do not silently send email from a suspended project.

---

# 42. Webhook Architecture

Webhooks notify external systems about platform events.

Flow:

```text
Platform Event
      ↓
Webhook Event Dispatcher
      ↓
Webhook Subscription
      ↓
Signed HTTP Request
      ↓
External Endpoint
      ↓
Response
      ↓
Webhook Log
```

---

# 43. Webhook Use Cases

Examples:

- Email sent.
- Email failed.
- OTP sent.
- OTP failed.
- Provider failure.
- Template published.
- Project usage threshold.
- Security event.
- API key created/revoked.

Only approved event types should be emitted.

---

# 44. Initial Webhook Events

Recommended initial events:

```text
email.sent
email.failed
otp.sent
otp.failed
provider.failed
api_key.revoked
usage.limit_reached
security.alert
```

Future events may be added without breaking existing webhook consumers.

---

# 45. Webhook Endpoint

A project can register one or more webhook endpoints.

Fields:

```text
webhook_id
project_id
name
url
secret
events
status
created_at
updated_at
```

The secret must be encrypted or securely managed because it is needed to sign outgoing requests.

---

# 46. Webhook URL Validation

Webhook URLs should normally require:

```text
https://
```

Production HTTP endpoints should be rejected unless an explicit development policy allows them.

Validate:

- URL syntax.
- Scheme.
- Host.
- Port policy.
- SSRF protections.
- Redirect behavior.

---

# 47. Webhook SSRF Protection

Webhook delivery can become a server-side request surface.

Protect against:

- localhost.
- Loopback.
- Private IP ranges.
- Link-local addresses.
- Cloud metadata endpoints.
- Internal hostnames.
- DNS rebinding.
- Dangerous redirects.

Do not blindly POST to arbitrary internal addresses.

---

# 48. Webhook Secret

Every webhook should have a unique signing secret.

Example conceptual header:

```http
X-Webhook-Signature: sha256=...
```

The secret must never be included in:

- URL.
- Event payload.
- Normal logs.
- Frontend response after initial configuration.

---

# 49. Webhook Signing

Recommended:

```text
HMAC-SHA256
```

Signature input should include a timestamp and exact payload.

Example concept:

```text
timestamp.payload
```

Then:

```text
HMAC-SHA256(secret, signed_content)
```

---

# 50. Webhook Headers

Recommended:

```http
Content-Type: application/json
User-Agent: EmailAPI-Webhook/1.0
X-Webhook-ID: wh_123
X-Webhook-Event: email.sent
X-Webhook-Timestamp: 1770000000
X-Webhook-Signature: sha256=...
X-Webhook-Delivery: delivery_123
```

Header names can be finalized in the API specification.

---

# 51. Webhook Payload

Example:

```json
{
  "id": "evt_123",
  "type": "email.sent",
  "created_at": "2026-10-05T12:00:00Z",
  "project_id": "project_123",
  "data": {
    "message_id": "msg_123",
    "provider": "gmail",
    "status": "sent"
  }
}
```

Payloads must avoid unnecessary secrets or sensitive message content.

---

# 52. Webhook Event ID

Every event should have a unique ID.

Example:

```text
evt_01...
```

Consumers can use this for idempotency.

---

# 53. Webhook Delivery ID

Every delivery attempt should also have an identifier.

Example:

```text
delivery_01...
```

This helps distinguish:

```text
same event
multiple delivery attempts
```

---

# 54. Webhook Idempotency

Webhook consumers must be able to safely process repeated events.

Because delivery is generally at-least-once:

```text
Event
 ↓
Attempt 1 fails
 ↓
Attempt 2 succeeds
```

The receiving system should deduplicate using event ID.

---

# 55. Webhook Delivery Model

Initial architecture:

```text
Event generated
      ↓
Webhook delivery service
      ↓
HTTP POST
      ↓
Record result
```

The system should be queue-compatible.

A future worker can process webhook deliveries asynchronously without changing the event contract.

---

# 56. Webhook Retry Policy

Retry transient failures.

Possible retry conditions:

```text
408
429
500
502
503
504
network timeout
connection failure
```

Do not repeatedly retry obvious permanent failures such as malformed destination configuration.

---

# 57. Webhook Backoff

Use exponential backoff with bounded maximum.

Concept:

```text
Attempt 1 → immediate
Attempt 2 → short delay
Attempt 3 → longer delay
Attempt 4 → longer delay
...
```

Add jitter to avoid synchronized retry storms.

---

# 58. Webhook Maximum Attempts

Recommended configurable maximum:

```text
5–10 attempts
```

Exact value is a deployment/configuration decision.

After exhaustion:

```text
FAILED
```

and create an operational/security log as appropriate.

---

# 59. Webhook Timeout

Each webhook request must have a strict timeout.

Do not allow a slow external endpoint to consume PHP workers indefinitely.

Recommended architecture:

```text
connect timeout
request timeout
total delivery timeout
```

Exact values are configuration.

---

# 60. Webhook Redirects

Do not blindly follow redirects.

If redirects are supported:

- Revalidate destination.
- Reapply SSRF checks.
- Preserve signing semantics safely.
- Limit redirect count.

A safer default is to avoid following redirects automatically.

---

# 61. Webhook Response Handling

Success normally means:

```text
2xx
```

The system should record:

```text
status_code
duration_ms
attempt
response_size
```

Do not store arbitrary response bodies indefinitely.

---

# 62. Webhook Logs

Recommended fields:

```text
webhook_log_id
webhook_id
event_id
delivery_id
attempt
status
http_status
duration_ms
error_code
created_at
next_retry_at
```

Avoid storing complete sensitive request/response bodies unless explicitly required.

---

# 63. Webhook Delivery States

Recommended:

```text
PENDING
DELIVERING
DELIVERED
RETRYING
FAILED
DISABLED
```

---

# 64. Webhook Disablement

A webhook may be disabled when:

- User disables it.
- Endpoint repeatedly fails.
- Security policy blocks it.
- Project is suspended.

Disablement must be visible and auditable.

---

# 65. Webhook Secret Rotation

Recommended flow:

```text
Generate new secret
      ↓
Show new secret once
      ↓
Consumer updates
      ↓
Activate new secret
```

For zero-downtime rotation, a future dual-secret window may be supported.

---

# 66. Webhook Test

Dashboard action:

```text
Send Test Event
```

It should:

- Use a synthetic event.
- Clearly mark test mode.
- Use the same signing mechanism.
- Record a webhook log.
- Not alter production email state.

---

# 67. Webhook Management API

Conceptual endpoints:

```http
GET    /api/v1/projects/{project}/webhooks
POST   /api/v1/projects/{project}/webhooks
GET    /api/v1/projects/{project}/webhooks/{webhook}
PATCH  /api/v1/projects/{project}/webhooks/{webhook}
DELETE /api/v1/projects/{project}/webhooks/{webhook}

POST   /api/v1/projects/{project}/webhooks/{webhook}/test
POST   /api/v1/projects/{project}/webhooks/{webhook}/enable
POST   /api/v1/projects/{project}/webhooks/{webhook}/disable
POST   /api/v1/projects/{project}/webhooks/{webhook}/rotate-secret

GET    /api/v1/projects/{project}/webhooks/{webhook}/logs
```

Exact schemas belong in `11-REST-API-SPECIFICATION.md`.

---

# 68. Webhook Event Dispatch

Concept:

```php
$eventBus->dispatch(
    new EmailSentEvent($message)
);
```

Then:

```text
Event Bus
   ↓
Webhook Dispatcher
   ↓
Matching subscriptions
   ↓
Delivery jobs
```

The event system should not be coupled to a single webhook implementation.

---

# 69. Event Matching

A webhook subscribes to explicit event types.

Example:

```json
{
  "events": [
    "email.sent",
    "email.failed"
  ]
}
```

Do not send every event to every webhook by default.

---

# 70. Webhook Authorization

Webhook management requires:

```text
Authentication
 ↓
Project access
 ↓
webhook:manage
 ↓
Action
```

Sending webhook events is a system operation, not a user-level bypass.

---

# 71. Webhook Secret Storage

Webhook secrets must not be stored as plaintext where avoidable.

Because the platform needs the secret to create HMAC signatures, use encryption at rest rather than one-way hashing.

This is intentionally different from API key storage.

---

# 72. API Key vs Webhook Secret

| Credential | Storage |
|---|---|
| API key secret | Hash |
| OAuth token | Encrypt |
| SMTP password | Encrypt |
| Provider API key | Encrypt |
| Webhook signing secret | Encrypt |

The distinction is based on whether the platform must recover the secret later.

---

# 73. Webhook Event Privacy

Events should include only required data.

Example:

```json
{
  "message_id": "msg_123",
  "status": "sent",
  "provider": "smtp"
}
```

Avoid:

```json
{
  "smtp_password": "...",
  "oauth_token": "...",
  "full_private_message_body": "..."
}
```

---

# 74. Webhook Payload Versioning

Include a payload version.

Example:

```json
{
  "version": "1",
  "id": "evt_123",
  "type": "email.sent"
}
```

Future changes can introduce:

```text
version 2
```

without breaking existing consumers.

---

# 75. Webhook Compatibility

Do not remove fields from an existing payload version unexpectedly.

For non-breaking changes:

- Add fields.
- Preserve existing field meaning.
- Maintain event IDs.
- Maintain signature rules.

Breaking changes require a new payload version.

---

# 76. Webhook Event Ordering

Do not assume global event ordering.

Events may be delivered:

```text
email.sent
email.failed
```

in different timing contexts depending on retries and processing.

Consumers should use event IDs/timestamps/state rather than assuming strict global order.

---

# 77. Project Usage Webhooks

Usage events can notify external systems when thresholds are reached.

Example:

```text
usage.limit_reached
```

Payload:

```json
{
  "project_id": "project_123",
  "metric": "emails_daily",
  "limit": 1000,
  "current": 1000
}
```

---

# 78. API Key Security Events

Possible event:

```text
api_key.revoked
```

This can be useful for external security automation.

Do not expose the revoked key secret.

---

# 79. Webhook and Email Events

Email event flow:

```text
Email Engine
    ↓
Provider result
    ↓
Email Log
    ↓
Domain Event
    ↓
Webhook Dispatcher
    ↓
Signed Delivery
```

The webhook should reflect the normalized platform event, not a raw provider exception.

---

# 80. Webhook Failure Isolation

A failing webhook must not cause an email send to fail.

Correct:

```text
Email sent
   ↓
Email log committed
   ↓
Webhook delivery fails
   ↓
Webhook retry
```

Incorrect:

```text
Email sent
   ↓
Webhook fails
   ↓
Mark email as failed
```

Webhook delivery is a downstream notification concern.

---

# 81. Webhook Queue Compatibility

Initial deployment may use cron/database-backed pending delivery processing.

Architecture:

```text
webhook_deliveries
      ↓
cron worker
      ↓
HTTP delivery
      ↓
result
```

Future queue systems can replace the worker without changing webhook APIs.

---

# 82. Cron/Webhook Worker

Worker responsibilities:

- Find pending deliveries.
- Lock delivery safely.
- Attempt HTTP request.
- Record result.
- Schedule retry.
- Mark delivered/failed.
- Release lock.

Avoid processing the same delivery concurrently.

---

# 83. Delivery Locking

Use database state/locking to prevent:

```text
Worker A → delivery 123
Worker B → delivery 123
```

from executing simultaneously.

Possible approach:

```text
PENDING
  ↓ atomic claim
DELIVERING
```

Then process.

---

# 84. Webhook Retry Race Protection

Before retry:

```text
Read current delivery state
 ↓
Confirm still retryable
 ↓
Claim
 ↓
Send
```

A disabled webhook should not be retried after disablement unless policy explicitly permits it.

---

# 85. Webhook Rate Limits

Protect both:

- Platform outbound requests.
- User's destination.

Possible limits:

```text
per webhook
per project
per destination host
global
```

This reduces accidental webhook storms.

---

# 86. Webhook Destination Health

Track:

```text
last_success_at
last_failure_at
consecutive_failures
recent_failure_rate
```

A persistently failing endpoint may be marked degraded or disabled.

---

# 87. Webhook Security Headers

Recommended:

```http
Content-Type: application/json
X-Webhook-ID: ...
X-Webhook-Event: ...
X-Webhook-Timestamp: ...
X-Webhook-Signature: ...
X-Webhook-Delivery: ...
```

No authentication token belonging to another system should be included automatically.

---

# 88. Webhook Consumer Verification

Documentation should show consumers how to:

1. Read timestamp.
2. Read raw request body.
3. Build signed payload.
4. Compute HMAC.
5. Compare signatures using constant-time comparison.
6. Check timestamp freshness.
7. Deduplicate event ID.

Never parse and reserialize JSON before signature verification.

---

# 89. Replay Protection

Webhook consumers should reject stale signatures.

Recommended:

```text
timestamp window
```

Example:

```text
±5 minutes
```

Exact window is configurable.

The platform's signature format must make replay verification possible.

---

# 90. Project API Documentation

Developer docs should include:

```text
Authentication
Projects
API Keys
Send Email
Templates
Variables
Providers
Webhooks
Logs
Usage
Errors
Rate Limits
```

The API key guide must explicitly distinguish browser/public keys from private server keys.

---

# 91. JavaScript Fetch Example

Example:

```javascript
async function sendWelcomeEmail(userName, email) {
  const response = await fetch(
    "https://api.example.com/api/v1/projects/project_123/email/send",
    {
      method: "POST",
      headers: {
        "Authorization": "Bearer eapi_public_restricted_key",
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        template: "welcome_email",
        to: email,
        variables: {
          user_name: userName,
          app_name: "My App"
        }
      })
    }
  );

  return response.json();
}
```

Production browser keys must have minimal scopes and strong rate limits.

---

# 92. Server-Side API Example

Private backend:

```text
Application Server
      ↓
Private API key
      ↓
Email API
```

The private key remains server-side.

This is the preferred model for sensitive applications.

---

# 93. CORS

Browser-based project API requests require controlled CORS.

Recommended project settings may include:

```text
allowed_origins
```

Example:

```text
https://example.com
https://www.example.com
```

Do not default to unrestricted:

```text
Access-Control-Allow-Origin: *
```

for sensitive project operations.

---

# 94. Origin + API Key

CORS is not authentication.

The platform must still validate:

```text
API key
project
scope
rate limit
```

Origin restrictions are an additional browser control.

---

# 95. Project Allowed Origins

Optional project configuration:

```text
Allowed Origins
├── https://example.com
└── https://www.example.com
```

This is especially useful for browser-facing send-only keys.

---

# 96. API Key and Origin Policy

For a browser-restricted key:

```text
API key valid
AND
origin allowed
AND
scope allowed
AND
project active
AND
rate limit available
```

Otherwise reject.

Server-side keys may not require browser-origin restrictions.

---

# 97. Project API Error Model

Example:

```json
{
  "success": false,
  "error": {
    "code": "API_KEY_SCOPE_DENIED",
    "message": "The API key does not have permission to perform this action."
  },
  "request_id": "req_123"
}
```

The request ID helps support/debugging.

---

# 98. Project API Logging

Record:

```text
request_id
project_id
api_key_id
route
method
status
duration
ip
origin
user_agent
created_at
```

Do not log:

```text
Authorization header
full API key
provider secrets
passwords
OAuth tokens
```

---

# 99. Project Deletion

Project deletion must be explicit and protected.

Recommended:

```text
Confirm project name
       ↓
Re-authentication where appropriate
       ↓
Warn about irreversible data
       ↓
Delete/archive according to retention policy
```

Deletion should address:

- API keys.
- Providers.
- Templates.
- Webhooks.
- Logs.
- Usage.
- Settings.

---

# 100. Project Suspension Effects

Suspending a project should:

- Reject new email sends.
- Reject new OTP sends.
- Disable API keys for operations.
- Stop webhook processing where appropriate.
- Preserve logs.
- Preserve audit records.
- Notify the owner/admin.

---

# 101. Project Archive Effects

Archiving should:

- Stop normal sending.
- Disable active API keys.
- Preserve data.
- Preserve logs.
- Allow authorized restoration.

---

# 102. API Key and Project Deletion

When a project is deleted:

```text
All API keys → revoked/invalid
Providers → disconnected/invalidated
Webhooks → disabled
Templates → archived/deleted per retention
Logs → retained/deleted per policy
```

No deleted project key may continue authenticating.

---

# 103. Webhook and Project Deletion

When project becomes inactive:

```text
Webhook delivery
      ↓
Project state check
      ↓
Do not send if disabled/deleted
```

This prevents abandoned integrations from continuing to receive data.

---

# 104. Project Notifications

Notify project owners about:

- API key creation.
- API key revocation.
- Provider failures.
- Usage threshold.
- Webhook failures.
- Security alerts.
- Project suspension.
- Important configuration changes.

Notifications must not include secrets.

---

# 105. Audit Events

Project/security audit examples:

```text
project.created
project.updated
project.suspended
project.archived
api_key.created
api_key.revoked
api_key.expired
webhook.created
webhook.updated
webhook.disabled
webhook.secret_rotated
```

Audit events are immutable records.

---

# 106. Project Database Relationships

Core:

```text
users
  ↓
projects
  ├── project_settings
  ├── providers
  ├── templates
  ├── api_keys
  ├── api_requests
  ├── email_logs
  ├── otp_logs
  ├── webhooks
  ├── webhook_logs
  └── usage_statistics
```

Foreign keys must enforce relationships.

---

# 107. Recommended Project Indexes

Important indexes include:

```text
projects(user_id, status)
projects(slug)
api_keys(project_id, status)
api_keys(public_prefix)
api_requests(project_id, created_at)
webhooks(project_id, status)
webhook_logs(webhook_id, created_at)
```

Exact database indexing is finalized in `09-DATABASE-SCHEMA.md`.

---

# 108. Project Service Layer

Recommended:

```text
ProjectService
ProjectAuthorizationService
ProjectSettingsService
ProjectLifecycleService
```

Responsibilities:

- Create.
- Update.
- Suspend.
- Archive.
- Restore.
- Delete.
- Resolve project context.
- Validate project permissions.

---

# 109. API Key Service Layer

Recommended:

```text
ApiKeyService
ApiKeyAuthenticator
ApiKeyScopeService
ApiKeyRotationService
ApiKeyAuditService
```

Responsibilities:

- Generate.
- Hash.
- Authenticate.
- Scope-check.
- Revoke.
- Rotate.
- Expire.
- Track usage.
- Audit.

---

# 110. Webhook Service Layer

Recommended:

```text
WebhookService
WebhookEventDispatcher
WebhookSigner
WebhookDeliveryService
WebhookRetryService
WebhookHealthService
```

Keep event creation separate from HTTP delivery.

---

# 111. Webhook Repository Layer

Recommended:

```text
WebhookRepository
WebhookDeliveryRepository
WebhookEventRepository
```

Repositories should handle persistence only.

---

# 112. API Key Repository

Recommended:

```text
ApiKeyRepository
```

Responsibilities:

- Find by prefix.
- Create.
- Revoke.
- Update metadata.
- Record last-used metadata.
- List project keys.

Never return secrets from generic repository methods unless the one-time creation response explicitly requires the generated secret.

---

# 113. API Key Authentication Middleware

Recommended middleware:

```text
ApiKeyAuthenticationMiddleware
```

Flow:

```text
Request
 ↓
Extract bearer key
 ↓
Authenticate
 ↓
Project context
 ↓
Scopes
 ↓
Rate limit
 ↓
Controller
```

---

# 114. Scope Middleware

Example:

```text
requireScope("email:send")
```

The route declares the minimum required permission.

This avoids scattering scope checks through controller code.

---

# 115. Project Context Object

After authentication:

```text
ProjectContext
├── project_id
├── api_key_id
├── user_id
├── scopes
├── environment
└── policy
```

Controllers/services receive the trusted context rather than trusting raw project IDs repeatedly.

---

# 116. Webhook Event Bus

Events should be domain-oriented.

Example:

```text
EmailSent
EmailFailed
OtpSent
OtpFailed
ProviderFailed
ApiKeyRevoked
UsageLimitReached
SecurityAlert
```

The webhook layer maps domain events to public webhook event names.

---

# 117. Event Payload Sanitization

Before dispatch:

```text
Domain Event
   ↓
Public Event Mapper
   ↓
Safe payload
   ↓
Webhook signer
```

Never serialize internal domain objects directly to external consumers.

---

# 118. Webhook Event Security

Public payload must not contain:

- Passwords.
- API keys.
- OAuth tokens.
- SMTP credentials.
- Encryption keys.
- Internal stack traces.
- Private database details.

Sensitive identifiers should be minimized.

---

# 119. Webhook Observability

Track:

```text
webhook_event_total
webhook_delivery_total
webhook_delivery_success_total
webhook_delivery_failure_total
webhook_retry_total
webhook_disabled_total
```

Useful labels:

```text
event_type
project
webhook
status
```

Avoid high-cardinality sensitive labels.

---

# 120. Webhook Delivery Example

```text
Email sent
   ↓
Event: email.sent
   ↓
Webhook subscription match
   ↓
Create delivery record
   ↓
Build JSON payload
   ↓
Create timestamp
   ↓
HMAC signature
   ↓
HTTP POST
   ↓
2xx
   ↓
DELIVERED
```

Failure:

```text
HTTP 503
   ↓
RETRYING
   ↓
Backoff
   ↓
Next attempt
```

---

# 121. API Key + Webhook Complete Flow

```text
Static Website
      ↓
Restricted API Key
      ↓
POST /email/send
      ↓
Project authentication
      ↓
Template rendering
      ↓
Email Engine
      ↓
Provider
      ↓
Email Log
      ↓
Domain Event
      ↓
Webhook Dispatcher
      ↓
Signed Webhook
      ↓
Customer Backend
```

This is the primary developer integration model.

---

# 122. Security Checklist

### Projects

- [ ] Project authorization enforced.
- [ ] Project state enforced.
- [ ] Cross-project access blocked.
- [ ] Project deletion protected.
- [ ] Suspension behavior tested.

### API Keys

- [ ] Cryptographically random.
- [ ] Secret hashed.
- [ ] Secret shown once.
- [ ] Revocation works.
- [ ] Expiry works.
- [ ] Scopes enforced.
- [ ] Browser keys restricted.
- [ ] Raw keys never logged.

### Webhooks

- [ ] HTTPS enforced.
- [ ] SSRF protection enabled.
- [ ] HMAC signatures enabled.
- [ ] Replay protection supported.
- [ ] Event IDs included.
- [ ] Delivery IDs included.
- [ ] Retries bounded.
- [ ] Secrets encrypted.
- [ ] Sensitive payloads excluded.
- [ ] Webhook failures isolated from email sending.

---

# 123. Testing Checklist

### Project tests

- [ ] Create.
- [ ] Update.
- [ ] Suspend.
- [ ] Archive.
- [ ] Restore.
- [ ] Delete.
- [ ] Cross-project authorization.

### API key tests

- [ ] Generate.
- [ ] Authenticate.
- [ ] Invalid key.
- [ ] Expired key.
- [ ] Revoked key.
- [ ] Suspended key.
- [ ] Scope denial.
- [ ] Rotation.
- [ ] Browser origin restriction.
- [ ] Rate limit.

### Webhook tests

- [ ] Create.
- [ ] Update.
- [ ] Delete.
- [ ] Event matching.
- [ ] HMAC signature.
- [ ] Timestamp validation.
- [ ] Retry.
- [ ] Backoff.
- [ ] Timeout.
- [ ] SSRF blocking.
- [ ] Duplicate delivery.
- [ ] Disablement.
- [ ] Secret rotation.

---

# 124. Definition of Done

The Projects/API Keys/Webhooks module is complete when:

- Projects can be created and managed.
- Project resources are isolated.
- Project lifecycle states work.
- API keys are securely generated.
- API key secrets are hashed.
- API scopes are enforced.
- Key rotation/revocation works.
- Browser/public keys are treated as non-secret.
- CORS/origin restrictions work.
- API usage is logged safely.
- Webhooks can be created and managed.
- Webhook secrets are encrypted.
- Webhook signatures are generated.
- Event IDs and delivery IDs exist.
- Webhook retries/backoff work.
- SSRF protection exists.
- Webhook failures do not fail email sends.
- Project/API/webhook audit events work.
- The system is queue-compatible.
- Static HTML/JS integration works.
- Server-side private-key integration works.
- Tests cover authorization and security boundaries.

---

# 125. Non-Negotiable Rules

1. Projects are the primary isolation boundary.
2. Every project resource must be server-side authorized.
3. API keys must never be stored plaintext.
4. API key secrets must be hashed.
5. Provider credentials must remain separate from API keys.
6. Browser API keys are not treated as secrets.
7. Browser keys must have minimal scopes.
8. Private API keys must never be exposed to browsers.
9. API keys must be revocable.
10. API keys must support least-privilege scopes.
11. API authentication must occur before project operations.
12. Webhook secrets must be encrypted.
13. Webhook signatures must use a secure MAC.
14. Webhook payloads must be sanitized.
15. Webhook URLs require SSRF protection.
16. Webhook failures must not mark emails as failed.
17. Webhook retries must be bounded.
18. Webhook delivery must be idempotency-friendly.
19. Event IDs must be unique.
20. Delivery IDs must identify individual attempts.
21. Project suspension must block sending.
22. Deleted project keys must never authenticate.
23. Secrets must never appear in logs.
24. CORS is not authentication.
25. Origin checks are an additional control.
26. Scope checks must be server-side.
27. Project IDs from clients are untrusted.
28. Template/provider/webhook IDs are untrusted.
29. Audit sensitive changes.
30. Preserve public API compatibility.
31. Do not couple webhook delivery to email success state.
32. Do not expose internal exceptions to clients.
33. Do not follow unsafe webhook redirects.
34. Do not send webhooks to internal/private addresses.
35. Do not create unrestricted administrative API keys for browser use.
36. Do not put provider credentials into client JavaScript.
37. Do not use predictable API key generation.
38. Do not use reversible storage for API key secrets.
39. Do not serialize internal domain objects directly as webhook payloads.
40. New project/API/webhook features must preserve the locked isolation model.

---

# 126. Final Architecture

```text
                         ┌──────────────────────┐
                         │       User           │
                         └──────────┬───────────┘
                                    │
                                    ▼
                         ┌──────────────────────┐
                         │      PROJECT         │
                         │ Isolation Boundary   │
                         └──────────┬───────────┘
                                    │
              ┌─────────────────────┼──────────────────────┐
              │                     │                      │
              ▼                     ▼                      ▼
       ┌────────────┐       ┌─────────────┐       ┌─────────────┐
       │ API Keys   │       │ Templates   │       │ Providers   │
       └─────┬──────┘       └──────┬──────┘       └─────────────┘
             │                     │
             ▼                     ▼
       ┌────────────┐       ┌─────────────┐
       │ API Auth   │       │ Email Engine│
       └─────┬──────┘       └──────┬──────┘
             │                     │
             └──────────┬──────────┘
                        ▼
                ┌─────────────────┐
                │   Email Logs    │
                └────────┬────────┘
                         │
                         ▼
                ┌─────────────────┐
                │  Domain Events  │
                └────────┬────────┘
                         │
                         ▼
                ┌─────────────────┐
                │ Webhook System  │
                └────────┬────────┘
                         │
                         ▼
                ┌─────────────────┐
                │ Signed HTTPS    │
                │ External System  │
                └─────────────────┘
```

---

# 127. Final Lock

This document establishes the Projects, API Keys and Webhooks architecture for the Email API Platform.

The following decisions are locked:

- Projects are the primary isolation boundary.
- Projects can contain independent providers, templates, API keys, logs, usage and webhooks.
- API keys authenticate programmatic project access.
- API key secrets are generated cryptographically and stored as hashes.
- Provider credentials and webhook secrets use encrypted storage because they must be recovered for outbound operations.
- API keys use least-privilege scopes.
- Browser-facing keys are treated as exposed credentials and must be restricted.
- Private server-side keys must never be exposed to frontend JavaScript.
- Project/API key authentication is separate from provider authentication.
- CORS is an additional browser security control, not authentication.
- Webhooks use signed HTTPS requests.
- Webhook delivery is at-least-once and must be idempotency-friendly.
- Webhook retries use bounded exponential backoff.
- Webhook URLs require SSRF protection.
- Webhook failures never change a successful email into a failed email.
- Domain events are separated from webhook transport.
- Project/API/webhook operations are audited.
- Project suspension/deletion invalidates active programmatic access.
- The architecture remains queue-compatible and provider-independent.
- Public API compatibility must be preserved.

**STATUS: FINAL / LOCKED**

**Next document:** `17-USER-PANEL.md`
