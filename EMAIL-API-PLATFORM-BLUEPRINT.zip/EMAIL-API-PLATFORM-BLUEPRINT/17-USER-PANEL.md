# 17 — USER PANEL

**Project:** Email API Platform  
**Document:** Complete User Dashboard, Navigation, Project Workspace, Email Operations, Settings & Security  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Related:** `05-UI-UX-DESIGN-SYSTEM.md`, `06-SCREENS-AND-NAVIGATION.md`, `10-BACKEND-PHP-ARCHITECTURE.md`, `13-EMAIL-ENGINE.md`, `15-TEMPLATE-ENGINE.md`, `16-PROJECTS-API-KEYS-WEBHOOKS.md`

---

## 1. Purpose

This document defines the complete authenticated user panel for the Email API Platform.

The User Panel is the primary workspace where users manage:

- Projects
- Email providers
- Gmail connections
- SMTP connections
- Templates
- Template variables
- Email sending
- Test emails
- API keys
- API integration
- Email logs
- OTP logs
- Usage and statistics
- Webhooks
- Notifications
- Profile
- Security
- Password
- Active sessions

The panel must remain consistent with the locked project architecture and must never bypass backend authorization.

---

# 2. User Panel Architecture

```text
Authenticated User
       │
       ▼
User Dashboard
       │
       ├── Projects
       │    └── Project Workspace
       │         ├── Overview
       │         ├── Providers
       │         ├── Templates
       │         ├── Send Email
       │         ├── API Integration
       │         ├── API Keys
       │         ├── Logs
       │         ├── Usage
       │         └── Webhooks
       │
       ├── Notifications
       ├── Profile
       └── Security
```

The project workspace is the main contextual boundary.

---

# 3. Locked User Screens

The User Panel covers these locked screens:

```text
18  User Dashboard
19  Projects
20  Create Project
21  Project Overview
22  Project Settings
23  Email Services
24  Add Gmail
25  Gmail Connection Success
26  Add SMTP
27  SMTP Connection Test
28  Provider Management
29  Email Templates
30  Create Template
31  Template Editor
32  Template Preview
33  Template Variables
34  Email Send
35  Test Email
36  API Integration
37  API Keys
38  API Key Create
39  API Documentation
40  Email Logs
41  Email Log Details
42  OTP Logs
43  Usage & Statistics
44  Webhooks
45  Webhook Settings
46  Notifications
47  Profile Settings
48  Security Settings
49  Password Change
50  Active Sessions
```

No additional core user screen is required outside the locked scope.

---

# 4. User Navigation

Recommended primary navigation:

```text
Dashboard

Projects
  ├── All Projects
  └── Current Project
       ├── Overview
       ├── Settings
       ├── Email Services
       ├── Templates
       ├── Send Email
       ├── API Integration
       ├── API Keys
       ├── Logs
       ├── OTP Logs
       ├── Usage
       └── Webhooks

Account
  ├── Notifications
  ├── Profile
  ├── Security
  ├── Password
  └── Active Sessions
```

---

# 5. Global User Panel Layout

Desktop:

```text
┌──────────────────────────────────────────────────────────────┐
│ Logo     Project Switcher                 Notifications Avatar│
├───────────────┬──────────────────────────────────────────────┤
│ Sidebar       │ Breadcrumbs                                  │
│               │                                              │
│ Dashboard     │ Page Content                                 │
│ Projects      │                                              │
│ Templates     │                                              │
│ API           │                                              │
│ Logs          │                                              │
│ Usage         │                                              │
│ Webhooks      │                                              │
│               │                                              │
│ Account       │                                              │
└───────────────┴──────────────────────────────────────────────┘
```

Mobile:

```text
┌───────────────────────────┐
│ Logo   Bell   Menu        │
├───────────────────────────┤
│ Project Switcher          │
├───────────────────────────┤
│ Breadcrumb / Page Title   │
│                           │
│ Content                   │
│                           │
└───────────────────────────┘
```

---

# 6. Project Context

Most project screens must display the active project.

Example:

```text
Projects / My SaaS / Email Templates
```

The active project should be visible in the project switcher.

Changing projects must refresh project-scoped data.

---

# 7. Project Switcher

The project switcher should provide:

- Current project.
- Search.
- Project list.
- Status.
- Environment.
- Create project action.

Example:

```text
My SaaS App
Production

Personal Website
Production

Testing
Development
```

Selecting another project must never expose the previous project's data.

---

# 8. Dashboard

Screen: `18 User Dashboard`

Purpose:

Give the user a fast overview of the platform.

Recommended cards:

```text
Projects
Emails Sent
Emails Failed
API Requests
Current Usage
Active Providers
Templates
Webhook Health
```

Additional sections:

```text
Recent Email Activity
Recent Security Events
Usage Trend
Quick Actions
```

---

# 9. Dashboard Quick Actions

Recommended:

```text
Create Project
Connect Gmail
Add SMTP
Create Template
Send Test Email
Create API Key
View API Docs
```

Actions should respect current project state.

---

# 10. Dashboard Empty State

For a new account:

```text
Welcome

Create your first project to start sending email.

[Create Project]
```

Optional guided setup:

```text
1. Create Project
2. Connect Provider
3. Create Template
4. Create API Key
5. Send Test Email
```

---

# 11. Projects

Screen: `19 Projects`

Display:

- Project name.
- Environment.
- Status.
- Provider status.
- Template count.
- Recent email activity.
- Created date.
- Actions.

Actions:

```text
Open
Settings
Archive
Delete
```

---

# 12. Project Search and Filtering

Support:

```text
Search
Status
Environment
Sort
Pagination
```

Search must be server-side for large datasets.

---

# 13. Create Project

Screen: `20 Create Project`

Fields:

```text
Project Name
Description
Environment
```

Optional:

```text
Timezone
```

Validation:

- Name required.
- Safe length.
- Trim whitespace.
- Normalize slug.
- Reject dangerous content.

After creation:

```text
Project created
      ↓
Project Overview
```

---

# 14. Project Overview

Screen: `21 Project Overview`

Display:

```text
Project Name
Environment
Status
Project ID
Created Date
Default Provider
```

Statistics:

```text
Emails Sent
Emails Failed
API Requests
Templates
Webhooks
```

Quick actions:

```text
Connect Provider
Create Template
Create API Key
Send Test Email
```

---

# 15. Project Settings

Screen: `22 Project Settings`

Sections:

```text
General
Environment
Default Provider
Allowed Origins
Rate Limits
Usage Limits
Log Retention
Danger Zone
```

Danger Zone:

```text
Suspend Project
Archive Project
Delete Project
```

Destructive operations require confirmation.

---

# 16. Project Settings Security

Sensitive changes may require:

- Re-authentication.
- Current password.
- OTP.
- Confirmation dialog.

The frontend must never decide whether re-authentication is required; the backend enforces the policy.

---

# 17. Email Services

Screen: `23 Email Services`

Purpose:

Central provider management for the active project.

Display:

```text
Default Provider
Provider Status
Connection Status
Last Test
Provider Type
```

Actions:

```text
Add Gmail
Add SMTP
Test
Set Default
Disconnect
```

---

# 18. Add Gmail

Screen: `24 Add Gmail`

Flow:

```text
Connect Gmail
      ↓
OAuth Authorization
      ↓
Google consent
      ↓
Callback
      ↓
Validate account
      ↓
Encrypt/store tokens
      ↓
Create provider connection
      ↓
Success
```

Never ask the user to paste an OAuth token manually unless explicitly supported as a separate advanced mechanism.

---

# 19. Gmail Connection Success

Screen: `25 Gmail Connection Success`

Display:

```text
Gmail Connected

Account
provider status
connection time
```

Actions:

```text
Go to Provider Management
Send Test Email
Set as Default
```

Do not display access/refresh tokens.

---

# 20. Add SMTP

Screen: `26 Add SMTP`

Fields:

```text
Provider Name
SMTP Host
Port
Encryption
Username
Password
From Name
From Email
```

Encryption options:

```text
TLS
SSL
STARTTLS
None
```

Unsafe configurations should be rejected or strongly warned according to deployment policy.

---

# 21. SMTP Connection Test

Screen: `27 SMTP Connection Test`

Test sequence:

```text
Validate fields
      ↓
Open connection
      ↓
TLS negotiation
      ↓
Authenticate
      ↓
Verify server response
      ↓
Close connection
```

Display:

```text
Connection Successful
```

or:

```text
Connection Failed
Reason
Recommended Fix
```

Never expose passwords or raw credentials.

---

# 22. Provider Management

Screen: `28 Provider Management`

Provider table:

```text
Provider
Type
Status
Default
Last Test
Created
Actions
```

Actions:

```text
Test
Set Default
Edit
Disconnect
```

A provider cannot be deleted if active dependencies require it unless the backend handles reassignment safely.

---

# 23. Provider Status

Recommended:

```text
CONNECTED
DISCONNECTED
ERROR
TESTING
SUSPENDED
```

Status must come from backend state.

---

# 24. Email Templates

Screen: `29 Email Templates`

Display:

```text
Template Name
Slug
Status
Version
Updated
Last Used
Actions
```

Actions:

```text
Create
Edit
Preview
Duplicate
Publish
Archive
Delete
```

Search/filter:

```text
Search
Status
Updated
```

---

# 25. Create Template

Screen: `30 Create Template`

Fields:

```text
Template Name
Subject
HTML Content
Plain Text Content
Variables
Description
```

A template should have a stable identifier/slug.

---

# 26. Template Editor

Screen: `31 Template Editor`

Recommended editor layout:

```text
┌────────────────────────────────────────────┐
│ Template Name       Save   Preview Publish │
├──────────────────┬─────────────────────────┤
│ Editor           │ Variable Helper         │
│                  │                         │
│ HTML             │ {{user_name}}           │
│                  │ {{app_name}}            │
├──────────────────┴─────────────────────────┤
│ Validation / status                         │
└────────────────────────────────────────────┘
```

The editor must support:

- HTML.
- Subject.
- Plain text.
- Variables.
- Validation.
- Preview.
- Save draft.
- Publish.

---

# 27. Template Preview

Screen: `32 Template Preview`

Preview should support:

```text
Desktop
Mobile
```

Variable sample data:

```json
{
  "user_name": "Demo User",
  "app_name": "Demo App"
}
```

Preview is sandboxed and must not send an email.

---

# 28. Template Variables

Screen: `33 Template Variables`

Display:

```text
Variable
Type
Required
Example
Description
```

Example:

```text
user_name
string
required
Demo User

verification_code
string
required
123456
```

Variable names must follow the template engine rules.

---

# 29. Email Send

Screen: `34 Email Send`

Purpose:

Allow manual/project-level email sending.

Fields:

```text
Provider
Template
To
CC
BCC
Reply-To
Subject
Variables
```

Optional advanced fields:

```text
From
Plain Text
Tags
Attachments
```

Before send:

```text
Validate
Estimate
Confirm
Send
```

---

# 30. Test Email

Screen: `35 Test Email`

Purpose:

Safely test provider/template configuration.

Fields:

```text
Recipient
Template
Provider
Sample Variables
```

Clearly mark:

```text
TEST EMAIL
```

Test mode must not alter production business data beyond the required email/log event.

---

# 31. API Integration

Screen: `36 API Integration`

Purpose:

Help developers connect their website/app.

Sections:

```text
Quick Start
Authentication
Send Email
Templates
Variables
JavaScript Fetch
Server-side Example
Error Handling
Rate Limits
Webhooks
```

Primary quick-start example:

```javascript
fetch("https://api.example.com/api/v1/projects/PROJECT_ID/email/send", {
  method: "POST",
  headers: {
    "Authorization": "Bearer YOUR_API_KEY",
    "Content-Type": "application/json"
  },
  body: JSON.stringify({
    template: "welcome_email",
    to: "user@example.com",
    variables: {
      user_name: "Demo User"
    }
  })
});
```

Browser-facing keys must be restricted.

---

# 32. API Keys

Screen: `37 API Keys`

Display:

```text
Name
Prefix
Scopes
Status
Created
Expires
Last Used
Actions
```

Actions:

```text
Create
Revoke
Rotate
View
```

The full secret must never be displayed after creation.

---

# 33. API Key Create

Screen: `38 API Key Create`

Fields:

```text
Key Name
Environment
Scopes
Expiration
Allowed Origins
```

Recommended presets:

```text
Browser Send
Server Integration
Development
```

After creation:

```text
API key generated.

Copy it now.
It will not be shown again.
```

---

# 34. API Documentation

Screen: `39 API Documentation`

Must include:

```text
Base URL
Authentication
Endpoints
Request schemas
Response schemas
Examples
Errors
Rate Limits
Webhooks
```

Documentation must remain synchronized with the actual API specification.

---

# 35. Email Logs

Screen: `40 Email Logs`

Columns:

```text
Message ID
Recipient
Subject
Provider
Status
Created
Duration
```

Filters:

```text
Status
Provider
Date
Recipient
Template
```

Pagination is mandatory for large datasets.

---

# 36. Email Log Details

Screen: `41 Email Log Details`

Display:

```text
Message ID
Request ID
Status
Provider
Recipient
Subject
Template
Created
Sent
Failure
```

Safe technical details:

```text
Provider response code
Normalized error
Retry count
Duration
```

Never show provider credentials.

---

# 37. OTP Logs

Screen: `42 OTP Logs`

Display:

```text
OTP Request ID
Destination
Purpose
Status
Attempts
Created
Expires
Verified
```

Never display the actual OTP value in normal user logs.

---

# 38. Usage & Statistics

Screen: `43 Usage & Statistics`

Metrics:

```text
Emails Sent
Emails Failed
OTP Sent
API Requests
Webhook Deliveries
Success Rate
Failure Rate
```

Time filters:

```text
Today
7 Days
30 Days
Custom
```

Charts must remain readable on mobile.

---

# 39. Usage Presentation

Recommended:

```text
Summary Cards
      ↓
Trend Chart
      ↓
Provider Breakdown
      ↓
Status Breakdown
      ↓
Recent Activity
```

Avoid excessive animation.

---

# 40. Webhooks

Screen: `44 Webhooks`

Display:

```text
Webhook Name
Endpoint
Events
Status
Last Delivery
Health
```

Actions:

```text
Create
Edit
Test
Disable
Enable
Rotate Secret
Delete
View Logs
```

---

# 41. Webhook Settings

Screen: `45 Webhook Settings`

Fields:

```text
Name
Endpoint URL
Events
Status
Retry Policy
```

Secret:

```text
Generate Secret
Rotate Secret
```

Secret must be shown only according to the locked webhook security policy.

---

# 42. Webhook Test UX

Flow:

```text
Select Test Event
       ↓
Confirm
       ↓
Send
       ↓
Delivery Result
```

Result:

```text
HTTP Status
Duration
Delivery ID
Timestamp
```

Do not show sensitive response data unnecessarily.

---

# 43. Notifications

Screen: `46 Notifications`

Categories:

```text
Security
Provider
Usage
Webhook
Project
System
```

Each notification:

```text
Title
Message
Time
Read/Unread
```

Actions:

```text
Mark Read
Mark All Read
```

---

# 44. Notification Preferences

Preferences may include:

```text
Provider failure
Usage threshold
Webhook failures
Security alerts
API key events
Project events
```

Critical security notifications should not be silently disabled where policy requires mandatory delivery.

---

# 45. Profile Settings

Screen: `47 Profile Settings`

Fields:

```text
Name
Email
Timezone
Language
Avatar
```

Email changes should require verification.

---

# 46. Profile Security

Changing account email may require:

```text
Current password
OTP/email verification
```

The new email must not become active until verification succeeds.

---

# 47. Security Settings

Screen: `48 Security Settings`

Sections:

```text
Account Security
Sessions
Login Protection
OTP
API Security
Activity
```

Display useful security information without exposing secrets.

---

# 48. Security Controls

Possible controls:

```text
Email verification
Password security
Session management
Login attempt protection
API key review
Security notifications
```

All security decisions are enforced by backend services.

---

# 49. Password Change

Screen: `49 Password Change`

Fields:

```text
Current Password
New Password
Confirm New Password
```

Requirements:

- Strong password policy.
- Current password verification.
- Secure hashing.
- Session/security policy enforcement.

After successful change, optionally revoke other sessions according to security policy.

---

# 50. Active Sessions

Screen: `50 Active Sessions`

Display:

```text
Device
Browser
IP
Approximate Location
Last Active
Current Session
```

Actions:

```text
Revoke
Revoke All Other Sessions
```

Precise location should not be inferred or exposed unnecessarily.

---

# 51. Session Security

Sessions must use:

- Secure cookies.
- HttpOnly.
- SameSite policy.
- HTTPS.
- Session ID regeneration after authentication.
- Server-side expiration.
- Revocation support.

The browser must never receive raw session internals.

---

# 52. Global Loading States

Every asynchronous page must define:

```text
Initial Loading
Refreshing
Submitting
Success
Empty
Error
Retry
```

Avoid blank screens during network requests.

---

# 53. Global Empty States

Examples:

### No projects

```text
No projects yet.
Create your first project.
```

### No templates

```text
No templates yet.
Create a template.
```

### No logs

```text
No email activity yet.
```

### No webhooks

```text
No webhooks configured.
```

---

# 54. Error States

Common UI states:

```text
Network Error
Unauthorized
Forbidden
Not Found
Validation Error
Rate Limited
Server Error
Provider Error
```

Use backend error codes to produce actionable messages.

Do not expose stack traces.

---

# 55. Success Feedback

Use:

- Inline confirmation.
- Toast.
- Status badge.
- Confirmation page for important flows.

Examples:

```text
Project created.
Provider connected.
Template saved.
API key created.
Webhook test delivered.
```

---

# 56. Confirmation Dialogs

Required for destructive actions:

```text
Delete Project
Delete Template
Revoke API Key
Delete Webhook
Disconnect Provider
Revoke Session
```

Dialog must state consequences clearly.

---

# 57. Form Validation

Client-side validation improves UX.

Server-side validation remains authoritative.

Validate:

```text
Required fields
Lengths
Formats
URLs
Emails
Identifiers
Scopes
Origins
```

Do not trust client validation.

---

# 58. Toast Rules

Toasts should:

- Be short.
- Be dismissible.
- Not contain secrets.
- Not block the interface.
- Have accessible text.

Critical errors should also have inline context.

---

# 59. Tables

Tables must support:

```text
Responsive behavior
Horizontal scrolling where required
Pagination
Sorting
Filtering
Empty state
Loading state
Error state
```

On mobile, convert dense rows into cards where appropriate.

---

# 60. Project Workspace Responsive Behavior

Desktop:

```text
Sidebar + content
```

Tablet:

```text
Compact sidebar
```

Mobile:

```text
Top bar + drawer
```

Project context must remain visible on all breakpoints.

---

# 61. Accessibility

User Panel must support:

- Keyboard navigation.
- Visible focus.
- Semantic headings.
- Labels.
- Form error associations.
- ARIA where required.
- Accessible dialogs.
- Screen-reader friendly status updates.
- Sufficient contrast.
- Reduced-motion preference.

---

# 62. Design System

Follow `05-UI-UX-DESIGN-SYSTEM.md`.

Locked baseline:

```text
Bootstrap 5.3+
Inter
JetBrains Mono
Lucide
CSS variables
Responsive layout
```

Do not introduce another UI framework.

---

# 63. Icon Rules

Use Lucide for:

```text
Navigation
Actions
Settings
Security
Logs
Projects
Templates
Webhooks
Notifications
```

Use official/Simple Icons for provider/technology brands.

Do not use arbitrary Unicode symbols as primary UI icons.

---

# 64. Project Status Badges

Recommended semantic labels:

```text
Active
Suspended
Archived
Deleted
```

Provider:

```text
Connected
Disconnected
Error
Testing
```

API key:

```text
Active
Revoked
Expired
Suspended
```

Webhook:

```text
Healthy
Degraded
Disabled
```

---

# 65. API Key Secret Handling in UI

The frontend may receive the newly generated secret once.

After navigation/refresh:

```text
secret unavailable
```

The UI must not attempt to reconstruct it.

Clipboard action should be explicit.

---

# 66. Provider Credential Handling in UI

Passwords/tokens:

- Never displayed after save unless specifically supported.
- Never placed in HTML attributes unnecessarily.
- Never logged to browser console.
- Never included in analytics events.
- Never returned by generic provider list APIs.

---

# 67. Template Security in UI

Template editor must warn users about:

- Unsafe HTML.
- Unsupported variables.
- Missing required variables.
- Excessive content size.
- Invalid markup.

Preview should use the platform's safe rendering mechanism.

---

# 68. Email Send Security

Manual send must enforce:

```text
Project access
Provider access
Template access
Recipient validation
Rate limit
Project status
Provider status
```

A UI button is never an authorization mechanism.

---

# 69. API Integration Security

Documentation must clearly label:

```text
PUBLIC/BROWSER-SAFE RESTRICTED KEY
```

versus:

```text
PRIVATE SERVER-SIDE KEY
```

The user panel should discourage placing private keys in frontend code.

---

# 70. User Panel API Layer

Frontend should communicate through a centralized API client.

Example structure:

```text
/api
  client.js
  auth.js
  projects.js
  providers.js
  templates.js
  email.js
  apiKeys.js
  logs.js
  usage.js
  webhooks.js
  notifications.js
  profile.js
  security.js
```

The client should standardize:

- Base URL.
- Headers.
- JSON parsing.
- Request IDs.
- Error handling.
- Authentication.
- Retry policy where appropriate.

---

# 71. Frontend State

Keep state minimal.

Recommended:

```text
currentUser
currentProject
navigationState
notifications
pageData
formState
```

Avoid building a heavy client-side state framework unless later scale requires it.

---

# 72. Project Switching

When project changes:

```text
Set active project
      ↓
Persist safe preference
      ↓
Refresh project-scoped data
      ↓
Update URL/context
```

Never reuse stale data from the previous project.

---

# 73. URL Design

Recommended examples:

```text
/dashboard

/projects
/projects/create

/projects/{project}/overview
/projects/{project}/settings
/projects/{project}/providers
/projects/{project}/templates
/projects/{project}/send
/projects/{project}/api
/projects/{project}/api-keys
/projects/{project}/logs
/projects/{project}/otp-logs
/projects/{project}/usage
/projects/{project}/webhooks

/account/profile
/account/security
/account/password
/account/sessions
/account/notifications
```

Exact route naming may follow the frontend router implementation while preserving screen identity.

---

# 74. Breadcrumbs

Examples:

```text
Projects / My SaaS
Projects / My SaaS / Templates
Projects / My SaaS / Templates / Welcome
Projects / My SaaS / API Keys
```

Mobile breadcrumbs should collapse intelligently.

---

# 75. Search

Global/project search may cover:

```text
Projects
Templates
Logs
Webhooks
API Keys
```

Search must respect project authorization.

---

# 76. Pagination

For large datasets:

```text
Server-side pagination
```

Use stable sorting.

Do not load thousands of logs into the browser at once.

---

# 77. Filtering

Filters should be represented in URL/query state where practical.

Example:

```text
?status=failed&provider=gmail&page=2
```

This improves:

- Sharing.
- Back/forward navigation.
- Refresh behavior.
- Debugging.

---

# 78. Performance

User Panel must:

- Lazy-load noncritical data.
- Avoid unnecessary API requests.
- Cache safe static metadata.
- Paginate logs.
- Debounce search.
- Avoid heavy animation.
- Optimize images/assets.
- Minimize JavaScript.

---

# 79. Dashboard Performance

Do not block the entire dashboard on one failing widget.

Example:

```text
Projects card → success
Usage card → success
Webhook health → error/retry
Recent logs → success
```

Widgets should degrade independently.

---

# 80. Network Failure Recovery

For safe GET requests:

```text
Retry
```

may be appropriate.

For state-changing requests:

```text
Do not blindly retry
```

unless idempotency is supported.

---

# 81. Unsaved Changes

Template editor and settings forms should detect unsaved changes.

Example:

```text
You have unsaved changes.
Leave page?
```

This must not interfere with deliberate submission/navigation.

---

# 82. Accessibility for Dynamic Content

Use accessible live regions for:

```text
Save success
Send result
Provider test result
Webhook test result
Validation errors
Rate limit errors
```

---

# 83. User Panel Security Boundary

The frontend is never trusted.

Backend must enforce:

```text
Authentication
Authorization
Project ownership/access
Scopes
CSRF for session endpoints
Validation
Rate limits
Security policy
```

---

# 84. Admin Separation

User Panel must never expose Admin Panel operations.

Admin routes and permissions are separate.

A normal user must not access:

```text
/admin/*
```

or administrative APIs.

---

# 85. Session Expiration UX

When session expires:

```text
API returns unauthorized
      ↓
Frontend detects
      ↓
Preserve safe navigation context
      ↓
Redirect to login
```

Do not expose session internals.

---

# 86. Rate-Limit UX

For HTTP 429:

```text
Too many requests.

Please wait and try again.
```

If `Retry-After` is provided, show an appropriate countdown or retry suggestion.

---

# 87. Provider Failure UX

Example:

```text
Gmail connection needs attention.

Last send failed because the provider rejected the request.

[Reconnect Gmail]
[View Logs]
```

Do not expose raw OAuth/provider secrets.

---

# 88. Webhook Failure UX

Example:

```text
Webhook endpoint is failing.

Last status: 503
Consecutive failures: 4

[Test Again]
[View Logs]
[Disable]
```

---

# 89. Security Alert UX

Security events should be visually clear.

Example:

```text
Security Alert

A project API key was revoked.
Time: ...
Project: ...
```

Never show the revoked secret.

---

# 90. User Onboarding

Recommended first-run sequence:

```text
Welcome
   ↓
Create Project
   ↓
Connect Provider
   ↓
Create Template
   ↓
Create API Key
   ↓
Send Test Email
   ↓
View API Integration
```

The onboarding state can be displayed on the dashboard.

---

# 91. Setup Progress

Example:

```text
Project Setup

✓ Project created
✓ Provider connected
○ Template created
○ API key created
○ Test email sent
```

Do not block advanced users from skipping steps.

---

# 92. Notification Center

Header bell should show:

```text
Unread count
```

Click opens:

```text
Recent notifications
View all
```

Notification data must be user-scoped.

---

# 93. Profile Avatar

If avatars are supported:

- Validate upload type.
- Restrict size.
- Sanitize filenames.
- Store outside executable paths.
- Prefer generated initials when no image exists.

---

# 94. User Preferences

Store only useful preferences:

```text
theme
timezone
language
sidebar state
last project
notification preferences
```

Preferences must not affect authorization.

---

# 95. Dark/Light Theme

The User Panel must support the locked theme system.

Use CSS variables.

Do not hardcode colors throughout components.

Theme preference can be:

```text
System
Light
Dark
```

if enabled by the global product design.

---

# 96. Mobile Navigation

Mobile menu should include:

```text
Dashboard
Projects
Current Project
Templates
API
Logs
Usage
Webhooks
Notifications
Account
```

Drawer must close after navigation.

Keyboard focus should remain accessible.

---

# 97. Touch Targets

Interactive controls should provide comfortable touch targets.

Avoid tiny icon-only controls without accessible labels.

---

# 98. User Panel Error Boundary

Unexpected frontend errors should show:

```text
Something went wrong.

Request ID: ...
[Retry]
```

Do not expose JavaScript stack traces to the user.

Development builds may log detailed errors separately.

---

# 99. API Request ID

Where available, show request ID in support/debug contexts.

Example:

```text
Request ID: req_01ABC...
```

Do not expose internal database IDs unnecessarily.

---

# 100. Audit Visibility

Users may see relevant project/account activity but not internal administrative audit data.

Examples visible:

```text
API key created
API key revoked
Provider connected
Password changed
Session revoked
```

Admin-only details remain in the Admin Panel.

---

# 101. User Panel Testing Matrix

Test:

```text
Desktop
Tablet
Mobile
Touch
Keyboard
Screen reader
Slow network
Offline/reconnect
Expired session
403
404
429
500
Provider failure
Empty state
Large dataset
Long project name
Long template
Validation errors
```

---

# 102. User Journey — First Email

```text
Register
 ↓
Verify email
 ↓
Login
 ↓
Dashboard
 ↓
Create Project
 ↓
Connect Gmail/SMTP
 ↓
Create Template
 ↓
Preview
 ↓
Create API Key
 ↓
Send Test Email
 ↓
Email Logs
```

---

# 103. User Journey — Static HTML

```text
Create Project
 ↓
Create restricted browser API key
 ↓
Configure allowed origin
 ↓
Create template
 ↓
Copy Fetch example
 ↓
Add JavaScript to website
 ↓
Browser
 ↓
Email API
 ↓
Provider
```

---

# 104. User Journey — Private Backend

```text
Create Project
 ↓
Create private API key
 ↓
Store key in server environment
 ↓
Backend sends request
 ↓
Email API
 ↓
Provider
```

Private keys must never be committed to source control.

---

# 105. User Journey — Webhook

```text
Create Webhook
 ↓
Enter HTTPS endpoint
 ↓
Select events
 ↓
Save
 ↓
Copy/receive secret
 ↓
Verify signatures
 ↓
Send Test Event
 ↓
Monitor Webhook Logs
```

---

# 106. Definition of Done

The User Panel is complete when:

- All 33 locked user screens are represented.
- Navigation is consistent.
- Project context is enforced.
- Project switching is safe.
- Providers can be managed.
- Gmail OAuth flow is integrated.
- SMTP configuration/testing works.
- Templates can be created, edited, previewed and published.
- Variables are visible and validated.
- Manual email/test email flows work.
- API integration documentation is available.
- API keys can be created/revoked/rotated.
- Secrets are handled securely.
- Logs are searchable/filterable/paginated.
- Usage statistics work.
- Webhooks can be managed and tested.
- Notifications work.
- Profile/security/session controls work.
- Responsive layouts work.
- Accessibility baseline is met.
- Loading/empty/error states exist.
- Backend authorization remains authoritative.
- No Admin functionality leaks into the User Panel.

---

# 107. Non-Negotiable Rules

1. User Panel never replaces backend authorization.
2. Project context must be explicit.
3. Cross-project data must never appear.
4. API key secrets are shown only according to one-time-display policy.
5. Provider secrets are never displayed casually.
6. Private API keys must never be exposed in browser code.
7. Browser keys must be restricted.
8. CORS is not authentication.
9. Destructive actions require confirmation.
10. Security-sensitive changes may require re-authentication.
11. Logs must never expose secrets.
12. OTP values must never appear in normal logs.
13. Admin functions remain isolated.
14. All project-scoped API requests must carry project authorization.
15. Frontend validation never replaces server validation.
16. Error messages must not expose stack traces.
17. Loading, empty and error states are mandatory.
18. Large datasets require pagination.
19. Mobile usability is mandatory.
20. Keyboard accessibility is mandatory.
21. Theme colors use the design system.
22. Icons follow the approved asset policy.
23. Templates must use the locked template engine.
24. Provider operations use the provider abstraction.
25. Email sends use the email engine.
26. Webhooks use the webhook architecture.
27. API keys use the API key architecture.
28. Session management uses the security architecture.
29. Project switching must clear stale project data.
30. No user-panel feature may bypass the locked architecture.

---

# 108. Final Architecture Summary

```text
                         USER
                          │
                          ▼
                 ┌─────────────────┐
                 │   USER PANEL    │
                 └────────┬────────┘
                          │
             ┌────────────┼────────────┐
             ▼            ▼            ▼
         ACCOUNT       PROJECTS     NOTIFICATIONS
                          │
                          ▼
                   PROJECT WORKSPACE
                          │
        ┌─────────┬───────┼────────┬─────────┐
        ▼         ▼       ▼        ▼         ▼
    Providers Templates  Send     API       Logs
                         Email   Keys
        │         │       │        │         │
        └─────────┴───────┴────────┴─────────┘
                          │
                          ▼
                    PHP REST API
                          │
                          ▼
                    EMAIL ENGINE
                          │
                          ▼
                 Gmail / SMTP / etc.
```

---

# 109. Final Lock

The User Panel architecture is now defined as the complete authenticated workspace for the Email API Platform.

Locked decisions:

- 33 user screens remain the official user-panel scope.
- Project workspace is the primary operational context.
- Account/security pages remain outside individual project context.
- Providers, templates, email sends, API keys, logs, usage and webhooks are project-scoped.
- Backend authorization is authoritative.
- Browser API keys are treated as exposed credentials.
- Private server API keys are never exposed to frontend JavaScript.
- Provider credentials and OAuth tokens remain protected.
- Responsive, accessible and performant UI is mandatory.
- User Panel never exposes Admin functionality.
- All screens use the global design system and approved assets.
- The User Panel integrates with the locked backend, email engine, template engine, provider, project/API-key/webhook and security architectures.
- No structural change is permitted without an explicit architecture revision.

**STATUS: FINAL / LOCKED**

**Next document:** `18-ADMIN-PANEL.md`
