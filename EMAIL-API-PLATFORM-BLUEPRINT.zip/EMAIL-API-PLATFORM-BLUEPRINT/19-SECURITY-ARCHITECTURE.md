# 19 — SECURITY ARCHITECTURE

**Project:** Email API Platform  
**Document:** Complete Security Architecture, Threat Model, Authentication, Authorization, Secrets, API, Email, Webhook, Admin, Database, Session, Logging, Monitoring & Incident Response  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Related:** `03-SYSTEM-ARCHITECTURE.md`, `10-BACKEND-PHP-ARCHITECTURE.md`, `12-AUTHENTICATION-AND-OTP.md`, `13-EMAIL-ENGINE.md`, `14-EMAIL-PROVIDERS.md`, `16-PROJECTS-API-KEYS-WEBHOOKS.md`, `17-USER-PANEL.md`, `18-ADMIN-PANEL.md`

---

## 1. Purpose

This document defines the complete security architecture for the Email API Platform.

Security is a cross-cutting system concern covering:

- Users
- Sessions
- Authentication
- Email verification
- OTP
- Password recovery
- Projects
- API keys
- Providers
- Gmail OAuth
- SMTP credentials
- Email sending
- Templates
- Webhooks
- REST APIs
- Admin operations
- Database access
- Logging
- Rate limiting
- IP controls
- Browser security
- CORS
- CSRF
- XSS
- SQL injection
- SSRF
- Sensitive-data protection
- Audit logging
- Incident response
- Deployment

The security model is FINAL / LOCKED and must remain consistent across the entire platform.

---

# 2. Security Principles

The platform follows these core principles:

```text
Defense in Depth
Least Privilege
Zero Trust Between Boundaries
Secure by Default
Fail Closed
Data Minimization
Explicit Authorization
Secret Isolation
Project Isolation
Auditability
Input Validation
Output Safety
Rate Limiting
Safe Error Handling
Secure Recovery
Operational Observability
```

---

# 3. Locked Security Features

The platform includes these 25 core security features:

1. Password Hashing
2. Secure Sessions
3. CSRF Protection
4. XSS Protection
5. SQL Injection Protection
6. Prepared Statements
7. API Key Authentication
8. API Key Hashing
9. OAuth 2.0
10. Encrypted OAuth Tokens
11. Encrypted SMTP Credentials
12. Rate Limiting
13. Login Attempt Protection
14. OTP Attempt Limiting
15. OTP Expiry
16. IP Blocking
17. Suspicious Activity Detection
18. Session Revocation
19. Audit Logs
20. Admin Activity Logs
21. Secure Headers
22. HTTPS Enforcement
23. CORS Control
24. Input Validation
25. Output Sanitization

These are mandatory baseline controls.

---

# 4. Security Boundary Model

```text
Internet
   │
   ▼
HTTPS / TLS
   │
   ▼
Web Server
   │
   ▼
Public API / Web Entry
   │
   ▼
Security Middleware
   ├── Authentication
   ├── Authorization
   ├── Rate Limit
   ├── CSRF
   ├── CORS
   ├── Validation
   └── Request Context
   │
   ▼
Application Services
   │
   ├── User/Auth
   ├── Project
   ├── Provider
   ├── Template
   ├── Email
   ├── API Key
   ├── Webhook
   └── Admin
   │
   ▼
Repositories / PDO
   │
   ▼
MySQL
```

External services are treated as untrusted boundaries:

```text
Google
SMTP servers
Brevo
Mailtrap
Webhook destinations
Browser clients
User-provided URLs
User-provided HTML
```

---

# 5. Threat Model

Primary threats include:

```text
Credential theft
Session theft
Account takeover
Brute-force login
OTP brute force
API key leakage
Cross-project access
Privilege escalation
Admin takeover
SQL injection
XSS
CSRF
SSRF
Webhook abuse
Email header injection
Malicious HTML
Provider credential exposure
Sensitive log leakage
Replay attacks
Rate-limit abuse
Spam/abuse through email API
Data enumeration
IDOR
Configuration abuse
Supply-chain vulnerabilities
Server compromise
```

---

# 6. Trust Zones

The platform uses logical trust zones:

```text
ZONE A — Public Internet
ZONE B — Browser/User Client
ZONE C — API Gateway / Web Layer
ZONE D — Application Services
ZONE E — Database
ZONE F — Secret Storage
ZONE G — External Providers
ZONE H — Admin Operations
```

Every crossing must have explicit controls.

---

# 7. Authentication Model

User authentication supports:

```text
Registration
Email Verification
Login
Password Change
Password Reset
Account Recovery
Secure Sessions
```

Admin authentication is separately privileged.

API authentication uses API keys.

These authentication mechanisms must not be mixed incorrectly.

---

# 8. Password Security

Passwords must:

- Never be stored plaintext.
- Never be logged.
- Never be returned by APIs.
- Be hashed using PHP's password hashing facilities.
- Use a modern password hashing algorithm supported by the deployment.
- Be rehashed when policy requires.
- Be validated against a reasonable strength policy.

Example:

```php
password_hash($password, PASSWORD_DEFAULT);
```

Verification:

```php
password_verify($password, $hash);
```

Do not implement custom password hashing.

---

# 9. Password Policy

Minimum policy should include:

```text
Minimum length
Maximum safe length
Reject empty values
Reject known-invalid input
Confirm password during sensitive changes
```

Do not rely exclusively on arbitrary complexity rules that harm usability.

Credential stuffing protection is handled through rate limiting and login monitoring.

---

# 10. Password Reset

Flow:

```text
Request Reset
      ↓
Generic Response
      ↓
Secure Token
      ↓
Short Expiry
      ↓
Password Reset
      ↓
Invalidate Token
      ↓
Update Password
      ↓
Apply Session Policy
      ↓
Audit Event
```

The request endpoint must not reveal whether an account exists.

---

# 11. Email Verification

Flow:

```text
Registration
   ↓
Generate Verification Token
   ↓
Store Safe Token Representation
   ↓
Send Verification Email
   ↓
User Clicks Link
   ↓
Validate Token
   ↓
Expire/Consume Token
   ↓
Mark Email Verified
```

Tokens must expire and be single-use.

---

# 12. OTP Security

OTP requirements:

- Cryptographically secure generation.
- Short expiration.
- Attempt limit.
- Resend cooldown.
- Purpose binding.
- User/project/context binding where applicable.
- Safe storage.
- No plaintext logging.
- Single successful consumption.

Example purposes:

```text
Email Verification
Login Verification
Password Recovery
Account Recovery
Sensitive Action
```

---

# 13. OTP Storage

Prefer storing a secure representation of the OTP rather than exposing the raw value in persistent storage.

Store:

```text
OTP ID
Purpose
User ID
Project ID where applicable
Hash/secure representation
Created At
Expires At
Attempts
Consumed At
```

---

# 14. OTP Abuse Protection

Protect against:

```text
Brute force
Resend flooding
Destination flooding
Enumeration
Replay
Parallel verification
```

Controls:

```text
Per-user limit
Per-IP limit
Per-destination limit
Purpose-specific limit
Cooldown
Expiration
Attempt counter
```

---

# 15. Session Security

Sessions must use:

```text
Secure cookies
HttpOnly
SameSite
HTTPS
Session ID regeneration
Server-side expiration
Idle timeout where appropriate
Revocation
```

Never place authentication session IDs in URLs.

---

# 16. Session Fixation Protection

After successful authentication:

```text
Regenerate session ID
```

When privilege changes occur, regenerate or invalidate sessions according to policy.

---

# 17. Session Revocation

Sessions can be revoked:

```text
User logs out
User changes password
User revokes session
Admin disables account
Security incident
```

Revocation must be server-enforced.

---

# 18. Active Session Data

Store safe metadata:

```text
Session ID hash/reference
User ID
Created At
Last Activity
IP
User Agent
Revoked At
```

Do not store unnecessary session secrets.

---

# 19. API Key Security

API keys authenticate project/API requests.

Architecture:

```text
Client
  ↓
API Key
  ↓
API Authentication
  ↓
Project Resolution
  ↓
Scope Check
  ↓
Rate Limit
  ↓
Endpoint Authorization
```

---

# 20. API Key Generation

Generate keys using a cryptographically secure random source.

Example conceptual structure:

```text
prefix + random secret
```

The secret must have sufficient entropy.

Never use:

```text
mt_rand()
rand()
predictable timestamps
user IDs
project IDs
```

for secret generation.

---

# 21. API Key Storage

Store:

```text
Key ID
Prefix
Hash
Project ID
Name
Scopes
Environment
Status
Created At
Expires At
Last Used
```

Store the secret only as a secure hash.

---

# 22. API Key Display

At creation:

```text
Show secret once
```

After leaving the creation flow:

```text
Secret cannot be recovered
```

The Admin Panel also cannot recover the secret.

Rotation creates a new secret.

---

# 23. API Key Scopes

Example:

```text
email:send
template:read
template:write
project:read
logs:read
usage:read
webhook:manage
```

Default keys should receive the minimum necessary scope.

---

# 24. Browser API Keys

Browser keys are inherently exposed.

They must be treated as restricted credentials.

Controls:

```text
Minimal scopes
Allowed origins
Rate limits
Environment restrictions
Send-only permissions where appropriate
```

Do not describe a browser key as a private secret.

---

# 25. Private Server API Keys

Private API keys:

- Must remain server-side.
- Must be stored in environment/secret management.
- Must never be committed to Git.
- Must never be included in frontend bundles.
- Must never be placed in public HTML.
- Must not be logged.

---

# 26. Project Isolation

Projects are a primary authorization boundary.

Every project-scoped operation must verify:

```text
Authenticated principal
      +
Project membership/ownership
      +
Required permission/scope
```

Never trust a project ID supplied by the client.

---

# 27. IDOR Protection

For every resource:

```text
Load resource
      ↓
Verify ownership/access
      ↓
Verify project relationship
      ↓
Verify role/scope
      ↓
Operate
```

Do not query resources only by:

```text
WHERE id = ?
```

when project/user authorization is also required.

---

# 28. Authorization Policy

Authorization should be explicit.

Example:

```text
User
  ├── Project A → allowed
  └── Project B → denied

API Key A
  ├── Project A → allowed
  └── Project B → denied
```

Admin permissions are separate.

---

# 29. Privilege Escalation Protection

Never allow users to modify:

```text
role
admin status
project ownership
security permissions
system settings
```

through ordinary user-controlled fields.

Server-side allowlists are mandatory.

---

# 30. Admin Security

Admin accounts require stronger controls.

Mandatory:

```text
Separate admin authorization
Least privilege
Audit logging
Session revocation
Rate limiting
Strong authentication
Secure cookies
HTTPS
```

Recommended/available according to deployment policy:

```text
MFA/OTP
Re-authentication
Admin IP restrictions
Security alerts
```

---

# 31. Admin Role Model

Recommended permissions:

```text
users.read
users.write
projects.read
projects.write
providers.read
providers.write
logs.read
security.read
security.write
settings.read
settings.write
admins.read
admins.write
```

A read-only administrator must not receive write permissions.

---

# 32. CSRF Protection

Session-authenticated browser state-changing requests require CSRF protection.

Protect:

```text
POST
PUT
PATCH
DELETE
```

where browser session authentication is used.

API key authenticated cross-origin requests use the API authentication model rather than relying on CSRF tokens.

---

# 33. CSRF Token Rules

Tokens must be:

- Unpredictable.
- Bound to the session/context.
- Validated server-side.
- Rotated according to security policy.
- Rejected when invalid or missing.

Do not place CSRF tokens in URLs.

---

# 34. CORS

CORS controls browser-origin access.

It does not authenticate users.

Configuration should:

```text
Allow only intended origins
Avoid wildcard credentials
Restrict methods
Restrict headers
Handle preflight safely
```

Browser API keys still require authentication/authorization.

---

# 35. XSS Protection

Protect against:

```text
Stored XSS
Reflected XSS
DOM XSS
Template-related HTML injection
```

Controls:

```text
Output encoding
Context-aware escaping
Sanitization where HTML is intentionally accepted
Content Security Policy
Safe DOM APIs
```

Never inject untrusted strings using unsafe HTML operations without sanitization.

---

# 36. User HTML Templates

HTML email templates are user-provided content.

The system must distinguish:

```text
Email HTML content
Application UI HTML
```

Email HTML should not automatically be treated as safe application HTML.

Template preview must be isolated/sandboxed.

---

# 37. Content Security Policy

Use a restrictive CSP appropriate to the application.

Example conceptual policy:

```text
default-src 'self'
script-src 'self'
style-src 'self' 'unsafe-inline' where required by implementation
img-src 'self' data: https:
connect-src 'self' https:
font-src 'self'
frame-ancestors 'none'
base-uri 'self'
form-action 'self'
```

The final policy must be tested against the actual frontend.

Avoid unnecessary `unsafe-eval`.

---

# 38. Clickjacking Protection

Use:

```text
Content-Security-Policy: frame-ancestors 'none'
```

or an equivalent policy where embedding is not required.

---

# 39. Secure HTTP Headers

Recommended baseline:

```text
Strict-Transport-Security
Content-Security-Policy
X-Content-Type-Options: nosniff
Referrer-Policy
Permissions-Policy
```

Avoid legacy headers where modern CSP replaces them.

---

# 40. HTTPS Enforcement

Production traffic must use HTTPS.

HTTP should redirect to HTTPS where appropriate.

Secure cookies require HTTPS.

Do not send:

```text
Passwords
API keys
OAuth tokens
SMTP credentials
Session cookies
```

over plaintext HTTP.

---

# 41. TLS

Use modern TLS configurations supported by the deployment.

Avoid obsolete protocols and weak cipher configurations.

Certificate expiration must be monitored.

---

# 42. SQL Injection Protection

All SQL must use parameterized queries.

Use PDO prepared statements.

Never concatenate untrusted input into SQL.

Bad:

```php
$sql = "SELECT * FROM users WHERE email = '$email'";
```

Good:

```php
$stmt = $pdo->prepare(
    'SELECT * FROM users WHERE email = :email'
);
$stmt->execute(['email' => $email]);
```

---

# 43. Dynamic SQL

When dynamic sorting/filtering is required:

```text
Use allowlists
```

Never insert arbitrary column names or SQL fragments from user input.

---

# 44. Input Validation

Validate all input at the application boundary.

Categories:

```text
Email
URL
UUID/ID
Slug
String length
Integer range
Enum
Boolean
Date/time
JSON
HTML
API scope
Provider type
```

Validation must happen server-side.

---

# 45. Output Sanitization

API output should be intentionally serialized.

Do not return internal objects directly.

Exclude:

```text
password_hash
API key hash
OAuth tokens
SMTP password
internal encryption material
private configuration
```

---

# 46. Mass Assignment Protection

Never hydrate privileged models directly from arbitrary request JSON.

Use explicit DTO/input mapping.

Example:

```text
Allowed:
name
description

Rejected:
is_admin
role
owner_id
security_policy
```

unless the authenticated principal explicitly has permission to modify those fields.

---

# 47. Email Header Injection

Validate:

```text
From
To
CC
BCC
Reply-To
Subject
```

Reject CR/LF injection in header values.

Never allow untrusted input to create arbitrary mail headers.

---

# 48. Email Abuse Protection

The platform is an email-sending service and must defend against abuse.

Controls:

```text
Per-user rate limits
Per-project limits
Per-key limits
Provider quotas
Recipient validation
Suspicious activity detection
Account suspension
Project suspension
Logging
```

---

# 49. Spam/Abuse Detection

Monitor signals such as:

```text
Sudden volume spike
High failure rate
Many unique recipients
Repeated invalid recipients
Unusual API traffic
Rapid project creation
Credential abuse
Provider rejection spikes
```

Signals should trigger review/rate limiting according to policy.

---

# 50. Rate Limiting Architecture

Apply limits at multiple layers:

```text
IP
User
Project
API Key
Endpoint
Provider
OTP Destination
Authentication
Webhook
```

Use appropriate windows and burst controls.

---

# 51. Rate Limit Response

Return:

```text
HTTP 429
```

with a safe structured error.

Where appropriate:

```text
Retry-After
```

may be included.

Do not reveal internal rate-limit implementation details.

---

# 52. Login Attempt Protection

Track:

```text
User/email
IP
Timestamp
Result
Reason
User agent
```

Controls:

```text
Rate limiting
Progressive delay
Temporary lockout where appropriate
IP reputation/blocking
Suspicious activity detection
```

Avoid permanent account lockout based solely on attacker-controlled requests.

---

# 53. IP Blocking

Blocked IPs may be applied at:

```text
Application layer
Reverse proxy/WAF layer
```

depending on deployment.

Application-level blocking must be efficient and indexed.

---

# 54. SSRF Protection

SSRF is especially important for:

```text
Webhook URLs
Remote imports
URL previews
External resource fetches
Provider callbacks
```

User-controlled URLs must not be fetched blindly.

---

# 55. Webhook SSRF Controls

Webhook destination validation should consider:

```text
HTTPS requirement
Private IP ranges
Loopback
Link-local addresses
Cloud metadata endpoints
Reserved networks
DNS rebinding
Redirects
Port restrictions
```

The exact implementation must protect against both hostname and resolved-IP abuse.

---

# 56. Webhook Requests

Webhook delivery should:

```text
Use HTTPS
Sign payload with HMAC-SHA256
Use timeout
Limit response size
Control redirects
Record delivery result
Retry safely
```

Webhook failures must not fail the primary email operation.

---

# 57. Webhook Replay Protection

Include:

```text
Event ID
Delivery ID
Timestamp
Signature
```

Recipients should verify the timestamp and reject stale/replayed requests according to their policy.

---

# 58. Webhook Secret Security

Webhook secrets must:

- Be generated securely.
- Be encrypted/protected if recovery is required.
- Never appear in logs.
- Be rotatable.
- Support secret versioning/transition where needed.

---

# 59. Webhook Signature

Conceptual:

```text
signature = HMAC-SHA256(secret, timestamp + "." + raw_body)
```

Use the exact locked implementation from the webhook architecture.

Consumers should use constant-time comparison.

---

# 60. OAuth 2.0 Security

Gmail integration uses OAuth 2.0.

Protect:

```text
Client credentials
Authorization state
Authorization code
Access token
Refresh token
Redirect URI
```

---

# 61. OAuth State Parameter

OAuth authorization must use an unpredictable state value.

Flow:

```text
Generate state
 ↓
Store server-side/session-bound state
 ↓
Redirect to provider
 ↓
Receive callback
 ↓
Validate state
 ↓
Exchange authorization code
```

Reject invalid/missing state.

---

# 62. OAuth Token Storage

OAuth tokens must be encrypted at rest.

Encryption keys must be stored separately from the encrypted database values.

Never:

```text
Log tokens
Return tokens to browser
Store tokens in HTML
Commit tokens to Git
```

---

# 63. OAuth Token Lifecycle

Handle:

```text
Token creation
Token refresh
Token expiration
Revocation
Provider errors
Reconnect
Disconnect
```

Provider state must reflect token health.

---

# 64. SMTP Credential Security

SMTP passwords/credentials must be encrypted at rest.

Use a dedicated encryption service.

Never store SMTP passwords in plaintext.

Never log them.

Never return them through generic provider APIs.

---

# 65. Encryption at Rest

Encrypt secrets that must be recovered:

```text
OAuth refresh tokens
OAuth access tokens where retained
SMTP passwords
Webhook secrets where recoverability is required
Other provider credentials
```

Use authenticated encryption where supported by the implementation.

---

# 66. Encryption Key Management

Application encryption keys must not be stored in the same database rows as the encrypted secrets.

Recommended hierarchy:

```text
Environment/Secret Store
        ↓
Application Encryption Key
        ↓
Encryption Service
        ↓
Encrypted Database Secret
```

Key rotation must be planned.

---

# 67. Key Rotation

Support rotation for:

```text
Application encryption key
Webhook secret
API keys
OAuth credentials when provider requires
```

Rotation must not accidentally destroy still-valid credentials.

---

# 68. Secret Redaction

Central logging must redact:

```text
Authorization
Cookie
Set-Cookie
API-Key
X-API-Key
OAuth tokens
SMTP passwords
Webhook secrets
OTP values
Passwords
```

Redaction must occur before logs are persisted.

---

# 69. Logging Security

Logs must not become a secret-exfiltration channel.

Never log:

```text
Full passwords
Full API keys
Tokens
SMTP credentials
OTP
Session cookies
Encryption keys
```

---

# 70. Audit Logging

Audit events must record safe metadata:

```text
Actor
Action
Target
Timestamp
IP
Request ID
Result
```

Examples:

```text
USER_SUSPENDED
PROJECT_CREATED
API_KEY_REVOKED
PROVIDER_CONNECTED
ADMIN_LOGIN
SECURITY_SETTING_CHANGED
```

---

# 71. Audit Log Integrity

Audit logs should be append-oriented.

Normal users cannot modify them.

Administrators should not have casual UI access to edit historical audit records.

Retention/deletion must follow explicit policy.

---

# 72. Error Handling Security

Public errors must be safe.

Do not return:

```text
Stack traces
SQL statements
Filesystem paths
Environment variables
Encryption details
Provider credentials
Internal class names
```

Use stable error codes.

Example:

```json
{
  "success": false,
  "error": {
    "code": "AUTH_INVALID",
    "message": "Authentication failed."
  }
}
```

---

# 73. Error Enumeration Protection

Avoid responses that reveal:

```text
Whether an email exists
Whether a user exists
Whether a provider credential is valid
Whether an API key prefix is valid
```

where such disclosure creates security risk.

---

# 74. Request IDs

Every API request should receive a request ID.

Use it for:

```text
Application logs
Audit logs
Provider diagnostics
User support
Error correlation
```

Never use request IDs as secrets.

---

# 75. Idempotency

Use idempotency for operations where duplicate execution is dangerous.

Examples:

```text
Email send
Webhook delivery
Sensitive mutations
```

The email engine and API specification define exact supported semantics.

---

# 76. Replay Protection

Protect sensitive operations using:

```text
Expiration
One-time tokens
Idempotency keys
State parameters
Nonce/timestamps
Session validation
```

---

# 77. Database Security

Database must use:

```text
Least-privilege DB user
Strong password/secret
TLS where appropriate
Private network access where possible
No public exposure
Prepared statements
Backups
Monitoring
```

Do not use the database root account from the web application.

---

# 78. Database User Permissions

Application DB user should receive only required privileges.

Separate migration/admin credentials from runtime credentials where practical.

---

# 79. Database Backups

Backups must be:

```text
Encrypted
Access-controlled
Monitored
Tested for restoration
Retained according to policy
```

Backups contain sensitive information and must be treated as production secrets.

---

# 80. Database Encryption

Where supported by the deployment, use encryption at rest for database/storage.

Application-level encryption remains mandatory for recoverable secrets.

---

# 81. File Upload Security

If the platform supports uploads such as avatars/attachments:

```text
Validate type
Validate size
Generate safe filenames
Store outside executable paths
Prevent path traversal
Scan where appropriate
Serve safely
```

Never trust file extensions.

---

# 82. Path Traversal

Reject/normalize unsafe paths.

Never allow user input to directly determine filesystem paths.

Avoid:

```text
../
absolute paths
null-byte tricks
```

for user-controlled resource selection.

---

# 83. Attachment Security

Email attachments must be subject to:

```text
Size limits
Count limits
MIME validation
Filename normalization
Memory/resource limits
Provider limits
```

Do not allow unrestricted upload sizes.

---

# 84. Template Security

Template processing must enforce:

```text
Project isolation
Variable validation
HTML handling
Size limits
Versioning
Safe preview
No arbitrary server-side code execution
```

Templates are data, not PHP programs.

---

# 85. Server-Side Code Execution Protection

Never evaluate user-provided:

```text
PHP
JavaScript on server
Shell commands
SQL
Template code with arbitrary execution
```

The template engine must use a controlled variable renderer.

---

# 86. Command Injection

Do not pass user-controlled strings to shell commands.

If an external command is absolutely required:

```text
Allowlist executable
Validate arguments
Avoid shell interpretation
Use safe process APIs
Limit environment
Timeout
```

---

# 87. Deserialization Security

Avoid unsafe deserialization of untrusted data.

Prefer:

```text
JSON
Validated DTOs
Explicit schemas
```

Do not unserialize arbitrary user input.

---

# 88. Dependency Security

Composer dependencies must be:

```text
Pinned/controlled
Reviewed
Updated
Scanned
Removed when unused
```

Run dependency security checks regularly.

---

# 89. Supply Chain Security

Protect:

```text
composer.lock
package/build assets where applicable
deployment scripts
CI credentials
repository secrets
```

Never commit:

```text
.env
API keys
OAuth credentials
SMTP credentials
private encryption keys
```

---

# 90. Environment Security

Separate:

```text
Development
Testing
Staging
Production
```

Production secrets must not be copied into development environments.

---

# 91. Environment Variables

Sensitive configuration may be provided through environment/secret management:

```text
DB credentials
APP encryption key
OAuth client secrets
SMTP defaults
API signing/configuration secrets
```

Do not expose environment variables through diagnostic pages.

---

# 92. Debug Mode

Production:

```text
APP_DEBUG=false
```

Production must not expose verbose exception output.

---

# 93. PHP Security

Use a supported PHP 8.3+ deployment.

Disable unnecessary PHP capabilities where operationally appropriate.

Keep:

```text
display_errors=Off
log_errors=On
```

in production.

---

# 94. Web Server Security

Public document root should expose only intended public files.

Application source, configuration and secrets must remain outside the public web root where possible.

---

# 95. Directory Exposure

Disable directory listing unless explicitly required.

Do not expose:

```text
.git
.env
vendor internals
logs
backups
config
private uploads
```

---

# 96. File Permissions

Use least privilege.

Typical principle:

```text
Application files → readable by runtime
Writable directories → only where required
Secrets → restricted
Logs → restricted
Backups → restricted
```

Avoid world-writable application directories.

---

# 97. Cron Security

Cron/worker jobs must:

- Run under a restricted service account.
- Use safe configuration.
- Avoid logging secrets.
- Have bounded execution.
- Be monitored.
- Be idempotent where possible.

---

# 98. Queue/Worker Security

If DB/cron queue compatibility is used initially:

```text
Worker
  ↓
Authenticated application services
  ↓
Same authorization/data policies
```

Do not create a privileged worker path that bypasses normal validation.

---

# 99. Provider Security

Provider adapters must:

```text
Receive only required data
Protect credentials
Normalize errors
Use timeouts
Validate responses
Avoid leaking provider secrets
```

Provider failures must not expose credentials to clients.

---

# 100. Email Engine Security

Email engine must enforce:

```text
Project authorization
Provider authorization
Recipient validation
Header validation
Template security
Attachment limits
Rate limits
Idempotency
Logging redaction
```

---

# 101. Email Content Privacy

Logs should avoid storing complete email bodies by default unless explicitly required by the product policy.

When content is stored:

```text
Limit retention
Restrict access
Protect sensitive content
Document privacy impact
```

---

# 102. Personal Data Minimization

Store only what is required.

Examples:

```text
Email address → required for delivery/account
IP → security/audit purpose
User agent → security/diagnostics
Email body → only when product requires
```

---

# 103. Data Retention

Define retention for:

```text
Email Logs
OTP Logs
API Logs
Webhook Logs
Security Logs
Audit Logs
Sessions
Notifications
```

Retention settings must be explicit and auditable.

---

# 104. Account Deletion

Account deletion must consider:

```text
Projects
Providers
Templates
API keys
Sessions
Webhooks
Logs
Notifications
Audit records
```

Security/audit records may require separate retention according to policy.

---

# 105. Project Deletion

Project deletion must:

```text
Revoke project API keys
Disable provider use
Disable webhooks
Prevent new sends
Handle templates/logs according to retention policy
Invalidate project access
Create audit event
```

---

# 106. Provider Disconnection

Disconnecting a provider must:

```text
Stop future use
Protect/delete credentials according to policy
Update provider state
Record audit event
```

Do not silently continue sending through a disconnected provider.

---

# 107. API Abuse Detection

Monitor:

```text
Request spikes
Authentication failures
Repeated 4xx/5xx
Unusual endpoint patterns
Recipient anomalies
Provider rejection
Key misuse
Cross-project probing
```

---

# 108. Suspicious Activity

Potential signals:

```text
Rapid login failures
Impossible/abnormal session behavior
Many project enumeration attempts
API key misuse
Unexpected volume
Multiple failed provider connections
Webhook abuse
```

Response can include:

```text
Rate limit
Require re-authentication
Revoke session
Revoke key
Block IP
Suspend project
Escalate to admin
```

Actions should be risk-based.

---

# 109. Security Event Severity

Recommended:

```text
CRITICAL
HIGH
MEDIUM
LOW
INFO
```

Examples:

```text
CRITICAL → confirmed admin compromise
HIGH → suspicious API key activity
MEDIUM → repeated failed login
LOW → single invalid request
INFO → successful security action
```

---

# 110. Incident Response

Basic workflow:

```text
Detect
  ↓
Classify
  ↓
Contain
  ↓
Investigate
  ↓
Eradicate
  ↓
Recover
  ↓
Review
```

---

# 111. Incident Containment

Possible actions:

```text
Revoke API key
Revoke sessions
Disconnect provider
Suspend project
Suspend user
Block IP
Disable webhook
Enable maintenance mode
```

Only authorized administrators may perform these actions.

---

# 112. Credential Compromise

If an API key is compromised:

```text
Revoke key
Create replacement
Review usage
Review logs
Check suspicious destinations
Notify user if policy requires
Audit event
```

If provider credentials are compromised:

```text
Disconnect/revoke
Rotate credentials
Review email activity
Restore provider safely
```

---

# 113. Admin Compromise

Potential response:

```text
Disable compromised admin
Revoke sessions
Rotate affected credentials
Review audit logs
Review security events
Check other admin accounts
```

High-risk administrative recovery should be performed out-of-band where necessary.

---

# 114. Security Monitoring

Monitor:

```text
Authentication
API traffic
Email volume
Provider errors
Webhook failures
Rate limits
Security events
Admin actions
Database health
Storage
Cron/worker health
```

---

# 115. Alerting

Alerts may trigger on:

```text
High failed-login rate
Sudden email spike
Provider outage
Repeated webhook failure
Database failure
Storage exhaustion
Admin anomaly
Security threshold
```

Alerts must avoid including secrets.

---

# 116. Health Checks

Internal health checks may verify:

```text
Application
Database
Storage
Email engine
Provider adapters
Cron/worker
```

Public health endpoints should reveal only safe information.

---

# 117. Security Testing

Required testing categories:

```text
Authentication
Authorization
Session
CSRF
XSS
SQL Injection
IDOR
API Keys
OAuth
SMTP credential handling
OTP
Rate limiting
SSRF
Webhook signatures
File uploads
Template rendering
Admin permissions
Audit logging
Error handling
```

---

# 118. Automated Security Tests

Recommended PHPUnit coverage:

```text
Password hashing
Login policy
Session revocation
Project isolation
API key hashing
Scope authorization
OTP expiration
OTP attempt limits
CSRF validation
Webhook signature
SSRF URL validation
Admin permission checks
Sensitive field redaction
```

---

# 119. Static Analysis

Recommended:

```text
PHPStan
PHPUnit
Composer audit/security checks
Linting
```

Use CI to prevent known security regressions.

---

# 120. Manual Security Review

Before production:

```text
Review public endpoints
Review auth flows
Review admin routes
Review secrets
Review headers
Review CORS
Review database permissions
Review file permissions
Review backups
Review provider credentials
Review logs
```

---

# 121. Security Headers Test

Verify:

```text
HSTS
CSP
X-Content-Type-Options
Referrer-Policy
Permissions-Policy
Frame protection
Secure cookies
```

---

# 122. Browser Security

Cookies should use:

```text
Secure
HttpOnly
SameSite
```

where applicable.

Do not store long-lived private authentication secrets in insecure browser storage.

---

# 123. Local Storage Rules

Avoid storing:

```text
Private API keys
OAuth tokens
Session secrets
SMTP credentials
```

in localStorage/sessionStorage.

Safe UI preferences may be stored if appropriate.

---

# 124. API Response Security

Use consistent response envelopes.

Example:

```json
{
  "success": true,
  "data": {},
  "meta": {
    "request_id": "req_..."
  }
}
```

Errors should be normalized.

---

# 125. Authentication Error Responses

Prefer generic responses where enumeration is possible.

Example:

```text
Invalid credentials.
```

rather than:

```text
User exists but password is wrong.
```

---

# 126. API Key Authentication Errors

Use safe errors such as:

```text
AUTH_INVALID
AUTH_REVOKED
AUTH_EXPIRED
FORBIDDEN
RATE_LIMITED
```

Do not reveal secret validation internals.

---

# 127. Request Size Limits

Limit:

```text
JSON body
HTML template size
Attachments
Webhook payloads
File uploads
Query lengths
```

Limits must protect memory and CPU.

---

# 128. Timeout Security

Set bounded timeouts for:

```text
Database operations where supported
Provider connections
SMTP
HTTP clients
Webhook delivery
OAuth requests
Workers
```

Never allow unbounded external requests.

---

# 129. Resource Exhaustion Protection

Protect against:

```text
Large request bodies
Huge templates
Many recipients
Many attachments
Regex abuse
Repeated preview rendering
Expensive analytics queries
Webhook response abuse
```

---

# 130. Regex Safety

Avoid catastrophic regular expressions.

For user-controlled text:

```text
Use bounded patterns
Limit input length
Prefer simple parsers
```

---

# 131. Template Variable Security

Variables must be:

```text
Explicitly defined
Validated
Typed where supported
Bounded in size
Escaped according to context
```

Do not allow variables to execute code.

---

# 132. URL Validation

Validate URLs using:

```text
Allowed scheme
Host
Port
Format
DNS/IP policy
```

For server-side fetching, also apply SSRF controls.

---

# 133. Redirect Security

Do not blindly follow external redirects.

For webhooks and external requests:

```text
Limit redirects
Revalidate destination
Block internal targets
```

---

# 134. Open Redirect Protection

User-controlled redirect destinations must be allowlisted or constrained.

Authentication/recovery flows must never allow arbitrary post-login redirects.

---

# 135. Enumeration Protection

Protect enumeration of:

```text
Users
Projects
API keys
Providers
Templates
Email addresses
OTP destinations
```

Use generic responses and authorization checks.

---

# 136. Brute Force Protection

Apply to:

```text
Login
Password reset
OTP verification
API authentication
Admin login
Sensitive actions
```

Use layered rate limits.

---

# 137. Recovery Security

Account recovery must require sufficient proof of ownership.

Never allow recovery based only on publicly discoverable data.

---

# 138. Email Account Security

Changing account email must require verification.

Changing security-critical information may require re-authentication.

---

# 139. Notification Security

Security notifications must not include:

```text
Passwords
API secrets
OAuth tokens
SMTP passwords
OTP values
```

---

# 140. Admin Notification Security

Admin alerts must also follow data minimization.

Security events should include enough context to investigate without exposing secrets.

---

# 141. Logging Privacy

Logs should use:

```text
Masking
Redaction
Data minimization
Retention controls
Access controls
```

Sensitive logs should have stricter permissions.

---

# 142. Database Query Authorization

Authorization must occur before returning records.

Preferred:

```text
repository query includes authorized scope
```

rather than:

```text
fetch everything
filter in frontend
```

---

# 143. Multi-Tenant Security

Project isolation must be enforced at every layer:

```text
Controller
Service
Policy
Repository
Database query
Log query
Cache
Webhook
Provider
```

Never rely on one layer alone.

---

# 144. Cache Security

Cache keys must include appropriate scope.

Bad:

```text
template:{id}
```

Better:

```text
project:{project_id}:template:{id}
```

Sensitive cached data must have controlled lifetime.

---

# 145. Cache Invalidation

When changing:

```text
Project
Provider
API Key
Template
Permissions
Security settings
```

invalidate affected cache entries.

---

# 146. Queue Security

Queued jobs must contain only the minimum required identifiers/data.

Do not place raw secrets into queue payloads.

Workers should re-load sensitive data securely.

---

# 147. Background Job Authorization

Workers operate on trusted internal jobs but must still verify:

```text
Resource exists
Resource state is valid
Operation is allowed
```

Do not create unrestricted "god mode" worker methods.

---

# 148. Webhook Worker Security

Webhook workers must:

```text
Use stored protected secrets
Validate destination policy
Sign payload
Apply timeout
Apply retry policy
Record delivery
```

---

# 149. Email Worker Security

Email workers must:

```text
Re-check project status
Resolve provider safely
Load secrets through encryption service
Use provider adapter
Record outcome
Redact logs
```

---

# 150. Provider Failover Security

Automatic failover, if enabled later, must not:

```text
Cross project boundaries
Use unauthorized provider
Expose credentials
Bypass provider policy
```

Provider selection remains project-scoped.

---

# 151. Security and Maintenance Mode

Maintenance mode may restrict:

```text
User authentication
API traffic
Email sending
Project mutations
```

Critical admin recovery paths should remain available only to authorized administrators.

---

# 152. Deployment Security

Production deployment must include:

```text
HTTPS
Secure environment
Correct file permissions
Production debug disabled
Secure headers
Restricted DB access
Secret management
Backups
Monitoring
Cron/worker protection
Dependency review
```

---

# 153. Git Security

Never commit:

```text
.env
API keys
OAuth credentials
SMTP passwords
Encryption keys
Production database dumps
Session secrets
Webhook secrets
```

Use `.gitignore`.

---

# 154. CI/CD Security

CI/CD secrets must be stored in the CI secret manager.

Build logs must not print secrets.

Deployment credentials must use least privilege.

---

# 155. Dependency Updates

Security updates should be applied promptly.

Before deployment:

```text
Run tests
Run static analysis
Run dependency audit
Review breaking changes
Deploy safely
```

---

# 156. Production Configuration Review

Before go-live verify:

```text
APP_DEBUG=false
HTTPS active
Cookies secure
CSP active
DB restricted
Secrets loaded securely
CORS restricted
Rate limits active
Logs redacted
Backups active
Admin security active
```

---

# 157. Security Documentation

Security-sensitive behavior must be documented in:

```text
Authentication
API
Email Engine
Provider
Webhook
Admin
Deployment
```

No security rule should exist only in frontend code.

---

# 158. Security Change Management

Any security architecture change must include:

```text
Threat review
Impact review
Backward compatibility review
Migration plan
Testing
Documentation update
```

Do not silently change security semantics.

---

# 159. Security Regression Prevention

Before release:

```text
Run automated security tests
Run authorization tests
Run API tests
Run dependency checks
Review changed endpoints
Review changed permissions
Review secrets/config
```

---

# 160. Production Security Checklist

```text
[ ] HTTPS enforced
[ ] HSTS configured
[ ] Secure cookies
[ ] HttpOnly cookies
[ ] SameSite policy
[ ] CSP configured
[ ] Secure headers
[ ] Debug disabled
[ ] DB least privilege
[ ] Prepared statements
[ ] API key hashing
[ ] OAuth encryption
[ ] SMTP encryption
[ ] Webhook secret protection
[ ] CSRF enabled
[ ] CORS restricted
[ ] Rate limits enabled
[ ] Login protection enabled
[ ] OTP limits enabled
[ ] SSRF protection enabled
[ ] Audit logs enabled
[ ] Log redaction enabled
[ ] Admin RBAC enabled
[ ] Backups configured
[ ] Dependency audit passed
[ ] Security tests passed
```

---

# 161. Definition of Done

The Security Architecture is complete when:

- Authentication is secure.
- Passwords are hashed.
- Sessions are protected and revocable.
- CSRF protection is implemented where required.
- XSS protections are implemented.
- SQL injection protections are implemented.
- Prepared statements are mandatory.
- API keys are securely generated and hashed.
- OAuth credentials are protected.
- SMTP credentials are encrypted.
- Rate limiting is layered.
- Login/OTP abuse is controlled.
- IP blocking exists.
- Suspicious activity can be detected.
- Audit/security logs exist.
- Secure headers are configured.
- HTTPS is enforced.
- CORS is controlled.
- Input validation is server-side.
- Output serialization is safe.
- Project isolation is enforced.
- IDOR protection is enforced.
- SSRF protections exist.
- Webhooks are signed and protected.
- Email header injection is blocked.
- Secrets are redacted from logs.
- Admin privileges are isolated.
- Database access is least privilege.
- Production debug output is disabled.
- Security testing is part of QA.
- Incident response procedures exist.
- No security control relies solely on frontend behavior.

---

# 162. Non-Negotiable Security Rules

1. Never store plaintext passwords.
2. Never log passwords.
3. Never return password hashes.
4. Never store API key secrets in plaintext.
5. Never expose private API keys to browser code.
6. Never log API keys.
7. Never expose OAuth tokens.
8. Never log OAuth tokens.
9. Never store SMTP passwords plaintext.
10. Never log SMTP passwords.
11. Never expose OTP values in normal logs.
12. Never trust project IDs without authorization.
13. Never trust client-side authorization.
14. Never rely on CORS for authentication.
15. Never bypass CSRF for browser session mutations.
16. Never concatenate untrusted SQL.
17. Never execute user-provided PHP/code.
18. Never fetch arbitrary user URLs without SSRF protection.
19. Never allow webhook delivery to bypass SSRF controls.
20. Never allow webhook failures to break primary email sending.
21. Never expose stack traces in production.
22. Never expose environment variables.
23. Never commit secrets to Git.
24. Never use unrestricted admin permissions.
25. Never let normal users access admin operations.
26. Never bypass project isolation.
27. Never bypass provider authorization.
28. Never bypass the Email Engine.
29. Never bypass audit logging for sensitive operations.
30. Never disable critical security controls without explicit authorization.
31. Always use prepared statements.
32. Always validate server-side.
33. Always serialize API responses intentionally.
34. Always use secure sessions.
35. Always rate-limit authentication.
36. Always limit OTP attempts.
37. Always expire sensitive tokens.
38. Always protect encryption keys separately from encrypted data.
39. Always redact secrets before logging.
40. Always test security controls before production.
41. Always minimize sensitive data.
42. Always use least privilege.
43. Always fail closed for authorization.
44. Always audit security-sensitive administrative changes.
45. Always preserve security compatibility when extending the architecture.

---

# 163. Final Security Architecture Diagram

```text
                           INTERNET
                              │
                              ▼
                         HTTPS / TLS
                              │
                              ▼
                      WEB SERVER / WAF
                              │
                              ▼
                    ┌──────────────────┐
                    │ SECURITY LAYER   │
                    │                  │
                    │ Auth             │
                    │ Authorization    │
                    │ CSRF             │
                    │ CORS             │
                    │ Rate Limits      │
                    │ Validation       │
                    │ Request ID       │
                    └────────┬─────────┘
                             │
                             ▼
                    APPLICATION SERVICES
                             │
       ┌─────────────┬───────┼─────────┬─────────────┐
       ▼             ▼       ▼         ▼             ▼
     Users        Projects  Email    Providers     Admin
       │             │       │         │             │
       └─────────────┴───────┴─────────┴─────────────┘
                             │
                             ▼
                    SECURITY SERVICES
                             │
       ┌──────────┬──────────┼──────────┬────────────┐
       ▼          ▼          ▼          ▼            ▼
    Sessions   API Keys    Encryption  Audit       Rate Limit
                             │
                             ▼
                        DATA LAYER
                             │
                  ┌──────────┴──────────┐
                  ▼                     ▼
                MySQL             Protected Secrets
                  │
                  ▼
             Encrypted Backups

External:
Gmail / SMTP / Brevo / Mailtrap / Webhooks
             ▲
             │
        Provider Adapters
```

---

# 164. Final Lock

The Security Architecture is now the authoritative security baseline for the Email API Platform.

Locked decisions:

- Security is cross-cutting and enforced server-side.
- Authentication and authorization are separate concerns.
- Projects are a primary multi-tenant isolation boundary.
- API keys are cryptographically generated and stored as hashes.
- Browser keys are treated as exposed/restricted credentials.
- Private server keys remain server-side.
- OAuth and SMTP credentials are encrypted at rest.
- Webhook secrets are protected and signatures use the locked HMAC model.
- SSRF protection is mandatory for server-side URL access.
- CSRF protects session-authenticated browser mutations.
- CORS is never treated as authentication.
- SQL uses prepared statements.
- User input is validated server-side.
- Output is intentionally serialized and sensitive fields are excluded.
- Rate limiting is layered.
- Login and OTP abuse controls are mandatory.
- Audit/security logging is mandatory for sensitive actions.
- Secrets are redacted from logs.
- Admin access uses least-privilege permissions.
- Database and deployment access follow least privilege.
- Production debug output is disabled.
- Security testing is part of the release process.
- Incident response and credential-revocation procedures are defined.
- No component may bypass the security architecture.
- No structural security change is permitted without an explicit architecture revision.

**STATUS: FINAL / LOCKED**

**Next document:** `20-FRONTEND-DEVELOPMENT-GUIDE.md`
