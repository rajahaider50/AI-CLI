# EMAIL API PLATFORM — PROJECT OVERVIEW

**Document ID:** 01  
**Document:** `01-PROJECT-OVERVIEW.md`  
**Status:** FINAL / LOCKED  
**Parent Authority:** `00-MASTER-BLUEPRINT.md`

---

## 1. DOCUMENT PURPOSE

This document provides the complete product-level overview of the Email API Platform.

It explains what the platform is, why it exists, who it serves, how the major parts work together, what the primary user journeys are, and where the boundaries of the product are.

This document does not replace the detailed architecture, API, database, security, UI, or deployment documents. Those areas are defined in their dedicated documents.

---

## 2. PRODUCT IDENTITY

The product is a professional hosted Email API platform designed to give HTML websites and HTML web applications access to transactional email functionality without requiring PHP on the customer's frontend project.

The platform provides:

- Email sending
- OTP sending
- Email verification
- Password recovery emails
- HTML email templates
- Gmail integration
- SMTP integration
- Optional provider integrations
- Project management
- API keys
- Webhooks
- Email logs
- OTP logs
- Usage information
- Security controls
- User dashboard
- Administrative dashboard

The product follows an EmailJS-style developer experience while maintaining its own backend, architecture, interface, branding, and provider system.

---

## 3. PROBLEM STATEMENT

Many HTML websites and static web applications cannot execute server-side PHP.

Developers therefore commonly need an external backend to perform tasks such as:

- Sending contact form emails
- Sending verification emails
- Sending OTP codes
- Sending password reset emails
- Sending transactional notifications
- Connecting frontend applications to SMTP providers

The platform solves this problem by providing a hosted PHP REST API.

Instead of:

```text
HTML Website
    |
    X
    PHP Backend
```

the developer can use:

```text
HTML Website
    |
    | HTTPS / JavaScript Fetch
    v
Email API Platform
    |
    +---- Gmail
    +---- SMTP
    +---- Optional Providers
    |
    v
Recipient
```

This removes the need to deploy a custom PHP email backend for every small HTML project.

---

## 4. PRODUCT VISION

The long-term vision is to provide a simple but professional email infrastructure layer for developers who need reliable transactional email capabilities without building an email backend from scratch.

The platform should make the basic workflow straightforward:

```text
Create Account
      ↓
Verify Email
      ↓
Create Project
      ↓
Connect Gmail or SMTP
      ↓
Create Template
      ↓
Generate API Key
      ↓
Connect HTML Website
      ↓
Send Email
      ↓
View Logs / Usage
```

The platform should hide unnecessary backend complexity from the frontend developer while retaining enough configuration and control for professional use.

---

## 5. TARGET USERS

### 5.1 HTML Website Developers

Developers building:

- Static websites
- Portfolio websites
- Business websites
- Landing pages
- Contact pages
- Marketing websites

They can use the platform to send contact-form and notification emails.

---

### 5.2 HTML Web Application Developers

Developers building:

- JavaScript applications
- Admin interfaces
- SaaS prototypes
- Browser-based tools
- Internal applications
- Progressive web applications

They can use the API for transactional email and OTP workflows.

---

### 5.3 Freelancers

Freelancers can create separate projects for different clients.

Example:

```text
Account
│
├── Client A Website
├── Client B Website
├── Client C Web App
└── Personal Website
```

Each project can have its own:

- API key
- Templates
- Provider
- Logs
- Configuration

---

### 5.4 Small Businesses

Small businesses can use the platform without maintaining a dedicated email backend.

Typical use cases:

- Contact forms
- Customer notifications
- Email verification
- Booking notifications
- Registration emails
- Password recovery

---

### 5.5 Developers Building Prototypes

The platform is suitable for rapid prototypes where creating a complete backend only for email would be unnecessary.

---

## 6. PRIMARY USE CASES

### Use Case 1 — Contact Form

```text
Visitor
  ↓
HTML Contact Form
  ↓
JavaScript
  ↓
Email API
  ↓
Configured Provider
  ↓
Business Email
```

---

### Use Case 2 — Email Verification

```text
User Registration
      ↓
Generate OTP
      ↓
Email API
      ↓
Gmail / SMTP
      ↓
User Inbox
      ↓
OTP Verification
```

---

### Use Case 3 — Password Recovery

```text
Forgot Password
      ↓
Generate secure OTP / recovery mechanism
      ↓
Send Email
      ↓
User Verification
      ↓
Password Reset
```

---

### Use Case 4 — Transactional Email

Examples:

- Account created
- Payment notification
- Booking confirmation
- Form submission
- Application status
- Security alert

---

### Use Case 5 — Multiple Projects

A single user can manage multiple websites/applications.

```text
User Account
│
├── Project 1
│     ├── API Key
│     ├── Gmail
│     ├── Templates
│     └── Logs
│
├── Project 2
│     ├── API Key
│     ├── SMTP
│     ├── Templates
│     └── Logs
│
└── Project 3
      ├── API Key
      ├── Templates
      └── Logs
```

---

## 7. CORE PRODUCT EXPERIENCE

The platform is divided into five major experiences:

### A. Public Website

Provides:

- Product introduction
- Features
- Provider information
- Documentation
- Pricing
- FAQ
- Contact
- Legal information

### B. Authentication

Provides:

- Registration
- Login
- Email verification
- OTP verification
- Password recovery
- Account recovery

### C. User Panel

Provides:

- Projects
- Email providers
- Templates
- API keys
- Email sending tools
- Logs
- Usage
- Webhooks
- Account settings
- Security

### D. REST API

Provides programmatic access to:

- Email sending
- OTP sending
- Template functionality
- Project functionality
- Webhooks
- Logs
- Usage

### E. Admin Panel

Provides centralized management of:

- Users
- Projects
- Providers
- Templates
- Logs
- API activity
- Usage
- Security
- System settings
- Administrators

---

## 8. USER JOURNEY

### New User

```text
Landing Page
     ↓
Register
     ↓
Email Verification
     ↓
Login
     ↓
Dashboard
     ↓
Create Project
     ↓
Connect Provider
     ↓
Create Template
     ↓
Generate API Key
     ↓
Integrate API
     ↓
Send Test Email
     ↓
Production Use
```

---

## 9. PROJECT CREATION JOURNEY

A project represents one website or application.

Recommended flow:

```text
Create Project
      ↓
Project Name
      ↓
Project Identifier
      ↓
Allowed Origin / Domain Configuration
      ↓
Provider Configuration
      ↓
Template Setup
      ↓
API Key
      ↓
Integration
```

The exact fields and validation rules are defined by the project and API documents.

---

## 10. PROVIDER CONNECTION JOURNEY

### Gmail

```text
User
 ↓
Add Gmail
 ↓
OAuth Authorization
 ↓
Google Consent
 ↓
Callback
 ↓
Token Validation
 ↓
Secure Token Storage
 ↓
Connection Test
 ↓
Gmail Ready
```

The platform should use OAuth rather than asking users to enter their normal Gmail password.

---

### SMTP

```text
User
 ↓
Add SMTP
 ↓
SMTP Host
 ↓
Port
 ↓
Encryption
 ↓
Username
 ↓
Password
 ↓
Connection Test
 ↓
Secure Credential Storage
 ↓
SMTP Ready
```

SMTP credentials must be protected and never displayed unnecessarily after storage.

---

## 11. TEMPLATE EXPERIENCE

The template system allows users to create reusable email designs.

A template can contain:

- Template name
- Subject
- HTML
- Variables
- Status
- Version
- Metadata

Example:

```html
<h1>Hello {{name}}</h1>

<p>Your verification code is:</p>

<strong>{{otp}}</strong>
```

The same template can be reused from multiple API calls.

---

## 12. API INTEGRATION EXPERIENCE

A developer creates a project and receives a project API credential.

The frontend can then make a request similar to:

```javascript
fetch("https://YOUR-DOMAIN.example/api/email/send", {
    method: "POST",
    headers: {
        "Content-Type": "application/json",
        "X-API-Key": "PROJECT_API_KEY"
    },
    body: JSON.stringify({
        template: "contact-form",
        to: "recipient@example.com",
        variables: {
            name: "John",
            message: "Hello"
        }
    })
});
```

The actual production endpoint, authentication header, request schema, response schema, and domain are defined in `11-REST-API-SPECIFICATION.md`.

This example is conceptual and is not a final API contract.

---

## 13. EMAIL REQUEST LIFECYCLE

A typical email request follows this sequence:

```text
1. Client Request
       ↓
2. HTTPS
       ↓
3. API Routing
       ↓
4. Authentication
       ↓
5. Project Validation
       ↓
6. Rate Limit Check
       ↓
7. Request Validation
       ↓
8. Template Resolution
       ↓
9. Variable Validation
       ↓
10. Provider Selection
       ↓
11. Email Construction
       ↓
12. Provider Send
       ↓
13. Result Processing
       ↓
14. Logging
       ↓
15. API Response
```

This lifecycle is expanded in the Email Engine and API documents.

---

## 14. OTP LIFECYCLE

The OTP workflow is:

```text
Request OTP
    ↓
Authenticate Request
    ↓
Validate User / Purpose
    ↓
Rate Limit
    ↓
Generate Secure OTP
    ↓
Store Protected OTP Record
    ↓
Create Email
    ↓
Send Through Provider
    ↓
Record Delivery Attempt
    ↓
User Enters OTP
    ↓
Verify
    ↓
Expire / Consume
```

OTP codes must not remain valid indefinitely.

---

## 15. LOGGING EXPERIENCE

Users should be able to understand what happened to their email requests.

Relevant information can include:

- Request ID
- Project
- Template
- Recipient metadata
- Provider
- Status
- Timestamp
- Error code where applicable
- Processing information

Sensitive values must be redacted.

Admin users receive broader operational and security visibility according to their permissions.

---

## 16. WEBHOOK CONCEPT

Webhooks allow the platform to notify another application about supported events.

Possible event categories include:

- Email request accepted
- Email sent
- Email failed
- OTP requested
- Provider error
- Other future event types

Webhook delivery must support:

- Secure endpoint configuration
- Event selection
- Authentication/signature strategy
- Retry policy
- Delivery logs

The exact implementation belongs in `16-PROJECTS-API-KEYS-WEBHOOKS.md`.

---

## 17. SECURITY EXPERIENCE

Security should be present without making normal usage unnecessarily complicated.

The platform must protect:

- User accounts
- Sessions
- API keys
- Gmail OAuth credentials
- SMTP credentials
- OTP codes
- Email metadata
- Administrative actions

Security mechanisms include:

- Password hashing
- Secure sessions
- Rate limiting
- API authentication
- Input validation
- SQL injection prevention
- XSS protection
- CSRF protection
- Credential encryption
- Audit logs
- IP controls
- HTTPS

The detailed security specification is maintained in `19-SECURITY-ARCHITECTURE.md`.

---

## 18. ADMIN EXPERIENCE

The administrator should be able to monitor and manage the platform centrally.

Primary areas:

```text
Admin Dashboard
     |
     +-- Users
     +-- Projects
     +-- Providers
     +-- Templates
     +-- Email Logs
     +-- OTP Logs
     +-- API Logs
     +-- Webhooks
     +-- Usage
     +-- Analytics
     +-- Security
     +-- System Settings
     +-- Admin Accounts
     +-- Audit Logs
```

The admin panel is not intended to replace the user's project dashboard. It is the platform-management layer.

---

## 19. MULTI-PROJECT MODEL

The system is designed for multiple projects per user.

Each project should provide logical separation for:

- API credentials
- Templates
- Provider configuration
- Logs
- Usage
- Integration settings

This prevents one project from unnecessarily exposing another project's configuration.

---

## 20. SCALABILITY DIRECTION

The first implementation can be designed for a normal PHP/MySQL deployment while keeping service boundaries modular.

The architecture should be prepared for future improvements such as:

- Queue workers
- Redis
- Background processing
- Horizontal scaling
- Additional email providers
- Additional webhook events
- Advanced analytics
- Custom domains
- Higher-volume delivery infrastructure

These are future extension points, not mandatory requirements for the initial implementation unless separately approved.

---

## 21. PRODUCT BOUNDARIES

### Included

- User accounts
- Email verification
- OTP
- Projects
- Gmail
- SMTP
- Optional provider adapters
- Templates
- API
- API keys
- Logs
- Webhooks
- Usage
- User dashboard
- Admin dashboard
- Security
- Responsive UI
- Documentation

### Not automatically included

The following should not be added without an explicit scope decision:

- Full marketing automation
- Newsletter campaign management
- Contact/CRM management
- Advanced email analytics requiring external tracking infrastructure
- Full drag-and-drop page builder
- SMS infrastructure
- Push notification infrastructure
- Payment processing
- Unrelated social integrations

The platform should remain focused on developer-oriented transactional email infrastructure.

---

## 22. DESIGN PRINCIPLES

The product interface should communicate:

- Trust
- Technical reliability
- Simplicity
- Professionalism
- Security
- Developer friendliness

The design must avoid:

- Excessive visual effects
- Unnecessary animation
- Inconsistent components
- Random icon styles
- Poor typography
- Overcrowded dashboards
- Unclear error messages

The complete design system is defined in `05-UI-UX-DESIGN-SYSTEM.md`.

---

## 23. MOBILE EXPERIENCE

The user panel and admin panel must be responsive.

Mobile users should be able to:

- Login
- Manage projects
- Review providers
- View templates
- View logs
- Review usage
- Change account settings
- Manage security

Complex tables should provide responsive alternatives rather than simply overflowing the viewport.

---

## 24. PERFORMANCE OBJECTIVES

The platform should prioritize:

- Fast first render
- Small frontend payloads
- Optimized images
- Efficient database queries
- Indexed lookup paths
- Limited unnecessary API requests
- Server-side caching where appropriate
- Efficient logging
- Clean provider handling

Performance must never be achieved by weakening security.

---

## 25. ACCESSIBILITY OBJECTIVES

The interface should support:

- Semantic HTML
- Keyboard navigation
- Visible focus states
- Appropriate labels
- Accessible forms
- Accessible buttons
- Sufficient contrast
- Meaningful error messages
- Screen-reader-friendly structure
- Reduced-motion considerations

Accessibility requirements are expanded in `21-RESPONSIVE-ACCESSIBILITY-PERFORMANCE.md`.

---

## 26. MAINTAINABILITY OBJECTIVES

The codebase should be designed so developers can understand it without relying on undocumented behavior.

Maintainability requires:

- Clear folders
- Clear naming
- Separation of concerns
- Reusable services
- Reusable UI components
- Consistent API responses
- Centralized configuration
- Centralized validation
- Consistent error handling
- Documentation for important decisions

---

## 27. FUTURE PROVIDER EXTENSIBILITY

The provider architecture must make it possible to add providers without changing the fundamental client integration.

For example:

```text
Existing Client API
       |
       v
Email Engine
       |
       v
Provider Interface
       |
       +-- Gmail
       +-- SMTP
       +-- Brevo
       +-- Mailtrap
       +-- Future Provider
```

The frontend developer should not need a completely different API for every provider.

---

## 28. FUTURE PRODUCT EXTENSIBILITY

The architecture may later support:

- Additional email providers
- Domain verification
- Sender identities
- Delivery analytics
- Queued email
- Retry workers
- Advanced webhook events
- Team accounts
- Role-based permissions
- Usage limits
- Billing
- Custom domains
- API versioning

These are extension points only and are not automatically part of the initial product scope.

---

## 29. SUCCESS CRITERIA

The initial product should be considered successful when a developer can:

1. Create an account.
2. Verify their email.
3. Log in securely.
4. Create a project.
5. Connect Gmail or SMTP.
6. Test the provider.
7. Create an HTML email template.
8. Create variables.
9. Generate a project API key.
10. Integrate the API into a plain HTML website.
11. Send an email successfully.
12. Send an OTP successfully.
13. View email/OTP logs.
14. Manage the project.
15. Revoke or rotate API credentials.
16. Manage account security.
17. Administer the platform through the Admin Panel.

---

## 30. PROJECT QUALITY STANDARD

The finished application must be:

- Functional
- Secure
- Responsive
- Maintainable
- Professional
- Developer-friendly
- API-oriented
- Provider-extensible
- Accessible
- Performance-conscious

A feature is not considered complete merely because its primary happy path works. Validation, authorization, errors, loading states, security, responsive behavior, and relevant documentation must also be considered.

---

## 31. RELATIONSHIP TO OTHER DOCUMENTS

This document provides product context.

The detailed implementation authority is distributed as follows:

```text
01 Project Overview
      ↓
02 Scope & Features
      ↓
03 Architecture
      ↓
04 Technology
      ↓
05 UI/UX
      ↓
06 Screens
      ↓
07 Assets
      ↓
08–09 Database
      ↓
10–16 Backend/API/Email
      ↓
17–18 Panels
      ↓
19 Security
      ↓
20–21 Frontend/Quality
      ↓
22 Testing
      ↓
23 Deployment
      ↓
24 Developer Rules
```

No section of this document should be interpreted as replacing a more detailed specification in a dedicated document.

---

## 32. FINAL PRODUCT SUMMARY

```text
PRODUCT:
Professional Email API Platform

TARGET:
HTML Websites + HTML Web Applications

BACKEND:
PHP 8.3+

DATABASE:
MySQL 8+

API:
REST + JSON

AUTH:
User Session + Project API Key

PRIMARY PROVIDERS:
Gmail + SMTP

OPTIONAL PROVIDERS:
Brevo + Mailtrap

EMAIL:
Transactional / application email

OTP:
Supported as a first-class feature

TEMPLATES:
Unlimited at architecture level

PROJECTS:
Multiple per user

WEBHOOKS:
Supported

LOGGING:
Email + OTP + API + Security

USER PANEL:
Complete developer dashboard

ADMIN PANEL:
Complete platform administration

SCREENS:
93

CORE MODULES:
24

DOCUMENTATION:
25 Markdown files
```

---

## 33. FINAL STATUS

**Document Status: FINAL / LOCKED**

This document is the approved project overview and must remain consistent with:

`00-MASTER-BLUEPRINT.md`

The next documentation file in the approved sequence is:

```text
02-FINAL-SCOPE-AND-FEATURES.md
```

**End of `01-PROJECT-OVERVIEW.md`**
