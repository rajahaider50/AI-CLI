# 11 — REST API Specification

**Project:** Email API Platform  
**Document:** `11-REST-API-SPECIFICATION.md`  
**Status:** FINAL / LOCKED  
**Version:** 1.0  
**Audience:** Backend developers, frontend developers, API integrators, QA, security reviewers, DevOps  
**Related documents:** 00–10 and 12–24 in the master blueprint

---

## 1. Purpose

This document is the authoritative REST API contract for the Email API Platform.

The API allows static HTML websites, JavaScript applications, mobile clients, internal applications, and server-side applications to use the platform's email capabilities through HTTPS without requiring PHP on the client website.

The API provides:

- authentication and account operations;
- project management;
- provider management;
- Gmail and SMTP connections;
- template management;
- email sending;
- OTP sending and verification;
- API-key authentication;
- webhooks;
- email/OTP/request logs;
- usage statistics;
- health and system status;
- standardized validation, rate-limit, and error responses.

The API is JSON-first, versioned, authenticated, project-aware, and designed for safe browser use.

---

## 2. Locked API Principles

1. All production API traffic uses HTTPS.
2. API responses use JSON unless an endpoint explicitly documents another representation.
3. API version 1 is exposed under `/api/v1`.
4. API keys are project-scoped.
5. Secrets are never returned in plaintext after creation.
6. Passwords, OAuth tokens, SMTP passwords, and API-key secret material are never logged.
7. Every request receives a request ID.
8. Validation happens at the API boundary and again at service boundaries where necessary.
9. Authorization is checked after authentication and before resource access.
10. Project isolation is mandatory.
11. Pagination is used for potentially large collections.
12. Rate limits apply to authentication, OTP, email sending, and other abuse-sensitive operations.
13. Idempotency is supported for email-send operations where appropriate.
14. Errors use stable machine-readable codes.
15. The API contract must remain compatible with the locked database and backend architecture.
16. Provider-specific implementation details remain behind provider adapters.
17. Client applications must not receive provider credentials or internal secrets.
18. CORS is allowlist-based, not wildcard in production for authenticated browser workflows.
19. Sensitive administrative endpoints require administrator authorization.
20. No endpoint bypasses the centralized authorization/policy layer.

---

# 3. Base URL

Production:

```text
https://api.example.com/api/v1
```

The actual production hostname is deployment-specific.

Development example:

```text
https://dev.example.com/api/v1
```

Do not hard-code the production hostname into the application source.

---

# 4. Content Types

Requests containing JSON:

```http
Content-Type: application/json
Accept: application/json
```

Successful responses:

```http
Content-Type: application/json
```

The API must reject unsupported media types where an endpoint requires JSON.

Recommended request body encoding:

```json
{
  "name": "My Website"
}
```

---

# 5. Request IDs

Every request receives a unique request identifier.

Example:

```http
X-Request-ID: req_01JEXAMPLE123
```

If the client supplies a valid request ID, the server may preserve it subject to validation and security rules. Otherwise the server generates one.

Responses should include:

```http
X-Request-ID: req_01JEXAMPLE123
```

Request IDs are safe to expose to clients and are intended for support and troubleshooting.

Never use request IDs as authentication credentials.

---

# 6. Authentication Model

The platform supports two primary authentication models.

## 6.1 User/session authentication

Used by the web dashboard.

Recommended:

```http
Cookie: secure_session_cookie
```

Session cookies must use:

- `Secure`;
- `HttpOnly`;
- appropriate `SameSite`;
- server-side session validation;
- expiration and revocation;
- session rotation after authentication-sensitive events.

CSRF protection applies to cookie-authenticated state-changing requests.

## 6.2 Project API-key authentication

Used by external websites and applications.

Header:

```http
X-API-Key: <project-api-key>
```

API keys are project-scoped.

The server stores only a secure representation/hash of the secret portion and displays the full secret only at creation time.

Do not send API keys through query parameters.

Bad:

```text
/api/v1/send-email?api_key=...
```

Good:

```http
X-API-Key: ...
```

---

# 7. API Key Format

A production implementation should use an identifiable prefix plus high-entropy secret.

Example:

```text
eak_live_xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

Recommended properties:

- environment-aware prefix;
- project association;
- non-guessable secret;
- stored hash;
- optional label;
- created timestamp;
- last-used timestamp;
- revoked timestamp;
- optional expiration;
- permission/scope metadata.

The exact generated secret format is an implementation detail and must not weaken entropy.

---

# 8. Authorization

Authentication answers:

> Who is making the request?

Authorization answers:

> Is this identity allowed to perform this action on this resource?

Authorization must verify:

1. authenticated identity;
2. project ownership/membership;
3. requested resource belongs to the active project;
4. required permission/scope;
5. resource status;
6. administrator privilege where required.

A user must never access another user's project by changing an ID in the URL.

Example unsafe assumption:

```text
GET /projects/123/templates
```

The existence of project `123` does not grant access.

---

# 9. Common Response Envelope

## 9.1 Success

Recommended structure:

```json
{
  "success": true,
  "data": {},
  "meta": {
    "request_id": "req_01JEXAMPLE123"
  }
}
```

For collection endpoints:

```json
{
  "success": true,
  "data": [],
  "meta": {
    "request_id": "req_01JEXAMPLE123",
    "pagination": {
      "page": 1,
      "per_page": 25,
      "total": 100,
      "total_pages": 4
    }
  }
}
```

## 9.2 Error

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "The request contains invalid fields.",
    "details": {
      "email": "A valid email address is required."
    }
  },
  "meta": {
    "request_id": "req_01JEXAMPLE123"
  }
}
```

The `message` is human-readable.

The `code` is stable and intended for programmatic handling.

Internal stack traces, SQL errors, filesystem paths, provider secrets, and sensitive diagnostics must never be returned in production.

---

# 10. HTTP Status Codes

| Status | Meaning |
|---:|---|
| 200 | Successful operation |
| 201 | Resource created |
| 202 | Accepted for processing |
| 204 | Successful operation with no response body |
| 400 | Malformed or invalid request |
| 401 | Authentication required/failed |
| 403 | Authenticated but not authorized |
| 404 | Resource not found |
| 405 | Method not allowed |
| 409 | Conflict |
| 413 | Payload too large |
| 415 | Unsupported media type |
| 422 | Validation failure |
| 429 | Rate limit exceeded |
| 500 | Internal server error |
| 502 | Upstream/provider failure |
| 503 | Service temporarily unavailable |

The exact status code must remain consistent across equivalent API operations.

---

# 11. Standard Error Codes

Core error codes include:

```text
AUTHENTICATION_REQUIRED
INVALID_CREDENTIALS
INVALID_API_KEY
API_KEY_REVOKED
API_KEY_EXPIRED
FORBIDDEN
PROJECT_ACCESS_DENIED
RESOURCE_NOT_FOUND
VALIDATION_ERROR
INVALID_JSON
MISSING_FIELD
INVALID_FIELD
DUPLICATE_RESOURCE
CONFLICT
RATE_LIMIT_EXCEEDED
OTP_EXPIRED
OTP_INVALID
OTP_ATTEMPTS_EXCEEDED
EMAIL_SEND_FAILED
PROVIDER_NOT_CONFIGURED
PROVIDER_AUTH_FAILED
PROVIDER_UNAVAILABLE
TEMPLATE_NOT_FOUND
TEMPLATE_VARIABLE_INVALID
WEBHOOK_DELIVERY_FAILED
PAYLOAD_TOO_LARGE
INTERNAL_ERROR
SERVICE_UNAVAILABLE
```

Codes should not be renamed casually after client integrations are released.

---

# 12. Pagination

Collection endpoints use:

```text
?page=1&per_page=25
```

Recommended limits:

- default: 25;
- minimum: 1;
- maximum: 100.

The server must clamp or reject unreasonable values.

Example:

```http
GET /api/v1/projects/{project_id}/email-logs?page=2&per_page=25
```

Response:

```json
{
  "success": true,
  "data": [],
  "meta": {
    "request_id": "req_...",
    "pagination": {
      "page": 2,
      "per_page": 25,
      "total": 120,
      "total_pages": 5
    }
  }
}
```

For high-volume future implementations, cursor pagination may be added without removing the stable page-based contract unless a major API version is introduced.

---

# 13. Filtering, Sorting, and Search

Where documented, collection endpoints may support:

```text
?status=sent
?provider=gmail
?search=welcome
?from=2026-01-01
?to=2026-01-31
?sort=created_at
?direction=desc
```

Filters must be validated against an allowlist.

Never interpolate raw query parameters into SQL.

---

# 14. Authentication API

## 14.1 Register

```http
POST /auth/register
```

Request:

```json
{
  "name": "Example User",
  "email": "user@example.com",
  "password": "StrongPasswordHere"
}
```

Response:

```json
{
  "success": true,
  "data": {
    "user": {
      "id": "usr_...",
      "name": "Example User",
      "email": "user@example.com",
      "email_verified": false
    }
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

Security:

- validate email;
- enforce password policy;
- hash password using PHP's password hashing API;
- normalize email consistently;
- prevent account enumeration where appropriate;
- trigger email verification flow.

---

## 14.2 Login

```http
POST /auth/login
```

Request:

```json
{
  "email": "user@example.com",
  "password": "StrongPasswordHere"
}
```

On success:

- create/rotate secure session;
- record login event;
- update session metadata;
- apply suspicious-login controls if configured.

Failed login responses should not reveal whether the email exists.

---

## 14.3 Logout

```http
POST /auth/logout
```

Requires authenticated session.

Response:

```json
{
  "success": true,
  "data": null,
  "meta": {
    "request_id": "req_..."
  }
}
```

The server invalidates the session.

---

## 14.4 Email Verification

```http
POST /auth/verify-email
```

Request:

```json
{
  "token": "verification-token"
}
```

The token must be:

- random;
- time-limited;
- single-use;
- securely stored/represented;
- invalidated after successful use.

---

## 14.5 Resend Verification

```http
POST /auth/resend-verification
```

The endpoint is rate-limited.

---

## 14.6 Forgot Password

```http
POST /auth/forgot-password
```

Request:

```json
{
  "email": "user@example.com"
}
```

Response should be intentionally non-enumerating.

---

## 14.7 Reset Password

```http
POST /auth/reset-password
```

Request:

```json
{
  "token": "reset-token",
  "password": "NewStrongPasswordHere"
}
```

After successful reset:

- invalidate reset token;
- revoke appropriate sessions;
- record security event.

---

## 14.8 Active Sessions

```http
GET /auth/sessions
DELETE /auth/sessions/{session_id}
POST /auth/sessions/revoke-all
```

A user may revoke individual sessions or all other sessions.

---

# 15. Project API

All project endpoints require user authentication unless explicitly stated otherwise.

## 15.1 List Projects

```http
GET /projects
```

## 15.2 Create Project

```http
POST /projects
```

Request:

```json
{
  "name": "My Website",
  "description": "Transactional email project"
}
```

## 15.3 Get Project

```http
GET /projects/{project_id}
```

## 15.4 Update Project

```http
PATCH /projects/{project_id}
```

## 15.5 Delete Project

```http
DELETE /projects/{project_id}
```

Deletion must follow the platform's retention policy. Hard deletion must not accidentally destroy required audit/security records.

## 15.6 Project Settings

```http
GET /projects/{project_id}/settings
PATCH /projects/{project_id}/settings
```

Project settings may include:

- project name;
- allowed origins;
- default provider;
- sending preferences;
- webhook defaults;
- notification preferences;
- rate-limit settings where authorized.

---

# 16. Provider API

## 16.1 List Providers

```http
GET /projects/{project_id}/providers
```

## 16.2 Add Gmail

```http
POST /projects/{project_id}/providers/gmail
```

Recommended flow:

1. client requests OAuth authorization;
2. server generates state;
3. user authorizes Google;
4. callback validates state;
5. authorization code is exchanged server-side;
6. encrypted tokens are stored;
7. provider connection is tested;
8. connection status is recorded.

OAuth tokens must never be returned to the browser as reusable credentials.

---

## 16.3 Gmail OAuth Start

```http
GET /projects/{project_id}/providers/gmail/oauth/start
```

This endpoint begins the authorization flow.

It may return an authorization URL or redirect directly, depending on the dashboard architecture.

---

## 16.4 Gmail OAuth Callback

```http
GET /providers/gmail/oauth/callback
```

The callback must validate:

- OAuth state;
- expected callback context;
- authorization response;
- token exchange result.

---

## 16.5 Add SMTP

```http
POST /projects/{project_id}/providers/smtp
```

Request example:

```json
{
  "name": "Primary SMTP",
  "host": "smtp.example.com",
  "port": 587,
  "encryption": "tls",
  "username": "smtp-user",
  "password": "smtp-password",
  "from_email": "noreply@example.com",
  "from_name": "Example App"
}
```

The password is encrypted at rest and never returned.

---

## 16.6 Test Provider

```http
POST /projects/{project_id}/providers/{provider_id}/test
```

Optional test payload:

```json
{
  "recipient": "test@example.com"
}
```

Provider testing must use controlled timeouts and must not expose credentials.

---

## 16.7 Provider Status

```http
GET /projects/{project_id}/providers/{provider_id}
```

Response exposes safe metadata:

```json
{
  "id": "prv_...",
  "type": "smtp",
  "name": "Primary SMTP",
  "status": "connected",
  "from_email": "noreply@example.com",
  "created_at": "2026-10-05T10:00:00Z"
}
```

Sensitive configuration is redacted.

---

## 16.8 Update/Delete Provider

```http
PATCH /projects/{project_id}/providers/{provider_id}
DELETE /projects/{project_id}/providers/{provider_id}
```

Deleting a provider must check whether it is the active/default provider and whether existing templates or sending workflows depend on it.

---

# 17. Template API

## 17.1 List Templates

```http
GET /projects/{project_id}/templates
```

## 17.2 Create Template

```http
POST /projects/{project_id}/templates
```

Request:

```json
{
  "name": "Welcome Email",
  "subject": "Welcome {{name}}",
  "html": "<h1>Hello {{name}}</h1>",
  "text": "Hello {{name}}"
}
```

## 17.3 Get Template

```http
GET /projects/{project_id}/templates/{template_id}
```

## 17.4 Update Template

```http
PATCH /projects/{project_id}/templates/{template_id}
```

## 17.5 Delete Template

```http
DELETE /projects/{project_id}/templates/{template_id}
```

## 17.6 Duplicate Template

```http
POST /projects/{project_id}/templates/{template_id}/duplicate
```

## 17.7 Preview Template

```http
POST /projects/{project_id}/templates/{template_id}/preview
```

Request:

```json
{
  "variables": {
    "name": "John",
    "verification_code": "123456"
  }
}
```

Template rendering must safely substitute variables without executing arbitrary server-side code.

---

# 18. Template Variables

Supported variable syntax:

```text
{{variable_name}}
```

Example:

```html
<h1>Hello {{name}}</h1>
<p>Your OTP is {{otp}}</p>
```

Variable names must be validated.

The template engine must not permit:

- PHP execution;
- arbitrary function calls;
- filesystem access;
- database expressions;
- shell commands;
- dynamic code evaluation.

Missing required variables should produce a controlled validation error.

---

# 19. Email Sending API

This is the primary public API.

## 19.1 Send Email

```http
POST /send-email
```

Authentication:

```http
X-API-Key: eak_live_...
```

Request using a template:

```json
{
  "template_id": "tpl_...",
  "to": [
    {
      "email": "recipient@example.com",
      "name": "John"
    }
  ],
  "variables": {
    "name": "John"
  }
}
```

Request using direct content:

```json
{
  "to": [
    {
      "email": "recipient@example.com",
      "name": "John"
    }
  ],
  "subject": "Welcome",
  "html": "<h1>Hello John</h1>",
  "text": "Hello John"
}
```

Optional fields:

```json
{
  "cc": [],
  "bcc": [],
  "reply_to": {
    "email": "support@example.com",
    "name": "Support"
  },
  "from": {
    "email": "noreply@example.com",
    "name": "Example App"
  },
  "provider_id": "prv_...",
  "metadata": {
    "order_id": "ORD-123"
  }
}
```

The server must validate sender identity against project/provider policy.

---

## 19.2 Send Email Response

Immediate synchronous example:

```json
{
  "success": true,
  "data": {
    "message_id": "msg_...",
    "status": "sent",
    "provider": "gmail"
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

If the platform uses deferred processing:

```http
202 Accepted
```

Example:

```json
{
  "success": true,
  "data": {
    "message_id": "msg_...",
    "status": "queued"
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

The API contract must clearly document whether the deployed email engine is synchronous or queued.

The architecture remains queue-compatible without requiring a mandatory external queue.

---

# 20. Email Recipients

Recipients must be represented as validated email addresses.

Supported fields:

- `to`;
- `cc`;
- `bcc`.

Each address may include:

```json
{
  "email": "john@example.com",
  "name": "John"
}
```

The server must:

- validate syntax;
- normalize where appropriate;
- enforce recipient limits;
- prevent header injection;
- reject malformed addresses.

---

# 21. Attachments

If attachments are supported by the deployment, they must be explicitly enabled and constrained.

Recommended representation:

```json
{
  "filename": "invoice.pdf",
  "content": "<base64-data>",
  "content_type": "application/pdf"
}
```

Controls must include:

- maximum request size;
- maximum attachment size;
- maximum attachment count;
- allowed MIME types;
- decoded-size validation;
- memory/time protection.

For large files, a future upload/reference mechanism may be introduced instead of embedding large base64 payloads.

---

# 22. Idempotency

Email sending should support:

```http
Idempotency-Key: unique-client-generated-value
```

Example:

```http
Idempotency-Key: order-123-welcome-v1
```

The server uses the key with the authenticated project/context to prevent accidental duplicate sends.

Rules:

- same key + same logical request → return original result;
- same key + materially different request → `409 CONFLICT`;
- retention period is implementation-defined and documented;
- keys must not be globally trusted across projects.

---

# 23. Send OTP API

```http
POST /otp/send
```

Authentication may use a project API key.

Request:

```json
{
  "channel": "email",
  "recipient": {
    "email": "user@example.com",
    "name": "John"
  },
  "purpose": "login",
  "template_id": "tpl_...",
  "metadata": {
    "user_id": "123"
  }
}
```

Server generates the OTP.

The client must not provide the OTP value for a normal generation request.

Response:

```json
{
  "success": true,
  "data": {
    "otp_id": "otp_...",
    "expires_in": 300,
    "status": "sent"
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

OTP security:

- cryptographically secure generation;
- short expiration;
- attempt limits;
- resend throttling;
- project/user/IP controls;
- one-time consumption;
- secure storage/representation;
- no plaintext OTP in logs.

---

# 24. Verify OTP API

```http
POST /otp/verify
```

Request:

```json
{
  "otp_id": "otp_...",
  "code": "123456"
}
```

Success:

```json
{
  "success": true,
  "data": {
    "verified": true
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

Invalid/expired/locked OTPs must use controlled error codes.

---

# 25. Email Verification API

The platform may use the same underlying OTP/token infrastructure for account verification, but public endpoint semantics remain separate where required by the dashboard.

Example:

```http
POST /auth/verify-email
```

The system records verification state and invalidates the verification token after successful use.

---

# 26. Email Logs API

## List

```http
GET /projects/{project_id}/email-logs
```

Filters may include:

```text
status
provider
template_id
recipient
from
to
```

## Details

```http
GET /projects/{project_id}/email-logs/{log_id}
```

Safe response example:

```json
{
  "id": "msg_...",
  "status": "sent",
  "provider": "gmail",
  "recipient_count": 1,
  "subject": "Welcome",
  "created_at": "2026-10-05T10:00:00Z",
  "sent_at": "2026-10-05T10:00:02Z"
}
```

Logs must not expose:

- API keys;
- OAuth tokens;
- SMTP passwords;
- passwords;
- internal stack traces.

Sensitive message content should follow the platform's privacy and retention policy.

---

# 27. OTP Logs API

```http
GET /projects/{project_id}/otp-logs
GET /projects/{project_id}/otp-logs/{log_id}
```

OTP logs may expose safe metadata such as:

- purpose;
- destination masked appropriately;
- status;
- attempt count;
- created time;
- expiration time;
- verified time.

Never expose the actual OTP secret.

---

# 28. API Request Logs

```http
GET /projects/{project_id}/api-logs
GET /projects/{project_id}/api-logs/{log_id}
```

Recommended safe fields:

- request ID;
- endpoint;
- HTTP method;
- status code;
- duration;
- authenticated project;
- timestamp;
- rate-limit outcome.

Request/response bodies should be selectively logged and sensitive fields must be redacted.

---

# 29. Usage API

```http
GET /projects/{project_id}/usage
```

Optional period:

```text
?from=2026-10-01&to=2026-10-05
```

Possible metrics:

- emails sent;
- emails failed;
- OTPs sent;
- OTPs verified;
- API requests;
- webhook deliveries;
- provider failures.

Example:

```json
{
  "success": true,
  "data": {
    "emails_sent": 1200,
    "emails_failed": 12,
    "otps_sent": 300,
    "api_requests": 5400
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

---

# 30. Webhook API

## Create

```http
POST /projects/{project_id}/webhooks
```

Request:

```json
{
  "url": "https://example.com/webhooks/email",
  "events": [
    "email.sent",
    "email.failed",
    "otp.sent",
    "otp.verified"
  ],
  "active": true
}
```

## List

```http
GET /projects/{project_id}/webhooks
```

## Get

```http
GET /projects/{project_id}/webhooks/{webhook_id}
```

## Update

```http
PATCH /projects/{project_id}/webhooks/{webhook_id}
```

## Delete

```http
DELETE /projects/{project_id}/webhooks/{webhook_id}
```

## Test

```http
POST /projects/{project_id}/webhooks/{webhook_id}/test
```

---

# 31. Webhook Delivery

Example payload:

```json
{
  "id": "evt_...",
  "type": "email.sent",
  "created_at": "2026-10-05T10:00:00Z",
  "data": {
    "message_id": "msg_...",
    "status": "sent"
  }
}
```

Recommended headers:

```http
Content-Type: application/json
X-Webhook-ID: wh_...
X-Webhook-Event: email.sent
X-Webhook-Timestamp: 2026-10-05T10:00:00Z
X-Webhook-Signature: ...
```

Webhook signatures should use a secure HMAC scheme.

Webhook secrets must be stored securely and never returned after creation.

Delivery should support:

- timeout;
- retry;
- exponential backoff;
- delivery logging;
- response status tracking;
- disablement after repeated failures where configured.

---

# 32. Health API

Public/basic health:

```http
GET /health
```

Example:

```json
{
  "success": true,
  "data": {
    "status": "ok"
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

Detailed internal health may check:

- database;
- application;
- provider infrastructure;
- filesystem;
- cron/worker state.

Detailed diagnostics must require authorization and must not expose secrets.

---

# 33. API Documentation Endpoint

A browser-facing documentation page may exist at:

```text
/api/docs
```

Machine-readable OpenAPI documentation may be exposed at:

```text
/api/openapi.json
```

if enabled.

The API specification should remain synchronized with actual routes and validation behavior.

---

# 34. Rate Limit API

Where exposed:

```http
GET /rate-limit
```

A response may contain:

```json
{
  "success": true,
  "data": {
    "limit": 100,
    "remaining": 87,
    "reset_at": "2026-10-05T11:00:00Z"
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

Recommended headers:

```http
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 87
X-RateLimit-Reset: 1791198000
```

When exceeded:

```http
429 Too Many Requests
```

with:

```http
Retry-After: 60
```

---

# 35. CORS

CORS is configured per environment.

Production browser projects should use explicit origin allowlists.

Example conceptual configuration:

```text
https://example.com
https://www.example.com
```

Avoid:

```text
Access-Control-Allow-Origin: *
```

for sensitive authenticated browser workflows.

Preflight requests must support required methods and headers.

CORS is not an authentication mechanism.

---

# 36. CSRF

CSRF protection is mandatory for cookie-authenticated state-changing requests.

API-key-authenticated requests are not protected by browser cookies in the same manner, but they remain subject to origin, rate-limit, authentication, and authorization controls.

CSRF tokens must be:

- unpredictable;
- session-bound;
- validated server-side;
- rotated where appropriate.

---

# 37. Validation Rules

Every endpoint must validate:

- JSON syntax;
- required fields;
- field types;
- string lengths;
- enum values;
- email formats;
- URL formats;
- IDs;
- pagination;
- dates;
- arrays;
- recipient limits;
- attachment limits;
- provider-specific fields.

Validation errors should identify safe field-level problems.

Example:

```json
{
  "success": false,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Validation failed.",
    "details": {
      "subject": "Subject is required.",
      "to": "At least one recipient is required."
    }
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

---

# 38. Security Headers

Production responses should include appropriate security headers, including where applicable:

```http
Strict-Transport-Security
Content-Security-Policy
X-Content-Type-Options
Referrer-Policy
Permissions-Policy
```

Do not expose server version details unnecessarily.

---

# 39. API Request Limits

The API must define limits for:

- request body size;
- JSON nesting/depth;
- number of recipients;
- number of variables;
- variable length;
- subject length;
- HTML body size;
- text body size;
- attachment count;
- attachment size;
- pagination;
- webhook payload size.

Limits must be enforced before expensive processing.

---

# 40. Email Provider Error Normalization

Provider-specific errors must be normalized.

Example internal provider errors:

```text
AUTH_FAILED
CONNECTION_FAILED
TIMEOUT
RATE_LIMITED
INVALID_RECIPIENT
QUOTA_EXCEEDED
MESSAGE_REJECTED
TEMPORARY_FAILURE
UNKNOWN_PROVIDER_ERROR
```

The public API should expose stable platform-level codes rather than leaking provider SDK exceptions.

Example:

```json
{
  "success": false,
  "error": {
    "code": "EMAIL_SEND_FAILED",
    "message": "The email could not be sent.",
    "details": {
      "reason": "PROVIDER_UNAVAILABLE"
    }
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

---

# 41. Retry Semantics

Clients should retry only when appropriate.

Generally retryable:

- `429`;
- `502`;
- `503`;
- selected transient provider failures.

Generally non-retryable without changing the request:

- `400`;
- `401`;
- `403`;
- `404`;
- `422`.

For email sending, use idempotency keys when retrying to prevent duplicate messages.

---

# 42. API Endpoint Matrix

| Area | Method | Endpoint |
|---|---|---|
| Auth | POST | `/auth/register` |
| Auth | POST | `/auth/login` |
| Auth | POST | `/auth/logout` |
| Auth | POST | `/auth/verify-email` |
| Auth | POST | `/auth/resend-verification` |
| Auth | POST | `/auth/forgot-password` |
| Auth | POST | `/auth/reset-password` |
| Sessions | GET | `/auth/sessions` |
| Sessions | DELETE | `/auth/sessions/{id}` |
| Sessions | POST | `/auth/sessions/revoke-all` |
| Projects | GET | `/projects` |
| Projects | POST | `/projects` |
| Projects | GET | `/projects/{id}` |
| Projects | PATCH | `/projects/{id}` |
| Projects | DELETE | `/projects/{id}` |
| Settings | GET | `/projects/{id}/settings` |
| Settings | PATCH | `/projects/{id}/settings` |
| Providers | GET | `/projects/{id}/providers` |
| Gmail | POST | `/projects/{id}/providers/gmail` |
| Gmail | GET | `/projects/{id}/providers/gmail/oauth/start` |
| Gmail | GET | `/providers/gmail/oauth/callback` |
| SMTP | POST | `/projects/{id}/providers/smtp` |
| Providers | POST | `/projects/{id}/providers/{provider_id}/test` |
| Providers | GET | `/projects/{id}/providers/{provider_id}` |
| Providers | PATCH | `/projects/{id}/providers/{provider_id}` |
| Providers | DELETE | `/projects/{id}/providers/{provider_id}` |
| Templates | GET | `/projects/{id}/templates` |
| Templates | POST | `/projects/{id}/templates` |
| Templates | GET | `/projects/{id}/templates/{template_id}` |
| Templates | PATCH | `/projects/{id}/templates/{template_id}` |
| Templates | DELETE | `/projects/{id}/templates/{template_id}` |
| Templates | POST | `/projects/{id}/templates/{template_id}/duplicate` |
| Templates | POST | `/projects/{id}/templates/{template_id}/preview` |
| Email | POST | `/send-email` |
| OTP | POST | `/otp/send` |
| OTP | POST | `/otp/verify` |
| Email Logs | GET | `/projects/{id}/email-logs` |
| Email Logs | GET | `/projects/{id}/email-logs/{log_id}` |
| OTP Logs | GET | `/projects/{id}/otp-logs` |
| OTP Logs | GET | `/projects/{id}/otp-logs/{log_id}` |
| API Logs | GET | `/projects/{id}/api-logs` |
| API Logs | GET | `/projects/{id}/api-logs/{log_id}` |
| Usage | GET | `/projects/{id}/usage` |
| Webhooks | GET | `/projects/{id}/webhooks` |
| Webhooks | POST | `/projects/{id}/webhooks` |
| Webhooks | GET | `/projects/{id}/webhooks/{webhook_id}` |
| Webhooks | PATCH | `/projects/{id}/webhooks/{webhook_id}` |
| Webhooks | DELETE | `/projects/{id}/webhooks/{webhook_id}` |
| Webhooks | POST | `/projects/{id}/webhooks/{webhook_id}/test` |
| Health | GET | `/health` |
| Rate Limit | GET | `/rate-limit` |

This matrix is the baseline contract and must remain synchronized with implementation.

---

# 43. Browser JavaScript Integration

A static HTML website can send email using Fetch.

Example:

```javascript
async function sendEmail() {
  const response = await fetch("https://api.example.com/api/v1/send-email", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "X-API-Key": "eak_live_REPLACE_WITH_PROJECT_KEY",
      "Idempotency-Key": crypto.randomUUID()
    },
    body: JSON.stringify({
      template_id: "tpl_welcome",
      to: [
        {
          email: "customer@example.com",
          name: "Customer"
        }
      ],
      variables: {
        name: "Customer"
      }
    })
  });

  const result = await response.json();

  if (!response.ok) {
    throw new Error(result?.error?.message || "Email request failed");
  }

  return result;
}
```

Production websites must never expose privileged administrative credentials in frontend JavaScript.

Project API keys used in browser applications must be intentionally designed for that exposure, restricted by project/origin/rate-limit policy, and never granted administrative privileges.

---

# 44. API Key Scope Model

Recommended scopes:

```text
email:send
otp:send
otp:verify
templates:read
projects:read
logs:read
usage:read
webhooks:manage
```

Default public/browser keys should receive the minimum required scope.

Dangerous administrative scopes must not be available to normal browser clients.

---

# 45. Public vs Dashboard API

The same REST foundation may serve:

### Public/project API

Used by external applications:

```text
X-API-Key
```

### Dashboard API

Used by the authenticated web panel:

```text
Secure session cookie
CSRF token
```

The implementation should share service and policy layers but must keep authentication mechanisms and permissions distinct.

---

# 46. Admin API

Administrative endpoints are not part of the normal project API surface.

They should use a protected namespace such as:

```text
/admin/users
/admin/projects
/admin/providers
/admin/logs
/admin/security
/admin/settings
```

Admin endpoints require:

- admin authentication;
- admin authorization;
- audit logging;
- stricter security controls;
- optional IP restrictions;
- session management;
- re-authentication for highly sensitive operations.

Admin credentials must never be accepted as project API keys.

---

# 47. Audit Requirements

The following events should be audited where applicable:

- login;
- logout;
- failed login;
- password reset;
- email verification;
- project creation/deletion;
- provider creation/update/deletion;
- Gmail authorization/revocation;
- SMTP configuration changes;
- API key creation/revocation;
- webhook changes;
- admin actions;
- security setting changes;
- IP blocking;
- rate-limit policy changes.

Audit entries must contain enough metadata to investigate an event without storing secrets.

---

# 48. Observability

Each request should be traceable through:

```text
request_id
→ API log
→ service operation
→ provider operation
→ email log / webhook log
```

Recommended metadata:

- request ID;
- project ID;
- endpoint;
- method;
- response status;
- execution time;
- provider ID;
- message ID;
- error code.

Never log:

- passwords;
- API secrets;
- OAuth refresh/access tokens;
- SMTP passwords;
- raw OTP values.

---

# 49. API Versioning

Current version:

```text
v1
```

Base path:

```text
/api/v1
```

Breaking changes require a new major version.

Non-breaking additions may include:

- optional response fields;
- new endpoints;
- new optional request fields;
- new provider adapters.

Do not silently change the meaning of an existing field.

---

# 50. Backward Compatibility

Existing clients should continue to function when:

- optional fields are added;
- additional metadata is returned;
- new providers are introduced;
- internal implementation changes;
- database optimizations occur.

Breaking changes must be versioned and documented.

---

# 51. OpenAPI Alignment

The implementation should maintain an OpenAPI specification covering:

- endpoints;
- parameters;
- request schemas;
- response schemas;
- authentication;
- error codes;
- examples;
- rate limits;
- webhook schemas.

The OpenAPI definition must not become a separate source of truth that diverges from validation code.

The preferred source-of-truth relationship is:

```text
API Contract
    ↓
Routes + Validation + Controllers
    ↓
Services + Policies
    ↓
Repositories + Provider Adapters
```

---

# 52. Testing Requirements

Every endpoint requires tests for:

### Happy path
- valid authentication;
- valid request;
- expected response;
- database state.

### Validation
- missing fields;
- invalid types;
- invalid formats;
- oversized values;
- unsupported enum values.

### Authorization
- unauthenticated;
- wrong project;
- revoked key;
- insufficient scope;
- suspended user;
- inactive provider.

### Security
- SQL injection payloads;
- XSS payloads;
- CSRF;
- replayed tokens;
- expired tokens;
- brute-force OTP attempts;
- rate-limit exhaustion;
- malformed JSON;
- oversized payloads.

### Provider
- successful send;
- provider authentication failure;
- timeout;
- temporary failure;
- invalid recipient;
- provider rate limit.

### Idempotency
- repeated same request/key;
- same key with changed payload;
- concurrent requests.

---

# 53. Example Error Scenarios

## Invalid API key

```http
401 Unauthorized
```

```json
{
  "success": false,
  "error": {
    "code": "INVALID_API_KEY",
    "message": "The API key is invalid."
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

## Project access denied

```http
403 Forbidden
```

```json
{
  "success": false,
  "error": {
    "code": "PROJECT_ACCESS_DENIED",
    "message": "You do not have access to this project."
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

## Rate limited

```http
429 Too Many Requests
```

```json
{
  "success": false,
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "Too many requests. Please try again later."
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

## Provider unavailable

```http
502 Bad Gateway
```

```json
{
  "success": false,
  "error": {
    "code": "PROVIDER_UNAVAILABLE",
    "message": "The configured email provider is temporarily unavailable."
  },
  "meta": {
    "request_id": "req_..."
  }
}
```

---

# 54. API Security Checklist

Before production:

- [ ] HTTPS enforced.
- [ ] API keys are high entropy.
- [ ] API keys are hashed/stored securely.
- [ ] API keys are never logged.
- [ ] Passwords are hashed.
- [ ] OAuth tokens are encrypted.
- [ ] SMTP passwords are encrypted.
- [ ] CSRF is enabled for cookie-authenticated mutations.
- [ ] CORS uses an allowlist.
- [ ] Project authorization is centralized.
- [ ] Rate limits are enabled.
- [ ] OTP limits are enabled.
- [ ] Login protection is enabled.
- [ ] Input validation is enabled.
- [ ] Output handling is safe.
- [ ] SQL uses prepared statements.
- [ ] Security headers are enabled.
- [ ] Request IDs are generated.
- [ ] Sensitive logs are redacted.
- [ ] Provider errors are normalized.
- [ ] Idempotency is implemented for supported send operations.
- [ ] Webhook signatures are enabled.
- [ ] Webhook retries are bounded.
- [ ] Payload limits are enforced.
- [ ] Admin endpoints are isolated.
- [ ] Audit logging is active.
- [ ] Error responses do not expose internals.

---

# 55. Performance Requirements

The API should:

- use PDO prepared statements;
- avoid N+1 database queries;
- paginate large collections;
- index common filter/sort columns;
- avoid loading entire log tables into memory;
- use bounded provider timeouts;
- avoid blocking unnecessary external calls;
- use caching only where correctness permits;
- support future queue/background processing;
- release resources promptly.

Email sending must not cause uncontrolled application worker exhaustion.

---

# 56. API Operational Rules

1. Controllers remain thin.
2. Business logic belongs in services.
3. Data access belongs in repositories.
4. Provider communication belongs in adapters.
5. Validation is centralized/reusable.
6. Authorization uses policies/services.
7. Secrets are handled by dedicated security/configuration services.
8. Errors are normalized at API boundaries.
9. Database transactions are used where atomicity is required.
10. External API calls occur outside long database transactions whenever possible.
11. Every important operation is observable.
12. All security-sensitive actions are auditable.
13. No endpoint directly exposes database rows without serialization.
14. Internal IDs and public IDs may be separated where required.
15. API contracts are documented before implementation changes.

---

# 57. Final API Architecture

```text
Client
  │
  ├── Static HTML / JavaScript
  ├── Web App
  └── Mobile / Server Client
          │
          ▼
      HTTPS / JSON
          │
          ▼
     API Router / v1
          │
          ▼
       Middleware
          │
   ┌──────┼─────────┐
   │      │         │
 Auth   CORS     Rate Limit
   │      │         │
   └──────┼─────────┘
          ▼
      Controllers
          │
          ▼
       Services
          │
   ┌──────┼─────────────┐
   │      │             │
Database Templates   Provider Engine
   │      │             │
   │      │       ┌─────┼─────┐
   │      │       │     │     │
   │      │     Gmail  SMTP  Optional
   │      │                    Providers
   │      │
   └──────┴──────────────┐
                         ▼
                  Logs / Usage /
                  Webhooks / Audit
```

---

# 58. Relationship to Other Documents

| Document | API relationship |
|---|---|
| 00 Master Blueprint | Locked API scope and principles |
| 01 Project Overview | Product/API user journeys |
| 02 Final Scope | API feature boundaries |
| 03 System Architecture | API-to-service architecture |
| 04 Technology Stack | PHP/REST/PDO implementation baseline |
| 05 UI/UX | Dashboard API consumption |
| 06 Screens | Screen-to-endpoint requirements |
| 07 Assets | API documentation/UI assets |
| 08 DB Architecture | Persistence architecture |
| 09 DB Schema | Tables backing API resources |
| 10 Backend PHP | Controllers/services/repositories/providers |
| 12 Authentication & OTP | Auth and OTP implementation details |
| 13 Email Engine | Send pipeline and provider execution |
| 14 Email Providers | Provider-specific adapters |
| 15 Template Engine | Template API behavior |
| 16 Projects/API Keys/Webhooks | Project and integration details |
| 17 User Panel | Dashboard-facing API usage |
| 18 Admin Panel | Administrative API requirements |
| 19 Security | Security controls |
| 20 Frontend Guide | Fetch/API integration |
| 21 Responsive/Accessibility/Performance | Client-side API UX |
| 22 Testing/QA | API test strategy |
| 23 Deployment | API deployment and operations |
| 24 Development Rules | Implementation governance |

---

# 59. Definition of Done

The REST API is complete only when:

- [ ] `/api/v1` is implemented.
- [ ] Authentication works.
- [ ] Project isolation is enforced.
- [ ] API keys work.
- [ ] Provider management works.
- [ ] Gmail OAuth works.
- [ ] SMTP configuration/test works.
- [ ] Templates work.
- [ ] Email sending works.
- [ ] OTP sending/verification works.
- [ ] Logs are available.
- [ ] Usage statistics work.
- [ ] Webhooks work.
- [ ] Health endpoint works.
- [ ] Rate limiting works.
- [ ] Validation is comprehensive.
- [ ] Error codes are standardized.
- [ ] CORS is configured.
- [ ] CSRF protects session-based mutations.
- [ ] Sensitive secrets are protected.
- [ ] Audit/security logging works.
- [ ] Automated endpoint tests pass.
- [ ] API documentation matches implementation.
- [ ] Production security review passes.

---

# 60. Non-Negotiable API Rules

1. Never transmit API keys in URLs.
2. Never return passwords.
3. Never return OAuth tokens.
4. Never return SMTP passwords.
5. Never return plaintext OTPs after generation.
6. Never trust a project ID without authorization.
7. Never trust client-supplied sender identity without policy validation.
8. Never execute template content as code.
9. Never expose SQL errors.
10. Never expose stack traces in production.
11. Never disable HTTPS in production.
12. Never use wildcard CORS for privileged browser workflows.
13. Never bypass rate limits for public endpoints without an explicit security decision.
14. Never log secrets.
15. Never allow unrestricted attachment sizes.
16. Never accept unsanitized provider error text as public API output.
17. Never silently introduce breaking API behavior.
18. Never allow admin operations through ordinary project API keys.
19. Never make provider-specific behavior leak into the core API contract unnecessarily.
20. Never bypass centralized authentication and authorization.
21. Always generate/request-track a request ID.
22. Always validate inputs.
23. Always use prepared statements.
24. Always enforce project isolation.
25. Always normalize provider errors.
26. Always test unauthorized access paths.
27. Always support safe retries for transient failures.
28. Always use idempotency where duplicate email sends are possible.
29. Always audit sensitive administrative/security changes.
30. Always keep this API specification synchronized with implementation.

---

# 61. Final Lock

This document defines the **locked REST API contract** for the Email API Platform.

The implementation must remain compatible with:

- the 93-screen product scope;
- the 24 core modules;
- the 29 user features;
- the 14 API feature areas;
- the 25 security feature areas;
- the modular-monolith PHP architecture;
- MySQL persistence;
- Gmail OAuth;
- SMTP;
- optional provider adapters;
- template rendering;
- API keys;
- OTP;
- webhooks;
- logs;
- usage analytics;
- the security architecture.

Future enhancements must be additive whenever possible. Breaking changes require explicit architectural review and a new API version.

**Status: FINAL / LOCKED.**

**Next document:** `12-AUTHENTICATION-AND-OTP.md`
